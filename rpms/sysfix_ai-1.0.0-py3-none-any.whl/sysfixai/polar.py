"""
Polar one-time purchase integration for Sysfix Pro ($15).

Architecture (local-first, no cloud dependencies):

  • Checkout:   polar.checkouts.create() → redirect user to Polar-hosted page
  • Activation: Two complementary paths:
      1. **Webhook** — ``order.paid`` event hits ``/api/webhook/polar``
         (requires the machine to be reachable, e.g. via ngrok/tunnel).
      2. **API poll** — ``verify_order_by_id()`` queries Polar directly
         (works on any machine, no inbound connectivity needed).
  • Licence:    Hardware-locked key written to ``~/.config/sysfix/licence.json``;
                ``premium`` / ``paid_tier`` flags set in Sysfix config so
                sentinel_bridge._is_paid_tier() returns True immediately.
  • Security:   Webhook payloads verified via **Standard Webhooks** (svix)
                HMAC-SHA256 signatures.  SDK authenticated with POLAR_ACCESS_TOKEN.
  • Idempotency: Duplicate ``order.paid`` events for the same order are ignored.
  • Audit:      All webhook events logged to ``~/.config/sysfix/polar_audit.log``.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import platform
import secrets
import subprocess
import time
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from threading import Thread
from typing import Any, Dict, Optional

log = logging.getLogger("sysfix.polar")

# ---------------------------------------------------------------------------
# Environment / configuration
# ---------------------------------------------------------------------------


def _load_dotenv() -> None:
    """Load variables from ``.env`` file next to the package root.

    Only sets values that are not already present in ``os.environ``
    so explicit exports always win.
    """
    # Walk up from this file to find project root .env
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if not env_path.is_file():
        return
    try:
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key, value = key.strip(), value.strip()
            if key and key not in os.environ:
                os.environ[key] = value
    except Exception as exc:
        log.debug(".env load failed: %s", exc)


_load_dotenv()

_POLAR_ACCESS_TOKEN: str = os.environ.get("POLAR_ACCESS_TOKEN", "")
_POLAR_PRODUCT_ID: str = os.environ.get("POLAR_PRODUCT_ID", "")
_POLAR_WEBHOOK_SECRET: str = os.environ.get("POLAR_WEBHOOK_SECRET", "")
_WEBHOOK_PORT: int = int(os.environ.get("POLAR_WEBHOOK_PORT", "9452"))

# Static Polar Checkout Link — no API call needed to start a purchase.
# This is a pre-configured link from the Polar dashboard.
_POLAR_CHECKOUT_URL: str = (
    os.environ.get("POLAR_CHECKOUT_URL")
    or "https://buy.polar.sh/polar_cl_tTB6FDmTJCTv08FdiaawTOA7WN0rxz6Q8RHWA40vu4G"
)


def get_checkout_url() -> str:
    """Return the Polar checkout URL for Sysfix Pro.

    Uses the static Checkout Link from the Polar dashboard.  No API
    credentials or SDK are needed — just open this URL in a browser
    or webview.
    """
    return _POLAR_CHECKOUT_URL

# Where we persist licence artefacts
try:
    from sysfixai.config import CONFIG_DIR, load_config, save_config
except ImportError:
    CONFIG_DIR = Path.home() / ".config" / "sysfix"

    def load_config() -> dict:  # type: ignore[misc]
        p = CONFIG_DIR / "settings.json"
        if p.exists():
            return json.loads(p.read_text())
        return {}

    def save_config(cfg: dict) -> None:  # type: ignore[misc]
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        (CONFIG_DIR / "settings.json").write_text(json.dumps(cfg, indent=2))

_LICENCE_FILE: Path = CONFIG_DIR / "licence.json"
_AUDIT_LOG: Path = CONFIG_DIR / "polar_audit.log"

# Webhook replay-attack tolerance (Standard Webhooks spec: 5 minutes)
_WEBHOOK_TOLERANCE_SECS: int = 300


# ---------------------------------------------------------------------------
# Audit logging
# ---------------------------------------------------------------------------


def _audit(action: str, **fields) -> None:
    """Append a timestamped entry to the Polar audit log.

    All webhook events, activations, and deactivations are recorded
    to ``~/.config/sysfix/polar_audit.log`` for troubleshooting.
    """
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        entry = {"ts": ts, "action": action, **fields}
        with open(_AUDIT_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as exc:
        log.debug("Audit log write failed: %s", exc)


# ---------------------------------------------------------------------------
# SDK client (lazy-initialised)
# ---------------------------------------------------------------------------

_polar_client: Any = None


def _get_polar_client():
    """Lazily initialise and return the Polar SDK client.

    Requires ``polar-sdk`` to be installed and
    ``POLAR_ACCESS_TOKEN`` to be set.
    """
    global _polar_client
    if _polar_client is not None:
        return _polar_client

    token = _POLAR_ACCESS_TOKEN
    if not token:
        raise RuntimeError(
            "POLAR_ACCESS_TOKEN is not set. "
            "Export it as an environment variable before starting Sysfix."
        )

    try:
        from polar_sdk import Polar
    except ImportError:
        raise ImportError(
            "The 'polar-sdk' package is required for Polar integration. "
            "Install it with:  pip install polar-sdk"
        )

    _polar_client = Polar(access_token=token)
    log.info("Polar SDK client initialised.")
    return _polar_client


# ---------------------------------------------------------------------------
# 1. Checkout session creation
# ---------------------------------------------------------------------------


def create_checkout_session(
    *,
    success_url: Optional[str] = None,
    customer_email: Optional[str] = None,
    metadata: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Create a Polar checkout session for the Sysfix Advanced product.

    Uses the official ``polar-sdk`` request format::

        polar.checkouts.create(request={
            "products": [POLAR_PRODUCT_ID],
            "success_url": "...",
        })

    Returns a dict with ``"url"`` (redirect the user here), ``"id"``,
    ``"product_id"``, and ``"hw_fingerprint"`` keys.

    Raises
    ------
    RuntimeError
        If the product ID or access token is not configured.
    Exception
        Propagated from the Polar SDK on network/API errors.
    """
    product_id = _POLAR_PRODUCT_ID
    if not product_id:
        raise RuntimeError(
            "POLAR_PRODUCT_ID is not set. "
            "Export it as an environment variable."
        )

    client = _get_polar_client()

    # Attach a hardware fingerprint so the licence is machine-locked
    hw_fp = _hardware_fingerprint()
    merged_metadata = dict(metadata or {})
    merged_metadata["hw_fingerprint"] = hw_fp

    # Build the request payload (matches polar-sdk API)
    request_payload: Dict[str, Any] = {
        "products": [product_id],
    }
    if success_url or os.environ.get("POLAR_SUCCESS_URL"):
        request_payload["success_url"] = (
            success_url or os.environ["POLAR_SUCCESS_URL"]
        )
    if customer_email:
        request_payload["customer_email"] = customer_email
    if merged_metadata:
        request_payload["metadata"] = merged_metadata

    checkout = client.checkouts.create(request=request_payload)

    result = {
        "id": getattr(checkout, "id", str(checkout)),
        "url": getattr(checkout, "url", str(checkout)),
        "product_id": product_id,
        "hw_fingerprint": hw_fp,
    }
    log.info("Checkout session created: %s", result["id"])
    return result


# ---------------------------------------------------------------------------
# 1b. API-based order verification (local-first activation path)
# ---------------------------------------------------------------------------


def verify_order_by_id(checkout_id: str) -> Dict[str, Any]:
    """Verify a completed purchase by querying the Polar API directly.

    This is the **preferred activation path for local-first apps** —
    no inbound connectivity or webhook tunnel required.  After the user
    completes checkout, pass the ``checkout_id`` (from the success-URL
    query string) to this function.

    Flow::

        1. User clicks "Buy Pro" → create_checkout_session()
        2. User pays on Polar → redirected to success_url?checkout_id=...
        3. App calls verify_order_by_id(checkout_id)
        4. If status == "succeeded" → activate_premium()

    Parameters
    ----------
    checkout_id : str
        The checkout session ID returned by ``create_checkout_session()``.

    Returns
    -------
    dict
        ``{"activated": True, "licence": {...}}`` on success, or
        ``{"activated": False, "reason": "..."}`` on failure.

    Raises
    ------
    RuntimeError
        If ``POLAR_ACCESS_TOKEN`` is not configured.
    """
    client = _get_polar_client()

    try:
        checkout = client.checkouts.get(id=checkout_id)
    except Exception as exc:
        log.error("Failed to retrieve checkout %s: %s", checkout_id, exc)
        return {"activated": False, "reason": f"API error: {exc}"}

    status = getattr(checkout, "status", "unknown")
    # status may be a CheckoutStatus enum or a plain string
    status_str = str(status).rsplit(".", 1)[-1].lower()
    if status_str not in ("succeeded", "confirmed"):
        log.info("Checkout %s status is '%s' — not activated.", checkout_id, status)
        return {"activated": False, "reason": f"checkout status: {status}"}

    # Extract order details
    order_id = (
        getattr(checkout, "order_id", None)
        or getattr(checkout, "id", checkout_id)
    )
    customer = getattr(checkout, "customer", None)
    email = ""
    if customer:
        email = getattr(customer, "email", "") or ""
    metadata = getattr(checkout, "metadata", {}) or {}
    hw_fp = metadata.get("hw_fingerprint")

    licence = activate_premium(
        order_id=str(order_id),
        customer_email=email,
        hw_fingerprint=hw_fp,
    )
    _audit("VERIFIED_VIA_API", checkout_id=checkout_id, order_id=str(order_id))
    return {"activated": True, "licence": licence}


def verify_order_by_key(licence_key: str) -> bool:
    """Verify a manually-entered licence key against the local store.

    Users who purchased on a different machine can enter their key
    in the Settings tab.  This validates the key format and activates
    the Pro tier locally (trusting the key holder).

    Returns ``True`` if activated.
    """
    # Basic format validation: 5 groups of 5 chars separated by hyphens
    import re
    if not re.match(r"^[A-Z2-9]{5}(-[A-Z2-9]{5}){4}$", licence_key.upper()):
        log.warning("Invalid licence key format: %s", licence_key[:8] + "...")
        return False

    licence_record: Dict[str, Any] = {
        "licence_key": licence_key.upper(),
        "order_id": "manual-entry",
        "customer_email": "",
        "hw_fingerprint": _hardware_fingerprint(),
        "activated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "machine_node": platform.node(),
        "tier": "pro",
    }

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _LICENCE_FILE.write_text(json.dumps(licence_record, indent=2))

    cfg = load_config()
    cfg["premium"] = True
    cfg["paid_tier"] = True
    cfg["licence_key"] = licence_key.upper()
    cfg["polar_order_id"] = "manual-entry"
    save_config(cfg)
    log.info("Pro activated via manual key entry: %s", licence_key[:8] + "...")
    _audit("ACTIVATED_MANUAL_KEY", key_prefix=licence_key[:8])
    return True


# ---------------------------------------------------------------------------
# 2. Webhook signature verification
# ---------------------------------------------------------------------------


def verify_webhook_signature(
    payload: bytes,
    headers: Dict[str, str],
    secret: Optional[str] = None,
) -> bool:
    """Verify the Standard Webhooks (svix) signature used by Polar.

    Polar signs webhooks per the `Standard Webhooks`_ spec:

    1. Signed content = ``{webhook-id}.{webhook-timestamp}.{body}``
    2. Secret is **base64-decoded** before use as HMAC key.
    3. ``webhook-signature`` header contains one or more versioned
       signatures: ``v1,<base64_hmac>``.

    Also enforces a **5-minute timestamp tolerance** to prevent replay
    attacks (per spec).

    .. _Standard Webhooks: https://www.standardwebhooks.com

    Parameters
    ----------
    payload : bytes
        Raw request body.
    headers : dict
        Request headers (case-insensitive lookup handled by caller).
        Must contain ``webhook-id``, ``webhook-timestamp``, and
        ``webhook-signature``.
    secret : str, optional
        Webhook secret (the ``whsec_...`` value from Polar dashboard).
        Falls back to ``POLAR_WEBHOOK_SECRET`` env var.

    Returns
    -------
    bool
        ``True`` if a valid ``v1`` signature matches.
    """
    import base64

    wh_secret = secret or _POLAR_WEBHOOK_SECRET
    if not wh_secret:
        log.warning("No webhook secret configured — rejecting payload.")
        return False

    msg_id = headers.get("webhook-id", "")
    msg_timestamp = headers.get("webhook-timestamp", "")
    msg_signature = headers.get("webhook-signature", "")

    if not msg_id or not msg_timestamp or not msg_signature:
        log.warning("Missing Standard Webhooks headers.")
        return False

    # ── Timestamp tolerance (reject replays > 5 min) ──
    try:
        ts = int(msg_timestamp)
        if abs(time.time() - ts) > _WEBHOOK_TOLERANCE_SECS:
            log.warning("Webhook timestamp outside tolerance window.")
            return False
    except (ValueError, TypeError):
        log.warning("Invalid webhook-timestamp header.")
        return False

    # ── Decode secret ──
    # Polar secrets may be prefixed with "whsec_"
    raw_secret = wh_secret.removeprefix("whsec_")
    try:
        secret_bytes = base64.b64decode(raw_secret)
    except Exception:
        # Fallback: treat it as raw UTF-8 (dev/testing mode)
        secret_bytes = raw_secret.encode()

    # ── Compute expected signature ──
    signed_content = f"{msg_id}.{msg_timestamp}.".encode() + payload
    expected = base64.b64encode(
        hmac.new(secret_bytes, signed_content, hashlib.sha256).digest()
    ).decode()

    # ── Compare against each version in the header ──
    for sig_part in msg_signature.split(" "):
        sig_part = sig_part.strip()
        if not sig_part.startswith("v1,"):
            continue
        sig_value = sig_part[3:]  # strip "v1," prefix
        if hmac.compare_digest(expected, sig_value):
            return True

    log.warning("Webhook signature mismatch.")
    return False


# ---------------------------------------------------------------------------
# 3. Activation — licence key generation & premium flag
# ---------------------------------------------------------------------------


def _hardware_fingerprint() -> str:
    """Generate a deterministic, privacy-respecting hardware fingerprint.

    Combines machine-id (or fallback UUID), hostname, and platform to
    produce a SHA-256 digest that uniquely identifies this machine
    without exposing raw identifiers.
    """
    parts: list[str] = []

    # /etc/machine-id (systemd — present on all mainstream Linux distros)
    machine_id_path = Path("/etc/machine-id")
    if machine_id_path.exists():
        parts.append(machine_id_path.read_text().strip())
    else:
        # Fallback: DMI product UUID (requires root) or hostname
        try:
            dmi = subprocess.check_output(
                ["cat", "/sys/class/dmi/id/product_uuid"],
                stderr=subprocess.DEVNULL,
            ).decode().strip()
            parts.append(dmi)
        except Exception:
            parts.append(platform.node())

    parts.append(platform.machine())   # e.g. x86_64
    parts.append(platform.system())    # e.g. Linux

    raw = "|".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()


def _generate_licence_key() -> str:
    """Generate a human-readable licence key (5 groups of 5 uppercase chars).

    Example: ``AXKD7-R3WPL-9MNBT-QF2YH-V6J8C``
    """
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no I/O/0/1
    groups: list[str] = []
    for _ in range(5):
        group = "".join(secrets.choice(alphabet) for _ in range(5))
        groups.append(group)
    return "-".join(groups)


def activate_premium(
    order_id: str,
    customer_email: str = "",
    hw_fingerprint: Optional[str] = None,
) -> Dict[str, Any]:
    """Activate Sysfix Pro for this machine.

    1. **Idempotency check** — if this ``order_id`` already activated a
       licence, returns the existing record instead of generating a new key.
    2. Generates a hardware-locked licence key.
    3. Writes the licence artefact to ``~/.config/sysfix/licence.json``.
    4. Sets ``premium = True`` and ``paid_tier = True`` in the Sysfix
       config so ``_is_paid_tier()`` in sentinel_bridge returns ``True``.

    Returns the licence record.
    """
    # ── Idempotency: don't re-activate for the same order ──
    existing = get_licence_info()
    if existing and existing.get("order_id") == order_id:
        log.info("Order %s already activated — skipping duplicate.", order_id)
        return existing

    hw_fp = hw_fingerprint or _hardware_fingerprint()
    licence_key = _generate_licence_key()

    licence_record: Dict[str, Any] = {
        "licence_key": licence_key,
        "order_id": order_id,
        "customer_email": customer_email,
        "hw_fingerprint": hw_fp,
        "activated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "machine_node": platform.node(),
        "tier": "pro",
    }

    # ── Persist licence file ──
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _LICENCE_FILE.write_text(json.dumps(licence_record, indent=2))
    log.info("Licence written to %s", _LICENCE_FILE)

    # ── Update Sysfix config — unlock premium/paid tier ──
    cfg = load_config()
    cfg["premium"] = True
    cfg["paid_tier"] = True
    cfg["licence_key"] = licence_key
    cfg["polar_order_id"] = order_id
    save_config(cfg)
    log.info("Sysfix Pro activated — order %s, key %s", order_id, licence_key)

    # ── Audit ──
    _audit("ACTIVATED", order_id=order_id, email=customer_email, key=licence_key)

    return licence_record


def is_licence_valid() -> bool:
    """Check whether a valid, hardware-matched licence exists."""
    if not _LICENCE_FILE.exists():
        return False
    try:
        rec = json.loads(_LICENCE_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    # Verify the fingerprint matches this machine
    return rec.get("hw_fingerprint") == _hardware_fingerprint()


def get_licence_info() -> Optional[Dict[str, Any]]:
    """Return the licence record or ``None``."""
    if not _LICENCE_FILE.exists():
        return None
    try:
        return json.loads(_LICENCE_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def deactivate_premium() -> bool:
    """Revoke the local licence (useful for machine transfer)."""
    try:
        order_id = ""
        if _LICENCE_FILE.exists():
            try:
                order_id = json.loads(_LICENCE_FILE.read_text()).get("order_id", "")
            except Exception:
                pass
            _LICENCE_FILE.unlink()
        cfg = load_config()
        cfg["premium"] = False
        cfg["paid_tier"] = False
        cfg.pop("licence_key", None)
        cfg.pop("polar_order_id", None)
        save_config(cfg)
        log.info("Premium deactivated.")
        _audit("DEACTIVATED", order_id=order_id)
        return True
    except Exception as exc:
        log.error("Failed to deactivate premium: %s", exc)
        return False


# ---------------------------------------------------------------------------
# 4. Webhook handler — lightweight HTTP server
# ---------------------------------------------------------------------------


class _PolarWebhookHandler(BaseHTTPRequestHandler):
    """Handle incoming Polar webhook POST requests.

    Verifies Standard Webhooks (svix) signatures before dispatching.
    """

    # Suppress default stderr logging
    def log_message(self, fmt, *args):  # noqa: D401
        log.debug(fmt, *args)

    def _send_json(self, code: int, body: dict) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(body).encode())

    def do_POST(self):
        """Process POST /api/webhook/polar."""
        if self.path.rstrip("/") != "/api/webhook/polar":
            self._send_json(404, {"error": "not found"})
            return

        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0 or content_length > 1_000_000:
            self._send_json(400, {"error": "invalid content length"})
            return

        payload = self.rfile.read(content_length)

        # ── Standard Webhooks signature verification ──
        wh_headers = {
            "webhook-id": self.headers.get("webhook-id", ""),
            "webhook-timestamp": self.headers.get("webhook-timestamp", ""),
            "webhook-signature": self.headers.get("webhook-signature", ""),
        }
        if not verify_webhook_signature(payload, wh_headers):
            log.warning("Webhook signature verification failed.")
            _audit("WEBHOOK_REJECTED", reason="signature_invalid")
            self._send_json(403, {"error": "invalid signature"})
            return

        # ── Parse event ──
        try:
            event = json.loads(payload)
        except json.JSONDecodeError:
            self._send_json(400, {"error": "invalid json"})
            return

        event_type = event.get("type", "")
        log.info("Received Polar webhook: %s", event_type)
        _audit("WEBHOOK_RECEIVED", event_type=event_type,
               webhook_id=wh_headers["webhook-id"])

        # ── Dispatch ──
        try:
            _dispatch_webhook_event(event_type, event)
        except Exception as exc:
            log.error("Webhook dispatch error: %s", exc)
            _audit("WEBHOOK_ERROR", event_type=event_type, error=str(exc))
            self._send_json(500, {"error": str(exc)})
            return

        self._send_json(200, {"status": "ok"})

    def do_GET(self):
        """Health-check endpoint."""
        status = {
            "status": "healthy",
            "service": "sysfix-polar-webhook",
            "licence_valid": is_licence_valid(),
        }
        self._send_json(200, status)


def _dispatch_webhook_event(event_type: str, event: Dict[str, Any]) -> None:
    """Route webhook events to the appropriate handler."""
    data = event.get("data", {})

    if event_type == "order.paid":
        order_id = data.get("id", data.get("order_id", str(uuid.uuid4())))
        customer = data.get("customer", {})
        email = customer.get("email", data.get("customer_email", ""))
        hw_fp = (data.get("metadata") or {}).get("hw_fingerprint")

        log.info("order.paid received — order %s, email %s", order_id, email)
        activate_premium(
            order_id=order_id,
            customer_email=email,
            hw_fingerprint=hw_fp,
        )

    elif event_type == "subscription.canceled":
        # One-time purchase model — subscriptions aren't expected,
        # but handle gracefully if Polar sends one.
        log.info("subscription.canceled received — ignoring (one-time model).")

    elif event_type == "order.refunded":
        log.info("order.refunded received — deactivating premium.")
        deactivate_premium()

    else:
        log.debug("Unhandled webhook event type: %s", event_type)


# ---------------------------------------------------------------------------
# Server lifecycle
# ---------------------------------------------------------------------------

_webhook_server: Optional[HTTPServer] = None
_webhook_thread: Optional[Thread] = None


def start_webhook_server(port: Optional[int] = None, daemon: bool = True) -> int:
    """Start the Polar webhook listener in a background thread.

    Returns the port number the server is listening on.
    """
    global _webhook_server, _webhook_thread
    if _webhook_server is not None:
        log.info("Webhook server already running.")
        return _webhook_server.server_address[1]

    listen_port = port or _WEBHOOK_PORT
    _webhook_server = HTTPServer(("127.0.0.1", listen_port), _PolarWebhookHandler)
    _webhook_thread = Thread(
        target=_webhook_server.serve_forever,
        name="polar-webhook",
        daemon=daemon,
    )
    _webhook_thread.start()
    log.info("Polar webhook server listening on 127.0.0.1:%d", listen_port)
    return listen_port


def stop_webhook_server() -> None:
    """Gracefully shut down the webhook server."""
    global _webhook_server, _webhook_thread
    if _webhook_server is not None:
        _webhook_server.shutdown()
        _webhook_server = None
    if _webhook_thread is not None:
        _webhook_thread.join(timeout=5)
        _webhook_thread = None
    log.info("Polar webhook server stopped.")


# ---------------------------------------------------------------------------
# 5. Usage billing — event metering
# ---------------------------------------------------------------------------


def ingest_usage_event(
    event_name: str,
    *,
    external_customer_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """Ingest a single usage event into Polar's metering system.

    Mirrors the polar-sdk ``polar.events.ingest()`` API.  Each event
    is associated with a named meter (e.g. ``"ai_query"``,
    ``"sentinel_scan"``) and tied to a customer via
    *external_customer_id*.

    Parameters
    ----------
    event_name : str
        Arbitrary meter name (must match a Meter configured in Polar).
    external_customer_id : str, optional
        Customer identifier.  Falls back to this machine's hardware
        fingerprint if not provided.
    metadata : dict, optional
        Arbitrary key/value pairs attached to the event
        (e.g. ``{"route": "/ai/chat", "model": "local"}``).

    Returns
    -------
    bool
        ``True`` if the event was ingested successfully.
    """
    try:
        client = _get_polar_client()
    except (RuntimeError, ImportError) as exc:
        log.debug("Polar SDK not available — skipping usage event: %s", exc)
        return False

    cust_id = external_customer_id or _hardware_fingerprint()
    event_payload: Dict[str, Any] = {
        "name": event_name,
        "external_customer_id": cust_id,
    }
    if metadata:
        event_payload["metadata"] = metadata

    try:
        client.events.ingest(events=[event_payload])
        log.debug("Usage event ingested: %s (customer=%s)", event_name, cust_id)
        return True
    except Exception as exc:
        log.warning("Failed to ingest usage event '%s': %s", event_name, exc)
        return False


def ingest_usage_events(
    events: list[Dict[str, Any]],
) -> bool:
    """Ingest multiple usage events in a single batch.

    Each item in *events* should have at least::

        {
            "name": "meter_name",
            "external_customer_id": "customer-id",
            "metadata": { ... },           # optional
        }

    Returns ``True`` if the batch was ingested successfully.
    """
    if not events:
        return True

    try:
        client = _get_polar_client()
    except (RuntimeError, ImportError) as exc:
        log.debug("Polar SDK not available — skipping batch ingest: %s", exc)
        return False

    # Ensure every event has an external_customer_id
    hw_fp = _hardware_fingerprint()
    normalised: list[Dict[str, Any]] = []
    for evt in events:
        entry: Dict[str, Any] = {
            "name": evt["name"],
            "external_customer_id": evt.get("external_customer_id", hw_fp),
        }
        if evt.get("metadata"):
            entry["metadata"] = evt["metadata"]
        normalised.append(entry)

    try:
        client.events.ingest(events=normalised)
        log.debug("Batch usage ingest: %d events", len(normalised))
        return True
    except Exception as exc:
        log.warning("Failed batch usage ingest (%d events): %s", len(normalised), exc)
        return False


# ---------------------------------------------------------------------------
# Convenience: status summary
# ---------------------------------------------------------------------------


def polar_status() -> Dict[str, Any]:
    """Return a quick status dict for the Polar integration."""
    licence = get_licence_info()
    return {
        "sdk_configured": bool(_POLAR_ACCESS_TOKEN),
        "product_configured": bool(_POLAR_PRODUCT_ID),
        "webhook_secret_set": bool(_POLAR_WEBHOOK_SECRET),
        "webhook_running": _webhook_server is not None,
        "licence_valid": is_licence_valid(),
        "licence_key": (licence or {}).get("licence_key"),
        "tier": (licence or {}).get("tier", "free"),
        "hw_fingerprint": _hardware_fingerprint(),
    }
