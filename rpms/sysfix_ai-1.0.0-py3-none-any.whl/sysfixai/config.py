"""
Configuration management for Sysfix GUI.

Handles saving and loading settings to/from config file.
"""

import json
import os
import pwd
from pathlib import Path


def _real_user_home() -> Path:
    """Return the real (non-root) user's home, even under sudo."""
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user:
        try:
            return Path(pwd.getpwnam(sudo_user).pw_dir)
        except KeyError:
            pass
    return Path.home()


CONFIG_DIR = _real_user_home() / ".config" / "sysfix"
CONFIG_FILE = CONFIG_DIR / "settings.json"

# Default configuration
DEFAULT_CONFIG = {
    "auto_scan_on_startup": True,
    "auto_apply_safe_fixes": False,
    "enable_ai_features": True,
    "enable_notifications": True,
    "enable_web_search": True,
    "auto_check_updates_on_startup": True,
    "memory_optimization": True,
    "disk_cleanup": True,
    "auto_deep_dive": False,
    "autostart_on_boot": False,
    "theme": "frutiger_aero",
    "ai_model": "",  # empty = auto-detect best model
    "ai_provider": "auto",  # auto | ollama | openai | anthropic | openrouter | openai_compatible | free_web
    "ollama_endpoint": "http://localhost:11434",  # Ollama API base URL
    "ai_fallback_free": True,  # if selected provider is unavailable, use free web fallback
    # Cloud/provider credentials (optional)
    "openai_api_key": "",
    "openai_model": "gpt-4o-mini",
    "openai_base_url": "https://api.openai.com/v1",
    "anthropic_api_key": "",
    "anthropic_model": "claude-3-5-sonnet-latest",
    "openrouter_api_key": "",
    "openrouter_model": "meta-llama/llama-3.3-70b-instruct:free",
    # Generic OpenAI-compatible API (LM Studio, local gateways, vLLM, etc.)
    "ai_compatible_base_url": "",
    "ai_compatible_api_key": "",
    "ai_compatible_model": "",
    "virustotal_api_key": "",  # free VT API key (optional)
    "github_token": "",  # GitHub PAT for private repo updates (optional)
    # Brain / learning system
    "enable_brain": True,                 # master toggle
    "brain_observe_system": True,         # learn installed tools, hardware
    "brain_observe_files": False,         # scan dotfiles, projects (needs permission)
    "brain_learn_conversations": True,    # extract insights from chats
    "brain_auto_observe_on_startup": True, # scan system when GUI opens
    # Semantic memory / embeddings
    "auto_rebuild_embeddings_on_startup": True,  # rebuild semantic index from brain on startup (enabled)
    # UI polish options
    "rounded_ui": True,              # use pill buttons and softer card styling
    "soft_colors": True,             # apply softer/desaturated color palettes
    # ELI5 vs Technical toggle
    "eli5_mode": False,              # True = plain-language explanations, False = technical details
    # Advanced diagnostics
    "enable_predictive_maintenance": True,  # S.M.A.R.T. trend analysis
    "enable_zombie_hunter": True,           # detect zombie/D-state processes
    "auto_snapshot_before_fix": True,       # create snapshot before AI fixes
    # Agent Mode (auto-execution) settings
    "agent_mode_enabled": False,
    "agent_mode_allowlist": [],  # list of allowed base commands (e.g., ["dnf","apt","systemctl"]) 
    "agent_mode_require_phrase": "ENABLE_AGENT",  # phrase required to enable agent mode
    "agent_mode_dry_run": True,  # when True, simulate commands instead of executing
    "agent_mode_auto_apply_templates": True,  # auto-apply deterministic templates when enabled
}


def ensure_config_dir():
    """Ensure config directory exists with correct ownership."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _fix_ownership(CONFIG_DIR)


def _fix_ownership(path: Path):
    """If running under sudo, chown the path back to the real user."""
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user:
        try:
            pw = pwd.getpwnam(sudo_user)
            os.chown(path, pw.pw_uid, pw.pw_gid)
        except (KeyError, PermissionError):
            pass


def load_config():
    """Load configuration from file or return defaults."""
    ensure_config_dir()
    
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                # Merge with defaults (in case new settings were added)
                return {**DEFAULT_CONFIG, **config}
        except Exception:
            return DEFAULT_CONFIG.copy()
    
    return DEFAULT_CONFIG.copy()


def save_config(config):
    """Save configuration to file."""
    ensure_config_dir()
    
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        _fix_ownership(CONFIG_FILE)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False


def get_setting(key, default=None):
    """Get a specific setting."""
    config = load_config()
    return config.get(key, default)


def set_setting(key, value):
    """Set a specific setting and save."""
    config = load_config()
    config[key] = value
    save_config(config)


def reset_config():
    """Reset configuration to defaults."""
    save_config(DEFAULT_CONFIG.copy())
