# ---------------------------------------------------------------------------
# Command info, usage, and alternatives
# ---------------------------------------------------------------------------

_COMMAND_INFO = {
    "ls": ("List directory contents", "ls [options] [path]", ["dir", "vdir"]),
    "cp": ("Copy files and directories", "cp [options] source dest", ["rsync", "install"]),
    "mv": ("Move/rename files and directories", "mv [options] source dest", ["rename"]),
    "rm": ("Remove files or directories", "rm [options] file", ["unlink"]),
    "find": ("Search for files in a directory hierarchy", "find [path] [options]", ["locate", "fd"]),
    "grep": ("Search for patterns in files", "grep [options] pattern [file]", ["ack", "ag", "ripgrep"]),
    "awk": ("Pattern scanning and processing language", "awk 'pattern { action }' [file]", ["sed", "perl"]),
    "sed": ("Stream editor for filtering and transforming text", "sed [options] script [file]", ["awk", "perl"]),
    "ps": ("Report process status", "ps [options]", ["top", "htop", "pgrep"]),
    "top": ("Display Linux processes", "top", ["htop", "glances"]),
    "htop": ("Interactive process viewer", "htop", ["top", "glances"]),
    "df": ("Report file system disk space usage", "df [options]", ["du"]),
    "du": ("Estimate file space usage", "du [options] [file]", ["ncdu"]),
    "free": ("Display memory usage", "free [options]", ["vmstat"]),
    "uname": ("Print system information", "uname [options]", ["hostnamectl"]),
    "chmod": ("Change file modes or Access Control Lists", "chmod [options] mode file", []),
    "chown": ("Change file owner and group", "chown [options] owner[:group] file", []),
    "tar": ("Archive utility", "tar [options] [file]", ["cpio", "pax"]),
    "curl": ("Transfer data from or to a server", "curl [options] [URL]", ["wget"]),
    "wget": ("Non-interactive network downloader", "wget [options] [URL]", ["curl"]),
    "ping": ("Send ICMP ECHO_REQUEST to network hosts", "ping [options] host", ["fping"]),
    "traceroute": ("Print the route packets take to network host", "traceroute [options] host", ["tracepath"]),
    "ifconfig": ("Configure network interfaces", "ifconfig [interface] [options]", ["ip"]),
    "ip": ("Show/manipulate routing, devices, policy routing, and tunnels", "ip [options] object", ["ifconfig"]),
    "systemctl": ("Control the systemd system and service manager", "systemctl [options] command", []),
    "journalctl": ("Query and display messages from the journal", "journalctl [options]", []),
    "dmesg": ("Print or control the kernel ring buffer", "dmesg [options]", []),
    "lsblk": ("List block devices", "lsblk [options]", ["blkid"]),
    "blkid": ("Locate/print block device attributes", "blkid [options]", ["lsblk"]),
    "mount": ("Mount a filesystem", "mount [options] device dir", []),
    "umount": ("Unmount file systems", "umount [options] dir|device", []),
    "fdisk": ("Partition table manipulator for Linux", "fdisk [options] device", ["parted", "cfdisk"]),
    "parted": ("Partition manipulation program", "parted [options] device", ["fdisk", "gparted"]),
    "mkfs": ("Build a Linux file system", "mkfs [options] device", []),
    "dd": ("Convert and copy a file", "dd [options]", []),
    "rsync": ("Fast, versatile file-copying tool", "rsync [options] source dest", ["scp"]),
    "scp": ("Secure copy (remote file copy program)", "scp [options] source dest", ["rsync"]),
    "ssh": ("OpenSSH remote login client", "ssh [options] user@host", []),
    "nano": ("Simple text editor", "nano [file]", ["vim", "emacs"]),
    "vim": ("Vi IMproved, a programmer's text editor", "vim [file]", ["nano", "emacs"]),
    "less": ("View file contents one screen at a time", "less [file]", ["more"]),
    "more": ("View file contents one screen at a time", "more [file]", ["less"]),
    "man": ("Display manual pages", "man [command]", ["info"]),
    "apt": ("Debian package manager", "apt [options] command", ["apt-get", "dnf", "yum", "pacman"]),
    "dnf": ("Fedora package manager", "dnf [options] command", ["yum", "apt", "pacman"]),
    "yum": ("RPM package manager", "yum [options] command", ["dnf", "apt", "pacman"]),
    "pacman": ("Arch Linux package manager", "pacman [options] command", ["apt", "dnf", "yum"]),
    "zypper": ("openSUSE package manager", "zypper [options] command", ["apt", "dnf", "yum", "pacman"]),
    "snap": ("Snap package manager", "snap [options] command", ["flatpak"]),
    "flatpak": ("Flatpak package manager", "flatpak [options] command", ["snap"]),
    "docker": ("Container platform", "docker [options] command", ["podman"]),
    "podman": ("Daemonless container engine", "podman [options] command", ["docker"]),
    "python3": ("Python 3 interpreter", "python3 [script]", ["perl", "ruby"]),
    "pip3": ("Python 3 package installer", "pip3 [options] package", []),
    "perl": ("Perl interpreter", "perl [script]", ["python3", "ruby"]),
    "ruby": ("Ruby interpreter", "ruby [script]", ["python3", "perl"]),
    "node": ("Node.js JavaScript runtime", "node [script]", ["python3", "perl", "ruby"]),
    "npm": ("Node.js package manager", "npm [options] command", []),
    "go": ("Go programming language toolchain", "go [command]", []),
    "gcc": ("GNU C compiler", "gcc [options] file.c", []),
    "g++": ("GNU C++ compiler", "g++ [options] file.cpp", []),
    "make": ("Utility to maintain groups of programs", "make [options]", []),
    "cmake": ("Cross-platform build system", "cmake [options]", []),
    "git": ("Distributed version control system", "git [command]", ["svn", "hg"]),
    "svn": ("Subversion version control system", "svn [command]", ["git", "hg"]),
    "hg": ("Mercurial version control system", "hg [command]", ["git", "svn"]),
    "nvidia-smi": ("NVIDIA System Management Interface", "nvidia-smi [options]", []),
    "rocm-smi": ("AMD ROCm System Management Interface", "rocm-smi [options]", []),
    "vainfo": ("VA-API video acceleration info", "vainfo", []),
}

def get_command_info(cmd: str) -> dict:
    """Return info, usage, and alternatives for a command, if known."""
    info = _COMMAND_INFO.get(cmd)
    if not info:
        return {}
    return {"description": info[0], "usage": info[1], "alternatives": info[2]}
"""
Fyxa's Brain — persistent learning & memory system.

Stores observations, facts, and conversation insights in a local JSON database.
Learns from:
  - System observation (installed packages, shell, DE, configs, projects)
  - Conversation history (AI extracts key facts after each exchange)
  - Past fix results (what worked, what failed)

Memory is injected into the AI system prompt so Fyxa gets smarter over time.
All data stays local: ~/.config/sysfix/brain.json
"""

import json
import os
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sysfixai.config import CONFIG_DIR, load_config, save_config

# Optional semantic-memory (embeddings + local vector store)
try:
    from sysfixai.embeddings import query as _semantic_query, add_text as _emb_add_text, rebuild_from_brain as _rebuild_vector_store, HAS_EMBEDDINGS
except Exception:
    # graceful fallbacks when embeddings backend is not available
    HAS_EMBEDDINGS = False
    def _semantic_query(q: str, top_k: int = 6):
        return []
    def _emb_add_text(_id: str, _text: str, _metadata: dict = None):
        return
    def _rebuild_vector_store(_brain: dict):
        return

# ---------------------------------------------------------------------------
# Storage paths
# ---------------------------------------------------------------------------

BRAIN_FILE = CONFIG_DIR / "brain.json"

# Maximum entries per category (prevents unbounded growth)
_MAX_FACTS = 200
_MAX_SOLUTIONS = 100
_MAX_OBSERVATIONS = 150
_MAX_INSIGHTS = 150

# ---------------------------------------------------------------------------
# Brain structure
# ---------------------------------------------------------------------------

_EMPTY_BRAIN: Dict[str, Any] = {
    "version": 1,
    "created": "",
    "last_updated": "",
    "system_profile": {},       # key → {value, learned_at, source}
    "user_preferences": {},     # key → {value, learned_at, source}
    "solution_history": [],     # [{issue, fix, worked, timestamp}]
    "observations": [],         # [{fact, category, timestamp, source}]
    "conversation_insights": [],  # [{insight, extracted_from, timestamp}]
    "stats": {
        "conversations_learned_from": 0,
        "system_scans": 0,
        "total_facts": 0,
    },
    "persistent_cache": {},
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------------------
# Core brain I/O
# ---------------------------------------------------------------------------

def _load_brain() -> Dict[str, Any]:
    """Load brain from disk, or create empty brain."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if BRAIN_FILE.exists():
        try:
            with open(BRAIN_FILE, "r") as f:
                brain = json.load(f)
            # Merge with defaults for forward compatibility
            for key, default in _EMPTY_BRAIN.items():
                if key not in brain:
                    brain[key] = default if not isinstance(default, dict) else default.copy()
            return brain
        except Exception:
            return _new_brain()
    return _new_brain()


def _new_brain() -> Dict[str, Any]:
    brain = json.loads(json.dumps(_EMPTY_BRAIN))  # deep copy
    brain["created"] = _now_iso()
    brain["last_updated"] = _now_iso()
    return brain


def _save_brain(brain: Dict[str, Any]):
    """Persist brain to disk."""
    brain["last_updated"] = _now_iso()
    brain["stats"]["total_facts"] = (
        len(brain.get("system_profile", {}))
        + len(brain.get("user_preferences", {}))
        + len(brain.get("solution_history", []))
        + len(brain.get("observations", []))
        + len(brain.get("conversation_insights", []))
    )
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        with open(BRAIN_FILE, "w") as f:
            json.dump(brain, f, indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Remember / Recall API
# ---------------------------------------------------------------------------

def remember(category: str, key: str, value: Any, source: str = "manual"):
    """Store a fact in the brain.

    category: 'system_profile' or 'user_preferences'
    """
    brain = _load_brain()
    store = brain.setdefault(category, {})
    store[key] = {
        "value": value,
        "learned_at": _now_iso(),
        "source": source,
    }
    # Enforce size limit
    if len(store) > _MAX_FACTS:
        oldest = sorted(store, key=lambda k: store[k].get("learned_at", ""))
        for k in oldest[: len(store) - _MAX_FACTS]:
            del store[k]
    _save_brain(brain)


def recall(category: str, key: str) -> Optional[Any]:
    """Retrieve a specific fact."""
    brain = _load_brain()
    entry = brain.get(category, {}).get(key)
    return entry["value"] if entry else None


def add_observation(fact: str, category: str = "general", source: str = "system"):
    """Add a general observation."""
    brain = _load_brain()
    obs = brain.setdefault("observations", [])
    # Deduplicate
    existing = {o["fact"] for o in obs}
    if fact in existing:
        return
    entry = {
        "fact": fact,
        "category": category,
        "timestamp": _now_iso(),
        "source": source,
    }
    obs.append(entry)
    if len(obs) > _MAX_OBSERVATIONS:
        brain["observations"] = obs[-_MAX_OBSERVATIONS:]
    _save_brain(brain)

    # Index into semantic store if available
    try:
        idx = len(brain.get("observations", [])) - 1
        _emb_add_text(f"obs:{idx}", fact, metadata={"category": category, "source": source})
    except Exception:
        pass


def add_solution(issue: str, fix: str, worked: bool):
    """Record whether a fix worked or not."""
    brain = _load_brain()
    sols = brain.setdefault("solution_history", [])
    entry = {
        "issue": issue[:200],
        "fix": fix[:300],
        "worked": worked,
        "timestamp": _now_iso(),
    }
    sols.append(entry)
    if len(sols) > _MAX_SOLUTIONS:
        brain["solution_history"] = sols[-_MAX_SOLUTIONS:]
    _save_brain(brain)

    # Index solution summary for semantic recall
    try:
        idx = len(brain.get("solution_history", [])) - 1
        txt = f"{entry['issue']}: {entry['fix']}"
        _emb_add_text(f"sol:{idx}", txt, metadata={"worked": worked})
    except Exception:
        pass


def add_insight(insight: str, source: str = "conversation"):
    """Store an insight extracted from a conversation."""
    brain = _load_brain()
    insights = brain.setdefault("conversation_insights", [])
    # Deduplicate (fuzzy — check first 60 chars)
    prefix = insight[:60].lower()
    for existing in insights:
        if existing["insight"][:60].lower() == prefix:
            return
    entry = {
        "insight": insight[:500],
        "extracted_from": source,
        "timestamp": _now_iso(),
    }
    insights.append(entry)
    if len(insights) > _MAX_INSIGHTS:
        brain["conversation_insights"] = insights[-_MAX_INSIGHTS:]
    _save_brain(brain)

    # Index insight into semantic store if available
    try:
        idx = len(brain.get("conversation_insights", [])) - 1
        _emb_add_text(f"insight:{idx}", entry["insight"], metadata={"source": source})
    except Exception:
        pass


# ---------------------------------------------------------------------------
# System observation — learn about the environment
# ---------------------------------------------------------------------------

def _run_quiet(cmd: List[str], timeout: int = 10) -> str:
    """Run a command and return stdout, or empty string."""
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, stdin=subprocess.DEVNULL,
        )
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def observe_system(deep: bool = False) -> List[str]:
    """Scan the system and learn facts.  Returns list of new things learned.

    Args:
        deep: If True, also scan dotfiles, projects, and installed packages.
              Requires 'brain_observe_files' permission.
    """
    learned: List[str] = []

    # Detect installed/usable Linux commands
    from shutil import which
    COMMON_COMMANDS = [
        "ls", "cat", "cp", "mv", "rm", "touch", "mkdir", "rmdir", "find", "grep", "awk", "sed", "ps", "top", "htop", "df", "du", "free", "uname", "whoami", "id", "chmod", "chown", "ln", "tar", "gzip", "bzip2", "xz", "curl", "wget", "ping", "traceroute", "ifconfig", "ip", "ss", "netstat", "systemctl", "journalctl", "dmesg", "lsblk", "blkid", "mount", "umount", "fdisk", "parted", "mkfs", "dd", "rsync", "scp", "ssh", "nano", "vim", "less", "more", "man", "apt", "dnf", "yum", "pacman", "zypper", "snap", "flatpak", "docker", "podman", "python3", "pip3", "perl", "ruby", "node", "npm", "go", "gcc", "g++", "make", "cmake", "git", "svn", "hg", "nvidia-smi", "rocm-smi", "vainfo"
    ]
    installed_cmds = {cmd: which(cmd) is not None for cmd in COMMON_COMMANDS}
    remember("system_profile", "installed_commands", installed_cmds, "system_scan")
    learned.append(f"Detected {sum(installed_cmds.values())} common commands installed")

    # ── Basic system facts (always safe) ────────────────────────────
    import platform
    remember("system_profile", "hostname", platform.node(), "system_scan")
    remember("system_profile", "os", platform.platform(), "system_scan")
    remember("system_profile", "kernel", platform.release(), "system_scan")
    remember("system_profile", "arch", platform.machine(), "system_scan")
    learned.append("OS & kernel")

    # Desktop environment
    de = os.environ.get("XDG_CURRENT_DESKTOP", "") or os.environ.get("DESKTOP_SESSION", "")
    if de:
        remember("system_profile", "desktop_environment", de, "system_scan")
        learned.append(f"DE: {de}")

    # Default shell
    shell = os.environ.get("SHELL", "")
    if shell:
        remember("system_profile", "shell", shell, "system_scan")
        learned.append(f"Shell: {shell}")

    # Username & home
    home = str(Path.home())
    remember("system_profile", "home_dir", home, "system_scan")
    remember("system_profile", "username", os.environ.get("USER", "unknown"), "system_scan")

    # CPU info
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu = line.split(":", 1)[1].strip()
                    remember("system_profile", "cpu_model", cpu, "system_scan")
                    learned.append(f"CPU: {cpu}")
                    break
    except Exception:
        pass

    # RAM
    try:
        import shutil as _sh
        mem_raw = _run_quiet(["free", "-h", "--si"])
        if mem_raw:
            for line in mem_raw.splitlines():
                if line.startswith("Mem:"):
                    parts = line.split()
                    if len(parts) >= 2:
                        remember("system_profile", "ram_total", parts[1], "system_scan")
                        learned.append(f"RAM: {parts[1]}")
    except Exception:
        pass


    # GPU autodetection: NVIDIA, AMD, Intel
    nv = _run_quiet(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"])
    if nv:
        parts = [p.strip() for p in nv.split(",")]
        if len(parts) >= 2:
            remember("system_profile", "gpu", parts[0], "system_scan")
            remember("system_profile", "vram_mb", parts[1], "system_scan")
            learned.append(f"GPU: {parts[0]}")
    else:
        # Try AMD detection via lspci and rocm-smi
        lspci = _run_quiet(["lspci"])
        amd_gpu = None
        intel_gpu = None
        if lspci:
            for line in lspci.splitlines():
                if "VGA compatible controller" in line or "3D controller" in line:
                    if "AMD" in line or "ATI" in line:
                        amd_gpu = line.strip()
                    elif "Intel" in line:
                        intel_gpu = line.strip()
        if amd_gpu:
            remember("system_profile", "gpu", amd_gpu, "system_scan")
            learned.append(f"GPU: {amd_gpu}")
            # Try to get VRAM with rocm-smi if available
            rocm = _run_quiet(["rocm-smi", "--showproductname", "--showvbios", "--showmeminfo", "vram"])
            if rocm:
                for rline in rocm.splitlines():
                    if "VRAM Total" in rline:
                        vram = rline.split(":")[-1].strip()
                        remember("system_profile", "vram_mb", vram, "system_scan")
                        break
        elif intel_gpu:
            remember("system_profile", "gpu", intel_gpu, "system_scan")
            learned.append(f"GPU: {intel_gpu}")
            # Try to get VRAM with vainfo if available
            vainfo = _run_quiet(["vainfo"])
            if vainfo:
                for vline in vainfo.splitlines():
                    if "total video memory" in vline.lower():
                        vram = vline.split(":")[-1].strip()
                        remember("system_profile", "vram_mb", vram, "system_scan")
                        break

    # Package manager
    import shutil
    for pm in ("dnf", "apt", "pacman", "zypper", "xbps-install"):
        if shutil.which(pm):
            remember("system_profile", "package_manager", pm, "system_scan")
            learned.append(f"Package manager: {pm}")
            break

    # Installed package count
    pm = recall("system_profile", "package_manager")
    if pm == "dnf":
        count = _run_quiet(["rpm", "-qa", "--qf", "x\n"])
        if count:
            remember("system_profile", "installed_packages", len(count.splitlines()), "system_scan")
    elif pm == "apt":
        count = _run_quiet(["dpkg", "--list"])
        if count:
            remember("system_profile", "installed_packages",
                     len([l for l in count.splitlines() if l.startswith("ii")]), "system_scan")
    elif pm == "pacman":
        count = _run_quiet(["pacman", "-Q"])
        if count:
            remember("system_profile", "installed_packages", len(count.splitlines()), "system_scan")

    # ── Deep scan (requires brain_observe_files) ─────────────────────
    if deep:
        learned.extend(_observe_dotfiles())
        learned.extend(_observe_projects())
        learned.extend(_observe_dev_tools())
        learned.extend(_observe_common_software())

    # Detect if we're running with root privileges and perform additional
    # privileged scans (kept small, truncated, and fault-tolerant).
    is_root = False
    try:
        is_root = hasattr(os, "geteuid") and os.geteuid() == 0
    except Exception:
        is_root = False

    if is_root:
        learned.append("Running as root: performing privileged scans")

        # Running services (systemd) — collect service names only
        units = _run_quiet(["systemctl", "list-units", "--type=service", "--state=running", "--no-pager", "--no-legend"], timeout=6)
        if units:
            svc_names = [line.split()[0] for line in units.splitlines() if line.strip()][:50]
            if svc_names:
                remember("system_profile", "running_services", svc_names, "root_scan")
                learned.append(f"Running services: {len(svc_names)}")

        # PCI devices (lspci) — short summary
        lspci = _run_quiet(["lspci", "-mm"], timeout=6)
        if lspci:
            remember("system_profile", "lspci_summary", lspci[:1000], "root_scan")
            learned.append("PCI devices discovered")

        # Block devices (lsblk)
        lsblk = _run_quiet(["lsblk", "-o", "NAME,SIZE,TYPE,MOUNTPOINT"], timeout=5)
        if lsblk:
            remember("system_profile", "block_devices", lsblk[:1000], "root_scan")
            learned.append("Block device layout recorded")

        # DMI / product name
        dm = _run_quiet(["dmidecode", "-s", "system-product-name"], timeout=4)
        if dm:
            remember("system_profile", "product_name", dm.strip()[:200], "root_scan")
            learned.append("Product name learned")

        # Recent journal (limited tail) — store as an observation (truncated)
        journal = _run_quiet(["journalctl", "-n", "200", "--no-pager"], timeout=6)
        if journal:
            excerpt = "\n".join(journal.splitlines()[-40:])[:1200]
            add_observation(excerpt, "logs", "root_scan")
            learned.append("Recent journal entries captured")

    # Update scan counter
    brain = _load_brain()
    brain["stats"]["system_scans"] = brain["stats"].get("system_scans", 0) + 1
    _save_brain(brain)

    return learned


def _observe_dotfiles() -> List[str]:
    """Learn from user's config files (shell rc, git config, etc.)."""
    learned = []
    home = Path.home()

    # Shell config
    for rc in (".bashrc", ".zshrc", ".config/fish/config.fish"):
        rc_path = home / rc
        if rc_path.exists():
            try:
                content = rc_path.read_text(errors="ignore")[:4000]
                # Learn aliases
                aliases = re.findall(r'alias\s+(\w+)=["\'](.+?)["\']', content)
                if aliases:
                    alias_dict = {a: v for a, v in aliases[:30]}
                    remember("user_preferences", f"aliases_{rc}", alias_dict, "dotfile_scan")
                    learned.append(f"Learned {len(aliases)} alias(es) from {rc}")
                # Learn exports / env vars
                exports = re.findall(r'export\s+(\w+)=(.+)', content)
                interesting_exports = {
                    k: v.strip('"').strip("'")[:100]
                    for k, v in exports
                    if k in ("EDITOR", "VISUAL", "BROWSER", "GOPATH",
                             "JAVA_HOME", "NVM_DIR", "PYENV_ROOT",
                             "CARGO_HOME", "RUSTUP_HOME", "PATH")
                }
                if interesting_exports:
                    remember("user_preferences", f"env_vars_{rc}", interesting_exports, "dotfile_scan")
                    learned.append(f"Learned env vars from {rc}")
            except Exception:
                pass

    # Git config
    gitconfig = home / ".gitconfig"
    if gitconfig.exists():
        try:
            content = gitconfig.read_text(errors="ignore")[:2000]
            name_match = re.search(r'name\s*=\s*(.+)', content)
            email_match = re.search(r'email\s*=\s*(.+)', content)
            if name_match:
                remember("user_preferences", "git_name", name_match.group(1).strip(), "dotfile_scan")
            if email_match:
                remember("user_preferences", "git_email", email_match.group(1).strip(), "dotfile_scan")
            learned.append("Learned git identity")
        except Exception:
            pass

    # SSH config (just learn which hosts are configured, not keys)
    ssh_config = home / ".ssh" / "config"
    if ssh_config.exists():
        try:
            content = ssh_config.read_text(errors="ignore")[:2000]
            hosts = re.findall(r'Host\s+(\S+)', content)
            hosts = [h for h in hosts if h != "*"]
            if hosts:
                remember("user_preferences", "ssh_hosts", hosts[:20], "dotfile_scan")
                learned.append(f"Learned {len(hosts)} SSH host(s)")
        except Exception:
            pass

    return learned


def _observe_projects() -> List[str]:
    """Discover project directories in common locations."""
    learned = []
    home = Path.home()
    projects: List[Dict[str, str]] = []

    search_dirs = [
        home,
        home / "Projects",
        home / "projects",
        home / "Code",
        home / "code",
        home / "dev",
        home / "Development",
        home / "src",
        home / "repos",
        home / "workspace",
        home / "Documents",
    ]

    seen = set()
    for search_dir in search_dirs:
        if not search_dir.is_dir():
            continue
        try:
            for child in sorted(search_dir.iterdir()):
                if not child.is_dir() or child.name.startswith("."):
                    continue
                if child in seen:
                    continue
                seen.add(child)
                # Check for project markers
                lang = _detect_project_lang(child)
                if lang:
                    projects.append({
                        "path": str(child),
                        "name": child.name,
                        "language": lang,
                    })
                    if len(projects) >= 30:
                        break
        except PermissionError:
            continue

    if projects:
        remember("system_profile", "projects", projects, "project_scan")
        langs = set(p["language"] for p in projects)
        learned.append(f"Found {len(projects)} project(s): {', '.join(sorted(langs))}")
        add_observation(
            f"User has {len(projects)} project(s) using: {', '.join(sorted(langs))}",
            category="development", source="project_scan",
        )

    return learned


def _detect_project_lang(path: Path) -> str:
    """Detect primary language of a project directory."""
    markers = {
        "Cargo.toml": "Rust",
        "go.mod": "Go",
        "package.json": "JavaScript/TypeScript",
        "tsconfig.json": "TypeScript",
        "pyproject.toml": "Python",
        "setup.py": "Python",
        "requirements.txt": "Python",
        "Pipfile": "Python",
        "Gemfile": "Ruby",
        "pom.xml": "Java",
        "build.gradle": "Java/Kotlin",
        "CMakeLists.txt": "C/C++",
        "Makefile": "C/C++",
        "*.sln": "C#/.NET",
        "mix.exs": "Elixir",
        "Dockerfile": "Docker",
        "docker-compose.yml": "Docker",
        "flake.nix": "Nix",
    }
    try:
        children = {c.name for c in path.iterdir()}
    except Exception:
        return ""
    for marker, lang in markers.items():
        if marker.startswith("*"):
            if any(c.endswith(marker[1:]) for c in children):
                return lang
        elif marker in children:
            return lang
    # Check for .git (at least it's a repo)
    if ".git" in children:
        return "unknown"
    return ""


def _observe_dev_tools() -> List[str]:
    """Detect installed development tools."""
    learned = []
    import shutil
    tools = {
        "git": "Git", "python3": "Python 3", "python": "Python",
        "node": "Node.js", "npm": "npm", "yarn": "Yarn", "pnpm": "pnpm",
        "rustc": "Rust", "cargo": "Cargo",
        "go": "Go", "gcc": "GCC", "g++": "G++", "clang": "Clang",
        "java": "Java", "javac": "Java SDK",
        "docker": "Docker", "podman": "Podman",
        "code": "VS Code", "nvim": "Neovim", "vim": "Vim", "emacs": "Emacs",
        "flatpak": "Flatpak", "snap": "Snap",
        "ollama": "Ollama", "nvidia-smi": "NVIDIA Driver",
        "ffmpeg": "FFmpeg", "obs": "OBS Studio",
        "steam": "Steam",
        "make": "Make", "cmake": "CMake", "meson": "Meson",
        "ruby": "Ruby", "php": "PHP", "perl": "Perl",
        "lua": "Lua", "julia": "Julia", "R": "R",
    }
    installed = {}
    for cmd, name in tools.items():
        if shutil.which(cmd):
            # Get version
            ver = ""
            if cmd in ("python3", "python", "node", "rustc", "go", "gcc", "java"):
                ver = _run_quiet([cmd, "--version"])
                if ver:
                    ver = ver.splitlines()[0][:80]
            installed[name] = ver or "installed"

    if installed:
        remember("system_profile", "dev_tools", installed, "tool_scan")
        learned.append(f"Found {len(installed)} dev tool(s)")
        add_observation(
            f"Installed dev tools: {', '.join(sorted(installed.keys()))}",
            category="development", source="tool_scan",
        )
    return learned


def _observe_common_software() -> List[str]:
    """Note commonly used desktop applications."""
    learned = []
    home = Path.home()

    # Check .local/share/applications and flatpak
    browsers = []
    for name in ("firefox", "google-chrome-stable", "chromium", "brave-browser", "vivaldi"):
        import shutil
        if shutil.which(name):
            browsers.append(name)
    if browsers:
        remember("user_preferences", "browsers", browsers, "app_scan")
        learned.append(f"Browsers: {', '.join(browsers)}")

    # Flatpak apps
    flatpak_list = _run_quiet(["flatpak", "list", "--app", "--columns=application"])
    if flatpak_list:
        apps = [l.strip() for l in flatpak_list.splitlines() if l.strip()]
        if apps:
            remember("system_profile", "flatpak_apps", apps[:50], "app_scan")
            learned.append(f"Found {len(apps)} Flatpak app(s)")

    return learned


# ---------------------------------------------------------------------------
# Conversation learning — extract insights via AI
# ---------------------------------------------------------------------------

def learn_from_conversation(
    messages: List[Dict[str, str]],
    ai_query_fn=None,
) -> List[str]:
    """Extract useful facts from recent conversation exchanges.

    Args:
        messages:     Last few chat messages [{"role": ..., "content": ...}]
        ai_query_fn:  Optional function(prompt) -> str for AI-powered extraction.
                      Falls back to rule-based extraction if not provided.

    Returns list of new insights learned.
    """
    learned = []

    # Rule-based extraction (always runs — fast and reliable)
    learned.extend(_extract_rules(messages))

    # AI-powered extraction (if available and we have enough conversation)
    if ai_query_fn and len(messages) >= 4:
        learned.extend(_extract_via_ai(messages, ai_query_fn))

    # Update counter
    if learned:
        brain = _load_brain()
        brain["stats"]["conversations_learned_from"] = (
            brain["stats"].get("conversations_learned_from", 0) + 1
        )
        _save_brain(brain)

    return learned


def _extract_rules(messages: List[Dict[str, str]]) -> List[str]:
    """Rule-based fact extraction from conversation."""
    learned = []
    for msg in messages:
        content = msg.get("content", "")
        role = msg.get("role", "")
        cl = content.lower()

        if role == "user":
            # Detect preferences
            if "i use " in cl or "i prefer " in cl or "i like " in cl:
                # Extract what they use/prefer
                for pattern in (r"i (?:use|prefer|like)\s+(\w[\w\s]{1,30})", ):
                    match = re.search(pattern, cl)
                    if match:
                        pref = match.group(1).strip()
                        if len(pref) > 2:
                            add_insight(f"User says they {match.group(0).strip()}", "conversation")
                            learned.append(f"Preference: {pref}")

            # Detect what they're working on
            if "working on " in cl or "building " in cl or "my project" in cl:
                for pattern in (r"(?:working on|building)\s+(.{3,60}?)(?:\.|,|$)", ):
                    match = re.search(pattern, cl)
                    if match:
                        project = match.group(1).strip()
                        add_insight(f"User is working on: {project}", "conversation")
                        learned.append(f"Project: {project}")

            # Detect their role / job
            if "i'm a " in cl or "i am a " in cl or "my job" in cl:
                for pattern in (r"i(?:'m| am) a[n]?\s+(\w[\w\s]{2,30})", ):
                    match = re.search(pattern, cl)
                    if match:
                        role_desc = match.group(1).strip()
                        remember("user_preferences", "role", role_desc, "conversation")
                        learned.append(f"Role: {role_desc}")

            # Detect distro/OS mentions
            for distro in ("fedora", "ubuntu", "arch", "debian", "mint", "manjaro",
                           "opensuse", "nixos", "gentoo", "void", "endeavouros"):
                if distro in cl:
                    remember("system_profile", "mentioned_distro", distro, "conversation")

        elif role == "assistant":
            # Learn from successful fixes
            if "fixed" in cl or "resolved" in cl or "that should fix" in cl:
                # Try to pair with the preceding user message
                idx = messages.index(msg)
                if idx > 0:
                    user_msg = messages[idx - 1].get("content", "")[:200]
                    add_solution(user_msg, content[:300], worked=True)
                    learned.append("Recorded successful fix")

    return learned


def _extract_via_ai(
    messages: List[Dict[str, str]],
    ai_query_fn,
) -> List[str]:
    """Use AI to extract deeper insights from conversation."""
    learned = []

    # Build a compact conversation summary for the AI
    recent = messages[-8:]  # last 4 exchanges
    convo_text = "\n".join(
        f"{'User' if m['role'] == 'user' else 'Fyxa'}: {m['content'][:200]}"
        for m in recent
    )

    prompt = (
        "Extract key facts about the USER from this conversation. "
        "Only output facts, one per line. Include things like:\n"
        "- What they're working on\n"
        "- Technical preferences or skill level\n"
        "- Problems they frequently have\n"
        "- Preferred tools or workflows\n"
        "- System setup details mentioned\n\n"
        "If no useful facts, output NONE.\n\n"
        f"Conversation:\n{convo_text}\n\nFacts:"
    )

    try:
        response = ai_query_fn(prompt)
        if response and "NONE" not in response.upper():
            for line in response.strip().splitlines():
                line = line.strip().lstrip("-•* ")
                if line and len(line) > 5:
                    add_insight(line, "ai_extraction")
                    learned.append(line)
    except Exception:
        pass

    return learned


# ---------------------------------------------------------------------------
# Context injection — retrieve relevant memories for AI prompts
# ---------------------------------------------------------------------------

def get_memory_context(query: str = "", max_tokens: int = 800) -> str:
    """Build a compact memory block for injection into the AI system prompt.

    Prioritizes:
    1. System profile (always included — compact)
    2. User preferences
    3. Recent insights relevant to the query
    4. Recent solutions

    Returns a formatted string ready for prompt injection.
    """
    brain = _load_brain()
    parts: List[str] = []
    budget = max_tokens

    # 1. System profile
    profile = brain.get("system_profile", {})
    if profile:
        lines = []
        priority_keys = [
            "hostname", "os", "cpu_model", "ram_total", "gpu",
            "desktop_environment", "shell", "package_manager",
            "installed_packages",
        ]
        for key in priority_keys:
            entry = profile.get(key)
            if entry:
                val = entry["value"] if isinstance(entry, dict) else entry
                lines.append(f"  {key}: {val}")
        # Dev tools
        tools_entry = profile.get("dev_tools")
        if tools_entry:
            tools = tools_entry["value"] if isinstance(tools_entry, dict) else tools_entry
            if isinstance(tools, dict):
                names = sorted(tools.keys())[:15]
                lines.append(f"  dev_tools: {', '.join(names)}")
        # Projects
        proj_entry = profile.get("projects")
        if proj_entry:
            projects = proj_entry["value"] if isinstance(proj_entry, dict) else proj_entry
            if isinstance(projects, list):
                summary = [f"{p['name']} ({p['language']})" for p in projects[:8]]
                lines.append(f"  projects: {', '.join(summary)}")

        if lines:
            block = "SYSTEM PROFILE (from brain):\n" + "\n".join(lines)
            if len(block) < budget:
                parts.append(block)
                budget -= len(block)

    # 2. User preferences
    prefs = brain.get("user_preferences", {})
    if prefs and budget > 100:
        lines = []
        for key, entry in list(prefs.items())[:10]:
            val = entry["value"] if isinstance(entry, dict) else entry
            if isinstance(val, (list, dict)):
                val = json.dumps(val)[:80]
            lines.append(f"  {key}: {val}")
        if lines:
            block = "USER PREFERENCES (from brain):\n" + "\n".join(lines)
            if len(block) < budget:
                parts.append(block)
                budget -= len(block)

    # 3. Semantic matches + relevant insights
    # Prefer semantic (embedding) matches when available; fall back to fuzzy matching.
    if query and HAS_EMBEDDINGS and budget > 100:
        try:
            sem = _semantic_query(query, top_k=8) or []
            # If store appears empty, attempt a rebuild from the brain and retry once
            if not sem:
                try:
                    _rebuild_vector_store(brain)
                    sem = _semantic_query(query, top_k=8) or []
                except Exception:
                    sem = sem or []

            if sem:
                sem_lines = []
                seen_texts = set()
                for r in sem:
                    txt = r.get("text", "")
                    if not txt or txt in seen_texts:
                        continue
                    seen_texts.add(txt)
                    score = r.get("score", 0.0)
                    sem_lines.append(f"  - {txt} (score={score:.2f})")
                if sem_lines:
                    block = "SEMANTIC MEMORIES (from brain embeddings):\n" + "\n".join(sem_lines[:8])
                    if len(block) < budget:
                        parts.append(block)
                        budget -= len(block)
        except Exception:
            pass

    # Keyword/fuzzy insights (always present)
    insights = brain.get("conversation_insights", [])
    if insights and budget > 100:
        # If we have a query, try to find relevant ones
        relevant = insights[-15:]  # most recent by default
        if query:
            import difflib
            q_low = query.lower()
            q_words = set(q_low.split())
            scored = []
            for ins in insights:
                text = ins["insight"].lower()
                # keyword overlap
                overlap = sum(1 for w in q_words if w in text)
                # fuzzy similarity (helps match paraphrases)
                sim = difflib.SequenceMatcher(None, q_low, text).ratio()
                # recency boost (newer insights get a small advantage)
                age_boost = 0
                try:
                    ts = ins.get("timestamp") or ""
                    if ts and ts.count("T"):
                        age_boost = 0.5
                except Exception:
                    age_boost = 0
                score = overlap * 2 + sim * 3 + age_boost
                if score > 0.15:
                    scored.append((score, ins))
            scored.sort(key=lambda x: x[0], reverse=True)
            if scored:
                relevant = [s[1] for s in scored[:12]]

        # Take the most relevant / recent insights but keep block compact
        lines = [f"  - {ins['insight']}" for ins in relevant[-8:]]
        if lines:
            block = "LEARNED INSIGHTS:\n" + "\n".join(lines)
            if len(block) < budget:
                parts.append(block)
                budget -= len(block)

    # 4. Recent solutions (last few)
    solutions = brain.get("solution_history", [])
    if solutions and budget > 100:
        recent_sols = solutions[-5:]
        lines = []
        for sol in recent_sols:
            status = "worked" if sol.get("worked") else "failed"
            lines.append(f"  - [{status}] {sol['issue'][:80]} → {sol['fix'][:80]}")
        if lines:
            block = "PAST FIXES:\n" + "\n".join(lines)
            if len(block) < budget:
                parts.append(block)

    return "\n\n".join(parts) if parts else ""


# ---------------------------------------------------------------------------
# Brain management API
# ---------------------------------------------------------------------------

def get_brain_stats() -> Dict[str, Any]:
    """Return brain statistics for display."""
    brain = _load_brain()
    return {
        "created": brain.get("created", "never"),
        "last_updated": brain.get("last_updated", "never"),
        "system_facts": len(brain.get("system_profile", {})),
        "user_preferences": len(brain.get("user_preferences", {})),
        "solutions": len(brain.get("solution_history", [])),
        "observations": len(brain.get("observations", [])),
        "insights": len(brain.get("conversation_insights", [])),
        "cache_entries": len(brain.get("persistent_cache", {})),
        "total_facts": brain.get("stats", {}).get("total_facts", 0),
        "system_scans": brain.get("stats", {}).get("system_scans", 0),
        "conversations_learned": brain.get("stats", {}).get("conversations_learned_from", 0),
    }


def get_brain_dump() -> List[str]:
    """Return all brain contents as human-readable lines."""
    brain = _load_brain()
    lines = []
    lines.append(f"Brain created: {brain.get('created', '?')}")
    lines.append(f"Last updated: {brain.get('last_updated', '?')}")
    lines.append("")

    section_count = 0

    # System profile
    profile = brain.get("system_profile", {})
    if profile:
        section_count += 1
        lines.append("═══ SYSTEM PROFILE ═══")
        for key, entry in sorted(profile.items()):
            val = entry["value"] if isinstance(entry, dict) else entry
            if isinstance(val, (dict, list)):
                val = json.dumps(val, indent=2)[:200]
            lines.append(f"  {key}: {val}")
        lines.append("")

    # User preferences
    prefs = brain.get("user_preferences", {})
    if prefs:
        section_count += 1
        lines.append("═══ USER PREFERENCES ═══")
        for key, entry in sorted(prefs.items()):
            val = entry["value"] if isinstance(entry, dict) else entry
            if isinstance(val, (dict, list)):
                val = json.dumps(val)[:200]
            lines.append(f"  {key}: {val}")
        lines.append("")

    # Observations
    obs = brain.get("observations", [])
    if obs:
        section_count += 1
        lines.append("═══ OBSERVATIONS ═══")
        for o in obs[-20:]:
            lines.append(f"  [{o.get('category', '?')}] {o['fact']}")
        if len(obs) > 20:
            lines.append(f"  ... and {len(obs) - 20} more")
        lines.append("")

    # Insights
    insights = brain.get("conversation_insights", [])
    if insights:
        section_count += 1
        lines.append("═══ CONVERSATION INSIGHTS ═══")
        for ins in insights[-20:]:
            lines.append(f"  - {ins['insight']}")
        if len(insights) > 20:
            lines.append(f"  ... and {len(insights) - 20} more")
        lines.append("")

    # Solutions
    sols = brain.get("solution_history", [])
    if sols:
        section_count += 1
        lines.append("═══ SOLUTION HISTORY ═══")
        for s in sols[-15:]:
            status = "✓" if s.get("worked") else "✗"
            lines.append(f"  {status} {s['issue'][:60]} → {s['fix'][:60]}")
        if len(sols) > 15:
            lines.append(f"  ... and {len(sols) - 15} more")
        lines.append("")

    # Persistent cache (used for saved conversations and other sticky state)
    cache = brain.get("persistent_cache", {})
    if cache:
        section_count += 1
        lines.append("═══ PERSISTENT CACHE ═══")
        lines.append(f"  Entries: {len(cache)}")
        keys = sorted(cache.keys())
        for key in keys[:15]:
            entry = cache.get(key, {})
            value = entry.get("value") if isinstance(entry, dict) else entry
            if isinstance(value, dict):
                if isinstance(value.get("threads"), dict):
                    preview = f"{len(value.get('threads', {}))} chat thread(s)"
                else:
                    preview = f"dict with {len(value)} key(s)"
            elif isinstance(value, list):
                preview = f"list with {len(value)} item(s)"
            else:
                preview = str(value)
            preview = preview.replace("\n", " ").strip()
            if len(preview) > 100:
                preview = preview[:97] + "..."
            lines.append(f"  {key}: {preview}")
        if len(keys) > 15:
            lines.append(f"  ... and {len(keys) - 15} more")
        lines.append("")

    # Semantic memory index (if available)
    semantic_preview = list_semantic_entries(limit=11)
    if semantic_preview:
        section_count += 1
        lines.append("═══ SEMANTIC MEMORY INDEX ═══")
        semantic_items = semantic_preview[:10]
        for item in semantic_items:
            item_id = str(item.get("id", "?"))
            txt = str(item.get("text", "")).strip().replace("\n", " ")
            if len(txt) > 100:
                txt = txt[:97] + "..."
            lines.append(f"  {item_id}: {txt or '[empty]'}")
        if len(semantic_preview) > len(semantic_items):
            lines.append("  ... and more")
        lines.append("")

    if section_count == 0:
        lines.append("Brain is empty — Fyxa hasn't learned anything yet.")
        lines.append("Run a system scan or chat with her to start building knowledge.")

    return lines


# ---- semantic index helpers (thin wrappers) -----------------------------

def list_semantic_entries(limit: int = 500) -> List[Dict[str, Any]]:
    """Return items present in the semantic/vector store (if available)."""
    try:
        from sysfixai import embeddings as emb
        items = emb.list_items()
        # return most-recent entries first (newest at the front) to match UI expectations
        try:
            items = list(reversed(items))
        except Exception:
            pass
        return items[:limit]
    except Exception:
        return []


def delete_semantic_entry(entry_id: str, remove_from_brain: bool = False) -> bool:
    """Delete a semantic index entry; optionally remove corresponding brain entry.

    Returns True if deletion succeeded in the semantic index.
    """
    try:
        from sysfixai import embeddings as emb
        items = emb.list_items()
        target = next((i for i in items if i.get("id") == entry_id), None)
        ok = emb.delete_item(entry_id)
        if ok and remove_from_brain and target:
            # best-effort: match by exact text in brain structures and remove
            brain = _load_brain()
            txt = target.get("text", "").strip()
            # conversation_insights
            ci = brain.get("conversation_insights", [])
            brain["conversation_insights"] = [x for x in ci if x.get("insight") != txt]
            # observations
            obs = brain.get("observations", [])
            brain["observations"] = [x for x in obs if x.get("fact") != txt]
            # solution_history (match either issue or fix)
            sols = brain.get("solution_history", [])
            brain["solution_history"] = [s for s in sols if not (txt.startswith(s.get("issue", "")) or txt in s.get("fix", ""))]
            _save_brain(brain)
        return ok
    except Exception:
        return False


def clear_semantic_index() -> bool:
    """Clear the entire semantic index and persisted backends."""
    try:
        from sysfixai import embeddings as emb
        emb.clear_index()
        return True
    except Exception:
        return False


def clear_brain():
    """Wipe the entire brain."""
    brain = _new_brain()
    _save_brain(brain)


def get_brain_size_kb() -> float:
    """Return brain file size in KB."""
    if BRAIN_FILE.exists():
        return BRAIN_FILE.stat().st_size / 1024
    return 0.0


def rebuild_semantic_index() -> bool:
    """Rebuild the on-disk semantic/vector index from the current brain.

    Returns True on success (or if no embedding backend configured), False on error.
    """
    try:
        brain = _load_brain()
        _rebuild_vector_store(brain)
        return True
    except Exception:
        return False


def export_semantic_entries(path: str, ids: Optional[List[str]] = None) -> bool:
    """Export semantic index items to a JSON file. If ids provided, export only those."""
    try:
        from sysfixai import embeddings as emb
        return emb.export_items(path, ids=ids)
    except Exception:
        return False


def import_semantic_entries(path: str, merge: bool = True) -> bool:
    """Import semantic items from a JSON export file. merge=False will clear existing index first."""
    try:
        from sysfixai import embeddings as emb
        return emb.import_items(path, merge=merge)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Persistent cache helpers
# ---------------------------------------------------------------------------

def set_cache(key: str, value: Any, metadata: Optional[Dict[str, Any]] = None) -> bool:
    """Store an arbitrary value in the brain's persistent cache."""
    try:
        brain = _load_brain()
        cache = brain.setdefault("persistent_cache", {})
        cache[key] = {
            "value": value,
            "metadata": metadata or {},
            "stored_at": _now_iso(),
        }
        _save_brain(brain)
        return True
    except Exception:
        return False


def get_cache(key: str) -> Optional[Dict[str, Any]]:
    try:
        brain = _load_brain()
        return brain.get("persistent_cache", {}).get(key)
    except Exception:
        return None


def list_cache() -> Dict[str, Any]:
    try:
        brain = _load_brain()
        return brain.get("persistent_cache", {})
    except Exception:
        return {}


def delete_cache(key: str) -> bool:
    try:
        brain = _load_brain()
        cache = brain.get("persistent_cache", {})
        if key in cache:
            del cache[key]
            brain["persistent_cache"] = cache
            _save_brain(brain)
            return True
        return False
    except Exception:
        return False


def save_cache_blob(name: str, data: bytes) -> Optional[str]:
    """Save binary blob to CONFIG_DIR/cache and return relative path recorded in cache entry."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        cache_dir = CONFIG_DIR / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", name)
        path = cache_dir / safe_name
        # avoid overwriting by adding a counter
        if path.exists():
            base = path.stem
            ext = path.suffix
            i = 1
            while (cache_dir / f"{base}_{i}{ext}").exists():
                i += 1
            path = cache_dir / f"{base}_{i}{ext}"
        with open(path, "wb") as f:
            f.write(data)
        return str(path)
    except Exception:
        return None


def get_cache_blob(path: str) -> Optional[bytes]:
    try:
        p = Path(path)
        if not p.exists():
            return None
        return p.read_bytes()
    except Exception:
        return None
