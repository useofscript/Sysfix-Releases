"""
Safety Intercept — global safety gate for AI-generated actions.

Enforces a mandatory confirmation step before any 'Act' phase that involves
sudo, hardware modifications, destructive operations, or sensitive file
changes. Every command proposed by the agentic loop passes through this
intercept before execution.

Features:
- Command classification: safe / needs-confirm / blocked
- Confidence scoring (0-100) based on command pattern analysis
- Structured intercept record for GUI modal display
- sudo / hardware / destructive pattern detection
- Configurable auto-approve threshold (default: never auto-approve)
- Audit log of all intercept decisions

Public API:
- intercept(commands, source="fyxa") → InterceptResult
- approve(intercept_id)              → marks an intercept as approved
- deny(intercept_id)                 → marks an intercept as denied
- get_pending()                      → list of pending intercepts
- get_audit_log(n=50)                → last N intercept records
- classify_command(cmd)              → (classification, confidence, notes)
"""

from __future__ import annotations

import os
import re
import time
import json
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class InterceptRecord:
    """A single safety intercept event."""
    intercept_id: str = ""
    timestamp: float = 0.0
    commands: List[str] = field(default_factory=list)
    source: str = "fyxa"       # fyxa / user / agent_loop
    classification: str = ""   # safe / needs_confirm / blocked
    confidence: int = 0        # 0-100 — how confident the AI was about this action
    risk_level: str = "low"    # low / medium / high / critical
    notes: List[str] = field(default_factory=list)
    status: str = "pending"    # pending / approved / denied / auto_approved
    decided_at: float = 0.0
    decided_by: str = ""       # user / auto / system


@dataclass
class InterceptResult:
    """Result of the intercept check — tells the caller what to do."""
    allowed: bool = False           # Can proceed immediately?
    intercept_id: str = ""          # ID if pending approval
    record: Optional[InterceptRecord] = None
    message: str = ""               # Human-readable explanation


# ---------------------------------------------------------------------------
# Pattern databases
# ---------------------------------------------------------------------------

# Commands that are always blocked (never run even with approval)
_NEVER_ALLOW = [
    r"rm\s+-rf\s+/\s*$",                 # rm -rf /
    r"rm\s+-rf\s+/\*",                    # rm -rf /*
    r"dd\s+if=/dev/zero\s+of=/dev/sd",    # dd zero to disk
    r"dd\s+if=/dev/zero\s+of=/dev/nvme",  # dd zero to nvme
    r"mkfs\.\w+\s+/dev/(sd|nvme)",        # format system disk
    r":\(\)\s*\{\s*:\|:\s*&\s*\}\s*;",   # fork bomb
    r">\s*/dev/sd[a-z]$",                 # redirect to raw device
    r"chmod\s+000\s+/",                   # remove all perms from /
    r"chown\s+.*\s+/$",                   # chown /
]

# Commands that require explicit confirmation (sudo, hardware, config)
_NEEDS_CONFIRM = [
    (r"\bsudo\b", "Uses elevated privileges (sudo)"),
    (r"\bsu\s+-?\s", "Switches to another user (su)"),
    (r"\bpkexec\b", "Uses polkit elevation"),
    (r"\bsystemctl\s+(start|stop|restart|enable|disable|mask)\b", "Modifies systemd services"),
    (r"\bdnf\s+(install|remove|erase|update|upgrade)\b", "Package manager operation"),
    (r"\bapt\s+(install|remove|purge|update|upgrade)\b", "Package manager operation"),
    (r"\bpacman\s+-[SRU]", "Package manager operation"),
    (r"\bsnap\s+(install|remove)\b", "Snap package operation"),
    (r"\bflatpak\s+(install|uninstall)\b", "Flatpak operation"),
    (r"/etc/", "Modifies system configuration (/etc/)"),
    (r"/boot/", "Touches boot partition (/boot/)"),
    (r"/usr/lib/", "Modifies system libraries"),
    (r"\biptables\b", "Modifies firewall rules"),
    (r"\bnft\b", "Modifies nftables rules"),
    (r"\bfirewall-cmd\b", "Modifies firewalld"),
    (r"\bufw\b", "Modifies UFW firewall"),
    (r"\bnvidia-smi\s+-", "NVIDIA GPU configuration"),
    (r"\bmodprobe\b", "Loads/unloads kernel modules"),
    (r"\brmmod\b", "Removes kernel modules"),
    (r"\binsmod\b", "Inserts kernel modules"),
    (r"\bsysctl\s+-w\b", "Writes kernel parameters"),
    (r"\bmount\b", "Mounts filesystems"),
    (r"\bumount\b", "Unmounts filesystems"),
    (r"\bmkfs\b", "Creates filesystem"),
    (r"\bfdisk\b", "Disk partitioning"),
    (r"\bgdisk\b", "GPT partitioning"),
    (r"\bparted\b", "Disk partitioning"),
    (r"\bdd\s+if=", "Raw disk operation (dd)"),
    (r"\bshutdown\b", "System shutdown"),
    (r"\breboot\b", "System reboot"),
    (r"\bpoweroff\b", "System poweroff"),
    (r"\bkill\s+-9\b", "Force-kills a process"),
    (r"\bkillall\b", "Kills processes by name"),
    (r"\bchmod\b", "Changes file permissions"),
    (r"\bchown\b", "Changes file ownership"),
    (r"\brm\s+-r", "Recursive file deletion"),
    (r"curl\s+.*\|\s*(ba)?sh", "Pipes remote script to shell"),
    (r"wget\s+.*\|\s*(ba)?sh", "Pipes remote script to shell"),
    (r"\bgrub", "Modifies bootloader"),
    (r"\bdracut\b", "Rebuilds initramfs"),
    (r"\bmkinitcpio\b", "Rebuilds initramfs"),
    (r"\bcrontab\b", "Modifies cron jobs"),
]

# Risk level escalation patterns
_HIGH_RISK = [
    r"\brm\s+-rf\b",
    r"\bdd\s+if=",
    r"\bmkfs\b",
    r"/dev/(sd|nvme)\b",
    r"\bshutdown\b",
    r"\breboot\b",
    r"\bpoweroff\b",
    r"curl.*\|\s*(ba)?sh",
    r"\bgrub",
]

_CRITICAL_RISK = [
    r"\brm\s+-rf\s+/",
    r"\bdd\s+if=/dev/zero",
    r"\bchmod\s+000\s+/",
    r":\(\)\s*\{",
]


# ---------------------------------------------------------------------------
# Command classification
# ---------------------------------------------------------------------------

def classify_command(cmd: str) -> Tuple[str, int, List[str]]:
    """Classify a single command.

    Returns:
        (classification, confidence, notes)
        classification: "safe" | "needs_confirm" | "blocked"
        confidence: 0-100 (AI's estimated confidence this is the right action)
        notes: list of human-readable warnings
    """
    notes: List[str] = []
    classification = "safe"
    risk = "low"

    # Check blocked patterns
    for pattern in _NEVER_ALLOW:
        if re.search(pattern, cmd):
            return "blocked", 0, [f"BLOCKED: matches destructive pattern ({pattern})"]

    # Check needs-confirm patterns
    for pattern, description in _NEEDS_CONFIRM:
        if re.search(pattern, cmd):
            classification = "needs_confirm"
            notes.append(description)

    # Assess risk level
    for pattern in _CRITICAL_RISK:
        if re.search(pattern, cmd):
            risk = "critical"
            break
    else:
        for pattern in _HIGH_RISK:
            if re.search(pattern, cmd):
                risk = "high"
                break
        else:
            if classification == "needs_confirm":
                risk = "medium"

    # Confidence scoring heuristic
    # Base confidence: start at 70, adjust based on patterns
    confidence = 70

    # Well-known safe commands get higher confidence
    safe_starts = ["echo", "cat", "ls", "pwd", "whoami", "date", "uname",
                   "free", "df", "du", "sensors", "lscpu", "lspci",
                   "ip addr", "ip link", "ip route", "ss ", "lsblk",
                   "systemctl status", "journalctl", "dmesg"]
    cmd_stripped = cmd.strip()
    for s in safe_starts:
        if cmd_stripped.startswith(s):
            confidence = 90
            break

    # Risky patterns lower confidence
    if risk == "high":
        confidence = max(confidence - 30, 10)
    elif risk == "critical":
        confidence = max(confidence - 50, 5)
    elif risk == "medium":
        confidence = max(confidence - 15, 30)

    # Piped commands are less predictable
    if "|" in cmd:
        confidence = max(confidence - 10, 10)
    if "&&" in cmd:
        confidence = max(confidence - 5, 10)

    return classification, confidence, notes


def classify_commands(commands: List[str]) -> Tuple[str, int, str, List[str]]:
    """Classify a batch of commands.

    Returns: (overall_classification, avg_confidence, risk_level, all_notes)
    """
    if not commands:
        return "safe", 100, "low", []

    classifications = []
    confidences = []
    all_notes: List[str] = []

    for cmd in commands:
        cls, conf, notes = classify_command(cmd)
        classifications.append(cls)
        confidences.append(conf)
        all_notes.extend(notes)

    # Overall classification is the most restrictive
    if "blocked" in classifications:
        overall = "blocked"
    elif "needs_confirm" in classifications:
        overall = "needs_confirm"
    else:
        overall = "safe"

    avg_confidence = sum(confidences) // len(confidences) if confidences else 0

    # Risk level
    if overall == "blocked":
        risk = "critical"
    elif any(re.search(p, "\n".join(commands)) for p in _CRITICAL_RISK):
        risk = "critical"
    elif any(re.search(p, "\n".join(commands)) for p in _HIGH_RISK):
        risk = "high"
    elif overall == "needs_confirm":
        risk = "medium"
    else:
        risk = "low"

    return overall, avg_confidence, risk, all_notes


# ---------------------------------------------------------------------------
# Intercept engine
# ---------------------------------------------------------------------------

_lock = threading.Lock()
_pending: Dict[str, InterceptRecord] = {}
_audit_log: List[InterceptRecord] = []
_MAX_AUDIT = 500


def intercept(
    commands: List[str],
    source: str = "fyxa",
    confidence_override: int = -1,
) -> InterceptResult:
    """Run commands through the safety intercept.

    Returns an InterceptResult telling the caller whether to proceed,
    wait for approval, or abort.
    """
    overall, confidence, risk, notes = classify_commands(commands)

    if confidence_override >= 0:
        confidence = confidence_override

    record = InterceptRecord(
        intercept_id=uuid4().hex[:12],
        timestamp=time.time(),
        commands=list(commands),
        source=source,
        classification=overall,
        confidence=confidence,
        risk_level=risk,
        notes=notes,
    )

    if overall == "blocked":
        record.status = "denied"
        record.decided_at = time.time()
        record.decided_by = "system"
        with _lock:
            _audit_log.append(record)
            if len(_audit_log) > _MAX_AUDIT:
                _audit_log.pop(0)
        return InterceptResult(
            allowed=False,
            intercept_id=record.intercept_id,
            record=record,
            message=f"BLOCKED: {'; '.join(notes[:3])}. This command is too dangerous to execute.",
        )

    if overall == "safe":
        record.status = "auto_approved"
        record.decided_at = time.time()
        record.decided_by = "auto"
        with _lock:
            _audit_log.append(record)
            if len(_audit_log) > _MAX_AUDIT:
                _audit_log.pop(0)
        return InterceptResult(
            allowed=True,
            intercept_id=record.intercept_id,
            record=record,
            message="Command classified as safe — proceeding.",
        )

    # needs_confirm — queue for user approval
    record.status = "pending"
    with _lock:
        _pending[record.intercept_id] = record
    return InterceptResult(
        allowed=False,
        intercept_id=record.intercept_id,
        record=record,
        message=f"Action requires confirmation. Risk: {risk}. Confidence: {confidence}%. "
                f"Warnings: {'; '.join(notes[:5])}",
    )


def approve(intercept_id: str, decided_by: str = "user") -> Optional[InterceptRecord]:
    """Approve a pending intercept."""
    with _lock:
        record = _pending.pop(intercept_id, None)
        if record:
            record.status = "approved"
            record.decided_at = time.time()
            record.decided_by = decided_by
            _audit_log.append(record)
            if len(_audit_log) > _MAX_AUDIT:
                _audit_log.pop(0)
    return record


def deny(intercept_id: str, decided_by: str = "user") -> Optional[InterceptRecord]:
    """Deny a pending intercept."""
    with _lock:
        record = _pending.pop(intercept_id, None)
        if record:
            record.status = "denied"
            record.decided_at = time.time()
            record.decided_by = decided_by
            _audit_log.append(record)
            if len(_audit_log) > _MAX_AUDIT:
                _audit_log.pop(0)
    return record


def get_pending() -> List[InterceptRecord]:
    """Return all pending intercept requests."""
    with _lock:
        return list(_pending.values())


def get_audit_log(n: int = 50) -> List[InterceptRecord]:
    """Return the last N audit log entries."""
    with _lock:
        return list(_audit_log[-n:])


def format_intercept_for_display(record: InterceptRecord) -> Dict[str, Any]:
    """Format an intercept record for GUI modal display.

    Returns a dict suitable for rendering the 'Confirm Action' modal.
    """
    risk_colors = {
        "low": "#4caf50",       # green
        "medium": "#ff9800",    # orange
        "high": "#f44336",      # red
        "critical": "#d500f9",  # neon purple
    }

    return {
        "intercept_id": record.intercept_id,
        "commands": record.commands,
        "source": record.source,
        "classification": record.classification,
        "confidence": record.confidence,
        "confidence_label": _confidence_label(record.confidence),
        "risk_level": record.risk_level,
        "risk_color": risk_colors.get(record.risk_level, "#ff9800"),
        "notes": record.notes,
        "status": record.status,
        "timestamp": record.timestamp,
        "command_count": len(record.commands),
    }


def _confidence_label(score: int) -> str:
    """Human-readable confidence label."""
    if score >= 90:
        return "Very High"
    elif score >= 70:
        return "High"
    elif score >= 50:
        return "Moderate"
    elif score >= 30:
        return "Low"
    else:
        return "Very Low"


def intercept_report() -> List[str]:
    """Human-readable report for CLI/GUI display."""
    report: List[str] = []
    pending = get_pending()
    audit = get_audit_log(10)

    report.append(f"Safety Intercept — {len(pending)} pending, {len(_audit_log)} total audited")
    report.append("")

    if pending:
        report.append("Pending approvals:")
        for r in pending:
            report.append(f"  [{r.intercept_id}] {r.risk_level} risk, {r.confidence}% confidence")
            for cmd in r.commands[:3]:
                report.append(f"    $ {cmd[:80]}")
            if len(r.commands) > 3:
                report.append(f"    ... and {len(r.commands) - 3} more")
            for note in r.notes[:2]:
                report.append(f"    ⚠ {note}")
    else:
        report.append("No pending approvals.")

    if audit:
        report.append("")
        report.append("Recent audit log:")
        for r in audit:
            status_icon = {"approved": "✓", "denied": "✗", "auto_approved": "⚡",
                           "pending": "⏳"}.get(r.status, "?")
            report.append(
                f"  {status_icon} [{r.intercept_id}] {r.status} by {r.decided_by} — "
                f"{r.risk_level} risk, {len(r.commands)} cmd(s)"
            )

    return report
