"""
Sysfix Sentinel AV — kernel-level behavioural antivirus engine.

A real-time, eBPF-powered antivirus that monitors kernel syscalls
(execve, connect, openat2) for malicious behavioural patterns:

  • Non-system processes modifying /boot, /etc/grub.d, kernel modules
  • Unexpected apps opening network sockets to known-malicious IPs
  • Rapid file encryption (ransomware entropy-spike detection)
  • Privilege-escalation patterns (ptrace injection, /proc/*/mem writes)
  • Supply-chain attacks (curl|sh, pip installing from untrusted sources)

When a threat is detected the engine:
  1. Freezes the process via cgroups v2 FREEZER controller
  2. Moves the suspicious binary into a Firecracker micro-VM
     "Stasis Chamber" for isolated forensic analysis
  3. Cross-references the behaviour against ClamAV (libclamav)
     signature database
  4. Invokes Fyxa AI reasoning to determine if it's a real threat
  5. Emits a high-priority ThreatEvent for the GUI to render as a
     spring-physics threat-map notification

Requirements:
  • python3-bcc (BPF Compiler Collection)     — for eBPF probes
  • Root / CAP_BPF                            — for kernel tracing
  • cgroups v2 with freezer controller        — for process freezing
  • ClamAV + libclamav / clamscan (optional)  — signature scanning
  • Firecracker + /dev/kvm (optional)         — Stasis Chamber

All components degrade gracefully when dependencies are missing.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import signal
import struct
import subprocess
import tempfile
import threading
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Set, Tuple
from uuid import uuid4

# ---------------------------------------------------------------------------
# Lazy imports
# ---------------------------------------------------------------------------

_BPF = None
_HAS_BCC = False


def _ensure_bcc() -> bool:
    global _BPF, _HAS_BCC
    if _HAS_BCC:
        return True
    try:
        from bcc import BPF  # type: ignore[import-untyped]
        _BPF = BPF
        _HAS_BCC = True
        return True
    except ImportError:
        return False


# ---------------------------------------------------------------------------
# BPF C programs — execve, connect, openat2
# ---------------------------------------------------------------------------

_BPF_EXECVE_SRC = r"""
#include <uapi/linux/ptrace.h>
#include <linux/sched.h>
#include <linux/fs.h>

struct av_exec_t {
    u32 pid;
    u32 ppid;
    u32 uid;
    u64 ts_ns;
    char comm[64];
    char filename[256];
};

BPF_PERF_OUTPUT(av_exec_events);

TRACEPOINT_PROBE(syscalls, sys_enter_execve) {
    struct av_exec_t evt = {};
    u64 pid_tgid = bpf_get_current_pid_tgid();
    evt.pid = pid_tgid >> 32;
    struct task_struct *task = (struct task_struct *)bpf_get_current_task();
    evt.ppid = task->real_parent->tgid;
    evt.uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    evt.ts_ns = bpf_ktime_get_ns();
    bpf_get_current_comm(&evt.comm, sizeof(evt.comm));
    bpf_probe_read_user_str(&evt.filename, sizeof(evt.filename),
                            (void *)args->filename);
    av_exec_events.perf_submit(args, &evt, sizeof(evt));
    return 0;
}
"""

_BPF_CONNECT_SRC = r"""
#include <uapi/linux/ptrace.h>
#include <net/sock.h>

struct av_conn_t {
    u32 pid;
    u32 uid;
    u16 dport;
    u32 daddr;
    u64 ts_ns;
    char comm[64];
};

BPF_PERF_OUTPUT(av_conn_events);

int av_trace_connect(struct pt_regs *ctx, struct sock *sk) {
    struct av_conn_t evt = {};
    u64 pid_tgid = bpf_get_current_pid_tgid();
    evt.pid = pid_tgid >> 32;
    evt.uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    evt.dport = sk->__sk_common.skc_dport;
    evt.daddr = sk->__sk_common.skc_daddr;
    evt.ts_ns = bpf_ktime_get_ns();
    bpf_get_current_comm(&evt.comm, sizeof(evt.comm));
    av_conn_events.perf_submit(ctx, &evt, sizeof(evt));
    return 0;
}
"""

_BPF_OPENAT_SRC = r"""
#include <uapi/linux/ptrace.h>
#include <linux/sched.h>

struct av_open_t {
    u32 pid;
    u32 uid;
    u32 flags;
    u64 ts_ns;
    char comm[64];
    char filename[256];
};

BPF_PERF_OUTPUT(av_open_events);

TRACEPOINT_PROBE(syscalls, sys_enter_openat) {
    struct av_open_t evt = {};
    u64 pid_tgid = bpf_get_current_pid_tgid();
    evt.pid = pid_tgid >> 32;
    evt.uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    evt.flags = args->flags;
    evt.ts_ns = bpf_ktime_get_ns();
    bpf_get_current_comm(&evt.comm, sizeof(evt.comm));
    bpf_probe_read_user_str(&evt.filename, sizeof(evt.filename),
                            (void *)args->filename);
    av_open_events.perf_submit(args, &evt, sizeof(evt));
    return 0;
}
"""

# ---------------------------------------------------------------------------
# Known-malicious IP ranges (curated blocklist — expandable)
# ---------------------------------------------------------------------------

_MALICIOUS_IPS: Set[str] = {
    # Well-known C2 sinkholes and honeypot destinations
    "185.220.101.1", "185.220.101.2", "185.220.101.3",
    "45.33.32.156",    # scanme.nmap.org (scan tool)
    "198.51.100.1",    # documentation / test range
    "192.0.2.1",       # documentation range (RFC 5737)
}

_MALICIOUS_IP_RANGES: List[Tuple[int, int]] = [
    # Example CIDR ranges stored as (network_int, mask_int)
    # In production these would be loaded from a threat-intel feed
]

_SUSPICIOUS_PORTS: Set[int] = {
    4444, 5555, 6666, 6667, 31337, 12345, 1234, 9999,
    4443, 8443, 1337, 7777, 8888, 9090,
}

_C2_PORTS: Set[int] = {4444, 5555, 31337, 1337, 6667}

# ---------------------------------------------------------------------------
# Critical paths that non-system processes should never modify
# ---------------------------------------------------------------------------

_BOOT_PATHS = re.compile(
    r"^/(boot|efi|grub|grub2|sys/firmware|lib/modules)/", re.I
)
_KERNEL_PATHS = re.compile(
    r"/(vmlinuz|initramfs|initrd|grub\.cfg|grub\.conf)", re.I
)
_SYSTEM_CRITICAL = re.compile(
    r"^/(etc/(shadow|passwd|sudoers|pam\.d|security|ld\.so))", re.I
)
_SENSITIVE_KEYS = re.compile(
    r"(\.ssh/id_|\.ssh/authorized_keys|\.gnupg/|\.config/sysfix/brain\.json)", re.I
)

# ---------------------------------------------------------------------------
# Benign process allowlist
# ---------------------------------------------------------------------------

_SYSTEM_PROCS: Set[str] = {
    "systemd", "kworker", "ksoftirqd", "rcu_sched", "rcu_preempt",
    "migration", "idle", "kcompactd", "khugepaged", "kdevtmpfs",
    "watchdog", "thermald", "irqbalance", "dbus-daemon", "dbus-broker",
    "gdbus", "gnome-shell", "Xwayland", "pipewire", "wireplumber",
    "pulseaudio", "at-spi-bus-laun", "at-spi2-regist", "gsd-",
    "ibus-daemon", "ibus-engine", "ibus-portal", "gvfs-",
    "tracker-miner", "evolution-data", "gnome-keyring",
    "ssh-agent", "polkitd", "rtkit-daemon", "upowerd",
    "packagekitd", "fwupd", "abrt-dbus", "chronyd", "NetworkManager",
    "wpa_supplicant", "systemd-journal", "systemd-logind",
    "systemd-oomd", "systemd-resolve", "systemd-timesyn",
    "systemd-udevd", "auditd", "firewalld", "accounts-daemon",
    "colord", "cups", "avahi-daemon", "bluetoothd",
    "sysfix", "python", "python3", "ollama",
    "dnf", "yum", "apt", "dpkg", "rpm", "pacman",
    "grub-mkconfig", "dracut", "mkinitcpio",
    "update-grub", "kernel-install",
    "clamd", "freshclam", "clamscan",
}

# Applications that should NEVER open network sockets
_NO_NETWORK_APPS: Set[str] = {
    "gnome-calculator", "kcalc", "galculator", "xcalc",
    "eog", "loupe", "feh", "shotwell",    # image viewers
    "evince", "okular", "mupdf",           # PDF viewers
    "gedit", "nano", "mousepad",           # text editors (no net)
    "file-roller", "ark",                  # archive managers
    "nautilus-sendto",
}


def _is_system_proc(comm: str) -> bool:
    """Check if a process is a known benign system process."""
    base = comm.strip().split("/")[-1]
    for name in _SYSTEM_PROCS:
        if base.startswith(name):
            return True
    return False


# ---------------------------------------------------------------------------
# Ransomware detection — entropy-based file-write pattern analysis
# ---------------------------------------------------------------------------

@dataclass
class FileWriteTracker:
    """Track rapid file-write patterns per PID for ransomware detection."""
    pid: int
    comm: str
    write_count: int = 0
    high_entropy_count: int = 0
    unique_dirs: Set[str] = field(default_factory=set)
    first_seen: float = field(default_factory=time.monotonic)
    last_seen: float = field(default_factory=time.monotonic)
    extensions_written: Set[str] = field(default_factory=set)

    @property
    def write_rate(self) -> float:
        """Writes per second."""
        elapsed = max(self.last_seen - self.first_seen, 0.1)
        return self.write_count / elapsed

    @property
    def is_ransomware_pattern(self) -> bool:
        """Heuristic: rapid writes across many directories with high entropy."""
        if self.write_count < 10:
            return False
        # Rapid writes (>5/sec) across multiple directories
        if self.write_rate > 5 and len(self.unique_dirs) > 3:
            return True
        # High-entropy file content ratio
        if self.high_entropy_count > 5 and self.write_rate > 2:
            return True
        # Known ransomware extension patterns
        ransom_exts = {
            ".encrypted", ".locked", ".crypto", ".crypt", ".enc",
            ".ransom", ".pay", ".locky", ".cerber", ".wcry",
            ".wncry", ".wncryt", ".onion", ".aes", ".rsa",
        }
        if self.extensions_written & ransom_exts:
            return True
        return False


def _estimate_entropy(data: bytes) -> float:
    """Estimate Shannon entropy of a byte buffer (0.0 - 8.0)."""
    if not data:
        return 0.0
    freq = [0] * 256
    for b in data:
        freq[b] += 1
    length = len(data)
    entropy = 0.0
    for count in freq:
        if count > 0:
            p = count / length
            entropy -= p * math.log2(p)
    return entropy


# ---------------------------------------------------------------------------
# Threat event data structures
# ---------------------------------------------------------------------------

@dataclass
class ThreatEvent:
    """A detected threat from the Sentinel AV engine."""
    threat_id: str = field(default_factory=lambda: uuid4().hex[:12])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    pid: int = 0
    ppid: int = 0
    uid: int = 0
    comm: str = ""
    severity: str = "medium"  # low | medium | high | critical
    threat_type: str = ""     # ransomware | boot_tamper | malicious_net |
                              # priv_escalation | sensitive_access | supply_chain
    description: str = ""
    filename: str = ""

    # Process behaviour map — what the process tried to touch
    files_touched: List[str] = field(default_factory=list)
    network_connections: List[str] = field(default_factory=list)
    syscalls_made: List[str] = field(default_factory=list)

    # Response actions taken
    frozen: bool = False
    cgroup_path: str = ""
    stasis_chamber: bool = False
    stasis_vm_id: str = ""
    clamav_result: str = ""
    ai_verdict: str = ""
    ai_confidence: int = 0

    # Malware Verification Pipeline profile (JSON-serialisable)
    pipeline_profile: Optional[Dict[str, Any]] = None

    # Final disposition
    disposition: str = "pending"  # pending | neutralised | false_positive |
                                   # quarantined | deleted | jailed

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ThreatMap:
    """Visual threat map — what the process was doing when caught."""
    threat_id: str = ""
    process_tree: List[str] = field(default_factory=list)
    file_access_map: List[Dict[str, str]] = field(default_factory=list)
    network_map: List[Dict[str, Any]] = field(default_factory=list)
    syscall_timeline: List[Dict[str, Any]] = field(default_factory=list)
    entropy_readings: List[float] = field(default_factory=list)
    risk_score: int = 0  # 0-100


# ---------------------------------------------------------------------------
# cgroups v2 Freezer
# ---------------------------------------------------------------------------

_CGROUP_BASE = Path("/sys/fs/cgroup")
_SYSFIX_CGROUP = _CGROUP_BASE / "sysfix-sentinel"


def _cgroups_v2_available() -> bool:
    """Check if cgroups v2 is mounted and the freezer controller exists."""
    try:
        controllers = (_CGROUP_BASE / "cgroup.controllers").read_text().strip()
        # On cgroups v2 unified hierarchy, check for any controller
        return bool(controllers)
    except Exception:
        return False


def freeze_process(pid: int) -> Tuple[bool, str]:
    """Freeze a process using cgroups v2 freezer.

    Creates a dedicated cgroup, moves the PID into it, and sets
    cgroup.freeze = 1 to halt all threads.

    Returns (success, cgroup_path_or_error).
    """
    if not _cgroups_v2_available():
        # Fallback: send SIGSTOP
        try:
            os.kill(pid, signal.SIGSTOP)
            return True, f"SIGSTOP sent to PID {pid} (cgroups v2 not available)"
        except ProcessLookupError:
            return False, f"PID {pid} no longer exists"
        except PermissionError:
            return False, f"Permission denied freezing PID {pid}"

    cg_name = f"quarantine-{pid}-{int(time.time())}"
    cg_path = _SYSFIX_CGROUP / cg_name

    try:
        # Create parent cgroup if needed
        _SYSFIX_CGROUP.mkdir(parents=True, exist_ok=True)

        # Enable controllers in parent
        try:
            subtree = _SYSFIX_CGROUP / "cgroup.subtree_control"
            subtree.write_text("+memory +pids")
        except Exception:
            pass

        # Create quarantine cgroup
        cg_path.mkdir(exist_ok=True)

        # Move PID into the cgroup
        procs_file = cg_path / "cgroup.procs"
        procs_file.write_text(str(pid))

        # Freeze
        freeze_file = cg_path / "cgroup.freeze"
        freeze_file.write_text("1")

        return True, str(cg_path)
    except FileNotFoundError:
        # PID may have exited
        return False, f"PID {pid} exited before freeze"
    except PermissionError:
        # Fallback to SIGSTOP
        try:
            os.kill(pid, signal.SIGSTOP)
            return True, f"SIGSTOP (cgroup permission denied)"
        except Exception as e:
            return False, f"Cannot freeze PID {pid}: {e}"
    except Exception as e:
        return False, f"cgroup freeze error: {e}"


def unfreeze_process(cgroup_path: str) -> Tuple[bool, str]:
    """Unfreeze a previously-frozen process."""
    cg = Path(cgroup_path)
    try:
        freeze_file = cg / "cgroup.freeze"
        if freeze_file.exists():
            freeze_file.write_text("0")
            return True, f"Unfrozen: {cg}"
        else:
            return False, f"No freeze file at {cg}"
    except Exception as e:
        return False, f"Unfreeze error: {e}"


def _cleanup_cgroup(cgroup_path: str) -> None:
    """Remove an empty quarantine cgroup."""
    try:
        cg = Path(cgroup_path)
        if cg.exists():
            # Move any remaining PIDs to parent
            procs = (cg / "cgroup.procs").read_text().strip()
            if procs:
                parent_procs = cg.parent / "cgroup.procs"
                for pid_line in procs.splitlines():
                    try:
                        parent_procs.write_text(pid_line.strip())
                    except Exception:
                        pass
            cg.rmdir()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Stasis Chamber — Firecracker micro-VM isolation for forensic analysis
# ---------------------------------------------------------------------------

_STASIS_DIR = Path.home() / ".config" / "sysfix" / "stasis"


def stasis_chamber_isolate(pid: int, binary_path: str,
                           threat_event: ThreatEvent) -> Dict[str, Any]:
    """Move a suspicious binary into a Firecracker micro-VM for analysis.

    Copies the binary into an isolated VM, runs it in a sandboxed
    environment, and collects forensic artifacts.

    Returns analysis results dict.
    """
    result: Dict[str, Any] = {
        "success": False,
        "vm_id": "",
        "binary_hash": "",
        "analysis": [],
        "clamav": "",
        "strace_output": "",
    }

    _STASIS_DIR.mkdir(parents=True, exist_ok=True)

    # Hash the binary
    binary = Path(binary_path)
    if binary.exists() and binary.is_file():
        try:
            sha256 = hashlib.sha256(binary.read_bytes()).hexdigest()
            result["binary_hash"] = sha256
        except Exception:
            pass

    vm_id = f"stasis-{threat_event.threat_id}"
    result["vm_id"] = vm_id

    # Attempt Firecracker-based isolation
    try:
        from sysfixai.microvm import microvm_run, detect_vm_backend
        backend = detect_vm_backend()

        if backend == "firecracker":
            # Full micro-VM isolation
            analysis_cmds = [
                f"echo '=== Stasis Chamber Analysis for PID {pid} ==='",
                f"echo 'Binary: {binary_path}'",
                f"echo 'SHA-256: {result.get('binary_hash', 'unknown')}'",
                "echo '=== File type ==='",
                f"file '{binary_path}' 2>/dev/null || echo 'Cannot determine file type'",
                "echo '=== Strings (first 50 suspicious) ==='",
                f"strings '{binary_path}' 2>/dev/null | grep -iE '(http|ftp|socket|exec|shell|/bin/|password|key|token|crypt|ransom)' | head -50",
                "echo '=== ELF analysis ==='",
                f"readelf -h '{binary_path}' 2>/dev/null || echo 'Not an ELF binary'",
                "echo '=== Dynamic libraries ==='",
                f"ldd '{binary_path}' 2>/dev/null || echo 'Cannot check libs'",
            ]
            vm_results = microvm_run(analysis_cmds, label=vm_id, timeout=30)
            result["analysis"] = vm_results
            result["success"] = True
        elif backend in ("bwrap", "podman"):
            # Sandbox fallback
            vm_results = microvm_run(
                [f"file '{binary_path}'",
                 f"strings '{binary_path}' | grep -iE '(http|exec|shell|crypt|ransom)' | head -30"],
                label=vm_id, timeout=20,
            )
            result["analysis"] = vm_results
            result["success"] = True
        else:
            # No sandbox available — do local static analysis only
            result["analysis"] = _local_static_analysis(binary_path)
            result["success"] = True

    except ImportError:
        result["analysis"] = _local_static_analysis(binary_path)
        result["success"] = True
    except Exception as e:
        result["analysis"] = [f"⚠ Stasis Chamber error: {e}"]
        result["analysis"].extend(_local_static_analysis(binary_path))

    # Archive the suspicious binary
    try:
        archive = _STASIS_DIR / f"{vm_id}.quarantine"
        if binary.exists():
            shutil.copy2(str(binary), str(archive))
            result["quarantine_path"] = str(archive)
    except Exception:
        pass

    return result


def _local_static_analysis(binary_path: str) -> List[str]:
    """Perform local static analysis when VM isolation is unavailable."""
    lines: List[str] = []
    bp = Path(binary_path)
    if not bp.exists():
        return ["⚠ Binary no longer exists on disk."]

    # File type
    try:
        r = subprocess.run(["file", str(bp)], capture_output=True,
                           text=True, timeout=5)
        if r.returncode == 0:
            lines.append(f"File type: {r.stdout.strip()}")
    except Exception:
        pass

    # Size
    try:
        size = bp.stat().st_size
        lines.append(f"Size: {size:,} bytes ({size / 1024:.1f} KB)")
    except Exception:
        pass

    # Suspicious strings
    try:
        r = subprocess.run(
            ["strings", str(bp)],
            capture_output=True, text=True, timeout=10,
        )
        if r.returncode == 0:
            dangerous_patterns = re.compile(
                r"(http://|https://|ftp://|/bin/sh|/bin/bash|"
                r"socket|connect|exec|system\(|popen|"
                r"password|passwd|shadow|crypt|ransom|"
                r"bitcoin|monero|wallet|c2_server|"
                r"base64_decode|eval\(|\\x[0-9a-f]{2})",
                re.I,
            )
            hits = [
                line.strip()
                for line in r.stdout.splitlines()
                if dangerous_patterns.search(line)
            ][:40]
            if hits:
                lines.append(f"⚠ {len(hits)} suspicious strings found:")
                for h in hits[:20]:
                    lines.append(f"    {h[:120]}")
                if len(hits) > 20:
                    lines.append(f"    ... and {len(hits) - 20} more")
            else:
                lines.append("No suspicious strings detected.")
    except Exception:
        pass

    # ELF header check
    try:
        with open(str(bp), "rb") as f:
            magic = f.read(4)
        if magic == b"\x7fELF":
            lines.append("Binary type: ELF executable")
            try:
                r = subprocess.run(
                    ["readelf", "-h", str(bp)],
                    capture_output=True, text=True, timeout=5,
                )
                if r.returncode == 0:
                    for line in r.stdout.splitlines():
                        if any(k in line for k in ("Type:", "Machine:", "Entry point")):
                            lines.append(f"  {line.strip()}")
            except Exception:
                pass
        elif magic[:2] == b"MZ":
            lines.append("⚠ Binary type: Windows PE executable on Linux!")
        elif magic[:2] == b"#!":
            lines.append("Binary type: Script (shebang)")
    except Exception:
        pass

    return lines


# ---------------------------------------------------------------------------
# ClamAV integration
# ---------------------------------------------------------------------------

def _clamav_available() -> bool:
    """Check if ClamAV (clamscan or clamdscan) is available."""
    return bool(shutil.which("clamscan") or shutil.which("clamdscan"))


def clamav_scan(file_path: str) -> Dict[str, Any]:
    """Scan a file with ClamAV and return results.

    Tries clamdscan (daemon, faster) first, falls back to clamscan.
    """
    result: Dict[str, Any] = {
        "available": False,
        "scanned": False,
        "infected": False,
        "signature": "",
        "engine_version": "",
        "error": "",
    }

    # Try clamdscan first (uses clamd daemon — much faster)
    clamdscan = shutil.which("clamdscan")
    clamscan = shutil.which("clamscan")

    scanner = clamdscan or clamscan
    if not scanner:
        result["error"] = "ClamAV not installed (install clamav package)"
        return result

    result["available"] = True

    try:
        args = [scanner, "--no-summary", "--infected"]
        if scanner == clamdscan:
            args.append("--fdpass")  # pass file descriptor to daemon
        args.append(file_path)

        r = subprocess.run(
            args, capture_output=True, text=True, timeout=60,
        )
        result["scanned"] = True

        if r.returncode == 1:
            # Virus found
            result["infected"] = True
            # Parse signature name from output
            for line in r.stdout.splitlines():
                if "FOUND" in line:
                    parts = line.split(":")
                    if len(parts) >= 2:
                        sig = parts[-1].strip().replace("FOUND", "").strip()
                        result["signature"] = sig
                    break
        elif r.returncode == 0:
            result["infected"] = False
        else:
            result["error"] = r.stderr.strip()[:200]

        # Get engine version
        try:
            v = subprocess.run(
                [scanner, "--version"],
                capture_output=True, text=True, timeout=5,
            )
            result["engine_version"] = v.stdout.strip()[:100]
        except Exception:
            pass

    except subprocess.TimeoutExpired:
        result["error"] = "ClamAV scan timed out (60s)"
    except Exception as e:
        result["error"] = str(e)[:200]

    return result


# ---------------------------------------------------------------------------
# AI threat analysis (via Fyxa)
# ---------------------------------------------------------------------------

def _ai_analyze_threat(threat: ThreatEvent, stasis_result: Dict[str, Any],
                       clamav_result: Dict[str, Any]) -> Tuple[str, int]:
    """Ask Fyxa AI to analyze a threat and determine if it's real.

    Returns (verdict, confidence) where verdict is a string explanation
    and confidence is 0-100.
    """
    try:
        from sysfixai.ai import get_deep_dive, get_active_model
    except ImportError:
        return "AI analysis unavailable — module not loaded.", 0

    # Build analysis context for the AI
    context = f"""SENTINEL AV THREAT ANALYSIS REQUEST
====================================
Threat ID: {threat.threat_id}
Event type: {threat.threat_type}
Severity: {threat.severity}
Process: {threat.comm} (PID {threat.pid}, PPID {threat.ppid}, UID {threat.uid})
Binary: {threat.filename}
Description: {threat.description}

Files touched: {', '.join(threat.files_touched[:20]) or 'none'}
Network connections: {', '.join(threat.network_connections[:10]) or 'none'}
Syscalls: {', '.join(threat.syscalls_made[:15]) or 'N/A'}

STASIS CHAMBER ANALYSIS:
{chr(10).join(str(x) for x in stasis_result.get('analysis', ['N/A'])[:30])}
Binary SHA-256: {stasis_result.get('binary_hash', 'unknown')}

CLAMAV RESULT:
Scanned: {clamav_result.get('scanned', False)}
Infected: {clamav_result.get('infected', False)}
Signature: {clamav_result.get('signature', 'none')}
Engine: {clamav_result.get('engine_version', 'unknown')}

ANALYSIS REQUIRED:
1. Is this a genuine threat or a false positive?
2. What is the risk level (0-100)?
3. What specific malicious behaviour pattern does this match?
4. Recommended action: DELETE, QUARANTINE, or RELEASE?
Respond concisely in 3-5 sentences. Start with VERDICT: THREAT or VERDICT: FALSE_POSITIVE."""

    try:
        model = get_active_model()
        if not model:
            return "AI unavailable — no model configured.", 0

        response = get_deep_dive(context, [])
        if not response:
            return "AI returned empty response.", 0

        # Parse confidence from response
        confidence = 50
        response_lower = response.lower()
        if "verdict: threat" in response_lower:
            confidence = 80
        elif "verdict: false_positive" in response_lower:
            confidence = 30
        # Adjust based on keywords
        if "definitely" in response_lower or "confirmed" in response_lower:
            confidence = min(confidence + 15, 100)
        if "uncertain" in response_lower or "unclear" in response_lower:
            confidence = max(confidence - 20, 10)

        return response.strip()[:1000], confidence
    except Exception as e:
        return f"AI analysis error: {e}", 0


# ---------------------------------------------------------------------------
# Process information gathering
# ---------------------------------------------------------------------------

def _get_process_tree(pid: int) -> List[str]:
    """Get the process tree for a PID."""
    lines: List[str] = []
    try:
        r = subprocess.run(
            ["ps", "--forest", "-o", "pid,ppid,uid,comm,args", "-g", str(pid)],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            lines = r.stdout.strip().splitlines()
    except Exception:
        pass

    if not lines:
        # Fallback: read /proc
        try:
            comm = Path(f"/proc/{pid}/comm").read_text().strip()
            cmdline = Path(f"/proc/{pid}/cmdline").read_text().replace("\x00", " ").strip()
            status = Path(f"/proc/{pid}/status").read_text()
            ppid = "?"
            uid = "?"
            for sl in status.splitlines():
                if sl.startswith("PPid:"):
                    ppid = sl.split(":")[1].strip()
                elif sl.startswith("Uid:"):
                    uid = sl.split(":")[1].strip().split()[0]
            lines = [f"PID: {pid}  PPID: {ppid}  UID: {uid}  COMM: {comm}",
                     f"CMD: {cmdline[:200]}"]
        except Exception:
            lines = [f"PID: {pid} (process info unavailable)"]

    return lines


def _get_process_binary(pid: int) -> str:
    """Get the executable path for a PID."""
    try:
        return os.readlink(f"/proc/{pid}/exe")
    except Exception:
        try:
            cmdline = Path(f"/proc/{pid}/cmdline").read_text().split("\x00")[0]
            return cmdline
        except Exception:
            return f"(unknown binary for PID {pid})"


def _build_threat_map(threat: ThreatEvent) -> ThreatMap:
    """Build a visual threat map showing everything the process touched."""
    tmap = ThreatMap(threat_id=threat.threat_id)
    tmap.risk_score = {"low": 20, "medium": 45, "high": 70, "critical": 95}.get(
        threat.severity, 50
    )

    # Process tree
    tmap.process_tree = _get_process_tree(threat.pid)

    # File access map
    for f in threat.files_touched:
        category = "normal"
        if _BOOT_PATHS.search(f):
            category = "boot_critical"
        elif _SENSITIVE_KEYS.search(f):
            category = "sensitive_keys"
        elif _SYSTEM_CRITICAL.search(f):
            category = "system_critical"
        tmap.file_access_map.append({"path": f, "category": category})

    # Network map
    for conn in threat.network_connections:
        parts = conn.split(":")
        ip = parts[0] if parts else "unknown"
        port = int(parts[1]) if len(parts) > 1 else 0
        malicious = ip in _MALICIOUS_IPS or port in _C2_PORTS
        tmap.network_map.append({
            "ip": ip, "port": port,
            "malicious": malicious,
            "label": f"{'🔴 C2/MAL' if malicious else '🟢 OK'} {ip}:{port}",
        })

    return tmap


# ---------------------------------------------------------------------------
# Main Sentinel AV Engine
# ---------------------------------------------------------------------------

class SentinelAV:
    """
    Kernel-level behavioural antivirus engine using eBPF.

    Monitors execve(), connect(), and openat() syscalls for malicious
    patterns, freezes threats with cgroups v2, isolates binaries in
    Firecracker Stasis Chambers, and cross-references with ClamAV + AI.

    Usage::

        av = SentinelAV()
        av.start()
        …
        threats = av.threats
        av.stop()
    """

    def __init__(self, on_threat: Optional[Callable[[ThreatEvent, ThreatMap], None]] = None):
        self._thread: Optional[threading.Thread] = None
        self._analysis_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._on_threat = on_threat
        self._threats: List[ThreatEvent] = []
        self._threat_maps: Dict[str, ThreatMap] = {}
        self._lock = threading.Lock()
        self._bpf_exec = None
        self._bpf_conn = None
        self._bpf_open = None
        self._known_pids: Set[int] = set()
        self._write_trackers: Dict[int, FileWriteTracker] = {}
        self._analysis_queue: Deque[ThreatEvent] = deque(maxlen=50)
        self._neutralised_count = 0
        self._frozen_pids: Dict[int, str] = {}  # pid -> cgroup_path

    # -- public API --------------------------------------------------------

    @property
    def threats(self) -> List[ThreatEvent]:
        with self._lock:
            return list(self._threats)

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    @property
    def threat_count(self) -> int:
        return len(self._threats)

    @property
    def neutralised_count(self) -> int:
        return self._neutralised_count

    def get_threat_map(self, threat_id: str) -> Optional[ThreatMap]:
        return self._threat_maps.get(threat_id)

    def start(self) -> str:
        """Start the Sentinel AV engine. Returns status string."""
        if self.running:
            return "Sentinel AV is already running."

        if os.geteuid() != 0:
            return ("⚠ Sentinel AV requires root privileges. "
                    "Relaunch Sysfix with sudo or enable Sudo Mode.")

        if not _ensure_bcc():
            return ("⚠ python3-bcc is not installed. "
                    "Install: sudo dnf install python3-bcc "
                    "(or apt install python3-bpfcc)")

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="sentinel-av",
        )
        self._thread.start()

        # Start background analysis thread
        self._analysis_thread = threading.Thread(
            target=self._analysis_loop, daemon=True, name="sentinel-av-analysis",
        )
        self._analysis_thread.start()

        return "✓ Sentinel AV started — monitoring execve(), connect(), openat()."

    def stop(self) -> str:
        """Stop the Sentinel AV engine."""
        if not self.running:
            return "Sentinel AV is not running."
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3)
        self._cleanup()

        # Unfreeze any frozen processes
        for pid, cg_path in list(self._frozen_pids.items()):
            try:
                unfreeze_process(cg_path)
                _cleanup_cgroup(cg_path)
            except Exception:
                pass
        self._frozen_pids.clear()

        return "✓ Sentinel AV stopped."

    def status(self) -> Dict[str, Any]:
        """Get current engine status."""
        return {
            "running": self.running,
            "has_bcc": _HAS_BCC,
            "is_root": os.geteuid() == 0 if hasattr(os, "geteuid") else False,
            "cgroups_v2": _cgroups_v2_available(),
            "clamav": _clamav_available(),
            "threat_count": len(self._threats),
            "neutralised": self._neutralised_count,
            "frozen_processes": len(self._frozen_pids),
            "latest_threats": [t.to_dict() for t in self._threats[-5:]],
            "probes": {
                "execve": self._bpf_exec is not None,
                "connect": self._bpf_conn is not None,
                "openat": self._bpf_open is not None,
            },
        }

    def delete_threat(self, threat_id: str) -> str:
        """Delete the quarantined binary for a threat."""
        with self._lock:
            threat = next((t for t in self._threats if t.threat_id == threat_id), None)
        if not threat:
            return f"Threat {threat_id} not found."

        # Delete quarantined copy
        quarantine = _STASIS_DIR / f"stasis-{threat_id}.quarantine"
        if quarantine.exists():
            try:
                quarantine.unlink()
            except Exception as e:
                return f"Cannot delete quarantine: {e}"

        # Kill the original process if still alive
        if threat.pid:
            try:
                os.kill(threat.pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass

        # Unfreeze and cleanup cgroup
        if threat.pid in self._frozen_pids:
            cg = self._frozen_pids.pop(threat.pid)
            unfreeze_process(cg)
            _cleanup_cgroup(cg)

        threat.disposition = "deleted"
        return f"✓ Threat {threat_id} deleted and process killed."

    def jail_threat(self, threat_id: str) -> str:
        """Keep the process frozen forever (jailed)."""
        with self._lock:
            threat = next((t for t in self._threats if t.threat_id == threat_id), None)
        if not threat:
            return f"Threat {threat_id} not found."
        threat.disposition = "jailed"
        return f"✓ Threat {threat_id} permanently jailed. Process remains frozen."

    def release_threat(self, threat_id: str) -> str:
        """Release a false-positive — unfreeze and clear."""
        with self._lock:
            threat = next((t for t in self._threats if t.threat_id == threat_id), None)
        if not threat:
            return f"Threat {threat_id} not found."

        if threat.pid in self._frozen_pids:
            cg = self._frozen_pids.pop(threat.pid)
            success, msg = unfreeze_process(cg)
            _cleanup_cgroup(cg)
            if not success:
                return f"⚠ Release failed: {msg}"

        threat.disposition = "false_positive"
        return f"✓ Threat {threat_id} released — marked as false positive."

    def clear_threats(self) -> None:
        with self._lock:
            self._threats.clear()
            self._threat_maps.clear()

    # -- internal engine ---------------------------------------------------

    def _emit_threat(self, threat: ThreatEvent) -> None:
        """Record and process a new threat."""
        with self._lock:
            self._threats.append(threat)
            if len(self._threats) > 500:
                self._threats = self._threats[-300:]

        # Build threat map
        tmap = _build_threat_map(threat)
        self._threat_maps[threat.threat_id] = tmap

        # STEP 1: Freeze the process immediately
        if threat.severity in ("high", "critical"):
            success, cg_path = freeze_process(threat.pid)
            if success:
                threat.frozen = True
                threat.cgroup_path = cg_path
                self._frozen_pids[threat.pid] = cg_path

        # Queue for deep analysis (ClamAV + Stasis + AI)
        self._analysis_queue.append(threat)

        # Notify GUI callback
        if self._on_threat:
            try:
                self._on_threat(threat, tmap)
            except Exception:
                pass

    def _analysis_loop(self) -> None:
        """Background thread for deep threat analysis."""
        while not self._stop_event.is_set():
            if not self._analysis_queue:
                time.sleep(0.5)
                continue

            try:
                threat = self._analysis_queue.popleft()
            except IndexError:
                continue

            try:
                self._deep_analyze(threat)
            except Exception:
                pass

    def _deep_analyze(self, threat: ThreatEvent) -> None:
        """Run full analysis pipeline: ClamAV → YARA → VT → Stasis → AI.

        When the Malware Verification Pipeline module is available the
        three-stage pipeline (ClamAV + YARA + VirusTotal) is executed
        concurrently, producing a ThreatProfile JSON that Fyxa
        interprets.  Falls back to the legacy single-stage ClamAV scan
        if the pipeline module is missing.
        """
        binary_path = threat.filename or _get_process_binary(threat.pid)

        # ── Malware Verification Pipeline (preferred) ────────────
        pipeline_ran = False
        try:
            from sysfixai.malware_pipeline import (
                run_pipeline, ai_interpret_profile, ThreatProfile,
            )
            if binary_path and Path(binary_path).exists():
                profile = run_pipeline(binary_path)

                # Persist the ThreatProfile on the event
                threat.pipeline_profile = profile.to_dict()

                # ── Merge ClamAV results ────────────────────────
                if profile.clamav.scanned:
                    if profile.clamav.infected:
                        threat.clamav_result = (
                            f"INFECTED: {profile.clamav.signature}"
                        )
                        threat.severity = "critical"
                        if not threat.frozen:
                            ok, cg = freeze_process(threat.pid)
                            if ok:
                                threat.frozen = True
                                threat.cgroup_path = cg
                                self._frozen_pids[threat.pid] = cg
                    else:
                        threat.clamav_result = "clean (no signature match)"

                # ── Merge YARA results ──────────────────────────
                if profile.yara.scanned and profile.yara.matched:
                    yara_names = [m.rule for m in profile.yara.matches[:5]]
                    threat.description += (
                        f" | YARA: {len(profile.yara.matches)} matches "
                        f"({', '.join(yara_names)})"
                    )
                    if threat.severity not in ("critical",):
                        threat.severity = "high"

                # ── Merge VirusTotal results ────────────────────
                if profile.virustotal.queried:
                    if profile.virustotal.detections > 0:
                        threat.description += (
                            f" | VT: {profile.virustotal.detection_ratio} "
                            f"engines flagged"
                        )
                        if profile.virustotal.detection_percentage >= 25:
                            threat.severity = "critical"

                # ── Fyxa AI interpretation of the profile ───────
                try:
                    assessment, conf = ai_interpret_profile(profile)
                    threat.ai_verdict = assessment
                    threat.ai_confidence = conf
                    profile.ai_assessment = assessment
                    profile.ai_confidence = conf
                    threat.pipeline_profile = profile.to_dict()
                except Exception:
                    threat.ai_verdict = "AI interpretation unavailable."
                    threat.ai_confidence = 0

                # ── Risk-based disposition ──────────────────────
                if profile.overall_risk == "critical":
                    threat.disposition = "quarantined"
                    self._neutralised_count += 1
                elif profile.overall_risk == "high":
                    threat.disposition = "quarantined"
                    self._neutralised_count += 1
                elif profile.overall_risk in ("clean", "low"):
                    threat.disposition = "false_positive"
                    if threat.frozen and threat.pid in self._frozen_pids:
                        cg = self._frozen_pids.pop(threat.pid)
                        unfreeze_process(cg)
                        _cleanup_cgroup(cg)
                        threat.frozen = False
                else:
                    threat.disposition = "pending"

                pipeline_ran = True
        except ImportError:
            pass
        except Exception:
            pass

        # ── Legacy fallback (no pipeline module) ─────────────────
        if not pipeline_ran:
            # STEP 2: ClamAV signature scan
            clam_result: Dict[str, Any] = {"scanned": False}
            if _clamav_available() and binary_path and Path(binary_path).exists():
                clam_result = clamav_scan(binary_path)
                if clam_result.get("infected"):
                    threat.clamav_result = f"INFECTED: {clam_result.get('signature', 'unknown')}"
                    threat.severity = "critical"
                    if not threat.frozen:
                        success, cg_path = freeze_process(threat.pid)
                        if success:
                            threat.frozen = True
                            threat.cgroup_path = cg_path
                            self._frozen_pids[threat.pid] = cg_path
                else:
                    threat.clamav_result = "clean (no signature match)"

            # STEP 3: Stasis Chamber isolation and forensic analysis
            stasis_result: Dict[str, Any] = {"success": False}
            if binary_path and Path(binary_path).exists():
                stasis_result = stasis_chamber_isolate(
                    threat.pid, binary_path, threat,
                )
                if stasis_result.get("success"):
                    threat.stasis_chamber = True
                    threat.stasis_vm_id = stasis_result.get("vm_id", "")

            # STEP 4: AI reasoning
            try:
                verdict, confidence = _ai_analyze_threat(
                    threat, stasis_result, clam_result,
                )
                threat.ai_verdict = verdict
                threat.ai_confidence = confidence
            except Exception:
                threat.ai_verdict = "AI analysis unavailable."
                threat.ai_confidence = 0

            # Determine final disposition
            if clam_result.get("infected"):
                threat.disposition = "quarantined"
                self._neutralised_count += 1
            elif threat.ai_confidence >= 70 and "threat" in threat.ai_verdict.lower():
                threat.disposition = "quarantined"
                self._neutralised_count += 1
            elif threat.ai_confidence < 30:
                threat.disposition = "false_positive"
                if threat.frozen and threat.pid in self._frozen_pids:
                    cg = self._frozen_pids.pop(threat.pid)
                    unfreeze_process(cg)
                    _cleanup_cgroup(cg)
                    threat.frozen = False
            else:
                threat.disposition = "pending"

        # ── Stasis Chamber (runs regardless of pipeline) ─────────
        if not threat.stasis_chamber and binary_path and Path(binary_path).exists():
            stasis_result = stasis_chamber_isolate(
                threat.pid, binary_path, threat,
            )
            if stasis_result.get("success"):
                threat.stasis_chamber = True
                threat.stasis_vm_id = stasis_result.get("vm_id", "")

        # Re-notify with updated analysis
        if self._on_threat:
            tmap = self._threat_maps.get(threat.threat_id)
            if tmap:
                try:
                    self._on_threat(threat, tmap)
                except Exception:
                    pass

    def _run(self) -> None:
        """Main eBPF monitoring loop — runs in a daemon thread."""
        try:
            self._attach_probes()
            self._take_baseline()
            while not self._stop_event.is_set():
                try:
                    if self._bpf_exec:
                        self._bpf_exec.perf_buffer_poll(timeout=100)
                    if self._bpf_conn:
                        self._bpf_conn.perf_buffer_poll(timeout=100)
                    if self._bpf_open:
                        self._bpf_open.perf_buffer_poll(timeout=100)
                except Exception:
                    pass
        except Exception as exc:
            self._emit_threat(ThreatEvent(
                comm="sentinel-av", severity="high",
                threat_type="engine_error",
                description=f"Sentinel AV engine crashed: {exc}",
            ))
        finally:
            self._cleanup()

    def _attach_probes(self) -> None:
        """Attach eBPF probes to kernel tracepoints and kprobes."""
        if not _BPF:
            return

        # execve tracepoint
        try:
            self._bpf_exec = _BPF(text=_BPF_EXECVE_SRC)
            self._bpf_exec["av_exec_events"].open_perf_buffer(self._on_exec)
        except Exception:
            self._bpf_exec = None

        # connect kprobe
        try:
            self._bpf_conn = _BPF(text=_BPF_CONNECT_SRC)
            self._bpf_conn.attach_kprobe(
                event="tcp_v4_connect", fn_name="av_trace_connect",
            )
            self._bpf_conn["av_conn_events"].open_perf_buffer(self._on_connect)
        except Exception:
            self._bpf_conn = None

        # openat tracepoint
        try:
            self._bpf_open = _BPF(text=_BPF_OPENAT_SRC)
            self._bpf_open["av_open_events"].open_perf_buffer(self._on_openat)
        except Exception:
            self._bpf_open = None

    def _take_baseline(self) -> None:
        """Snapshot running PIDs so we don't alert on them."""
        try:
            for entry in Path("/proc").iterdir():
                if entry.name.isdigit():
                    self._known_pids.add(int(entry.name))
        except Exception:
            pass

    def _cleanup(self) -> None:
        for bpf in (self._bpf_exec, self._bpf_conn, self._bpf_open):
            if bpf:
                try:
                    bpf.cleanup()
                except Exception:
                    pass
        self._bpf_exec = None
        self._bpf_conn = None
        self._bpf_open = None
        self._thread = None

    # -- eBPF event callbacks -----------------------------------------------

    def _on_exec(self, cpu, data, size) -> None:
        """Process execve() events — detect boot tampering, supply-chain, etc."""
        if not self._bpf_exec:
            return
        try:
            event = self._bpf_exec["av_exec_events"].event(data)
            pid = event.pid
            ppid = event.ppid
            uid = event.uid
            comm = event.comm.decode("utf-8", errors="replace")
            filename = event.filename.decode("utf-8", errors="replace")
        except Exception:
            return

        if _is_system_proc(comm):
            return

        self._known_pids.add(pid)
        threats: List[Tuple[str, str, str]] = []  # (type, severity, desc)

        # Boot/kernel tampering
        if _BOOT_PATHS.search(filename) or _KERNEL_PATHS.search(filename):
            threats.append((
                "boot_tamper", "critical",
                f"Non-system process modifying boot/kernel: {filename}",
            ))

        # Sensitive file access (SSH keys, shadow, etc.)
        if _SENSITIVE_KEYS.search(filename):
            threats.append((
                "sensitive_access", "high",
                f"Process accessing sensitive keys: {filename}",
            ))

        # Binary executed from /tmp or /dev/shm
        if filename.startswith(("/tmp/", "/dev/shm/")):
            threats.append((
                "supply_chain", "high",
                f"Binary executed from volatile path: {filename}",
            ))

        # Curl-pipe-shell pattern (common supply-chain attack)
        if any(p in filename for p in ("curl", "wget")) and uid == 0:
            threats.append((
                "supply_chain", "medium",
                f"Root-level download tool execution: {filename}",
            ))

        # Privilege escalation — ptrace-related binaries
        if any(p in filename.lower() for p in ("ptrace", "strace", "gdb", "ltrace")):
            if uid != 0:
                threats.append((
                    "priv_escalation", "medium",
                    f"Debugging/tracing tool by non-root user: {filename}",
                ))

        for threat_type, severity, description in threats:
            self._emit_threat(ThreatEvent(
                pid=pid, ppid=ppid, uid=uid, comm=comm,
                severity=severity, threat_type=threat_type,
                description=description, filename=filename,
                files_touched=[filename],
                syscalls_made=["execve"],
            ))

    def _on_connect(self, cpu, data, size) -> None:
        """Process connect() events — detect C2, malicious IPs, etc."""
        if not self._bpf_conn:
            return
        try:
            event = self._bpf_conn["av_conn_events"].event(data)
            pid = event.pid
            uid = event.uid
            comm = event.comm.decode("utf-8", errors="replace")
            dport = ((event.dport & 0xFF) << 8) | ((event.dport >> 8) & 0xFF)
            daddr = event.daddr
            ip = (f"{daddr & 0xFF}.{(daddr >> 8) & 0xFF}."
                  f"{(daddr >> 16) & 0xFF}.{(daddr >> 24) & 0xFF}")
        except Exception:
            return

        if _is_system_proc(comm):
            return
        if ip.startswith("0.") or ip == "0.0.0.0" or ip.startswith("127."):
            return

        threats: List[Tuple[str, str, str]] = []

        # App that should never use network
        if comm.lower() in _NO_NETWORK_APPS or any(
            comm.lower().startswith(a) for a in _NO_NETWORK_APPS
        ):
            threats.append((
                "malicious_net", "critical",
                f"{comm} opened network socket to {ip}:{dport} "
                f"— this app should have NO network access",
            ))

        # Known malicious IP
        if ip in _MALICIOUS_IPS:
            threats.append((
                "malicious_net", "critical",
                f"Connection to known-malicious IP: {ip}:{dport}",
            ))

        # C2 port
        if dport in _C2_PORTS:
            threats.append((
                "malicious_net", "high",
                f"Connection to known C2/backdoor port: {ip}:{dport}",
            ))

        # Suspicious port
        if dport in _SUSPICIOUS_PORTS and dport not in _C2_PORTS:
            threats.append((
                "malicious_net", "medium",
                f"Connection to suspicious port: {ip}:{dport}",
            ))

        for threat_type, severity, description in threats:
            self._emit_threat(ThreatEvent(
                pid=pid, uid=uid, comm=comm,
                severity=severity, threat_type=threat_type,
                description=description,
                filename=_get_process_binary(pid),
                network_connections=[f"{ip}:{dport}"],
                syscalls_made=["connect"],
            ))

    def _on_openat(self, cpu, data, size) -> None:
        """Process openat() events — detect ransomware, boot writes, etc."""
        if not self._bpf_open:
            return
        try:
            event = self._bpf_open["av_open_events"].event(data)
            pid = event.pid
            uid = event.uid
            flags = event.flags
            comm = event.comm.decode("utf-8", errors="replace")
            filename = event.filename.decode("utf-8", errors="replace")
        except Exception:
            return

        if _is_system_proc(comm):
            return

        # Only care about write operations
        O_WRONLY = 0o1
        O_RDWR = 0o2
        O_CREAT = 0o100
        is_write = bool(flags & (O_WRONLY | O_RDWR | O_CREAT))

        if not is_write:
            return

        # Track write patterns for ransomware detection
        tracker = self._write_trackers.get(pid)
        if tracker is None:
            tracker = FileWriteTracker(pid=pid, comm=comm)
            self._write_trackers[pid] = tracker

        tracker.write_count += 1
        tracker.last_seen = time.monotonic()
        if "/" in filename:
            tracker.unique_dirs.add(str(Path(filename).parent))
        ext = Path(filename).suffix.lower()
        if ext:
            tracker.extensions_written.add(ext)

        # Entropy check on small files being written
        if is_write and Path(filename).exists():
            try:
                data = Path(filename).read_bytes()[:4096]
                ent = _estimate_entropy(data)
                if ent > 7.5:  # near-random = encrypted
                    tracker.high_entropy_count += 1
            except Exception:
                pass

        # Check for ransomware pattern
        if tracker.is_ransomware_pattern:
            self._emit_threat(ThreatEvent(
                pid=pid, uid=uid, comm=comm,
                severity="critical",
                threat_type="ransomware",
                description=(
                    f"RANSOMWARE PATTERN: {comm} writing {tracker.write_count} files "
                    f"at {tracker.write_rate:.1f}/sec across {len(tracker.unique_dirs)} directories. "
                    f"High-entropy writes: {tracker.high_entropy_count}. "
                    f"Extensions: {', '.join(list(tracker.extensions_written)[:10])}"
                ),
                filename=_get_process_binary(pid),
                files_touched=list(tracker.unique_dirs)[:20],
                syscalls_made=["openat", "write"],
            ))
            # Remove tracker to avoid re-alerting every write
            del self._write_trackers[pid]

        # Boot/kernel write protection
        if _BOOT_PATHS.search(filename) or _KERNEL_PATHS.search(filename):
            self._emit_threat(ThreatEvent(
                pid=pid, uid=uid, comm=comm,
                severity="critical",
                threat_type="boot_tamper",
                description=f"Process writing to boot/kernel path: {filename}",
                filename=_get_process_binary(pid),
                files_touched=[filename],
                syscalls_made=["openat"],
            ))

        # System-critical file modification
        if _SYSTEM_CRITICAL.search(filename):
            self._emit_threat(ThreatEvent(
                pid=pid, uid=uid, comm=comm,
                severity="high",
                threat_type="sensitive_access",
                description=f"Process modifying critical system file: {filename}",
                filename=_get_process_binary(pid),
                files_touched=[filename],
                syscalls_made=["openat"],
            ))

        # Clean up old trackers (>60 seconds idle)
        now = time.monotonic()
        stale = [p for p, t in self._write_trackers.items()
                 if now - t.last_seen > 60]
        for p in stale:
            del self._write_trackers[p]


# ---------------------------------------------------------------------------
# Module-level singleton and convenience API
# ---------------------------------------------------------------------------

_av_instance: Optional[SentinelAV] = None
_av_lock = threading.Lock()


def get_av() -> SentinelAV:
    """Return the singleton Sentinel AV instance."""
    global _av_instance
    with _av_lock:
        if _av_instance is None:
            _av_instance = SentinelAV()
        return _av_instance


def start_av(on_threat: Optional[Callable[[ThreatEvent, ThreatMap], None]] = None) -> str:
    """Start the global Sentinel AV engine."""
    av = get_av()
    if on_threat:
        av._on_threat = on_threat
    return av.start()


def stop_av() -> str:
    """Stop the global Sentinel AV engine."""
    return get_av().stop()


def av_status() -> Dict[str, Any]:
    """Get Sentinel AV status."""
    return get_av().status()


def av_threats() -> List[Dict]:
    """Get all detected threats as dicts."""
    return [t.to_dict() for t in get_av().threats]


def delete_threat(threat_id: str) -> str:
    """Delete a quarantined threat."""
    return get_av().delete_threat(threat_id)


def jail_threat(threat_id: str) -> str:
    """Permanently jail a threat."""
    return get_av().jail_threat(threat_id)


def release_threat(threat_id: str) -> str:
    """Release a false-positive threat."""
    return get_av().release_threat(threat_id)


def av_report() -> List[str]:
    """Generate a human-readable Sentinel AV status report."""
    av = get_av()
    lines: List[str] = []

    if not _HAS_BCC:
        lines.append("⚠ python3-bcc is not installed.")
        lines.append("  Install: sudo dnf install python3-bcc")
        lines.append("  (or: sudo apt install python3-bpfcc)")
        lines.append("")

    is_root = os.geteuid() == 0 if hasattr(os, "geteuid") else False
    if not is_root:
        lines.append("⚠ Sentinel AV requires root privileges.")
        lines.append("  Relaunch Sysfix with sudo or enable Sudo Mode.")
        lines.append("")

    st = av.status()

    # Engine status
    if st["running"]:
        lines.append(f"✓ Sentinel AV is ACTIVE")
    else:
        lines.append("● Sentinel AV is stopped.")
        lines.append("  Start it from the Health tab or CLI.")
        lines.append("")

    # Probe status
    probes = st.get("probes", {})
    lines.append("")
    lines.append("eBPF Probes:")
    for probe, active in probes.items():
        icon = "✓" if active else "✗"
        lines.append(f"  {icon} {probe}()")

    # Capabilities
    lines.append("")
    lines.append("Capabilities:")
    lines.append(f"  {'✓' if st.get('cgroups_v2') else '✗'} cgroups v2 Freezer")
    lines.append(f"  {'✓' if st.get('clamav') else '✗'} ClamAV signature scanning")

    # Stasis Chamber backend
    try:
        from sysfixai.microvm import detect_vm_backend
        backend = detect_vm_backend()
        lines.append(f"  {'✓' if backend != 'none' else '✗'} Stasis Chamber ({backend})")
    except ImportError:
        lines.append(f"  ✗ Stasis Chamber (microvm module missing)")

    # AI
    try:
        from sysfixai.ai import get_active_model
        model = get_active_model()
        lines.append(f"  {'✓' if model else '⚠'} Fyxa AI reasoning ({model or 'no model'})")
    except ImportError:
        lines.append(f"  ✗ Fyxa AI reasoning (ai module missing)")

    # Malware Verification Pipeline
    try:
        from sysfixai.malware_pipeline import pipeline_capabilities
        caps = pipeline_capabilities()
        lines.append("")
        lines.append("Malware Verification Pipeline:")
        clam_cap = caps.get("clamav", {})
        if clam_cap.get("pyclamd"):
            lines.append("  ✓ Stage 1: ClamAV (pyclamd — direct daemon)")
        elif clam_cap.get("available"):
            lines.append("  ✓ Stage 1: ClamAV (subprocess)")
        else:
            lines.append("  ✗ Stage 1: ClamAV not available")
        yara_cap = caps.get("yara", {})
        if yara_cap.get("yara_python") and yara_cap.get("rules_present"):
            lines.append("  ✓ Stage 2: YARA (rules loaded)")
        elif yara_cap.get("yara_python"):
            lines.append("  ⚠ Stage 2: YARA (no rules — run sysfix pipeline --update-yara)")
        else:
            lines.append("  ✗ Stage 2: YARA not available (pip install yara-python)")
        vt_cap = caps.get("virustotal", {})
        if vt_cap.get("available"):
            lines.append("  ✓ Stage 3: VirusTotal (API key set)")
        elif vt_cap.get("vt_py"):
            lines.append("  ⚠ Stage 3: VirusTotal (no API key)")
        else:
            lines.append("  ✗ Stage 3: VirusTotal not available (pip install vt-py)")
    except ImportError:
        pass

    # Statistics
    lines.append("")
    lines.append("Statistics:")
    lines.append(f"  Threats detected: {st['threat_count']}")
    lines.append(f"  Threats neutralised: {st['neutralised']}")
    lines.append(f"  Processes frozen: {st['frozen_processes']}")

    # Recent threats
    if st.get("latest_threats"):
        lines.append("")
        lines.append("Recent Threats:")
        sev_icons = {"low": "🟢", "medium": "🟡", "high": "🟠", "critical": "🔴"}
        for t in st["latest_threats"]:
            icon = sev_icons.get(t.get("severity", ""), "⚪")
            disp = t.get("disposition", "pending").upper()
            lines.append(
                f"  {icon} [{t.get('severity', '?').upper()}] "
                f"{t.get('threat_type', '?')} — {t.get('comm', '?')} "
                f"(PID {t.get('pid', '?')}) [{disp}]"
            )
            desc = t.get("description", "")
            if desc:
                lines.append(f"      {desc[:120]}")
    elif st["running"]:
        lines.append("")
        lines.append("  No threats detected yet — system is clean.")

    return lines


def format_threat_for_display(threat: ThreatEvent) -> Dict[str, Any]:
    """Format a threat event for GUI display (colors, labels, icons)."""
    sev_colors = {
        "low": "#22c55e",      # green
        "medium": "#f59e0b",   # amber
        "high": "#f97316",     # orange
        "critical": "#ef4444", # red
    }
    sev_icons = {
        "low": "🟢", "medium": "🟡", "high": "🟠", "critical": "🔴",
    }
    type_icons = {
        "ransomware": "🔐", "boot_tamper": "🥾", "malicious_net": "🌐",
        "priv_escalation": "👤", "sensitive_access": "🔑",
        "supply_chain": "📦", "engine_error": "⚙",
    }
    disp_labels = {
        "pending": "⏳ Pending Review",
        "neutralised": "🛡 Neutralised",
        "quarantined": "🔒 Quarantined",
        "false_positive": "✅ False Positive",
        "deleted": "🗑 Deleted",
        "jailed": "⛓ Jailed Forever",
    }

    return {
        "threat_id": threat.threat_id,
        "severity": threat.severity,
        "severity_color": sev_colors.get(threat.severity, "#6b7280"),
        "severity_icon": sev_icons.get(threat.severity, "⚪"),
        "type_icon": type_icons.get(threat.threat_type, "⚠"),
        "type_label": threat.threat_type.replace("_", " ").title(),
        "disposition": threat.disposition,
        "disposition_label": disp_labels.get(threat.disposition, threat.disposition),
        "comm": threat.comm,
        "pid": threat.pid,
        "description": threat.description,
        "frozen": threat.frozen,
        "clamav": threat.clamav_result,
        "ai_verdict": threat.ai_verdict,
        "ai_confidence": threat.ai_confidence,
        "stasis": threat.stasis_chamber,
        "pipeline_profile": threat.pipeline_profile,
    }
