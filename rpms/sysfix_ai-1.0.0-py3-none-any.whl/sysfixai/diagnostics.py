"""
Extended diagnostics module — security scanning, network checks, and system health.

Provides non-destructive, read-only system analysis.  Every function returns
a list of human-readable strings and never raises.
"""

import os
import re
import subprocess
import stat
import hashlib
import json
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
try:
    import tomllib
except Exception:  # pragma: no cover - Python < 3.11 fallback
    tomllib = None

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


# ──────────────────────────────────────────────────────────────────────────
# Security / antivirus scanning
# ──────────────────────────────────────────────────────────────────────────

def security_scan_full() -> List[str]:
    """Run every security check and return a unified report."""
    results: List[str] = []
    results.extend(check_listening_ports())
    results.extend(check_firewall_status())
    results.extend(check_failed_logins())
    results.extend(check_suid_binaries())
    results.extend(check_world_writable_dirs())
    results.extend(check_tmp_suspicious())
    results.extend(check_ssh_config())
    results.extend(check_suspicious_processes())
    results.extend(check_rootkit_tools())
    results.extend(check_user_accounts())
    return results if results else ["No security concerns detected."]


def check_listening_ports() -> List[str]:
    """List all listening TCP/UDP ports and flag unusual ones."""
    issues: List[str] = []
    well_known_safe = {22, 53, 80, 123, 323, 443, 631, 5353, 5355, 11434}  # ssh, dns, http, ntp, chrony, https, cups, mdns, llmnr, ollama
    try:
        r = subprocess.run(
            ["ss", "-tulnp"],
            capture_output=True, text=True, timeout=10,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            lines = r.stdout.strip().splitlines()
            listeners: List[str] = []
            flagged: List[str] = []
            for line in lines[1:]:  # skip header
                parts = line.split()
                if len(parts) >= 5:
                    proto = parts[0]
                    local = parts[4]
                    proc = parts[-1] if "users:" in parts[-1] else ""
                    # Extract port
                    port_str = local.rsplit(":", 1)[-1] if ":" in local else ""
                    try:
                        port = int(port_str)
                    except ValueError:
                        port = 0
                    proc_name = ""
                    m = re.search(r'\("([^"]+)"', proc)
                    if m:
                        proc_name = m.group(1)
                    entry = f"  {proto:<5} :{port:<6} {proc_name}"
                    listeners.append(entry)
                    if port and port not in well_known_safe and port < 1024:
                        flagged.append(f"Unusual low port :{port} ({proc_name or 'unknown'})")
            if listeners:
                issues.append(f"Listening services ({len(listeners)}):\n" + "\n".join(listeners))
            for f in flagged:
                issues.append(f"WARN: {f}")
    except FileNotFoundError:
        issues.append("INFO: 'ss' not found — cannot check listening ports")
    except Exception:
        pass
    return issues


def check_firewall_status() -> List[str]:
    """Check if a firewall is active (firewalld or ufw)."""
    issues: List[str] = []
    found = False
    try:
        r = subprocess.run(
            ["systemctl", "is-active", "firewalld"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.stdout.strip() == "active":
            # Get zone info
            z = subprocess.run(
                ["firewall-cmd", "--get-active-zones"],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            zone_info = z.stdout.strip() if z.returncode == 0 else ""
            issues.append(f"Firewall: firewalld ACTIVE\n  {zone_info}" if zone_info
                          else "Firewall: firewalld ACTIVE")
            found = True
        else:
            issues.append("WARN: firewalld is NOT active")
    except FileNotFoundError:
        pass
    except Exception:
        pass

    if not found:
        try:
            r = subprocess.run(
                ["ufw", "status"],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0 and "active" in r.stdout.lower():
                issues.append(f"Firewall: ufw ACTIVE")
                found = True
            elif r.returncode == 0:
                issues.append("WARN: ufw is installed but NOT active")
        except FileNotFoundError:
            pass
        except Exception:
            pass

    if not found and not issues:
        issues.append("WARN: No firewall detected (firewalld / ufw)")
    return issues


def check_failed_logins() -> List[str]:
    """Check for recent failed login attempts via journalctl."""
    issues: List[str] = []
    try:
        since = (datetime.now() - timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
        r = subprocess.run(
            ["journalctl", "--since", since, "-q", "--no-pager",
             "_SYSTEMD_UNIT=sshd.service", "SYSLOG_IDENTIFIER=sshd"],
            capture_output=True, text=True, timeout=10,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            fail_count = r.stdout.lower().count("failed password")
            invalid_count = r.stdout.lower().count("invalid user")
            if fail_count or invalid_count:
                issues.append(
                    f"SSH login attempts (last 24h): "
                    f"{fail_count} failed password, {invalid_count} invalid user"
                )
                if fail_count > 20:
                    issues.append("WARN: High number of failed SSH logins — consider fail2ban")
            else:
                issues.append("SSH: No failed login attempts in last 24h")
        else:
            issues.append("SSH: No login log entries found (sshd may not be running)")
    except FileNotFoundError:
        issues.append("INFO: journalctl not found")
    except Exception:
        pass
    return issues


def check_suid_binaries() -> List[str]:
    """Scan for SUID/SGID binaries outside normal locations."""
    issues: List[str] = []
    known_suid = {
        "/usr/bin/sudo", "/usr/bin/su", "/usr/bin/passwd", "/usr/bin/chsh",
        "/usr/bin/chfn", "/usr/bin/newgrp", "/usr/bin/gpasswd", "/usr/bin/mount",
        "/usr/bin/umount", "/usr/bin/pkexec", "/usr/bin/crontab",
        "/usr/bin/fusermount3", "/usr/bin/fusermount",
        "/usr/sbin/unix_chkpwd", "/usr/sbin/pam_timestamp_check",
        "/usr/lib/polkit-1/polkit-agent-helper-1",
        "/usr/libexec/polkit-agent-helper-1",
        "/usr/lib/Xorg.wrap", "/usr/libexec/Xorg.wrap",
    }
    suspect: List[str] = []
    try:
        # Quick scan of common dirs (avoid full / scan which is slow)
        for search_dir in ["/usr/local/bin", "/usr/local/sbin", "/opt", "/tmp", "/var/tmp"]:
            if not os.path.isdir(search_dir):
                continue
            r = subprocess.run(
                ["find", search_dir, "-perm", "/6000", "-type", "f",
                 "-maxdepth", "4"],
                capture_output=True, text=True, timeout=15,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0 and r.stdout.strip():
                for path in r.stdout.strip().splitlines():
                    path = path.strip()
                    if path and path not in known_suid:
                        suspect.append(path)
        if suspect:
            listing = "\n".join(f"  {s}" for s in suspect[:15])
            issues.append(f"WARN: Unusual SUID/SGID binaries ({len(suspect)}):\n{listing}")
        else:
            issues.append("SUID/SGID: No unusual setuid binaries found")
    except Exception:
        pass
    return issues


def check_world_writable_dirs() -> List[str]:
    """Check for world-writable directories (excluding /tmp, /var/tmp)."""
    issues: List[str] = []
    safe_ww = {"/tmp", "/var/tmp", "/var/lock", "/run/lock", "/dev/shm", "/dev/mqueue"}
    try:
        r = subprocess.run(
            ["find", "/", "-maxdepth", "3", "-type", "d", "-perm", "-0002",
             "-not", "-path", "/proc/*", "-not", "-path", "/sys/*",
             "-not", "-path", "/dev/*", "-not", "-path", "/run/*",
             "-not", "-path", "/snap/*"],
            capture_output=True, text=True, timeout=15,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            suspicious = [
                d.strip() for d in r.stdout.strip().splitlines()
                if d.strip() and d.strip() not in safe_ww and not d.strip().startswith("/tmp")
            ]
            if suspicious:
                listing = "\n".join(f"  {d}" for d in suspicious[:10])
                issues.append(f"WARN: World-writable directories ({len(suspicious)}):\n{listing}")
            else:
                issues.append("Permissions: No unusual world-writable directories")
        else:
            issues.append("Permissions: No unusual world-writable directories")
    except Exception:
        pass
    return issues


def check_tmp_suspicious() -> List[str]:
    """Scan /tmp and /dev/shm for suspicious executables or scripts."""
    issues: List[str] = []
    suspect: List[str] = []
    for scan_dir in ["/tmp", "/dev/shm", "/var/tmp"]:
        if not os.path.isdir(scan_dir):
            continue
        try:
            r = subprocess.run(
                ["find", scan_dir, "-maxdepth", "3", "-type", "f",
                 "(", "-executable", "-o", "-name", "*.sh", "-o",
                 "-name", "*.py", "-o", "-name", "*.pl", "-o",
                 "-name", "*.elf", ")"],
                capture_output=True, text=True, timeout=10,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0 and r.stdout.strip():
                for f in r.stdout.strip().splitlines():
                    f = f.strip()
                    if f:
                        suspect.append(f)
        except Exception:
            pass
    if suspect:
        listing = "\n".join(f"  {s}" for s in suspect[:15])
        issues.append(f"WARN: Executables in temp dirs ({len(suspect)}):\n{listing}")
    else:
        issues.append("Temp dirs: No suspicious executables found")
    return issues


def check_ssh_config() -> List[str]:
    """Check SSH server config for common security weaknesses."""
    issues: List[str] = []
    sshd_conf = Path("/etc/ssh/sshd_config")
    if not sshd_conf.exists():
        issues.append("SSH server: Not installed (no sshd_config)")
        return issues
    try:
        text = sshd_conf.read_text()
        # Check root login
        if re.search(r"^\s*PermitRootLogin\s+yes", text, re.MULTILINE | re.IGNORECASE):
            issues.append("WARN: SSH allows root login (PermitRootLogin yes)")
        else:
            issues.append("SSH: Root login disabled or restricted")
        # Check password auth
        if re.search(r"^\s*PasswordAuthentication\s+yes", text, re.MULTILINE | re.IGNORECASE):
            issues.append("INFO: SSH allows password authentication (consider key-only)")
        # Check default port
        port_match = re.search(r"^\s*Port\s+(\d+)", text, re.MULTILINE)
        if port_match:
            port = int(port_match.group(1))
            if port == 22:
                issues.append("INFO: SSH on default port 22")
        else:
            issues.append("INFO: SSH on default port 22")
    except PermissionError:
        issues.append("SSH config: Cannot read (permission denied — run as root for full scan)")
    except Exception:
        pass
    return issues


def check_suspicious_processes() -> List[str]:
    """Flag processes with suspicious characteristics."""
    issues: List[str] = []
    if not HAS_PSUTIL:
        return issues
    suspect: List[str] = []
    suspicious_names = {
        "cryptominer", "xmrig", "minerd", "cpuminer",
        "stratum", "nanopool", "ethminer", "t-rex",
        "nbminer", "phoenixminer", "lolminer",
    }
    try:
        for proc in psutil.process_iter(["pid", "name", "exe", "cpu_percent"]):
            try:
                info = proc.info
                name_lower = (info.get("name") or "").lower()
                exe = info.get("exe") or ""
                # Known miner names
                if any(s in name_lower for s in suspicious_names):
                    suspect.append(f"PID {info['pid']}: {info['name']} ({exe})")
                # Process running from /tmp or /dev/shm
                if exe and (exe.startswith("/tmp/") or exe.startswith("/dev/shm/") or
                            exe.startswith("/var/tmp/")):
                    suspect.append(f"PID {info['pid']}: {info['name']} running from {exe}")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except Exception:
        pass
    if suspect:
        listing = "\n".join(f"  {s}" for s in suspect[:10])
        issues.append(f"WARN: Suspicious processes ({len(suspect)}):\n{listing}")
    else:
        issues.append("Processes: No suspicious activity detected")
    return issues


def check_rootkit_tools() -> List[str]:
    """Run rkhunter or chkrootkit if available, otherwise do manual checks."""
    issues: List[str] = []
    import shutil as _sh

    # Try rkhunter
    if _sh.which("rkhunter"):
        try:
            r = subprocess.run(
                ["sudo", "rkhunter", "--check", "--skip-keypress", "--report-warnings-only", "-q"],
                capture_output=True, text=True, timeout=120,
                stdin=subprocess.DEVNULL,
            )
            if r.stdout.strip():
                issues.append(f"rkhunter warnings:\n  {r.stdout.strip()[:500]}")
            else:
                issues.append("rkhunter: No warnings")
        except subprocess.TimeoutExpired:
            issues.append("INFO: rkhunter scan timed out")
        except Exception:
            issues.append("INFO: rkhunter found but scan failed (may need sudo)")
    elif _sh.which("chkrootkit"):
        try:
            r = subprocess.run(
                ["sudo", "chkrootkit", "-q"],
                capture_output=True, text=True, timeout=120,
                stdin=subprocess.DEVNULL,
            )
            if r.stdout.strip():
                output = r.stdout.strip()[:500]
                if "not found" not in output.lower() and "nothing found" not in output.lower():
                    issues.append(f"chkrootkit output:\n  {output}")
                else:
                    issues.append("chkrootkit: No infections found")
            else:
                issues.append("chkrootkit: Clean scan")
        except subprocess.TimeoutExpired:
            issues.append("INFO: chkrootkit scan timed out")
        except Exception:
            issues.append("INFO: chkrootkit found but scan failed (may need sudo)")
    else:
        issues.append("INFO: No rootkit scanner installed (install rkhunter or chkrootkit for deeper scans)")
    return issues


def check_user_accounts() -> List[str]:
    """Check for unusual user accounts."""
    issues: List[str] = []
    try:
        with open("/etc/passwd", "r") as f:
            lines = f.readlines()
        uid_0_users = []
        no_shell_count = 0
        regular_users = []
        for line in lines:
            parts = line.strip().split(":")
            if len(parts) >= 7:
                user, _, uid_str, _, _, home, shell = parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]
                uid = int(uid_str) if uid_str.isdigit() else -1
                if uid == 0 and user != "root":
                    uid_0_users.append(user)
                if uid >= 1000 and "/nologin" not in shell and "/false" not in shell:
                    regular_users.append(user)
                if "/nologin" in shell or "/false" in shell:
                    no_shell_count += 1
        if uid_0_users:
            issues.append(f"WARN: Non-root users with UID 0: {', '.join(uid_0_users)}")
        if regular_users:
            issues.append(f"User accounts ({len(regular_users)}): {', '.join(regular_users)}")
        else:
            issues.append("User accounts: No regular login users found")
    except Exception:
        pass
    return issues


# ──────────────────────────────────────────────────────────────────────────
# Network diagnostics
# ──────────────────────────────────────────────────────────────────────────

def network_diagnostics() -> List[str]:
    """Run a full network health check."""
    results: List[str] = []
    results.extend(check_network_interfaces())
    results.extend(check_dns_resolution())
    results.extend(check_gateway_latency())
    results.extend(check_internet_connectivity())
    return results if results else ["Network diagnostics: No data available"]


def check_wifi_info() -> List[str]:
    """Show Wi-Fi connection details (SSID, BSSID, signal, speed, quality)."""
    issues: List[str] = []
    import shutil as _sh
    if _sh.which("nmcli"):
        try:
            rows = _nmcli_wifi_rows()
            active = [row for row in rows if row.get("active") == "yes"]
            if active:
                for row in active:
                    ssid = row.get("ssid") or "<hidden>"
                    signal = row.get("signal", "?")
                    freq = row.get("freq", "?")
                    rate = row.get("rate", "?")
                    sec = row.get("security", "?")
                    bssid = row.get("bssid") or "?"
                    chan = row.get("chan") or "?"
                    issues.append(
                        f"Wi-Fi: {ssid}  signal {signal}%  {freq} MHz  {rate}  "
                        f"chan {chan}  bssid {bssid}  [{sec}]"
                    )

                    sig_v = _as_int(signal)
                    rate_mbps = _rate_to_mbps(rate)
                    if sig_v is not None:
                        if sig_v < 35:
                            issues.append("WARN: Wi-Fi signal is weak (<35%). Move closer or reduce interference.")
                        elif sig_v < 55:
                            issues.append("INFO: Wi-Fi signal is moderate. Throughput may vary.")
                    if rate_mbps is not None and rate_mbps < 80:
                        issues.append(
                            f"WARN: Link rate is low ({rate_mbps:.0f} Mbit/s). "
                            "Consider moving to 5/6 GHz or a stronger access point."
                        )

                    better = _best_same_ssid_candidate(rows, row)
                    if better:
                        issues.append(
                            "WARN: Stronger access point detected for this SSID: "
                            f"{better.get('bssid', '?')} ({better.get('signal', '?')}%). "
                            "Run 'Optimize Wi-Fi' in Network Actions to roam to it."
                        )
            else:
                issues.append("INFO: No active Wi-Fi connection")
                best = _best_overall_wifi(rows)
                if best:
                    issues.append(
                        "INFO: Strongest nearby network: "
                        f"{best.get('ssid') or '<hidden>'} "
                        f"{best.get('signal', '?')}%  "
                        f"{best.get('rate', '?')}  bssid {best.get('bssid', '?')}"
                    )
        except Exception:
            issues.append("INFO: Could not query Wi-Fi")
    elif _sh.which("iwconfig"):
        try:
            r = subprocess.run(
                ["iwconfig"], capture_output=True, text=True, timeout=10,
                stdin=subprocess.DEVNULL,
            )
            ssid_m = re.search(r'ESSID:"([^"]+)"', r.stdout)
            sig_m = re.search(r"Signal level=(-?\d+)", r.stdout)
            freq_m = re.search(r"Frequency:(\S+)", r.stdout)
            bssid_m = re.search(r"Access Point:\s*([0-9A-Fa-f:]{17})", r.stdout)
            if ssid_m:
                info = f"Wi-Fi: {ssid_m.group(1)}"
                if sig_m:
                    info += f"  signal {sig_m.group(1)}dBm"
                if freq_m:
                    info += f"  {freq_m.group(1)}"
                if bssid_m:
                    info += f"  bssid {bssid_m.group(1)}"
                issues.append(info)
            else:
                issues.append("INFO: No active Wi-Fi connection")
        except Exception:
            pass
    else:
        issues.append("INFO: nmcli/iwconfig not available for Wi-Fi check")
    return issues


def optimize_wifi_connection() -> List[str]:
    """Roam to a stronger BSSID for the current SSID when available."""
    import shutil as _sh
    if not _sh.which("nmcli"):
        return ["INFO: nmcli is not installed; cannot optimize Wi-Fi automatically."]

    try:
        rows = _nmcli_wifi_rows()
        active = next((row for row in rows if row.get("active") == "yes"), None)
        if not active:
            return ["INFO: No active Wi-Fi connection to optimize."]

        current_ssid = active.get("ssid", "")
        current_bssid = active.get("bssid", "")
        current_signal = _as_int(active.get("signal", ""))
        target = _best_same_ssid_candidate(rows, active)
        if not target:
            return ["Wi-Fi already appears to be using the best available access point for this SSID."]

        target_bssid = target.get("bssid", "")
        target_signal = _as_int(target.get("signal", "")) or 0
        if not target_bssid:
            return ["INFO: Candidate access point does not have a valid BSSID."]

        r = subprocess.run(
            ["nmcli", "device", "wifi", "connect", target_bssid],
            capture_output=True, text=True, timeout=20,
            stdin=subprocess.DEVNULL,
        )
        out = (r.stdout or r.stderr or "").strip()
        if r.returncode == 0:
            results = [
                "Wi-Fi optimization: success.",
                f"Roamed from {current_bssid or '?'} ({current_signal or '?'}%) "
                f"to {target_bssid} ({target_signal}%) on SSID '{current_ssid or '<hidden>'}'.",
            ]
            if out:
                results.append(f"INFO: {out}")
            results.extend(check_wifi_info())
            return results
        if "Secrets were required" in out or "No network with SSID" in out:
            return [
                "WARN: Could not auto-roam to stronger access point.",
                f"Reason: {out or 'Network credentials may be required.'}",
            ]
        return [
            "WARN: Wi-Fi optimization failed.",
            f"Reason: {out or f'nmcli exited with {r.returncode}'}",
        ]
    except subprocess.TimeoutExpired:
        return ["WARN: Wi-Fi optimization timed out."]
    except Exception as e:
        return [f"WARN: Wi-Fi optimization error: {e}"]


def _nmcli_split(line: str) -> List[str]:
    """Split nmcli terse output while respecting escaped delimiters."""
    parts: List[str] = []
    buf: List[str] = []
    escaped = False
    for ch in line.rstrip("\n"):
        if escaped:
            buf.append(ch)
            escaped = False
            continue
        if ch == "\\":
            escaped = True
            continue
        if ch == ":":
            parts.append("".join(buf))
            buf = []
            continue
        buf.append(ch)
    parts.append("".join(buf))
    return parts


def _nmcli_wifi_rows() -> List[Dict[str, str]]:
    r = subprocess.run(
        ["nmcli", "-t", "-f", "ACTIVE,SSID,BSSID,SIGNAL,FREQ,RATE,CHAN,SECURITY", "dev", "wifi"],
        capture_output=True, text=True, timeout=10,
        stdin=subprocess.DEVNULL,
    )
    if r.returncode != 0:
        return []
    rows: List[Dict[str, str]] = []
    for raw in r.stdout.strip().splitlines():
        if not raw:
            continue
        cols = _nmcli_split(raw)
        if len(cols) < 8:
            cols.extend([""] * (8 - len(cols)))
        rows.append(
            {
                "active": cols[0].strip().lower(),
                "ssid": cols[1].strip(),
                "bssid": cols[2].strip(),
                "signal": cols[3].strip(),
                "freq": cols[4].strip(),
                "rate": cols[5].strip(),
                "chan": cols[6].strip(),
                "security": cols[7].strip(),
            }
        )
    return rows


def _as_int(value: str) -> Optional[int]:
    m = re.search(r"-?\d+", str(value))
    if not m:
        return None
    try:
        return int(m.group(0))
    except Exception:
        return None


def _rate_to_mbps(rate: str) -> Optional[float]:
    m = re.search(r"([\d.]+)\s*Mbit/s", str(rate), flags=re.IGNORECASE)
    if not m:
        m = re.search(r"([\d.]+)", str(rate))
    if not m:
        return None
    try:
        return float(m.group(1))
    except Exception:
        return None


def _best_overall_wifi(rows: List[Dict[str, str]]) -> Optional[Dict[str, str]]:
    best = None
    best_sig = -1
    for row in rows:
        sig = _as_int(row.get("signal", ""))
        if sig is None:
            continue
        if sig > best_sig:
            best_sig = sig
            best = row
    return best


def _best_same_ssid_candidate(rows: List[Dict[str, str]], active_row: Dict[str, str]) -> Optional[Dict[str, str]]:
    ssid = active_row.get("ssid", "")
    if not ssid:
        return None
    cur_bssid = active_row.get("bssid", "")
    cur_sig = _as_int(active_row.get("signal", "")) or 0

    candidates = []
    for row in rows:
        if row.get("ssid", "") != ssid:
            continue
        if row.get("bssid", "") == cur_bssid:
            continue
        sig = _as_int(row.get("signal", ""))
        if sig is None:
            continue
        if sig >= cur_sig + 8:
            candidates.append((sig, row))
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def check_public_ip() -> List[str]:
    """Fetch the public IP address."""
    issues: List[str] = []
    for url in ["https://api.ipify.org", "https://ifconfig.me/ip"]:
        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header("User-Agent", "curl/7.0")
            with urllib.request.urlopen(req, timeout=5) as resp:
                ip = resp.read().decode().strip()
                if ip:
                    issues.append(f"Public IP: {ip}")
                    return issues
        except Exception:
            continue
    issues.append("WARN: Could not determine public IP")
    return issues


def check_traceroute(host: str = "8.8.8.8", max_hops: int = 15) -> List[str]:
    """Run traceroute to a host and return hop-by-hop results."""
    issues: List[str] = []
    import shutil as _sh
    cmd = None
    if _sh.which("traceroute"):
        cmd = ["traceroute", "-m", str(max_hops), "-w", "2", host]
    elif _sh.which("tracepath"):
        cmd = ["tracepath", "-m", str(max_hops), host]
    else:
        return ["INFO: traceroute/tracepath not installed"]
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=45,
            stdin=subprocess.DEVNULL,
        )
        lines = r.stdout.strip().splitlines()
        if lines:
            issues.append(f"Traceroute to {host} ({len(lines)} hops):")
            for line in lines[:max_hops + 1]:
                issues.append(f"  {line.strip()}")
        else:
            issues.append(f"WARN: Traceroute to {host} returned no output")
    except subprocess.TimeoutExpired:
        issues.append(f"WARN: Traceroute to {host} timed out")
    except Exception as e:
        issues.append(f"WARN: Traceroute error: {e}")
    return issues


def check_active_connections() -> List[str]:
    """Summarise active network connections by state."""
    issues: List[str] = []
    if not HAS_PSUTIL:
        return ["INFO: psutil not available for connection check"]
    try:
        conns = psutil.net_connections(kind="inet")
        states: Dict[str, int] = {}
        for c in conns:
            st = c.status if c.status else "NONE"
            states[st] = states.get(st, 0) + 1
        summary_parts = [f"{st}: {n}" for st, n in sorted(states.items())]
        issues.append(f"Active connections: {sum(states.values())} total")
        if summary_parts:
            issues.append(f"  States: {', '.join(summary_parts)}")
        # Show a few established connections
        established = [c for c in conns if c.status == "ESTABLISHED" and c.raddr]
        if established:
            issues.append(f"  Established: {len(established)} remote connections")
            for c in established[:8]:
                rip, rport = c.raddr
                issues.append(f"    → {rip}:{rport}")
            if len(established) > 8:
                issues.append(f"    … and {len(established) - 8} more")
    except PermissionError:
        issues.append("INFO: Need root to list all connections")
    except Exception:
        pass
    return issues


def check_bandwidth_usage() -> List[str]:
    """Show current bandwidth counters from psutil."""
    issues: List[str] = []
    if not HAS_PSUTIL:
        return ["INFO: psutil not available for bandwidth check"]
    try:
        io = psutil.net_io_counters()
        def _human(b: int) -> str:
            for unit in ["B", "KB", "MB", "GB", "TB"]:
                if b < 1024:
                    return f"{b:.1f} {unit}"
                b /= 1024
            return f"{b:.1f} PB"
        issues.append(f"Network I/O (since boot):")
        issues.append(f"  Sent: {_human(io.bytes_sent)}  |  Received: {_human(io.bytes_recv)}")
        issues.append(f"  Packets: {io.packets_sent} sent, {io.packets_recv} recv")
        if io.errin or io.errout or io.dropin or io.dropout:
            issues.append(f"  WARN: Errors in={io.errin} out={io.errout}  "
                          f"Drops in={io.dropin} out={io.dropout}")
    except Exception:
        pass
    return issues


def check_ping(host: str = "8.8.8.8", count: int = 4) -> List[str]:
    """Ping a host and return results."""
    issues: List[str] = []
    try:
        r = subprocess.run(
            ["ping", "-c", str(count), "-W", "2", host],
            capture_output=True, text=True, timeout=15,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            avg_match = re.search(r"rtt.*=\s*[\d.]+/([\d.]+)/([\d.]+)", r.stdout)
            loss_match = re.search(r"(\d+)% packet loss", r.stdout)
            loss = loss_match.group(1) if loss_match else "?"
            if avg_match:
                avg_ms = float(avg_match.group(1))
                issues.append(f"Ping {host}: {avg_ms:.1f}ms avg, {loss}% loss")
            else:
                issues.append(f"Ping {host}: Reachable, {loss}% loss")
        else:
            issues.append(f"WARN: Ping {host} failed — host unreachable")
    except subprocess.TimeoutExpired:
        issues.append(f"WARN: Ping {host} timed out")
    except Exception as e:
        issues.append(f"WARN: Ping error: {e}")
    return issues


def check_firewall_brief() -> List[str]:
    """Quick firewall status summary for network context."""
    issues: List[str] = []
    import shutil as _sh
    if _sh.which("firewall-cmd"):
        try:
            r = subprocess.run(
                ["firewall-cmd", "--state"],
                capture_output=True, text=True, timeout=10,
                stdin=subprocess.DEVNULL,
            )
            state = r.stdout.strip()
            if r.returncode == 0 and "running" in state:
                issues.append("Firewall: Active (firewalld)")
                # Get default zone
                z = subprocess.run(
                    ["firewall-cmd", "--get-default-zone"],
                    capture_output=True, text=True, timeout=5,
                    stdin=subprocess.DEVNULL,
                )
                if z.stdout.strip():
                    issues.append(f"  Default zone: {z.stdout.strip()}")
            else:
                issues.append("WARN: Firewall is not running")
        except Exception:
            pass
    elif _sh.which("ufw"):
        try:
            r = subprocess.run(
                ["ufw", "status"],
                capture_output=True, text=True, timeout=10,
                stdin=subprocess.DEVNULL,
            )
            if "active" in r.stdout.lower():
                issues.append("Firewall: Active (ufw)")
            else:
                issues.append("WARN: Firewall is inactive (ufw)")
        except Exception:
            pass
    else:
        issues.append("INFO: No firewall manager found (firewalld/ufw)")
    return issues


def check_network_interfaces() -> List[str]:
    """List active network interfaces with IPs."""
    issues: List[str] = []
    if not HAS_PSUTIL:
        return ["INFO: psutil not available for network check"]
    try:
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        active = []
        for iface, addr_list in addrs.items():
            if iface == "lo":
                continue
            iface_stat = stats.get(iface)
            is_up = iface_stat.isup if iface_stat else False
            if is_up:
                ipv4 = ""
                for addr in addr_list:
                    if addr.family.name == "AF_INET":
                        ipv4 = addr.address
                        break
                speed = f"{iface_stat.speed}Mbps" if iface_stat and iface_stat.speed > 0 else "?"
                active.append(f"  {iface}: {ipv4 or 'no IPv4'} ({speed})")
        if active:
            issues.append("Active interfaces:\n" + "\n".join(active))
        else:
            issues.append("WARN: No active network interfaces detected")
    except Exception:
        pass
    return issues


def check_dns_resolution() -> List[str]:
    """Test DNS resolution for common domains."""
    issues: List[str] = []
    import socket
    test_domains = ["google.com", "cloudflare.com"]
    resolved = 0
    for domain in test_domains:
        try:
            socket.getaddrinfo(domain, 80, socket.AF_INET, socket.SOCK_STREAM)
            resolved += 1
        except Exception:
            issues.append(f"WARN: DNS resolution failed for {domain}")
    if resolved == len(test_domains):
        issues.append("DNS: Resolution working")
    # Show configured DNS servers
    try:
        resolv = Path("/etc/resolv.conf").read_text()
        servers = re.findall(r"^\s*nameserver\s+(\S+)", resolv, re.MULTILINE)
        if servers:
            issues.append(f"DNS servers: {', '.join(servers)}")
    except Exception:
        pass
    return issues


def check_gateway_latency() -> List[str]:
    """Ping the default gateway and report latency."""
    issues: List[str] = []
    try:
        r = subprocess.run(
            ["ip", "route", "show", "default"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        gw_match = re.search(r"via\s+(\S+)", r.stdout)
        if gw_match:
            gw = gw_match.group(1)
            p = subprocess.run(
                ["ping", "-c", "3", "-W", "2", gw],
                capture_output=True, text=True, timeout=10,
                stdin=subprocess.DEVNULL,
            )
            if p.returncode == 0:
                avg_match = re.search(r"rtt.*=\s*[\d.]+/([\d.]+)", p.stdout)
                avg_ms = float(avg_match.group(1)) if avg_match else -1
                if avg_ms > 0:
                    status = "OK" if avg_ms < 5 else ("Slow" if avg_ms < 50 else "WARN: Very slow")
                    issues.append(f"Gateway {gw}: {avg_ms:.1f}ms avg ({status})")
                else:
                    issues.append(f"Gateway {gw}: Reachable")
            else:
                issues.append(f"WARN: Gateway {gw} unreachable")
        else:
            issues.append("WARN: No default gateway found")
    except Exception:
        pass
    return issues


def check_internet_connectivity() -> List[str]:
    """Quick internet connectivity test."""
    issues: List[str] = []
    try:
        import urllib.request
        req = urllib.request.Request(
            "http://connectivitycheck.gstatic.com/generate_204",
            method="HEAD",
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 204:
                issues.append("Internet: Connected")
            else:
                issues.append(f"Internet: Unexpected status {resp.status}")
    except Exception:
        issues.append("WARN: Internet connectivity check failed")
    return issues


# ──────────────────────────────────────────────────────────────────────────
# System health extras
# ──────────────────────────────────────────────────────────────────────────

def check_pending_updates() -> List[str]:
    """Check for available system updates (Fedora / Debian)."""
    issues: List[str] = []
    import shutil as _sh
    if _sh.which("dnf"):
        try:
            r = subprocess.run(
                ["dnf", "check-update", "-q", "--refresh"],
                capture_output=True, text=True, timeout=60,
                stdin=subprocess.DEVNULL,
            )
            # dnf returns 100 if updates available, 0 if none
            if r.returncode == 100 and r.stdout.strip():
                lines = [l for l in r.stdout.strip().splitlines() if l.strip()]
                issues.append(f"System updates available: {len(lines)} packages")
            elif r.returncode == 0:
                issues.append("System updates: Fully up to date")
            else:
                issues.append("System updates: Could not check (dnf error)")
        except subprocess.TimeoutExpired:
            issues.append("INFO: Update check timed out")
        except Exception:
            pass
    elif _sh.which("apt"):
        try:
            subprocess.run(
                ["apt", "update", "-qq"],
                capture_output=True, text=True, timeout=60,
                stdin=subprocess.DEVNULL,
            )
            r = subprocess.run(
                ["apt", "list", "--upgradable", "-qq"],
                capture_output=True, text=True, timeout=30,
                stdin=subprocess.DEVNULL,
            )
            if r.stdout.strip():
                lines = [l for l in r.stdout.strip().splitlines() if l.strip()]
                issues.append(f"System updates available: {len(lines)} packages")
            else:
                issues.append("System updates: Fully up to date")
        except Exception:
            pass
    else:
        issues.append("INFO: No supported package manager found for update check")
    return issues


def check_pending_updates_detailed() -> List[str]:
    """Check for available system updates with package-level detail."""
    issues: List[str] = []
    import shutil as _sh
    if _sh.which("dnf"):
        try:
            r = subprocess.run(
                ["dnf", "check-update", "-q", "--refresh"],
                capture_output=True, text=True, timeout=90,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 100 and r.stdout.strip():
                lines = [l for l in r.stdout.strip().splitlines() if l.strip()]
                issues.append(f"Updates available: {len(lines)} packages\n")
                # Categorise: security vs regular (rough heuristic)
                for line in lines[:60]:
                    parts = line.split()
                    pkg_name = parts[0] if parts else line.strip()
                    issues.append(f"  • {pkg_name}")
                if len(lines) > 60:
                    issues.append(f"  … and {len(lines) - 60} more")
                # Check for security updates specifically
                try:
                    sr = subprocess.run(
                        ["dnf", "updateinfo", "list", "--security", "-q"],
                        capture_output=True, text=True, timeout=30,
                        stdin=subprocess.DEVNULL,
                    )
                    sec_lines = [l for l in sr.stdout.strip().splitlines() if l.strip()]
                    if sec_lines:
                        issues.append(f"\nWARN: {len(sec_lines)} security updates pending!")
                    else:
                        issues.append("\nNo security-specific updates pending.")
                except Exception:
                    pass
            elif r.returncode == 0:
                issues.append("System updates: Fully up to date ✓")
            else:
                issues.append("System updates: Could not check (dnf error)")
        except subprocess.TimeoutExpired:
            issues.append("INFO: Update check timed out")
        except Exception:
            pass
    elif _sh.which("apt"):
        try:
            subprocess.run(
                ["apt", "update", "-qq"],
                capture_output=True, text=True, timeout=60,
                stdin=subprocess.DEVNULL,
            )
            r = subprocess.run(
                ["apt", "list", "--upgradable"],
                capture_output=True, text=True, timeout=30,
                stdin=subprocess.DEVNULL,
            )
            if r.stdout.strip():
                lines = [l for l in r.stdout.strip().splitlines()
                         if l.strip() and not l.startswith("Listing")]
                issues.append(f"Updates available: {len(lines)} packages\n")
                for line in lines[:60]:
                    pkg = line.split("/")[0] if "/" in line else line.strip()
                    issues.append(f"  • {pkg}")
                if len(lines) > 60:
                    issues.append(f"  … and {len(lines) - 60} more")
            else:
                issues.append("System updates: Fully up to date ✓")
        except Exception:
            pass
    else:
        issues.append("INFO: No supported package manager found")
    return issues


def check_systemd_failed() -> List[str]:
    """Check for failed systemd services."""
    issues: List[str] = []
    try:
        r = subprocess.run(
            ["systemctl", "--failed", "--no-pager", "--no-legend", "-q"],
            capture_output=True, text=True, timeout=10,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            failed = r.stdout.strip().splitlines()
            names = []
            for line in failed:
                parts = line.split()
                if parts:
                    names.append(parts[0].replace(".service", ""))
            if names:
                issues.append(f"Failed services ({len(names)}): {', '.join(names[:10])}")
        else:
            issues.append("Systemd: No failed services")
    except Exception:
        pass
    return issues


def check_boot_time() -> List[str]:
    """Report system boot time and uptime."""
    issues: List[str] = []
    if HAS_PSUTIL:
        try:
            import time
            boot = psutil.boot_time()
            boot_dt = datetime.fromtimestamp(boot)
            uptime_sec = time.time() - boot
            days = int(uptime_sec // 86400)
            hours = int((uptime_sec % 86400) // 3600)
            mins = int((uptime_sec % 3600) // 60)
            parts = []
            if days:
                parts.append(f"{days}d")
            parts.append(f"{hours}h {mins}m")
            issues.append(f"Boot time: {boot_dt.strftime('%Y-%m-%d %H:%M')} (uptime: {' '.join(parts)})")
        except Exception:
            pass
    # systemd-analyze for boot speed
    try:
        r = subprocess.run(
            ["systemd-analyze"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            issues.append(f"Boot speed: {r.stdout.strip().splitlines()[0].strip()}")
    except Exception:
        pass
    return issues


def check_journal_errors() -> List[str]:
    """Scan recent journal for critical/error messages."""
    issues: List[str] = []
    try:
        since = (datetime.now() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        r = subprocess.run(
            ["journalctl", "--since", since, "-p", "err", "--no-pager", "-q",
             "--output=short-monotonic"],
            capture_output=True, text=True, timeout=10,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            lines = r.stdout.strip().splitlines()
            issues.append(f"Journal errors (last 1h): {len(lines)} entries")
            # Show first few unique
            seen = set()
            samples = []
            for line in lines:
                # Simplify for dedup
                key = re.sub(r"\d+", "N", line)[-80:]
                if key not in seen:
                    seen.add(key)
                    samples.append(line.strip()[-120:])
                if len(samples) >= 5:
                    break
            if samples:
                issues.append("  Recent errors:\n" + "\n".join(f"    {s}" for s in samples))
        else:
            issues.append("Journal: No errors in the last hour")
    except Exception:
        pass
    return issues


def check_usb_devices() -> List[str]:
    """List connected USB devices."""
    issues: List[str] = []
    try:
        r = subprocess.run(
            ["lsusb"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            devices = r.stdout.strip().splitlines()
            # Filter out hubs
            real_devices = [d for d in devices if "hub" not in d.lower()]
            issues.append(f"USB devices ({len(real_devices)}):\n" +
                          "\n".join(f"  {d.strip()}" for d in real_devices[:15]))
        else:
            issues.append("USB: No devices detected")
    except FileNotFoundError:
        issues.append("INFO: lsusb not found")
    except Exception:
        pass
    return issues


def check_smart_health() -> List[str]:
    """Check SMART disk health if smartctl is available."""
    issues: List[str] = []
    import shutil as _sh
    if not _sh.which("smartctl"):
        issues.append("INFO: smartctl not installed (install smartmontools for disk health)")
        return issues
    # Find block devices
    try:
        r = subprocess.run(
            ["lsblk", "-dnpo", "NAME,TYPE"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            for line in r.stdout.strip().splitlines():
                parts = line.split()
                if len(parts) >= 2 and parts[1] == "disk":
                    dev = parts[0]
                    sr = subprocess.run(
                        ["sudo", "smartctl", "-H", dev],
                        capture_output=True, text=True, timeout=10,
                        stdin=subprocess.DEVNULL,
                    )
                    if sr.returncode == 0 and sr.stdout:
                        if "PASSED" in sr.stdout:
                            issues.append(f"SMART {dev}: PASSED")
                        elif "FAILED" in sr.stdout:
                            issues.append(f"WARN: SMART {dev}: FAILED — disk may be failing!")
                        else:
                            issues.append(f"SMART {dev}: Status unknown")
    except Exception:
        issues.append("SMART: Could not check disk health")
    return issues


# ──────────────────────────────────────────────────────────────────────────
# Self-update — check & pull from GitHub (supports private repos via token)
# ──────────────────────────────────────────────────────────────────────────

_REPO_ROOT: Optional[Path] = None

# GitHub coordinates — change these if you fork / rename the project
_GH_OWNER = "useofscript"
_GH_REPO  = "Sysfix-Releases"


def check_sysfix_integrity(max_files: int = 700) -> List[str]:
    """Verify that key Sysfix files look intact and parse correctly.

    This is a local sanity check (no network). It validates readability,
    basic format/syntax, and computes a session fingerprint.
    """
    issues: List[str] = []
    repo = _find_repo_root()
    base = repo if repo is not None else Path(__file__).resolve().parent.parent

    scan_roots: List[Path] = []
    pkg_dir = base / "sysfixai"
    if pkg_dir.is_dir():
        scan_roots.append(pkg_dir)
    else:
        scan_roots.append(Path(__file__).resolve().parent)

    script_paths: List[Path] = []
    for rel in ("sysfix", "sysfix-launcher", "pyproject.toml", "README.md"):
        p = base / rel
        if p.is_file():
            script_paths.append(p)

    allow_ext = {
        ".py", ".toml", ".json", ".md", ".txt", ".desktop",
        ".png", ".jpg", ".jpeg", ".svg",
    }
    skip_dirs = {"__pycache__", ".git", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
    allow_empty = {"__init__.py"}
    allow_empty_ext = {".py", ".md", ".txt"}

    total = 0
    warnings = 0
    errors = 0
    digest = hashlib.sha256()

    def _iter_candidate_files():
        yielded = set()
        for p in script_paths:
            yielded.add(str(p))
            yield p
        for root in scan_roots:
            for p in sorted(root.rglob("*")):
                if not p.is_file():
                    continue
                if any(part in skip_dirs for part in p.parts):
                    continue
                if str(p) in yielded:
                    continue
                ext = p.suffix.lower()
                if ext not in allow_ext:
                    continue
                yielded.add(str(p))
                yield p

    for fp in _iter_candidate_files():
        total += 1
        if total > max_files:
            issues.append(f"INFO: Integrity check capped at {max_files} files.")
            break
        rel = str(fp.relative_to(base)) if fp.is_relative_to(base) else fp.name
        try:
            blob = fp.read_bytes()
        except Exception as e:
            issues.append(f"ERROR: Integrity: unreadable file: {rel} ({e})")
            errors += 1
            continue

        digest.update(rel.encode("utf-8", errors="ignore"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(blob).digest())

        if len(blob) == 0 and fp.name not in allow_empty and fp.suffix.lower() not in allow_empty_ext:
            issues.append(f"WARN: Integrity: suspicious empty file: {rel}")
            warnings += 1
            continue

        ext = fp.suffix.lower()
        if ext == ".py":
            try:
                src = blob.decode("utf-8")
                compile(src, str(fp), "exec")
            except Exception as e:
                issues.append(f"ERROR: Integrity: Python parse failed: {rel} ({e})")
                errors += 1
        elif ext == ".json":
            try:
                json.loads(blob.decode("utf-8"))
            except Exception as e:
                issues.append(f"ERROR: Integrity: JSON parse failed: {rel} ({e})")
                errors += 1
        elif ext == ".toml" and tomllib is not None:
            try:
                tomllib.loads(blob.decode("utf-8"))
            except Exception as e:
                issues.append(f"ERROR: Integrity: TOML parse failed: {rel} ({e})")
                errors += 1
        elif ext == ".png" and not blob.startswith(b"\x89PNG\r\n\x1a\n"):
            issues.append(f"ERROR: Integrity: invalid PNG header: {rel}")
            errors += 1

    fingerprint = digest.hexdigest()[:16]
    if errors == 0 and warnings == 0:
        issues.insert(0, f"Integrity check: PASSED ({total} files verified)")
    elif errors == 0:
        issues.insert(0, f"WARN: Integrity check passed with {warnings} warning(s) across {total} files")
    else:
        issues.insert(0, f"WARN: Integrity check found {errors} error(s) and {warnings} warning(s)")
    issues.append(f"INFO: Integrity fingerprint: {fingerprint}")
    return issues


def _find_repo_root() -> Optional[Path]:
    """Locate the sysfix-ai git repo root."""
    global _REPO_ROOT
    if _REPO_ROOT:
        return _REPO_ROOT
    # Walk up from this file
    candidate = Path(__file__).resolve().parent.parent
    if (candidate / ".git").is_dir():
        _REPO_ROOT = candidate
        return _REPO_ROOT
    return None


def _gh_token() -> str:
    """Return the GitHub PAT from config (if any)."""
    try:
        from sysfixai.config import load_config
        return load_config().get("github_token", "")
    except Exception:
        return ""


def _current_version() -> str:
    """Return the installed version string."""
    try:
        from sysfixai import __version__
        return __version__
    except Exception:
        return "0.0.0"


def _gh_api(endpoint: str, token: str = "", timeout: int = 15) -> dict:
    """Hit the GitHub REST API and return parsed JSON.

    Works with both public and private repos (via personal access token).
    Uses only stdlib so there's zero extra dependency.
    """
    import urllib.request, urllib.error, json as _json
    url = f"https://api.github.com/repos/{_GH_OWNER}/{_GH_REPO}/{endpoint}"
    req = urllib.request.Request(url)
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("User-Agent", "sysfix-ai-updater")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    resp = urllib.request.urlopen(req, timeout=timeout)
    return _json.loads(resp.read().decode())


# ── Version comparison helpers ──────────────────────────────────────────

def _parse_version(v: str):
    """Parse a version string like '1.0.0' into a comparable tuple."""
    import re as _re
    nums = _re.findall(r"\d+", v)
    return tuple(int(n) for n in nums) if nums else (0,)


def _is_newer(remote: str, local: str) -> bool:
    return _parse_version(remote) > _parse_version(local)


# ── Public API ──────────────────────────────────────────────────────────

def check_sysfix_update() -> List[str]:
    """Check if a newer version of sysfix-ai is available.

    Strategy:
      1. If running from a git repo → use git fetch (dev/source installs).
      2. Otherwise → query GitHub Releases API (RPM / pip installs).
         Supports private repos when a GitHub token is configured in Settings.
    """
    issues: List[str] = []
    repo = _find_repo_root()

    # ── Path A: git-based (developer / editable install) ────────────
    if repo is not None:
        try:
            branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=5,
                cwd=str(repo), stdin=subprocess.DEVNULL,
            ).stdout.strip()
            if not branch:
                issues.append("INFO: Could not determine git branch")
                return issues

            # Configure credential for private repos
            token = _gh_token()
            env = dict(os.environ)
            if token:
                env["GIT_ASKPASS"] = "echo"
                # Set up the remote URL with token for fetch
                remote_url = subprocess.run(
                    ["git", "remote", "get-url", "origin"],
                    capture_output=True, text=True, timeout=5,
                    cwd=str(repo), stdin=subprocess.DEVNULL,
                ).stdout.strip()
                # If it's an SSH url or plain HTTPS, build authenticated HTTPS url
                auth_url = f"https://x-access-token:{token}@github.com/{_GH_OWNER}/{_GH_REPO}.git"

                fetch = subprocess.run(
                    ["git", "fetch", auth_url, branch, "--quiet"],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo), stdin=subprocess.DEVNULL, env=env,
                )
                ref = "FETCH_HEAD"
            else:
                fetch = subprocess.run(
                    ["git", "fetch", "origin", branch, "--quiet"],
                    capture_output=True, text=True, timeout=30,
                    cwd=str(repo), stdin=subprocess.DEVNULL,
                )
                ref = f"origin/{branch}"

            if fetch.returncode != 0:
                issues.append("INFO: Could not reach GitHub to check for updates")
                if token:
                    issues.append("  Hint: Verify your GitHub token in Settings is correct")
                return issues

            behind = subprocess.run(
                ["git", "rev-list", "--count", f"HEAD..{ref}"],
                capture_output=True, text=True, timeout=5,
                cwd=str(repo), stdin=subprocess.DEVNULL,
            ).stdout.strip()
            n = int(behind) if behind.isdigit() else 0

            if n > 0:
                log = subprocess.run(
                    ["git", "log", "--oneline", f"HEAD..{ref}"],
                    capture_output=True, text=True, timeout=5,
                    cwd=str(repo), stdin=subprocess.DEVNULL,
                ).stdout.strip()
                issues.append(f"Sysfix update available: {n} new commit(s) on {branch}")
                if log:
                    issues.append(f"  Changes:\n{log}")
            else:
                issues.append(f"Sysfix: Up to date (branch: {branch})")
        except Exception as e:
            issues.append(f"INFO: Git-based update check failed: {e}")
        return issues

    # ── Path B: release-based (RPM / pip install — no .git) ─────────
    token = _gh_token()
    local_ver = _current_version()
    try:
        release = _gh_api("releases/latest", token=token)
        remote_ver = release.get("tag_name", "").lstrip("vV")
        body = release.get("body", "") or ""
        assets = release.get("assets", [])

        if not remote_ver:
            issues.append("INFO: Could not parse latest release version from GitHub")
            return issues

        if _is_newer(remote_ver, local_ver):
            issues.append(f"Sysfix update available: v{remote_ver} (you have v{local_ver})")
            if body:
                # Show first few lines of release notes
                notes = body.strip().splitlines()[:8]
                issues.append("  Release notes:")
                for line in notes:
                    issues.append(f"    {line}")
            # List RPM assets if available
            rpms = [a for a in assets if a.get("name", "").endswith(".rpm")]
            if rpms:
                issues.append(f"  RPM available: {rpms[0]['name']}")
        else:
            issues.append(f"Sysfix: Up to date (v{local_ver})")
    except Exception as e:
        err = str(e)
        if "401" in err or "403" in err:
            issues.append("INFO: GitHub authentication failed — check your token in Settings")
        elif "404" in err:
            issues.append("INFO: No releases found (or repo is private — add a GitHub token in Settings)")
        else:
            issues.append(f"INFO: Release-based update check failed: {e}")
    return issues


def apply_sysfix_update() -> List[str]:
    """Pull the latest version from GitHub.

    - Git repos: fast-forward pull (supports private repos via token).
    - RPM installs: download the latest .rpm asset and install it.
    """
    issues: List[str] = []
    repo = _find_repo_root()
    token = _gh_token()

    # ── Path A: git pull ────────────────────────────────────────────
    if repo is not None:
        try:
            branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=5,
                cwd=str(repo), stdin=subprocess.DEVNULL,
            ).stdout.strip()

            if token:
                auth_url = f"https://x-access-token:{token}@github.com/{_GH_OWNER}/{_GH_REPO}.git"
                r = subprocess.run(
                    ["git", "pull", auth_url, branch, "--ff-only"],
                    capture_output=True, text=True, timeout=60,
                    cwd=str(repo), stdin=subprocess.DEVNULL,
                )
            else:
                r = subprocess.run(
                    ["git", "pull", "origin", branch, "--ff-only"],
                    capture_output=True, text=True, timeout=60,
                    cwd=str(repo), stdin=subprocess.DEVNULL,
                )
            if r.returncode == 0:
                issues.append(f"Sysfix updated successfully!\n{r.stdout.strip()}")
                issues.append("INFO: Restart Sysfix to use the new version.")
            else:
                err = r.stderr.strip() or r.stdout.strip()
                issues.append(f"WARN: Update failed (local changes?)\n  {err[:300]}")
        except Exception as e:
            issues.append(f"ERROR: {e}")
        return issues

    # ── Path B: download & install RPM from GitHub Releases ─────────
    try:
        release = _gh_api("releases/latest", token=token)
        remote_ver = release.get("tag_name", "").lstrip("vV")
        assets = release.get("assets", [])

        rpms = [a for a in assets if a.get("name", "").endswith(".rpm")]
        if not rpms:
            issues.append("INFO: No RPM found in the latest release.")
            issues.append("  You may need to update manually.")
            return issues

        rpm_asset = rpms[0]
        rpm_name = rpm_asset["name"]
        rpm_url = rpm_asset["url"]  # API URL (requires Accept header)

        # Download the RPM via the API (works for private repos)
        import urllib.request, tempfile
        req = urllib.request.Request(rpm_url)
        req.add_header("Accept", "application/octet-stream")
        req.add_header("User-Agent", "sysfix-ai-updater")
        if token:
            req.add_header("Authorization", f"Bearer {token}")

        tmp_dir = tempfile.mkdtemp(prefix="sysfix-update-")
        rpm_path = os.path.join(tmp_dir, rpm_name)
        issues.append(f"Downloading {rpm_name}...")

        resp = urllib.request.urlopen(req, timeout=120)
        with open(rpm_path, "wb") as f:
            f.write(resp.read())

        issues.append(f"Downloaded to {rpm_path}")

        # Install the RPM
        import shutil as _sh
        if _sh.which("dnf"):
            r = subprocess.run(
                ["sudo", "dnf", "install", "-y", rpm_path],
                capture_output=True, text=True, timeout=120,
                stdin=subprocess.DEVNULL,
            )
        elif _sh.which("rpm"):
            r = subprocess.run(
                ["sudo", "rpm", "-Uvh", rpm_path],
                capture_output=True, text=True, timeout=120,
                stdin=subprocess.DEVNULL,
            )
        else:
            issues.append(f"RPM saved to: {rpm_path}")
            issues.append("Install manually: sudo dnf install " + rpm_path)
            return issues

        if r.returncode == 0:
            issues.append(f"Sysfix updated to v{remote_ver}!")
            issues.append("INFO: Restart Sysfix to use the new version.")
        else:
            err = r.stderr.strip() or r.stdout.strip()
            issues.append(f"WARN: RPM install returned errors:\n  {err[:300]}")
            issues.append(f"  RPM saved at: {rpm_path}")
    except Exception as e:
        err = str(e)
        if "401" in err or "403" in err:
            issues.append("ERROR: GitHub authentication failed — check your token in Settings")
        else:
            issues.append(f"ERROR: {e}")
    return issues


# ──────────────────────────────────────────────────────────────────────────
# System package update — apply pending Fedora / Debian updates
# ──────────────────────────────────────────────────────────────────────────

def apply_system_updates(progress_cb=None) -> List[str]:
    """Apply system package updates.  Returns status messages.

    Uses ``pkexec`` (polkit) when available so a graphical password dialog
    is shown instead of requiring a terminal for ``sudo``.

    Args:
        progress_cb: Optional callable(str) for streaming progress lines.
    """
    issues: List[str] = []
    import shutil as _sh

    # Choose privilege-escalation method: pkexec (GUI-friendly) > sudo
    _pkexec = _sh.which("pkexec")
    _is_root = os.geteuid() == 0 if hasattr(os, "geteuid") else False

    def _elevate(cmd: list) -> list:
        """Prepend the best privilege-escalation wrapper."""
        if _is_root:
            return cmd
        if _pkexec:
            return [_pkexec] + cmd
        return ["sudo"] + cmd

    if _sh.which("dnf"):
        try:
            run_cmd = _elevate(["dnf", "upgrade", "--refresh", "-y"])
            method = "pkexec" if _pkexec and not _is_root else ("sudo" if not _is_root else "direct")
            issues.append(f"Running: {' '.join(run_cmd)} ...")
            if progress_cb:
                progress_cb(f"Running dnf upgrade via {method} — this may take a few minutes...")
            r = subprocess.run(
                run_cmd,
                capture_output=True, text=True, timeout=600,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                # Count installed/upgraded lines
                upgraded = [l for l in r.stdout.splitlines()
                            if "Upgraded" in l or "Installed" in l or "Removed" in l]
                if upgraded:
                    issues.append("System updated:\n" + "\n".join(f"  {l.strip()}" for l in upgraded[-10:]))
                else:
                    out_tail = r.stdout.strip().splitlines()[-5:]
                    issues.append("System updated:\n" + "\n".join(f"  {l.strip()}" for l in out_tail))
            else:
                issues.append(f"WARN: dnf upgrade failed (exit {r.returncode})")
                if r.stderr.strip():
                    issues.append(f"  {r.stderr.strip()[:300]}")
        except subprocess.TimeoutExpired:
            issues.append("WARN: Update timed out after 10 minutes")
        except Exception as e:
            issues.append(f"ERROR: {e}")
    elif _sh.which("apt"):
        try:
            run_cmd = _elevate(["apt", "update", "-qq"])
            method = "pkexec" if _pkexec and not _is_root else ("sudo" if not _is_root else "direct")
            issues.append(f"Running: apt update && apt upgrade -y via {method} ...")
            if progress_cb:
                progress_cb(f"Running apt upgrade via {method} — this may take a few minutes...")
            subprocess.run(
                run_cmd,
                capture_output=True, text=True, timeout=120,
                stdin=subprocess.DEVNULL,
            )
            r = subprocess.run(
                _elevate(["apt", "upgrade", "-y", "-qq"]),
                capture_output=True, text=True, timeout=600,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                issues.append(f"System updated.\n  {r.stdout.strip()[-300:]}")
            else:
                issues.append(f"WARN: apt upgrade failed")
        except subprocess.TimeoutExpired:
            issues.append("WARN: Update timed out")
        except Exception as e:
            issues.append(f"ERROR: {e}")
    else:
        issues.append("INFO: No supported package manager (dnf/apt)")
    return issues


# ──────────────────────────────────────────────────────────────────────────
# Autostart management — XDG autostart .desktop entry
# ──────────────────────────────────────────────────────────────────────────

_AUTOSTART_DIR = Path.home() / ".config" / "autostart"
_DESKTOP_NAME = "sysfix-ai.desktop"
_DESKTOP_PATH = _AUTOSTART_DIR / _DESKTOP_NAME


def is_autostart_enabled() -> bool:
    """Check whether sysfix-ai is configured to start on login."""
    return _DESKTOP_PATH.exists()


def enable_autostart() -> str:
    """Create XDG autostart entry so Sysfix launches on login."""
    try:
        _AUTOSTART_DIR.mkdir(parents=True, exist_ok=True)
        # Find the sysfix executable — prefer the venv wrapper
        repo = _find_repo_root()
        venv_bin = repo / ".venv" / "bin" / "sysfix" if repo else None
        if venv_bin and venv_bin.exists():
            exec_cmd = str(venv_bin) + " gui"
        else:
            import shutil as _sh
            which = _sh.which("sysfix")
            exec_cmd = f"{which} gui" if which else "sysfix gui"

        desktop = (
            "[Desktop Entry]\n"
            "Type=Application\n"
            "Name=Sysfix AI\n"
            "Comment=System Diagnostics & AI-Powered Repair\n"
            f"Exec={exec_cmd}\n"
            "Icon=utilities-system-monitor\n"
            "Terminal=false\n"
            "Categories=System;Monitor;\n"
            "X-GNOME-Autostart-enabled=true\n"
            "StartupNotify=false\n"
        )
        _DESKTOP_PATH.write_text(desktop)
        return "Autostart enabled — Sysfix will launch on next login."
    except Exception as e:
        return f"Failed to enable autostart: {e}"


def disable_autostart() -> str:
    """Remove XDG autostart entry."""
    try:
        if _DESKTOP_PATH.exists():
            _DESKTOP_PATH.unlink()
        return "Autostart disabled."
    except Exception as e:
        return f"Failed to disable autostart: {e}"


# ──────────────────────────────────────────────────────────────────────────
# Virus / malware hash scanning — VirusTotal + MalwareBazaar
# ──────────────────────────────────────────────────────────────────────────

# MalwareBazaar (abuse.ch) — free, no API key needed
_BAZAAR_URL = "https://mb-api.abuse.ch/api/v1/"

# VirusTotal v3 — free tier (4 lookups/min, 500/day) API key optional
_VT_URL = "https://www.virustotal.com/api/v3/files/"


def _sha256_file(path: str, chunk_size: int = 65536) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _check_malwarebazaar(sha256: str) -> Optional[Dict]:
    """Query MalwareBazaar for a SHA-256 hash.  No API key required."""
    try:
        data = urllib.parse.urlencode({
            "query": "get_info",
            "hash": sha256,
        }).encode()
        req = urllib.request.Request(_BAZAAR_URL, data=data, method="POST")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
        if result.get("query_status") == "hash_not_found":
            return None
        if result.get("query_status") == "ok" and result.get("data"):
            entry = result["data"][0]
            return {
                "source": "MalwareBazaar",
                "sha256": entry.get("sha256_hash", sha256),
                "file_type": entry.get("file_type_mime", "?"),
                "signature": entry.get("signature") or "unknown",
                "tags": entry.get("tags") or [],
                "first_seen": entry.get("first_seen", "?"),
            }
    except Exception:
        pass
    return None


def _check_virustotal(sha256: str, api_key: str = "") -> Optional[Dict]:
    """Query VirusTotal v3 for a SHA-256 hash.  Requires API key."""
    if not api_key:
        return None
    try:
        req = urllib.request.Request(
            _VT_URL + sha256,
            headers={"x-apikey": api_key},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read())
        attrs = result.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {})
        malicious = stats.get("malicious", 0)
        undetected = stats.get("undetected", 0)
        total = malicious + stats.get("harmless", 0) + undetected + stats.get("suspicious", 0)
        return {
            "source": "VirusTotal",
            "sha256": sha256,
            "detections": f"{malicious}/{total}",
            "malicious": malicious,
            "name": attrs.get("meaningful_name") or attrs.get("magic", "?"),
            "type": attrs.get("type_description", "?"),
            "reputation": attrs.get("reputation", "?"),
        }
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None  # Not in VT database
        return None
    except Exception:
        return None


def scan_file_hash(file_path: str, vt_api_key: str = "") -> List[str]:
    """Scan a single file against MalwareBazaar and optionally VirusTotal.

    Returns human-readable result lines.
    """
    results: List[str] = []
    path = Path(file_path)
    if not path.exists():
        return [f"ERROR: File not found: {file_path}"]
    if not path.is_file():
        return [f"ERROR: Not a regular file: {file_path}"]
    try:
        size_mb = path.stat().st_size / (1024 * 1024)
        sha = _sha256_file(str(path))
        results.append(f"File: {path.name} ({size_mb:.2f} MB)")
        results.append(f"SHA-256: {sha}")

        # MalwareBazaar (always available)
        mb = _check_malwarebazaar(sha)
        if mb:
            results.append(f"WARN: MALWARE DETECTED by {mb['source']}!")
            results.append(f"  Signature: {mb['signature']}")
            results.append(f"  Type: {mb['file_type']}")
            results.append(f"  First seen: {mb['first_seen']}")
            if mb.get("tags"):
                results.append(f"  Tags: {', '.join(mb['tags'][:8])}")
        else:
            results.append("MalwareBazaar: Not found in malware database (clean)")

        # VirusTotal (if key provided)
        if vt_api_key:
            vt = _check_virustotal(sha, vt_api_key)
            if vt:
                if vt["malicious"] > 0:
                    results.append(f"WARN: VirusTotal: {vt['detections']} engines flagged this file!")
                else:
                    results.append(f"VirusTotal: {vt['detections']} — clean")
                results.append(f"  Name: {vt['name']}")
                results.append(f"  Type: {vt['type']}")
            else:
                results.append("VirusTotal: Not found in database")
        else:
            results.append("VirusTotal: No API key configured (optional — add in Settings)")

    except PermissionError:
        results.append(f"ERROR: Permission denied reading {file_path}")
    except Exception as e:
        results.append(f"ERROR: {e}")
    return results


def scan_directory_hashes(
    dir_path: str,
    vt_api_key: str = "",
    max_files: int = 50,
    max_size_mb: float = 100,
    extensions: tuple = (".exe", ".msi", ".sh", ".py", ".pl", ".elf",
                         ".bin", ".so", ".dll", ".deb", ".rpm",
                         ".AppImage", ".run", ".jar", ".class"),
    progress_cb=None,
) -> List[str]:
    """Scan files in a directory against malware databases.

    Args:
        dir_path:    Directory to scan.
        vt_api_key:  Optional VirusTotal API key.
        max_files:   Stop after this many files to avoid rate limits.
        max_size_mb: Skip files larger than this.
        extensions:  File extensions to scan (empty tuple = all files).
        progress_cb: Optional callable(str) for progress updates.
    """
    results: List[str] = []
    p = Path(dir_path)
    if not p.is_dir():
        return [f"ERROR: Not a directory: {dir_path}"]

    results.append(f"Scanning: {dir_path}")
    scanned = 0
    flagged = 0
    clean = 0

    try:
        files = sorted(p.rglob("*"))
    except PermissionError:
        return [f"ERROR: Permission denied accessing {dir_path}"]

    for fp in files:
        if scanned >= max_files:
            results.append(f"INFO: Stopped at {max_files} files (limit)")
            break
        if not fp.is_file():
            continue
        # Extension filter
        if extensions and fp.suffix.lower() not in extensions:
            continue
        # Size filter
        try:
            size_mb = fp.stat().st_size / (1024 * 1024)
            if size_mb > max_size_mb:
                continue
            if size_mb < 0.001:  # skip tiny/empty files
                continue
        except Exception:
            continue

        scanned += 1
        if progress_cb:
            progress_cb(f"Scanning {scanned}: {fp.name}...")

        try:
            sha = _sha256_file(str(fp))
            mb = _check_malwarebazaar(sha)
            if mb:
                results.append(f"WARN: MALWARE: {fp.name} — {mb['signature']} ({mb['source']})")
                flagged += 1
            else:
                clean += 1
            # VT check (rate limited — be conservative)
            if vt_api_key and scanned <= 4:
                vt = _check_virustotal(sha, vt_api_key)
                if vt and vt["malicious"] > 0:
                    results.append(
                        f"WARN: VirusTotal: {fp.name} flagged by {vt['detections']} engines"
                    )
                    flagged += 1
        except Exception:
            pass

    results.append(f"\nScan complete: {scanned} files checked, {flagged} flagged, {clean} clean")
    return results
