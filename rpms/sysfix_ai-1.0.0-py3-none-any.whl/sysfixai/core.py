"""
Enhanced core module for sysfix-ai.
"""

import socket
import psutil
import subprocess
import shutil
import os
from typing import List, Tuple, Dict, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from sysfixai.ai import (
    get_ai_fix,
    get_ai_context_aware_fix,
    prepare_system_context,
    AIRecommendation,
    confirm_action,
    verify_fix
)


class IssueStatus(Enum):
    """Status of a detected issue."""
    DETECTED = "detected"
    FIXED = "fixed"
    UNRESOLVED = "unresolved"
    SKIPPED = "skipped"


@dataclass
class TrackedIssue:
    """An issue being tracked."""
    description: str
    issue_type: str
    status: IssueStatus = IssueStatus.DETECTED
    attempts: List[str] = field(default_factory=list)


class IssueTracker:
    """Track issues and their resolution status.
    
    Maintains a session-level record of detected issues and their
    resolution status (fixed, unresolved, skipped).
    """
    def __init__(self) -> None:
        """Initialize issue tracker."""
        self.issues: List[TrackedIssue] = []
        self.resolved: int = 0
        self.unresolved: int = 0
    
    def add(self, desc: str, itype: str) -> TrackedIssue:
        """Add a new issue to track.
        
        Args:
            desc: Issue description
            itype: Issue type (memory, temperature, storage, etc)
        
        Returns:
            The created TrackedIssue object
        
        Raises:
            ValueError: If description or type is empty
        """
        if not desc or not itype:
            raise ValueError("Description and type cannot be empty")
        
        issue = TrackedIssue(description=desc, issue_type=itype)
        self.issues.append(issue)
        return issue
    
    def mark_fixed(self, issue: TrackedIssue) -> None:
        """Mark an issue as fixed.
        
        Args:
            issue: The TrackedIssue to mark as fixed
        
        Raises:
            ValueError: If issue is not tracked by this tracker
        """
        if issue not in self.issues:
            raise ValueError("Issue not tracked by this tracker")
        
        issue.status = IssueStatus.FIXED
        self.resolved += 1
    
    def mark_unresolved(self, issue: TrackedIssue, attempt: str) -> None:
        """Mark an issue as unresolved after attempted fix.
        
        Args:
            issue: The TrackedIssue to mark
            attempt: Description of the attempted fix
        
        Raises:
            ValueError: If issue is not tracked or attempt is empty
        """
        if issue not in self.issues:
            raise ValueError("Issue not tracked by this tracker")
        if not attempt:
            raise ValueError("Attempt description cannot be empty")
        
        issue.status = IssueStatus.UNRESOLVED
        issue.attempts.append(attempt)
        self.unresolved += 1
    
    def mark_skipped(self, issue: TrackedIssue) -> None:
        """Mark an issue as skipped by user.
        
        Args:
            issue: The TrackedIssue to skip
        
        Raises:
            ValueError: If issue is not tracked by this tracker
        """
        if issue not in self.issues:
            raise ValueError("Issue not tracked by this tracker")
        
        issue.status = IssueStatus.SKIPPED
    
    def summary(self) -> str:
        total = len(self.issues)
        skipped = total - self.resolved - self.unresolved
        lines = [
            "",
            "=" * 60,
            "SESSION SUMMARY",
            "=" * 60,
            f"Total: {total}",
            f"  Fixed: {self.resolved}",
            f"  Unresolved: {self.unresolved}",
            f"  Skipped: {skipped}",
            "=" * 60,
        ]
        return "\n".join(lines)


tracker = IssueTracker()


def is_ollama_running(host: str = '127.0.0.1', port: int = 11434, timeout: float = 1) -> bool:
    """Check if Ollama server is running.
    
    Args:
        host: Ollama server host (default: 127.0.0.1)
        port: Ollama server port (default: 11434)
        timeout: Connection timeout in seconds (default: 1)
    
    Returns:
        True if Ollama is running and responding, False otherwise
    
    Note:
        This function gracefully handles connection errors and timeouts.
    """
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (socket.timeout, socket.error, OSError):
        return False


def diagnose() -> List[str]:
    """Run system diagnostics."""
    issues = []
    issues.extend(check_linux_distro())
    issues.extend(check_audio_compatibility())
    issues.extend(check_conflicting_apps())
    issues.extend(check_audio())
    issues.extend(check_memory())
    issues.extend(check_storage())
    issues.extend(check_temperatures())
    issues.extend(check_bios())
    issues.extend(check_motherboard())
    issues.extend(check_system_info())
    return issues if issues else ["No issues detected."]


def categorize_issues(issues: List[str]) -> Dict[str, List[str]]:
    """Categorize issues into PROBLEMS, WARNINGS, and INFO sections."""
    categorized = {
        "problems": [],    # Things that need fixing (high temp, high memory, etc)
        "warnings": [],    # Warnings (BIOS, audio conflicts, etc)
        "info": []         # Informational items (OS, CPU, RAM, etc)
    }
    
    if not issues or (len(issues) == 1 and issues[0] == "No issues detected."):
        return categorized
    
    for issue in issues:
        issue_lower = issue.lower()
        
        # PROBLEMS - High temps, high memory, storage
        if any(x in issue_lower for x in ["high temp", "high memory", "storage"]):
            categorized["problems"].append(issue)
        
        # WARNINGS - BIOS, dangerous situations, conflicts
        elif any(x in issue_lower for x in ["warning:", "bios", "conflict", "both running"]):
            categorized["warnings"].append(issue)
        
        # INFO - System info, distros, audio systems, motherboard, etc
        else:
            categorized["info"].append(issue)
    
    return categorized


def check_linux_distro() -> List[str]:
    """Check Linux distribution version and compatibility."""
    issues = []
    try:
        if os.path.exists("/etc/os-release"):
            with open("/etc/os-release") as f:
                distro_info = {}
                for line in f:
                    if "=" in line:
                        key, val = line.strip().split("=", 1)
                        distro_info[key] = val.strip('"')
                
                name = distro_info.get("NAME", "Unknown")
                version = distro_info.get("VERSION", "Unknown")
                distro_id = distro_info.get("ID", "unknown")
                
                issues.append(f"Linux Distribution: {name} {version}")
                
                if distro_id == "fedora":
                    fedora_version = distro_info.get("VERSION_ID", "")
                    if fedora_version:
                        issues.append(f"Fedora Version: {fedora_version}")
        else:
            issues.append("Linux distribution info unavailable")
    except Exception as e:
        issues.append(f"Failed to check Linux distribution: {e}")
    return issues


def check_audio_compatibility() -> List[str]:
    """Check for audio system compatibility issues (PipeWire vs PulseAudio)."""
    issues = []
    try:
        pipewire_running = subprocess.run(
            ["systemctl", "--user", "is-active", "pipewire"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        ).returncode == 0
        
        pulseaudio_running = subprocess.run(
            ["systemctl", "--user", "is-active", "pulseaudio"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        ).returncode == 0
        
        if pipewire_running and pulseaudio_running:
            issues.append("CONFLICT: Both PipeWire and PulseAudio running!")
        elif pipewire_running:
            issues.append("Audio System: PipeWire (newer audio server)")
        elif pulseaudio_running:
            issues.append("Audio System: PulseAudio (legacy audio server)")
        else:
            issues.append("Audio System: Unknown or not running")
    except Exception as e:
        issues.append(f"Failed to check audio compatibility: {e}")
    return issues


def check_conflicting_apps() -> List[str]:
    """Check for known conflicting applications."""
    issues = []
    conflicting_apps = {
        "discord": ["slack", "teams"],
        "pipewire": ["pulseaudio"],
    }
    
    try:
        running_processes = set()
        for proc in psutil.process_iter(['name']):
            try:
                running_processes.add(proc.name().lower())
            except psutil.NoSuchProcess:
                continue
        
        for app, conflicts in conflicting_apps.items():
            if app in running_processes:
                running_conflicts = [c for c in conflicts if c in running_processes]
                if running_conflicts:
                    issues.append(
                        f"CONFLICT: {app.upper()} conflicts with {', '.join(running_conflicts).upper()}"
                    )
    except Exception as e:
        issues.append(f"Failed to check conflicting apps: {e}")
    return issues


def check_motherboard() -> List[str]:
    issues = []
    try:
        if shutil.which("dmidecode"):
            # dmidecode requires root — skip entirely when not elevated
            if os.geteuid() != 0:
                return issues
            cmd = ["dmidecode", "-t", "baseboard"]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if result.returncode == 0:
                lines = [l.strip() for l in result.stdout.splitlines() if l.strip()]
                info = [l for l in lines if any(k in l.lower() for k in ["manufacturer", "product name", "version"])]
                issues.append("Motherboard: " + ", ".join(info) if info else "Motherboard info unavailable")
    except Exception:
        pass
    return issues


def check_system_info() -> List[str]:
    issues = []
    try:
        uname = os.uname()
        issues.append(f"System: {uname.sysname} {uname.release} ({uname.machine})")
        issues.append(f"Node: {uname.nodename}")
        if os.path.exists("/proc/cpuinfo"):
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.lower().startswith("model name"):
                        issues.append("CPU: " + line.strip().split(":", 1)[-1].strip())
                        break
        mem = psutil.virtual_memory()
        issues.append(f"RAM: {mem.total // (1024*1024)} MB total")
    except Exception:
        pass
    return issues


def check_audio() -> List[str]:
    """Check audio system status.
    
    Verifies PulseAudio/PipeWire is running and accessible.
    
    Returns:
        List of audio issues, or empty list if audio OK
    
    Note:
        Gracefully handles systems without audio support.
    """
    issues = []
    
    try:
        result = subprocess.run(
            ["pactl", "info"],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if result.returncode != 0 or "Server Name" not in result.stdout:
            issues.append("Audio system check failed (PulseAudio may not be running).")
    
    except FileNotFoundError:
        # pactl not installed - PulseAudio may not be available
        issues.append("Audio system not found (PulseAudio not installed).")
    except subprocess.TimeoutExpired:
        issues.append("Audio system check timed out (service may be hung).")
    except Exception:
        issues.append("Audio system check failed.")
    
    return issues


def check_memory() -> List[str]:
    """Check for high memory usage by processes.
    
    Identifies processes consuming more than 500MB of RAM.
    
    Returns:
        List of memory issues found, or empty list if all OK
    
    Note:
        Gracefully handles processes that may exit during iteration.
    """
    issues = []
    hogs = []
    
    try:
        for proc in psutil.process_iter(['pid', 'name', 'memory_info']):
            try:
                mem_mb = proc.info['memory_info'].rss / (1024 * 1024)
                if mem_mb > 500:
                    hogs.append((proc.info['name'], proc.info['pid'], mem_mb))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                # Process died, permission denied, or zombie - skip it
                continue
    except Exception:
        # psutil errors - return gracefully
        return ["Memory check failed - unable to access process information"]
    
    if hogs:
        # Sort by memory usage (descending) for most relevant issues first
        hogs_sorted = sorted(hogs, key=lambda x: x[2], reverse=True)
        desc = "High memory: " + ", ".join(
            f"{n} (PID {p}) using {m:.1f} MB" 
            for n, p, m in hogs_sorted
        )
        issues.append(desc)
    
    return issues


def check_storage() -> List[str]:
    """Check disk space usage.
    
    Monitors root filesystem (/) for available space.
    Alerts when usage exceeds 90%.
    
    Returns:
        List of storage warnings, or empty list if space available
    
    Raises:
        Issues logged gracefully if filesystem info unavailable
    """
    issues = []
    
    try:
        total, used, free = shutil.disk_usage("/")
        used_pct = (used / total) * 100 if total > 0 else 0
        
        if used_pct > 95:
            free_gb = free / (1024**3)
            issues.append(f"Critical: Storage critically low: {used_pct:.1f}% used ({free_gb:.1f}GB free).")
        elif used_pct > 90:
            free_gb = free / (1024**3)
            issues.append(f"Storage full: {used_pct:.1f}% used ({free_gb:.1f}GB free).")
    
    except Exception:
        issues.append("Storage check failed - unable to access filesystem information")
    
    return issues


def check_temperatures() -> List[str]:
    """Check system temperatures and identify overheating.
    
    Monitors CPU, GPU, and other temperature sensors.
    Alerts when temperatures exceed 85°C.
    
    Returns:
        List of temperature warnings, or empty list if all normal
    
    Note:
        Returns empty list if temperature sensors are unavailable
        (common on some systems without proper sensor drivers).
    """
    issues = []
    
    try:
        temps = psutil.sensors_temperatures()
        if not temps:
            return []  # No temperature sensors found
        
        # Collect all high-temp alerts, sorted by severity
        alerts = []
        for sensor, entries in temps.items():
            for entry in entries:
                if entry.current > 85:
                    alerts.append((
                        entry.current,  # For sorting by severity
                        sensor,
                        entry.current,
                        entry.high if hasattr(entry, 'high') else None
                    ))
        
        # Sort by temperature (highest first) for most critical issues first
        for temp, sensor, current, high_threshold in sorted(alerts, reverse=True):
            if temp > 95:
                msg = f"Critical temperature: {sensor} at {current:.1f}C"
            elif temp > 90:
                msg = f"Very high temperature: {sensor} at {current:.1f}C"
            else:
                msg = f"High temperature: {sensor} at {current:.1f}C"
            
            issues.append(msg)
    
    except Exception:
        # Gracefully handle sensor errors
        pass
    
    return issues


def check_bios() -> List[str]:
    issues = []
    if shutil.which("dmidecode"):
        issues.append("WARNING: BIOS detected. DO NOT attempt automated BIOS updates.")
        issues.append("BIOS flashing is dangerous and can brick your system.")
    return issues


def determine_type(issue: str) -> str:
    """Determine issue type from description."""
    i = issue.lower()
    if "memory" in i or "mb ram" in i:
        return "memory"
    elif "storage" in i or "disk" in i or "space" in i:
        return "storage"
    elif "temp" in i or "cpu" in i or "heat" in i:
        return "temperature"
    elif "audio" in i or "sound" in i or "pulseaudio" in i:
        return "audio"
    elif "bios" in i or "motherboard" in i:
        return "bios"
    return "general"


def apply_fix_confirm(issue: str, tracked: TrackedIssue, system_context: dict = None) -> Tuple[bool, str]:
    """Apply fix with user confirmation and verification."""
    issue_type = determine_type(issue)
    
    if not is_ollama_running():
        print("Ollama not running. Running basic fix.")
        result = apply_fix_basic(issue)
        return False, result
    
    # Get AI recommendation with context awareness
    if system_context:
        rec = get_ai_context_aware_fix(issue, issue_type, system_context)
    else:
        rec = get_ai_fix(issue, issue_type)
    
    print("\n" + "=" * 60)
    print("AI RECOMMENDATION")
    print("=" * 60)
    
    # Color by safety
    if rec.safety == "dangerous":
        color = "red"
    elif rec.safety == "moderate":
        color = "yellow"
    else:
        color = "green"
    
    print(f"Action: {rec.action.upper()}")
    if rec.target:
        print(f"Target: {rec.target}")
    print(f"Why: {rec.reason}")
    
    print("\n" + "-" * 60)
    
    if rec.safety == "dangerous":
        print("DANGEROUS - Type CONFIRM to proceed:")
    else:
        print("Type y to proceed, n to skip:")
    
    while True:
        choice = input(">> ").strip().lower()
        
        if choice == 'y':
            confirmed = True
            break
        elif choice == 'n':
            confirmed = False
            break
        elif choice == 'confirm' and rec.safety == "dangerous":
            confirmed = True
            break
        else:
            if rec.safety == "dangerous":
                print("Type CONFIRM or n:")
            else:
                print("Type y or n:")
    
    if not confirmed:
        print("Skipped by user.")
        tracker.mark_skipped(tracked)
        return False, "Skipped"
    
    # Apply fix
    print("Applying fix...")
    result = execute_rec(rec, issue)
    tracked.attempts.append(f"{rec.action}: {rec.reason}")
    
    # Verify
    print("Verifying...")
    ok, msg = verify_fix(issue_type)
    
    if ok:
        print(f"OK: {msg}")
        tracker.mark_fixed(tracked)
        return True, msg
    else:
        print(f"NOT RESOLVED: {msg}")
        tracker.mark_unresolved(tracked, result)
        return False, msg


def execute_rec(rec: AIRecommendation, issue: str) -> str:
    """Execute AI recommendation."""
    action = rec.action.lower()
    
    if action == "kill":
        return kill_process(rec, issue)
    elif action == "optimize":
        return optimize_memory()
    elif action == "free_space":
        return free_disk_space()
    elif action == "restart":
        return restart_service(issue)
    elif action == "warning":
        return show_warning(rec)
    elif action == "skip":
        return "Skipped"
    return f"Unknown: {action}"


def kill_process(rec: AIRecommendation, issue: str) -> str:
    """Kill a process."""
    target = (rec.target or "").lower()
    issue_lower = issue.lower()
    killed = []
    
    processes = {
        "chrome": ["chrome", "chromium"],
        "plasmashell": ["plasma", "plasmashell"],
        "firefox": ["firefox"],
        "discord": ["discord"],
    }
    
    for proc_name, keywords in processes.items():
        if proc_name in target or any(kw in issue_lower for kw in keywords):
            for proc in psutil.process_iter(['pid', 'name']):
                try:
                    if proc.info['name'] and proc_name in proc.info['name'].lower():
                        p = psutil.Process(proc.info['pid'])
                        p.terminate()
                        p.wait(timeout=3)
                        killed.append(proc.info['name'])
                except Exception:
                    pass
    
    if killed:
        return f"Killed: {', '.join(killed)}"
    return "No matching processes"


def optimize_memory() -> str:
    """Optimize memory."""
    try:
        subprocess.run(["sudo", "bash", "-c", "echo 3 > /proc/sys/vm/drop_caches"], check=True)
        return "Memory optimized"
    except Exception:
        return "Memory optimization failed (needs sudo)"


def free_disk_space() -> str:
    """Free disk space."""
    freed = []
    try:
        subprocess.run(["sudo", "apt-get", "clean"], check=True)
        freed.append("apt cache")
    except Exception:
        pass
    try:
        subprocess.run(["sudo", "journalctl", "--vacuum-time=2d"], check=True)
        freed.append("journal")
    except Exception:
        pass
    return f"Freed: {', '.join(freed)}" if freed else "Failed to free space"


def restart_service(issue: str) -> str:
    """Restart a service."""
    if "audio" in issue.lower() or "pulseaudio" in issue.lower():
        try:
            subprocess.run(["pulseaudio", "--kill"], check=False)
            subprocess.run(["pulseaudio", "--start"], check=False)
            return "PulseAudio restarted"
        except Exception:
            return "Failed to restart audio"
    return "Service restart not applicable"


def show_warning(rec: AIRecommendation) -> str:
    """Show warning message."""
    print("=" * 60)
    print("WARNING")
    print("=" * 60)
    print(rec.reason)
    return "Warning shown"


def apply_fix_basic(issue: str) -> str:
    """Apply basic fix without AI."""
    print(f"Fixing: {issue[:50]}...")
    
    if "memory" in issue.lower():
        return optimize_memory()
    elif "storage" in issue.lower():
        return free_disk_space()
    elif "audio" in issue.lower():
        return "No auto-fix for audio"
    elif "temp" in issue.lower():
        return "Manual cooling required"
    elif "bios" in issue.lower():
        return "BIOS fixes not automated"
    return "No fix available"


def ai_auto_fix(issues: List[str]):
    """Auto-fix all issues with full system context."""
    if not is_ollama_running():
        print("Ollama not running.")
        for issue in issues:
            if issue != "No issues detected.":
                apply_fix_basic(issue)
        return
    
    print("AI Auto-Fix Mode")
    print("System-aware fixes with full context analysis\n")
    
    # Prepare system context once with all issues
    system_context = prepare_system_context(issues)
    
    for i, issue in enumerate(issues, 1):
        if issue == "No issues detected.":
            continue
        
        print(f"\n[{i}/{len(issues)}] Processing...")
        tracked = tracker.add(issue, determine_type(issue))
        ok, msg = apply_fix_confirm(issue, tracked, system_context)
        
        if ok:
            print(f"  OK: {msg}")
        elif msg != "Skipped":
            print(f"  FAILED: {msg}")
    
    print(tracker.summary())


def ai_deep_dive():
    """Interactive troubleshooting mode."""
    if not is_ollama_running():
        print("Ollama not running.")
        return
    
    print("Deep Dive Mode")
    main_issue = input("What is the main issue? ").strip()
    details = input("Additional details: ").strip()
    
    print("Analyzing...")
    from sysfixai.ai import get_deep_dive
    analysis = get_deep_dive(f"{main_issue}\n{details}")
    
    print("\n" + "=" * 60)
    print("AI ANALYSIS")
    print("=" * 60)
    print(analysis)


def get_bios_info() -> dict:
    """Extract detailed BIOS and motherboard information."""
    bios_info = {
        "manufacturer": "Unknown",
        "product": "Unknown",
        "version": "Unknown",
        "release_date": "Unknown",
        "board_vendor": "Unknown",
        "board_model": "Unknown",
        "bios_vendor": "Unknown"
    }
    
    try:
        # first try reading from sysfs which usually doesn't require root
        try:
            for key, path in [("board_vendor", "/sys/class/dmi/id/board_vendor"),
                              ("board_model", "/sys/class/dmi/id/board_name"),
                              ("manufacturer", "/sys/class/dmi/id/sys_vendor"),
                              ("product", "/sys/class/dmi/id/product_name"),
                              ("version", "/sys/class/dmi/id/product_version"),
                              ("bios_vendor", "/sys/class/dmi/id/bios_vendor")]:
                if os.path.exists(path):
                    try:
                        with open(path) as f:
                            bios_info[key] = f.read().strip()
                    except Exception:
                        pass
        except Exception:
            pass

        # Try to get BIOS info from dmidecode (skip sudo — may block without tty)
        result = subprocess.run(["dmidecode", "-t", "system"], 
                              capture_output=True, text=True, timeout=5,
                              stdin=subprocess.DEVNULL)
        
        lines = result.stdout.split('\n')
        for line in lines:
            if "Manufacturer:" in line:
                bios_info["manufacturer"] = line.split(":", 1)[1].strip()
            elif "Product Name:" in line:
                bios_info["product"] = line.split(":", 1)[1].strip()
            elif "Version:" in line:
                bios_info["version"] = line.split(":", 1)[1].strip()
            elif "Release Date:" in line:
                bios_info["release_date"] = line.split(":", 1)[1].strip()
        
        # Get motherboard info
        result = subprocess.run(["dmidecode", "-t", "baseboard"],
                              capture_output=True, text=True, timeout=5,
                              stdin=subprocess.DEVNULL)
        lines = result.stdout.split('\n')
        for line in lines:
            if "Manufacturer:" in line:
                bios_info["board_vendor"] = line.split(":", 1)[1].strip()
            elif "Product Name:" in line:
                bios_info["board_model"] = line.split(":", 1)[1].strip()
    except Exception as e:
        bios_info["error"] = str(e)
    
    return bios_info


def create_bios_folder() -> str:
    """Create a BIOS folder for storing firmware files."""
    bios_path = os.path.expanduser("~/bios_firmware")
    try:
        os.makedirs(bios_path, exist_ok=True)
        return bios_path
    except Exception as e:
        return f"Error creating BIOS folder: {e}"


def get_overclock_guidance(system_context: dict = None) -> str:
    """Get safe overclocking guidance based on system specs."""
    guidance = """
╔════════════════════════════════════════════════════════════════════════╗
║                    ⚠️  OVERCLOCKING GUIDANCE ⚠️                        ║
║                                                                        ║
║ WARNING: Overclocking can permanently damage your hardware!          ║
║ Only proceed if you understand the risks completely.                 ║
╚════════════════════════════════════════════════════════════════════════╝

🔒 SAFE OVERCLOCKING PRINCIPLES:

1. MEMORY (RAM) OVERCLOCKING - Safest Option
   ├─ Increase frequency by 50-100 MHz increments
   ├─ Monitor temps (should stay <60°C)
   ├─ Test with MemTest86+ after each change
   ├─ Keep voltage within rated spec (+5% maximum)
   └─ Revert if system becomes unstable

2. CPU MULTIPLIER OVERCLOCKING - Medium Risk
   ├─ Increase by 1 (100 MHz per step)
   ├─ Monitor temps (CPU <80°C safe, <70°C recommended)
   ├─ Stress test with Prime95/Linpack for 1 hour minimum
   ├─ Increase voltage cautiously (Intel: +0.05V max, AMD: +0.05V max)
   └─ Keep LLC (Load Line Calibration) enabled

3. BCLK OVERCLOCKING - Most Dangerous
   ├─ NOT RECOMMENDED without expert knowledge
   ├─ Affects entire system timing including PCIe/USB
   ├─ Can corrupt data and break components
   └─ Alternative: Use frequency multiplier instead

⚠️  MANDATORY SAFETY CHECKS:

   □ Test with Prime95 for stability (minimum 1 hour, ideally 8+)
   □ Monitor with HWInfo64 or similar during stress test
   □ Check for data corruption with MemTest86+ (4+ passes)
   □ Back up critical data before attempting overclocking
   □ Keep your hand near power button (for emergency shutdown)
   □ Have BIOS reset jumper location identified
   □ Ensure adequate cooling (heatsink, thermal paste, airflow)

📊 CONSERVATIVE SAFE SETTINGS (Most Hardware):

   Memory: +50-150 MHz (YMMV)
   CPU Multiplier: +2-4 steps (200-400 MHz)
   Voltage Increase: +0.025-0.05V only
   Temperature Limit: Keep under 80°C under load

❌ DO NOT:
   ✗ Disable any safety features (XMP, profiles, etc.)
   ✗ Increase voltage without testing
   ✗ Skip stability testing
   ✗ Ignore temperature warnings
   ✗ Change BCLK without expert knowledge
   ✗ Mix different RAM modules without testing
   ✗ Disable power-saving features without reason

✓ DO:
   ✓ Document your settings (write them down)
   ✓ Test incrementally (change one thing at a time)
   ✓ Save successful settings to BIOS profiles
   ✓ Monitor voltage and temperatures continuously
   ✓ Keep backups of your data
   ✓ Have recovery method ready (Windows boot USB, etc.)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

By continuing, you acknowledge that overclocking risks hardware failure,
data loss, and voiding your warranty.
"""
    return guidance


def sudo_mode():
    """Advanced mode for hardware tuning and BIOS operations (VERY DANGEROUS)."""
    print("\n" + "="*70)
    print("⚠️  SUDO MODE - ADVANCED HARDWARE TUNING")
    print("="*70)
    
    print("""
This mode provides tools for:
  • BIOS updates and firmware management
  • Safe RAM overclocking
  • CPU frequency tuning
  • Advanced system settings

⚡ EXTREME DANGER ⚡
""")
    
    print("""
You can PERMANENTLY DAMAGE your hardware in this mode.
- Incorrect BIOS updates can brick your motherboard
- Overclocking at wrong voltage can fry your CPU
- Running hot can destroy components
- Data loss may occur

ONLY PROCEED IF YOU:
  ✓ Backup all important data
  ✓ Understand hardware specifications
  ✓ Have recovery methods ready
  ✓ Can revert BIOS changes manually
  ✓ Know how to contact hardware support
""")
    
    # Triple confirmation
    confirm1 = input("I understand the risks (yes/no): ").strip().lower()
    if confirm1 != "yes":
        print("Exiting sudo mode. Wise choice.")
        return
    
    confirm2 = input("I have backed up my data (yes/no): ").strip().lower()
    if confirm2 != "yes":
        print("Exiting sudo mode. Please backup first!")
        return
    
    confirm3 = input("Type 'I take full responsibility': ").strip()
    if confirm3 != "I take full responsibility":
        print("Exiting sudo mode.")
        return
    
    print("\n✓ Entering advanced mode...\n")
    
    while True:
        print("\nSUDO MODE MENU")
        print("  [1] View BIOS Information")
        print("  [2] Get Overclocking Guidance")
        print("  [3] Create BIOS Firmware Folder")
        print("  [4] Get CPU Overclocking Settings")
        print("  [5] Get RAM Overclocking Settings")
        print("  [6] AI-Assisted Hardware Tuning")
        print("  [q] Exit Sudo Mode")
        
        choice = input("\n>> ").strip().lower()
        
        if choice == "1":
            print("\nFetching BIOS Information...")
            bios = get_bios_info()
            print("\n" + "BIOS INFORMATION")
            for key, val in bios.items():
                if key != "error":
                    print(f"  {key.replace('_', ' ').title()}: {val}")
        
        elif choice == "2":
            print(get_overclock_guidance())
        
        elif choice == "3":
            path = create_bios_folder()
            print(f"✓ BIOS folder ready at: {path}")
            print("Download your firmware updates here")
        
        elif choice == "4":
            print("""
CPU SAFE OVERCLOCKING SETTINGS:

Intel Core i7-11700K (Your CPU):
  Conservative: +3 multiplier (300 MHz), 1.35V
  Moderate: +5 multiplier (500 MHz), 1.37V
  Aggressive: +7 multiplier (700 MHz), 1.40V
  
Recommended: Start with Conservative settings
Test each setting for 1-2 hours with Prime95

⚠️  Do NOT exceed 1.45V without expert guidance
⚠️  CPU should not exceed 80°C under sustained load
""")
        
        elif choice == "5":
            print("""
RAM SAFE OVERCLOCKING SETTINGS:

Standard DDR4 (3200 MHz base):
  Conservative: 3250-3300 MHz, same voltage
  Moderate: 3400-3600 MHz, +0.03V
  Aggressive: 3700-4000 MHz, +0.05V
  
Recommended: Test with MemTest86+ (minimum 200% coverage)

⚠️  Do NOT exceed rated voltage by more than 5%
⚠️  RAM should stay below 50°C
⚠️  Odds of stability decrease significantly over 3600 MHz
""")
        
        elif choice == "6":
            if is_ollama_running():
                print("AI-Assisted tuning coming soon...")
                # Future: integrate AI for personalized tuning advice
            else:
                print("Ollama required for AI assistance")
        
        elif choice == "q":
            print("Exiting sudo mode. Be careful out there!")
            break
        
        else:
            print("Invalid choice")


