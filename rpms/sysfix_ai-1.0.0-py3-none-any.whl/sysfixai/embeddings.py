"""
Lightweight embeddings + vector store for Fyxa's brain.

- Uses sentence-transformers if available for real embeddings (optional).
- Persists a small on-disk index at ~/.config/sysfix/vector_store.json.
- Gracefully falls back to fuzzy-text matching (difflib) when embeddings lib is not present.

API:
- HAS_EMBEDDINGS: bool
- add_text(id, text, metadata=None)
- query(query, top_k=6) -> list of {"id","text","metadata","score"}
- rebuild_from_brain(brain_dict)

This module is intentionally dependency-light and safe to import even
if heavy ML libs are not installed.
"""
from __future__ import annotations

import json
import math
import os
import threading
import logging
import warnings
import contextlib
import io
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from sentence_transformers import SentenceTransformer
    import numpy as _np
    _ST_AVAILABLE = True
except Exception:
    SentenceTransformer = None  # type: ignore
    _np = None
    _ST_AVAILABLE = False

try:
    import difflib
except Exception:
    difflib = None

from sysfixai.config import CONFIG_DIR

_STORE_PATH = CONFIG_DIR / "vector_store.json"
_LOCK = threading.RLock()

# Public flag: whether we have a real embedding model available
HAS_EMBEDDINGS = _ST_AVAILABLE

# Optional backends
try:
    import faiss as _faiss  # type: ignore
    HAS_FAISS = True
except Exception:
    _faiss = None
    HAS_FAISS = False

try:
    # chromadb may emit a Python-3.14 compatibility UserWarning on some installs; suppress that specific message
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Core Pydantic V1 functionality isn't compatible with Python 3.14 or greater.")
        import chromadb as _chromadb  # type: ignore
        from chromadb.config import Settings as _ChromaSettings  # type: ignore
    HAS_CHROMADB = True
except Exception:
    _chromadb = None
    _ChromaSettings = None
    HAS_CHROMADB = False

# Default embedding model name (if available)
_EMBED_MODEL_NAME = "all-MiniLM-L6-v2"


class _SimpleStore:
    def __init__(self, path: Path = _STORE_PATH):
        self.path = path
        self._data: List[Dict[str, Any]] = []
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                with open(self.path, "r") as f:
                    self._data = json.load(f)
            except Exception:
                self._data = []
        else:
            self._data = []

    def _save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path, "w") as f:
                json.dump(self._data, f)
        except Exception:
            pass

    def all_items(self) -> List[Dict[str, Any]]:
        return list(self._data)

    def upsert(self, id: str, text: str, metadata: Optional[Dict[str, Any]] = None, vector: Optional[List[float]] = None):
        with _LOCK:
            for it in self._data:
                if it.get("id") == id:
                    it["text"] = text
                    it["metadata"] = metadata or {}
                    if vector is not None:
                        it["vector"] = vector
                    self._save()
                    return
            entry = {"id": id, "text": text, "metadata": metadata or {}, "vector": vector}
            self._data.append(entry)
            self._save()

    def query_fuzzy(self, q: str, top_k: int = 6) -> List[Dict[str, Any]]:
        # fallback fuzzy matching using difflib
        candidates = []
        for it in self._data:
            try:
                txt = it.get("text", "")
                score = 0.0
                if difflib:
                    score = difflib.SequenceMatcher(None, q, txt).ratio()
                else:
                    # trivial containment heuristic
                    score = 1.0 if q.lower() in txt.lower() else 0.0
                candidates.append((score, it))
            except Exception:
                continue
        candidates.sort(key=lambda x: x[0], reverse=True)
        return [{**it, "score": float(s)} for s, it in candidates[:top_k] if s > 0]


# Single global store
_STORE = _SimpleStore()

# Lazy-loaded sentence-transformers model
_ST_MODEL = None

# Paths for optional persisted FAISS index + metadata
_FAISS_INDEX_PATH = CONFIG_DIR / "faiss.index"
_FAISS_META_PATH = CONFIG_DIR / "faiss_meta.json"

# In-memory cached FAISS index and id-order mapping
_FAISS_INDEX = None
_FAISS_META: List[str] = []


def _ensure_model():
    global _ST_MODEL
    if not HAS_EMBEDDINGS:
        return None
    if _ST_MODEL is None:
        try:
            # Temporarily silence verbose logging/progress from transformers / hf-hub / sentence-transformers
            prev_levels = {}
            for logger_name in ("transformers", "huggingface_hub", "sentence_transformers"):
                logger = logging.getLogger(logger_name)
                prev_levels[logger_name] = logger.level
                logger.setLevel(logging.ERROR)
            try:
                # also redirect stdout/stderr to hide tqdm/progress output during model download/load
                with open(os.devnull, "w") as devnull:
                    with contextlib.redirect_stdout(devnull), contextlib.redirect_stderr(devnull):
                        _ST_MODEL = SentenceTransformer(_EMBED_MODEL_NAME)
            finally:
                for name, lvl in prev_levels.items():
                    logging.getLogger(name).setLevel(lvl)
        except Exception:
            _ST_MODEL = None
    return _ST_MODEL


def _cosine(a: List[float], b: List[float]) -> float:
    try:
        if _np is not None:
            va = _np.array(a, dtype=float)
            vb = _np.array(b, dtype=float)
            denom = (va @ va) ** 0.5 * (vb @ vb) ** 0.5
            return float((va @ vb) / denom) if denom > 0 else 0.0
        # pure-python fallback
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        return dot / (na * nb) if na > 0 and nb > 0 else 0.0
    except Exception:
        return 0.0


def embed_texts(texts: List[str]) -> List[Optional[List[float]]]:
    """Return embedding vectors for the provided texts, or None entries if not available."""
    if not HAS_EMBEDDINGS:
        return [None for _ in texts]
    model = _ensure_model()
    if model is None:
        return [None for _ in texts]
    try:
        arr = model.encode(texts, show_progress_bar=False)
        # convert to plain python lists
        if hasattr(arr, "tolist"):
            return [v.tolist() for v in arr]
        return [list(map(float, v)) for v in arr]
    except Exception:
        return [None for _ in texts]


def add_text(id: str, text: str, metadata: Optional[Dict[str, Any]] = None):
    """Index a text string (will compute embedding if model is available).

    Also incrementally persists FAISS/Chroma entries when possible so the
    semantic index stays up-to-date and fast.
    """
    vec = None
    try:
        vecs = embed_texts([text])
        vec = vecs[0]
    except Exception:
        vec = None

    _STORE.upsert(id, text, metadata=metadata or {}, vector=vec)

    # Incremental persistence for fast retrieval backends
    try:
        # Persist FAISS index if available and we produced a vector
        if HAS_FAISS and vec is not None:
            items_with_vecs = [it for it in _STORE.all_items() if it.get("vector")]
            if items_with_vecs:
                _persist_faiss_index(items_with_vecs)
    except Exception:
        pass

    try:
        # Upsert into Chroma collection if available
        if HAS_CHROMADB and vec is not None:
            client = _chromadb.Client(_ChromaSettings(persist_directory=str(CONFIG_DIR / "chromadb"), anonymized_telemetry=False))
            try:
                coll = client.get_collection(name="sysfixai")
            except Exception:
                coll = client.create_collection(name="sysfixai")
            # prefer upsert when available
            if hasattr(coll, "upsert"):
                coll.upsert(ids=[id], metadatas=[metadata or {}], documents=[text], embeddings=[vec])
            else:
                # fall back to add (remove existing id first)
                try:
                    coll.delete(ids=[id])
                except Exception:
                    pass
                coll.add(ids=[id], metadatas=[metadata or {}], documents=[text], embeddings=[vec])
    except Exception:
        pass


def rebuild_from_brain(brain: Dict[str, Any]):
    """Build the on-disk store from brain contents (observations, insights, solutions).

    This is idempotent and safe to call repeatedly. If a backend like Chroma
    is available it will be synced as well.
    """
    with _LOCK:
        # clear current store by overwriting file
        _STORE._data = []
        # index conversation insights
        for i, ins in enumerate(brain.get("conversation_insights", []) or []):
            add_text(f"insight:{i}", ins.get("insight", ""), metadata={"source": ins.get("extracted_from")})
        # index observations
        for i, obs in enumerate(brain.get("observations", []) or []):
            add_text(f"obs:{i}", obs.get("fact", ""), metadata={"category": obs.get("category")})
        # index solution history fixes
        for i, sol in enumerate(brain.get("solution_history", []) or []):
            txt = f"{sol.get('issue','')}: {sol.get('fix','')}"
            add_text(f"sol:{i}", txt, metadata={"worked": sol.get("worked")})

    # If Chroma is available, mirror the store there for faster retrieval across runs
    if HAS_CHROMADB:
        try:
            client = _chromadb.Client(_ChromaSettings(persist_directory=str(CONFIG_DIR / "chromadb"), anonymized_telemetry=False))
            coll = None
            try:
                coll = client.get_collection(name="sysfixai")
            except Exception:
                coll = client.create_collection(name="sysfixai")
            # clear and upsert
            coll.delete(ids=[it["id"] for it in _STORE.all_items()])
            for it in _STORE.all_items():
                # upsert expects list inputs
                coll.add(ids=[it["id"]], metadatas=[it.get("metadata", {})], documents=[it.get("text", "")], embeddings=[it.get("vector")])
        except Exception:
            pass

    # Persist a FAISS index for fast local similarity if available
    if HAS_FAISS:
        try:
            items_with_vecs = [it for it in _STORE.all_items() if it.get("vector")]
            if items_with_vecs:
                _persist_faiss_index(items_with_vecs)
        except Exception:
            pass


# ---- management helpers -------------------------------------------------

def list_items() -> List[Dict[str, Any]]:
    """Return a copy of all items in the local vector store."""
    return _STORE.all_items()


def export_items(path: str, ids: Optional[List[str]] = None) -> bool:
    """Export items to a JSON file. If `ids` is provided, only export those ids."""
    try:
        items = _STORE.all_items()
        if ids is not None:
            items = [it for it in items if it.get("id") in set(ids)]
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w") as f:
            json.dump(items, f, indent=2)
        return True
    except Exception:
        return False


def import_items(path: str, merge: bool = True) -> bool:
    """Import items from a JSON file. If merge=False, existing index will be cleared first."""
    try:
        p = Path(path)
        if not p.exists():
            return False
        with open(p, "r") as f:
            items = json.load(f)
        if not isinstance(items, list):
            return False
        with _LOCK:
            if not merge:
                _STORE._data = []
            for it in items:
                # Upsert using available data (vector optional)
                _STORE.upsert(it.get("id"), it.get("text", ""), metadata=it.get("metadata", {}), vector=it.get("vector"))
        # Persist FAISS/Chroma if possible
        try:
            if HAS_CHROMADB:
                client = _chromadb.Client(_ChromaSettings(persist_directory=str(CONFIG_DIR / "chromadb"), anonymized_telemetry=False))
                try:
                    coll = client.get_collection(name="sysfixai")
                except Exception:
                    coll = client.create_collection(name="sysfixai")
                # clear and re-add everything
                coll.delete(ids=[it["id"] for it in _STORE.all_items()])
                for it in _STORE.all_items():
                    coll.add(ids=[it["id"]], metadatas=[it.get("metadata", {})], documents=[it.get("text", "")], embeddings=[it.get("vector")])
        except Exception:
            pass

        if HAS_FAISS:
            try:
                items_with_vecs = [it for it in _STORE.all_items() if it.get("vector")]
                if items_with_vecs:
                    _persist_faiss_index(items_with_vecs)
            except Exception:
                pass

        return True
    except Exception:
        return False


def delete_item(item_id: str) -> bool:
    """Delete a single item from the local vector store and backends.

    Returns True if an item was removed, False otherwise.
    """
    removed = False
    with _LOCK:
        all_items = _STORE.all_items()
        new_items = [it for it in all_items if it.get("id") != item_id]
        if len(new_items) != len(all_items):
            _STORE._data = new_items
            _STORE._save()
            removed = True
    # remove from Chroma
    if removed and HAS_CHROMADB:
        try:
            client = _chromadb.Client(_ChromaSettings(persist_directory=str(CONFIG_DIR / "chromadb"), anonymized_telemetry=False))
            coll = client.get_collection(name="sysfixai")
            coll.delete(ids=[item_id])
        except Exception:
            pass
    # refresh persisted FAISS index
    if HAS_FAISS:
        try:
            items_with_vecs = [it for it in _STORE.all_items() if it.get("vector")]
            if items_with_vecs:
                _persist_faiss_index(items_with_vecs)
            else:
                # remove existing files if none remain
                try:
                    if _FAISS_INDEX_PATH.exists():
                        _FAISS_INDEX_PATH.unlink()
                    if _FAISS_META_PATH.exists():
                        _FAISS_META_PATH.unlink()
                except Exception:
                    pass
        except Exception:
            pass
    return removed


def clear_index():
    """Completely clear the local semantic index and any persisted backends."""
    with _LOCK:
        _STORE._data = []
        _STORE._save()
    # clear chroma
    if HAS_CHROMADB:
        try:
            client = _chromadb.Client(_ChromaSettings(persist_directory=str(CONFIG_DIR / "chromadb"), anonymized_telemetry=False))
            try:
                client.delete_collection(name="sysfixai")
            except Exception:
                pass
        except Exception:
            pass
    # remove persisted FAISS files
    try:
        if _FAISS_INDEX_PATH.exists():
            _FAISS_INDEX_PATH.unlink()
        if _FAISS_META_PATH.exists():
            _FAISS_META_PATH.unlink()
    except Exception:
        pass
    # Persist a FAISS index for fast local similarity if available
    if HAS_FAISS:
        try:
            items_with_vecs = [it for it in _STORE.all_items() if it.get("vector")]
            if items_with_vecs:
                _persist_faiss_index(items_with_vecs)
        except Exception:
            pass

def _persist_faiss_index(items: List[Dict[str, Any]]):
    """Build and persist a FAISS index from provided items (which must have 'vector').
    Also write a metadata file mapping row -> item id for later lookup.
    """
    global _FAISS_INDEX, _FAISS_META
    if not HAS_FAISS:
        return
    try:
        import numpy as _np
        vecs = _np.array([it["vector"] for it in items], dtype=_np.float32)
        if vecs.size == 0:
            return
        dim = vecs.shape[1]
        _faiss.normalize_L2(vecs)
        idx = _faiss.IndexFlatIP(dim)
        idx.add(vecs)
        # persist
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            _faiss.write_index(idx, str(_FAISS_INDEX_PATH))
            with open(_FAISS_META_PATH, "w") as f:
                json.dump([it["id"] for it in items], f)
        except Exception:
            pass
        _FAISS_INDEX = idx
        _FAISS_META = [it["id"] for it in items]
    except Exception:
        return


def _load_persisted_faiss():
    """Attempt to load a persisted FAISS index and metadata into memory."""
    global _FAISS_INDEX, _FAISS_META
    if not HAS_FAISS:
        return None
    if _FAISS_INDEX is not None:
        return _FAISS_INDEX
    try:
        if _FAISS_INDEX_PATH.exists() and _FAISS_META_PATH.exists():
            idx = _faiss.read_index(str(_FAISS_INDEX_PATH))
            with open(_FAISS_META_PATH, "r") as f:
                meta = json.load(f)
            _FAISS_INDEX = idx
            _FAISS_META = meta
            return _FAISS_INDEX
    except Exception:
        _FAISS_INDEX = None
        _FAISS_META = []
    return None


def _query_via_faiss(qv: List[float], top_k: int = 6) -> List[Dict[str, Any]]:
    # Prefer an in-memory or persisted FAISS index for speed.
    try:
        import numpy as _np
        # try to load persisted index first
        idx = _load_persisted_faiss()
        items = None
        if idx is not None and _FAISS_META:
            # use metadata mapping to look up items
            n_req = min(top_k, len(_FAISS_META))
            qv_arr = _np.array([qv], dtype=_np.float32)
            _faiss.normalize_L2(qv_arr)
            D, I = idx.search(qv_arr, n_req)
            results = []
            for score, i in zip(D[0].tolist(), I[0].tolist()):
                try:
                    item_id = _FAISS_META[i]
                    it = next((x for x in _STORE.all_items() if x.get("id") == item_id), None)
                    if it:
                        results.append({**it, "score": float(score)})
                except Exception:
                    continue
            if results:
                return results
        # fallback: build in-memory from available vectors
        items = [it for it in _STORE.all_items() if it.get("vector")]
        if not items:
            return []
        vecs = _np.array([it["vector"] for it in items], dtype=_np.float32)
        dim = vecs.shape[1]
        idx = _faiss.IndexFlatIP(dim)
        _faiss.normalize_L2(vecs)
        idx.add(vecs)
        qv_arr = _np.array([qv], dtype=_np.float32)
        _faiss.normalize_L2(qv_arr)
        D, I = idx.search(qv_arr, min(top_k, len(items)))
        results = []
        for score, i in zip(D[0].tolist(), I[0].tolist()):
            it = items[i]
            results.append({**it, "score": float(score)})
        return results
    except Exception:
        return []


def query(q: str, top_k: int = 6) -> List[Dict[str, Any]]:
    """Return top-k matches from the local store.

    Each result dict contains: id, text, metadata, score.
    """
    q = (q or "").strip()
    if not q:
        return []

    # If a Chroma backend exists, prefer it (fast, persistent)
    if HAS_CHROMADB:
        try:
            client = _chromadb.Client(_ChromaSettings(persist_directory=str(CONFIG_DIR / "chromadb"), anonymized_telemetry=False))
            coll = client.get_collection(name="sysfixai")
            docs = coll.query(query_texts=[q], n_results=top_k)
            results = []
            for score, id_, doc, meta in zip(docs["distances"][0], docs["ids"][0], docs["documents"][0], docs.get("metadatas", [[]])[0]):
                results.append({"id": id_, "text": doc, "metadata": meta or {}, "score": float(1.0 - score)})
            return results
        except Exception:
            pass

    # If we have real embeddings, compute query vector and use cosine similarity
    if HAS_EMBEDDINGS:
        vecs = embed_texts([q])
        qv = vecs[0]
        if qv is None:
            return _STORE.query_fuzzy(q, top_k=top_k)

        # If FAISS is available and stored vectors exist, try FAISS first
        if HAS_FAISS:
            try:
                # ensure persisted index is loaded for speed
                _load_persisted_faiss()
                faiss_res = _query_via_faiss(qv, top_k=top_k)
                if faiss_res:
                    return faiss_res
            except Exception:
                pass

        # Fallback: cosine comparisons over stored vectors
        candidates = []
        for it in _STORE.all_items():
            v = it.get("vector")
            if not v:
                # fallback to fuzzy score on the text
                if difflib:
                    s = difflib.SequenceMatcher(None, q, it.get("text","")).ratio()
                else:
                    s = 0.0
            else:
                s = _cosine(qv, v)
            candidates.append((s, it))
        candidates.sort(key=lambda x: x[0], reverse=True)
        return [{**it, "score": float(s)} for s, it in candidates[:top_k] if s > 0]

    # no embeddings available — use fuzzy text matching
    return _STORE.query_fuzzy(q, top_k=top_k)


# Attempt to load any persisted FAISS index at import time to speed up first queries
try:
    if HAS_FAISS:
        _load_persisted_faiss()
except Exception:
    pass
