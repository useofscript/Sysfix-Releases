"""
Workspace agent helpers — lightweight indexer and summarizer.

Purpose: give Fyxa a compact, safe, and local view of the user's workspace
so she can produce more accurate, context-aware plans. Indexing is limited
by file count and size to avoid leaking large files or secrets.

Functions:
- index_workspace(root, max_files, max_size_bytes) -> List[Dict]
- get_workspace_summary(root, query, max_files, max_chars) -> str

Indexing policy (defaults):
- max_files=200, max_size_bytes=50KB per file
- include only common source/text file extensions
"""
from pathlib import Path
from typing import List, Dict, Any
import os
import json

TEXT_EXTS = {
    ".py", ".md", ".txt", ".toml", ".cfg", ".ini", ".json", ".yaml", ".yml",
    ".sh", ".rs", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".html",
}


def _is_text_file(path: Path) -> bool:
    return path.suffix.lower() in TEXT_EXTS or path.name.lower().startswith("readme")


def index_workspace(root: str = ".", max_files: int = 200, max_size_bytes: int = 50 * 1024) -> List[Dict[str, Any]]:
    """Index small text files under `root` and return light summaries.

    Returns list of dicts: {"path": str, "summary": str}
    """
    p = Path(root).expanduser().resolve()
    found: List[Dict[str, Any]] = []
    if not p.exists() or not p.is_dir():
        return found

    # Walk but avoid virtual envs, node_modules, .git, build dirs
    ignore_dirs = {".git", "node_modules", "venv", "dist", "build", "__pycache__"}
    count = 0
    for dirpath, dirnames, filenames in os.walk(p):
        # prune ignored dirs
        dirnames[:] = [d for d in dirnames if d not in ignore_dirs]
        for fn in filenames:
            if count >= max_files:
                break
            fp = Path(dirpath) / fn
            try:
                if not _is_text_file(fp):
                    continue
                size = fp.stat().st_size
                if size > max_size_bytes:
                    continue
                text = fp.read_text(errors="ignore")[:4096]
                # Build a tiny summary: first non-empty lines up to ~400 chars
                lines = [l.strip() for l in text.splitlines() if l.strip()]
                summary = " ".join(lines[:6])[:400]
                found.append({"path": str(fp.relative_to(p)), "summary": summary})
                count += 1
            except Exception:
                continue
        if count >= max_files:
            break

    return found


def get_workspace_summary(root: str = ".", query: str = "", max_files: int = 80, max_chars: int = 1200) -> str:
    """Return a compact, human-readable workspace summary suitable for prompts.

    When a `query` is provided, rank files by simple relevance heuristics so
    Fyxa sees the most relevant snippets first.
    """
    items = index_workspace(root, max_files=max_files)
    if not items:
        return ""

    if query:
        import difflib
        q = query.lower()
        scored = []
        q_words = set(q.split())
        for it in items:
            text = it["summary"].lower()
            overlap = sum(1 for w in q_words if w in text)
            sim = difflib.SequenceMatcher(None, q, text).ratio()
            score = overlap * 2 + sim * 3
            scored.append((score, it))
        scored.sort(key=lambda x: x[0], reverse=True)
        items = [s[1] for s in scored if s[0] > 0.05][:max_files]
        # if nothing scored well, fallback to most recent items
        if not items:
            items = index_workspace(root, max_files=max_files)

    lines = [f"WORKSPACE SUMMARY (root={root}):"]
    for it in items[:max_files]:
        lines.append(f"- {it['path']}: {it['summary']}")
    out = "\n".join(lines)
    return out[:max_chars]