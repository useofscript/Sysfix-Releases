"""
Enhanced CLI module for sysfix-ai.

Provides a full-featured command-line interface mirroring every capability
of the graphical UI: diagnostics, AI chat, security scanning, network
analysis, virus scanning, system updates, and brain/memory management.

Styled with Rich for a professional terminal experience.
"""

from typing import List, Optional, Dict
import time
import os
import sys

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.text import Text
from rich.rule import Rule
from rich.prompt import Confirm, Prompt
from rich.markdown import Markdown
from rich.logging import RichHandler
import logging

from sysfixai import __version__
from sysfixai.core import (
    diagnose,
    categorize_issues,
    ai_auto_fix,
    ai_deep_dive,
    sudo_mode,
    tracker,
    is_ollama_running,
)

console = Console()

logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    handlers=[RichHandler(console=console)],
)

# ── Shared helpers ──────────────────────────────────────────────────────────


def print_banner() -> None:
    banner = Text.assemble(
        "\n",
        ("SYSFIX-AI", "bold green"),
        (f"  v{__version__}", "dim green"),
        (" — Linux Diagnostics & AI-Powered Fixes\n", "cyan"),
        ("Powered by Fyxa AI  •  © 2026 useofscript  •  MIT Licensed\n", "dim yellow"),
    )
    console.print(banner)


def print_section(title: str) -> None:
    console.print(Rule(title=f"[bold cyan]{title}[/bold cyan]", style="cyan"))


def print_success(msg: str) -> None:
    console.print(f"[green]✓[/green] [bold green]{msg}[/bold green]")


def print_warning(msg: str) -> None:
    console.print(f"[yellow]⚠[/yellow] [bold yellow]{msg}[/bold yellow]")


def print_error(msg: str) -> None:
    console.print(f"[red]✗[/red] [bold red]{msg}[/bold red]")


def print_info(msg: str) -> None:
    console.print(f"[cyan]ℹ[/cyan] [bold cyan]{msg}[/bold cyan]")


def _pause() -> None:
    console.input("\n[dim]Press Enter to continue…[/dim]")


def _spinner(label: str, func, *args, **kwargs):
    """Run *func* behind a spinner, return its result."""
    result = None
    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"[cyan]{label}", total=None)
        result = func(*args, **kwargs)
        progress.update(task, completed=True, description=f"[green]{label} — done[/green]")
    return result


# ── Diagnostics helpers ─────────────────────────────────────────────────────


def scan_with_progress() -> List[str]:
    return _spinner("Scanning system…", diagnose)


def display_issues(issues: List[str]) -> int:
    if not issues or (len(issues) == 1 and issues[0] == "No issues detected."):
        console.print(Panel(
            "[green bold]✓ System is healthy![/green bold]\n"
            "[cyan]No issues detected during diagnostic scan.[/cyan]",
            title="[green bold]System Status[/green bold]",
            border_style="green", padding=(1, 2),
        ))
        return 0

    categorized = categorize_issues(issues)
    problem_count = 0

    if categorized["problems"]:
        problem_count = len(categorized["problems"])
        tbl = Table(title=f"[red bold]⚠  CRITICAL ISSUES ({problem_count})[/red bold]",
                    style="red", border_style="red", show_header=True, padding=(0, 1))
        tbl.add_column("[red bold]Issue[/red bold]", style="red", no_wrap=False)
        for i, p in enumerate(categorized["problems"], 1):
            tbl.add_row(f"[bold]{i}.[/bold] {p}")
        console.print(Panel(tbl, border_style="red", padding=(1, 2)))

    if categorized["warnings"]:
        tbl = Table(title=f"[yellow bold]⚡ WARNINGS ({len(categorized['warnings'])})[/yellow bold]",
                    style="yellow", border_style="yellow", show_header=True, padding=(0, 1))
        tbl.add_column("[yellow bold]Warning[/yellow bold]", style="yellow", no_wrap=False)
        for w in categorized["warnings"]:
            tbl.add_row(w)
        console.print(Panel(tbl, border_style="yellow", padding=(1, 2)))

    if categorized["info"]:
        tbl = Table(title=f"[cyan bold]ℹ  SYSTEM INFO ({len(categorized['info'])})[/cyan bold]",
                    style="cyan", border_style="cyan", show_header=True, padding=(0, 1))
        tbl.add_column("[cyan bold]Information[/cyan bold]", style="cyan", no_wrap=False)
        for info in categorized["info"]:
            tbl.add_row(info)
        console.print(Panel(tbl, border_style="cyan", padding=(1, 2)))

    return problem_count


# ═══════════════════════════════════════════════════════════════════════════
# CLI root
# ═══════════════════════════════════════════════════════════════════════════

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """sysfix-ai — Professional Linux diagnostics with AI-powered fixes, security
    scanning, network analysis, brain memory, and more.

    Run without a subcommand to see this help.
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command()
def gui():
    """Launch the graphical interface."""
    try:
        from sysfixai.gui import main as gui_main

        gui_main()
    except Exception as e:
        print_error(f"Failed to launch GUI: {e}")
        print_info("If running headless, use: sysfix interactive")


# ═══════════════════════════════════════════════════════════════════════════
# Diagnostics commands
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def check():
    """Run system diagnostics with optional AI assistance."""
    print_banner()

    print_section("System Status")
    if is_ollama_running():
        print_success("Ollama AI service is running")
    else:
        print_warning("Ollama AI service not running (basic mode only)")

    console.print()
    print_section("System Diagnostics")
    issues = scan_with_progress()
    console.print()
    problem_count = display_issues(issues)

    if problem_count > 0 and is_ollama_running():
        console.print()
        console.print(Panel(
            "[cyan]AI assistance available for this system.[/cyan]",
            title="[cyan bold]AI Mode[/cyan bold]", border_style="cyan",
        ))
        if Confirm.ask("[cyan bold]Would you like AI assistance to fix issues?[/cyan bold]", default=False):
            console.print()
            console.print(Panel(
                "[cyan bold]1[/cyan bold] — Fast Sweep (quick fixes with confirmation)\n"
                "[cyan bold]2[/cyan bold] — Deep Dive (detailed troubleshooting)",
                title="[cyan bold]AI Modes[/cyan bold]", border_style="cyan",
            ))
            mode = Prompt.ask("[cyan bold]Choice[/cyan bold]", choices=["1", "2"], default="1")
            console.print()
            if mode == "1":
                print_section("Fast Sweep Mode")
                print_info("Scanning for quick fixes…")
                ai_auto_fix(issues)
            else:
                print_section("Deep Dive Mode")
                ai_deep_dive()


@cli.command()
@click.argument("issue_number", type=int)
def fix(issue_number):
    """Apply fix for a given issue number."""
    print_banner()
    print_section("Fetching Issues")
    issues = diagnose()

    if not issues or issues[0] == "No issues detected.":
        print_success("No issues to fix — system is healthy!")
        return

    if issue_number < 1 or issue_number > len(issues):
        print_error(f"Invalid issue number: {issue_number}")
        console.print(f"[cyan]Valid range: 1–{len(issues)}[/cyan]")
        return

    issue = issues[issue_number - 1]
    console.print()
    console.print(Panel(f"[white]{issue}[/white]", title="[cyan bold]Issue[/cyan bold]",
                        border_style="cyan", padding=(1, 2)))
    console.print()

    if Confirm.ask("[cyan bold]Use AI assistant to fix?[/cyan bold]", default=True):
        if is_ollama_running():
            print_section("AI Fix Mode")
            ai_auto_fix([issue])
        else:
            print_warning("Ollama service not available — basic mode only")
    else:
        print_info("Fix cancelled")


@cli.command()
def run():
    """Quick scan and fix with AI assistance (fast mode)."""
    print_banner()

    print_section("System Status")
    if is_ollama_running():
        print_success("Ollama AI service is running")
    else:
        print_warning("Ollama AI service not running (basic mode only)")

    console.print()
    print_section("System Diagnostics")
    issues = scan_with_progress()
    console.print()
    problem_count = display_issues(issues)

    if problem_count > 0 and is_ollama_running():
        console.print()
        if Confirm.ask("[cyan bold]Apply AI fixes?[/cyan bold]", default=True):
            mode = Prompt.ask("[cyan bold]Mode[/cyan bold]", choices=["1", "2"],
                             default="1", show_choices=False)
            console.print()
            if mode == "1":
                print_section("Fast Sweep Mode")
                ai_auto_fix(issues)
            else:
                print_section("Deep Dive Mode")
                ai_deep_dive()


@cli.command()
def status():
    """Display quick system status and health check."""
    print_banner()
    print_section("System Status")

    if is_ollama_running():
        print_success("Ollama AI service is running")
    else:
        print_warning("Ollama AI service not running")

    console.print()
    print_info("Running quick diagnostics…")
    issues = _spinner("Analysing system", diagnose)
    console.print()

    categorized = categorize_issues(issues)
    summary_lines = [
        f"[cyan bold]Total Items:[/cyan bold] {len(issues)}",
        f"[red bold]Problems:[/red bold]   {len(categorized['problems'])}",
        f"[yellow bold]Warnings:[/yellow bold]   {len(categorized['warnings'])}",
        f"[cyan bold]Info Items:[/cyan bold] {len(categorized['info'])}",
    ]

    if categorized["problems"]:
        border, msg = "red", "[red bold]⚠ ATTENTION NEEDED[/red bold]"
    elif categorized["warnings"]:
        border, msg = "yellow", "[yellow bold]⚠ Some warnings[/yellow bold]"
    else:
        border, msg = "green", "[green bold]✓ System Healthy[/green bold]"

    console.print(Panel("\n".join(summary_lines), title=msg, border_style=border, padding=(1, 2)))

    if tracker.issues:
        console.print()
        console.print(Panel(tracker.summary(), title="[cyan bold]Session Summary[/cyan bold]",
                            border_style="cyan", padding=(1, 2)))


# ═══════════════════════════════════════════════════════════════════════════
# Security
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def security():
    """Run a full security audit (ports, firewall, SUID, SSH, rootkits, …)."""
    print_banner()
    print_section("Security Audit")

    from sysfixai.diagnostics import security_scan_full

    results = _spinner("Running security checks…", security_scan_full)
    console.print()

    if len(results) == 1 and "no security" in results[0].lower():
        print_success("No security concerns detected.")
    else:
        tbl = Table(title="[red bold]Security Findings[/red bold]",
                    border_style="red", show_header=True, padding=(0, 1))
        tbl.add_column("#", style="bold", width=4)
        tbl.add_column("Finding", style="white", no_wrap=False)
        for i, line in enumerate(results, 1):
            style = "red" if any(k in line.lower() for k in ("warning", "fail", "suspicious", "concern")) else "yellow"
            tbl.add_row(str(i), f"[{style}]{line}[/{style}]")
        console.print(Panel(tbl, border_style="red", padding=(1, 2)))

    console.print()
    print_info(f"Total findings: {len(results)}")


# ═══════════════════════════════════════════════════════════════════════════
# Network
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def network():
    """Run network diagnostics (interfaces, DNS, gateway, connectivity)."""
    print_banner()
    print_section("Network Diagnostics")

    from sysfixai.diagnostics import network_diagnostics

    results = _spinner("Testing network…", network_diagnostics)
    console.print()

    for line in results:
        low = line.lower()
        if any(k in low for k in ("ok", "pass", "success", "reachable", "active")):
            print_success(line)
        elif any(k in low for k in ("fail", "error", "unreachable", "no ")):
            print_error(line)
        elif any(k in low for k in ("warning", "slow")):
            print_warning(line)
        else:
            print_info(line)


# ═══════════════════════════════════════════════════════════════════════════
# System Health
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def health():
    """System health check (boot time, failed services, journal, SMART, USB)."""
    print_banner()
    print_section("System Health")

    from sysfixai.diagnostics import (
        check_boot_time, check_systemd_failed, check_journal_errors,
        check_usb_devices, check_smart_health,
    )

    all_results: List[str] = []
    checks = [
        ("Boot time", check_boot_time),
        ("Systemd services", check_systemd_failed),
        ("Journal errors", check_journal_errors),
        ("USB devices", check_usb_devices),
        ("SMART disk health", check_smart_health),
    ]

    for label, fn in checks:
        res = _spinner(label, fn)
        all_results.extend(res)
        console.print()

    tbl = Table(title="[cyan bold]Health Report[/cyan bold]",
                border_style="cyan", show_header=True, padding=(0, 1))
    tbl.add_column("#", style="bold", width=4)
    tbl.add_column("Detail", style="white", no_wrap=False)
    for i, line in enumerate(all_results, 1):
        low = line.lower()
        if any(k in low for k in ("fail", "error", "degraded")):
            style = "red"
        elif any(k in low for k in ("warning", "slow")):
            style = "yellow"
        else:
            style = "cyan"
        tbl.add_row(str(i), f"[{style}]{line}[/{style}]")
    console.print(Panel(tbl, border_style="cyan", padding=(1, 2)))


# ═══════════════════════════════════════════════════════════════════════════
# Virus / malware scanning
# ═══════════════════════════════════════════════════════════════════════════

@cli.command("scan")
@click.argument("target", default="")
@click.option("--downloads", is_flag=True, help="Scan ~/Downloads directory.")
def scan_cmd(target: str, downloads: bool):
    """Scan a file or directory for known malware hashes.

    TARGET can be a file path or directory path.  Use --downloads to scan
    your Downloads folder.  Checks SHA-256 hashes against MalwareBazaar
    (and VirusTotal if an API key is configured in Settings).
    """
    print_banner()
    print_section("Malware Hash Scan")

    from sysfixai.diagnostics import scan_file_hash, scan_directory_hashes
    from sysfixai.config import get_setting

    vt_key = get_setting("virustotal_api_key", "")

    if downloads:
        dl_dir = os.path.expanduser("~/Downloads")
        if not os.path.isdir(dl_dir):
            print_error("~/Downloads directory not found.")
            return
        target = dl_dir

    if not target:
        print_error("Provide a file/directory path, or use --downloads.")
        console.print("[dim]  sysfix scan /path/to/file[/dim]")
        console.print("[dim]  sysfix scan /path/to/dir[/dim]")
        console.print("[dim]  sysfix scan --downloads[/dim]")
        return

    target = os.path.expanduser(target)

    if os.path.isfile(target):
        print_info(f"Scanning file: {target}")
        results = _spinner("Checking hash…", scan_file_hash, target, vt_key)
        console.print()
        for line in results:
            low = line.lower()
            if any(k in low for k in ("clean", "not found", "no match")):
                print_success(line)
            elif any(k in low for k in ("malware", "malicious", "detected", "threat")):
                print_error(line)
            else:
                print_info(line)

    elif os.path.isdir(target):
        print_info(f"Scanning directory: {target}")
        results = _spinner("Hashing files…", scan_directory_hashes, target, vt_key)
        console.print()

        clean = [r for r in results if any(k in r.lower() for k in ("clean", "not found", "no match"))]
        threats = [r for r in results if any(k in r.lower() for k in ("malware", "malicious", "detected", "threat"))]
        other = [r for r in results if r not in clean and r not in threats]

        if threats:
            for t in threats:
                print_error(t)
        if other:
            for o in other:
                print_info(o)

        console.print()
        print_info(f"Files scanned: {len(results)}  |  Threats: {len(threats)}  |  Clean: {len(clean)}")
    else:
        print_error(f"Path not found: {target}")


# ═══════════════════════════════════════════════════════════════════════════
# Updates
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--system", "do_system", is_flag=True, help="Apply system package updates (dnf/apt).")
@click.option("--self", "do_self", is_flag=True, help="Update sysfix-ai from GitHub.")
@click.option("--check-only", is_flag=True, help="Only check for updates, don't install.")
def update(do_system: bool, do_self: bool, check_only: bool):
    """Check for and apply updates.

    Without flags, checks for both system and sysfix updates.
    """
    print_banner()

    from sysfixai.diagnostics import (
        check_pending_updates, apply_system_updates,
        check_sysfix_update, apply_sysfix_update,
    )

    if not do_system and not do_self:
        do_system = do_self = True

    # ── Sysfix update ──
    if do_self:
        print_section("Sysfix Update")
        result = _spinner("Checking sysfix-ai…", check_sysfix_update)
        console.print()
        for line in result:
            if "behind" in line.lower() or "update" in line.lower():
                print_warning(line)
            else:
                print_info(line)

        if not check_only and any("behind" in l.lower() for l in result):
            if Confirm.ask("[cyan bold]Pull latest sysfix-ai?[/cyan bold]", default=True):
                out = _spinner("Pulling…", apply_sysfix_update)
                console.print()
                for line in out:
                    print_success(line) if "success" in line.lower() or "updated" in line.lower() else print_info(line)

    # ── System updates ──
    if do_system:
        print_section("System Package Updates")
        result = _spinner("Checking packages…", check_pending_updates)
        console.print()
        for line in result:
            if any(k in line.lower() for k in ("available", "update", "upgrade")):
                print_warning(line)
            else:
                print_info(line)

        if not check_only and any("available" in l.lower() for l in result):
            if Confirm.ask("[cyan bold]Apply system updates? (requires sudo)[/cyan bold]", default=False):
                out = _spinner("Applying updates…", apply_system_updates)
                console.print()
                for line in out:
                    print_info(line)


# ═══════════════════════════════════════════════════════════════════════════
# Brain / Memory
# ═══════════════════════════════════════════════════════════════════════════

@cli.group()
def brain():
    """Manage Fyxa's persistent memory (brain).

    The brain stores everything Fyxa learns about your system, preferences,
    past solutions, and conversation insights.  Data is stored locally at
    ~/.config/sysfix/brain.json — nothing leaves your machine.
    """
    pass


@brain.command("stats")
def brain_stats():
    """Show brain statistics."""
    print_banner()
    print_section("Brain Statistics")

    from sysfixai.memory import get_brain_stats, get_brain_size_kb

    stats = get_brain_stats()
    size = get_brain_size_kb()

    tbl = Table(border_style="cyan", show_header=False, padding=(0, 2))
    tbl.add_column("Key", style="cyan bold")
    tbl.add_column("Value", style="white")
    tbl.add_row("Created", stats.get("created", "never"))
    tbl.add_row("Last updated", stats.get("last_updated", "never"))
    tbl.add_row("System facts", str(stats.get("system_facts", 0)))
    tbl.add_row("User preferences", str(stats.get("user_preferences", 0)))
    tbl.add_row("Solutions", str(stats.get("solutions", 0)))
    tbl.add_row("Observations", str(stats.get("observations", 0)))
    tbl.add_row("Insights", str(stats.get("insights", 0)))
    tbl.add_row("Total facts learned", str(stats.get("total_facts", 0)))
    tbl.add_row("System scans", str(stats.get("system_scans", 0)))
    tbl.add_row("Conversations learned", str(stats.get("conversations_learned", 0)))
    tbl.add_row("File size", f"{size:.1f} KB")

    console.print(Panel(tbl, title="[cyan bold]Fyxa's Brain[/cyan bold]",
                        border_style="cyan", padding=(1, 2)))


@brain.command("view")
def brain_view():
    """Dump all brain contents."""
    print_banner()
    print_section("Brain Dump")

    from sysfixai.memory import get_brain_dump

    lines = get_brain_dump()
    for line in lines:
        if line.startswith("═══"):
            console.print(f"\n[cyan bold]{line}[/cyan bold]")
        elif line.startswith("  ✓"):
            console.print(f"[green]{line}[/green]")
        elif line.startswith("  ✗"):
            console.print(f"[red]{line}[/red]")
        elif line.startswith("  "):
            console.print(f"[white]{line}[/white]")
        else:
            console.print(f"[dim]{line}[/dim]")


@brain.command("learn")
@click.option("--deep", is_flag=True, help="Deep learn: scan dotfiles, projects, dev tools, and common software.")
def brain_learn(deep: bool):
    """Teach Fyxa about your system.

    Without --deep: detects hardware, OS, DE, shell, package manager.
    With --deep: also scans dotfiles, projects, dev tools, installed software.
    """
    print_banner()
    label = "Deep learning system…" if deep else "Learning system…"
    print_section("Brain: Learn System")

    from sysfixai.memory import observe_system

    results = _spinner(label, observe_system, deep=deep)
    console.print()

    for line in results:
        print_info(line)

    console.print()
    print_success(f"Learned {len(results)} new facts.")


@brain.command("clear")
def brain_clear():
    """Erase all brain memory (cannot be undone)."""
    print_banner()
    print_section("Clear Brain")

    if Confirm.ask("[red bold]Erase ALL of Fyxa's memory? This cannot be undone.[/red bold]", default=False):
        from sysfixai.memory import clear_brain
        clear_brain()
        print_success("Brain cleared.")
    else:
        print_info("Cancelled — brain untouched.")


# ═══════════════════════════════════════════════════════════════════════════
# AI Chat (Fyxa)
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def chat():
    """Start an interactive conversation with Fyxa AI.

    Talk to Fyxa just like in the GUI — she has web search, system context,
    conversation memory, and brain knowledge.  Type 'exit' or 'quit' to leave.
    """
    print_banner()
    print_section("Fyxa AI Chat")

    if not is_ollama_running():
        print_error("Ollama is not running — please start it first: ollama serve")
        return

    from sysfixai.ai import get_deep_dive, get_system_snapshot, get_active_model

    model = get_active_model()
    print_success(f"Connected to Ollama — model: {model}")
    console.print()
    console.print(Panel(
        "[green bold]Hey! I'm Fyxa, your system engineer with web search.[/green bold]\n\n"
        "[cyan]I can see your live system stats, diagnose issues, search for\n"
        "solutions online, and help manage your projects.  Ask me anything!\n\n"
        "Type [bold]exit[/bold] or [bold]quit[/bold] to leave.[/cyan]",
        title="[green bold]Fyxa[/green bold]", border_style="green", padding=(1, 2),
    ))

    system_context = get_system_snapshot()
    chat_history: List[Dict[str, str]] = []

    while True:
        console.print()
        try:
            user_input = console.input("[cyan bold]You ❯ [/cyan bold]").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit", "q", "bye"):
            break

        chat_history.append({"role": "user", "content": user_input})

        with Progress(
            SpinnerColumn(style="green"),
            TextColumn("[green]Fyxa is thinking…[/green]"),
            console=console,
        ) as progress:
            progress.add_task("", total=None)
            response = get_deep_dive(
                user_input,
                gui_mode=True,
                chat_history=chat_history,
                system_context=system_context,
            )

        chat_history.append({"role": "assistant", "content": response})

        console.print()
        console.print(Panel(
            response,
            title="[green bold]Fyxa[/green bold]", border_style="green", padding=(1, 2),
        ))

    console.print()
    console.print(Panel(
        "[green bold]See you later! Stay secure. 🔒[/green bold]",
        border_style="green", padding=(1, 2),
    ))


# ═══════════════════════════════════════════════════════════════════════════
# Version
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def version():
    """Show sysfix-ai version information."""
    from sysfixai.ai import get_active_model

    console.print(Panel(
        f"[cyan bold]sysfix-ai[/cyan bold]  v{__version__}\n"
        f"[dim]AI model:[/dim]  {get_active_model()}\n"
        f"[dim]Ollama:[/dim]   {'running' if is_ollama_running() else 'not running'}\n"
        f"[dim]Python:[/dim]   {sys.version.split()[0]}\n"
        f"[dim]License:[/dim]  MIT — © 2026 useofscript",
        title="[cyan bold]Version Info[/cyan bold]", border_style="cyan", padding=(1, 2),
    ))


# ═══════════════════════════════════════════════════════════════════════════
# Sudo / Hardware mode
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def sudomode():
    """Advanced mode for hardware tuning (VERY DANGEROUS)."""
    sudo_mode()


# ═══════════════════════════════════════════════════════════════════════════
# Advanced diagnostics
# ═══════════════════════════════════════════════════════════════════════════

@cli.command("advanced")
def advanced_cmd():
    """Run all advanced diagnostics (health score, predictive, zombies, kernel, logs, repos, energy)."""
    from sysfixai.advanced_diagnostics import advanced_diagnostics_full
    print_banner()
    print_section("Advanced Diagnostics")
    results = _spinner("Running advanced diagnostics…", advanced_diagnostics_full)
    console.print()
    for line in results:
        low = line.lower()
        if "danger" in low or "critical" in low:
            print_error(line)
        elif "warn" in low:
            print_warning(line)
        elif "ok:" in low or "excellent" in low or "good" in low:
            print_success(line)
        else:
            print_info(line)
    _pause()


@cli.command("health-score")
def health_score_cmd():
    """Compute a comprehensive hardware health score (0-100)."""
    from sysfixai.advanced_diagnostics import hardware_health_score
    print_banner()
    print_section("Hardware Health Score")
    results = _spinner("Computing…", hardware_health_score)
    console.print()
    for line in results:
        if "Health Score" in line:
            console.print(f"[bold cyan]{line}[/bold cyan]")
        elif "WARN" in line or "DANGER" in line:
            print_warning(line)
        else:
            print_info(line)


@cli.command("predict")
def predict_cmd():
    """Predictive disk analysis — S.M.A.R.T. trend & lifespan estimation."""
    from sysfixai.advanced_diagnostics import smart_predictive_analysis
    print_banner()
    print_section("Predictive Disk Analysis")
    results = _spinner("Analysing S.M.A.R.T. data…", smart_predictive_analysis)
    console.print()
    for line in results:
        if "WARN" in line or "DANGER" in line:
            print_error(line)
        elif "OK" in line:
            print_success(line)
        else:
            print_info(line)


@cli.command("zombies")
def zombies_cmd():
    """Hunt zombie and D-state processes."""
    from sysfixai.advanced_diagnostics import zombie_process_hunter
    print_banner()
    print_section("Zombie Process Hunter")
    results = _spinner("Hunting…", zombie_process_hunter)
    console.print()
    for line in results:
        if "WARN" in line:
            print_warning(line)
        elif "OK" in line:
            print_success(line)
        else:
            print_info(line)


@cli.command("kernel-audit")
def kernel_audit_cmd():
    """Audit kernel sysctl parameters and suggest optimisations."""
    from sysfixai.advanced_diagnostics import kernel_param_audit
    print_banner()
    print_section("Kernel Parameter Audit")
    results = _spinner("Auditing…", kernel_param_audit)
    console.print()
    for line in results:
        if "→" in line:
            print_warning(line)
        elif "good" in line.lower():
            print_success(line)
        else:
            print_info(line)


@cli.command("energy")
def energy_cmd():
    """Analyse energy usage and suggest battery optimisations."""
    from sysfixai.advanced_diagnostics import energy_profile
    print_banner()
    print_section("Energy Profile")
    results = _spinner("Profiling…", energy_profile)
    console.print()
    for line in results:
        if "WARN" in line or "TIP" in line:
            print_warning(line)
        elif "LOW BATTERY" in line:
            print_error(line)
        else:
            print_info(line)


@cli.command("logs")
def logs_cmd():
    """Analyse system logs for pre-failure patterns (last 24h)."""
    from sysfixai.advanced_diagnostics import log_pattern_analysis
    print_banner()
    print_section("Log Pattern Analysis")
    results = _spinner("Scanning logs…", log_pattern_analysis)
    console.print()
    for line in results:
        if "DANGER" in line:
            print_error(line)
        elif "WARN" in line:
            print_warning(line)
        elif "OK" in line:
            print_success(line)
        else:
            print_info(line)


@cli.command("repos")
def repos_cmd():
    """Audit package repositories for orphans, duplicates, and broken deps."""
    from sysfixai.advanced_diagnostics import repo_audit
    print_banner()
    print_section("Repository Audit")
    results = _spinner("Auditing…", repo_audit)
    console.print()
    for line in results:
        if "WARN" in line:
            print_warning(line)
        elif "OK" in line:
            print_success(line)
        else:
            print_info(line)


@cli.command("export-brain")
@click.argument("path", required=False, default="")
def export_brain_cmd(path):
    """Export Fyxa's brain to a portable JSON file."""
    from sysfixai.advanced_diagnostics import export_brain
    print_section("Brain Export")
    results = export_brain(path)
    for line in results:
        if "OK" in line:
            print_success(line)
        elif "ERROR" in line:
            print_error(line)
        else:
            print_info(line)


@cli.command("import-brain")
@click.argument("path")
@click.option("--replace", is_flag=True, help="Replace brain entirely instead of merging")
def import_brain_cmd(path, replace):
    """Import a Fyxa brain export from another machine."""
    from sysfixai.advanced_diagnostics import import_brain
    print_section("Brain Import")
    results = import_brain(path, merge=not replace)
    for line in results:
        if "OK" in line:
            print_success(line)
        elif "ERROR" in line:
            print_error(line)
        else:
            print_info(line)


@cli.command("prescriptive")
def prescriptive_cmd():
    """Prescriptive analysis — predict problems before they happen."""
    from sysfixai.sandbox import prescriptive_analysis
    print_section("Prescriptive Analysis")
    results = prescriptive_analysis()
    for line in results:
        if "🔴" in line:
            print_error(line)
        elif "🟡" in line:
            print_warning(line)
        else:
            print_info(line)


@cli.command("golden-state")
@click.option("--capture", is_flag=True, help="Capture current system as Golden State baseline")
@click.option("--reconcile", is_flag=True, help="Restart stopped services that should be active")
def golden_state_cmd(capture, reconcile):
    """Golden State — declarative system baseline and drift detection."""
    if capture:
        from sysfixai.sandbox import capture_current_as_golden
        print_section("Capture Golden State")
        for line in capture_current_as_golden():
            print_info(line)
    elif reconcile:
        from sysfixai.sandbox import golden_state_reconcile_services
        print_section("Golden State Reconcile")
        for line in golden_state_reconcile_services():
            print_info(line)
    else:
        from sysfixai.sandbox import golden_state_drift_check
        print_section("Golden State Drift Check")
        results = golden_state_drift_check()
        for line in results:
            if "⚠" in line:
                print_warning(line)
            elif "✓" in line:
                print_success(line)
            else:
                print_info(line)


@cli.command("log-search")
@click.argument("query")
@click.option("--hours", default=24, help="Hours to search back (default: 24)")
def log_search_cmd(query, hours):
    """Search system logs with natural language."""
    from sysfixai.sandbox import semantic_log_search
    print_section("Semantic Log Search")
    results = semantic_log_search(query, hours=hours)
    for line in results:
        if line.strip().startswith("["):
            print_info(line)
        else:
            print_info(line)


@cli.command("sandbox")
@click.argument("commands", nargs=-1, required=True)
def sandbox_cmd(commands):
    """Test command(s) in a sandboxed environment before applying."""
    from sysfixai.sandbox import sandbox_dry_run
    print_section("Sandbox Dry-Run")
    results = sandbox_dry_run(list(commands))
    for line in results:
        if "PASS" in line:
            print_success(line)
        elif "FAIL" in line:
            print_error(line)
        else:
            print_info(line)


@cli.command("safety-pin")
def safety_pin_cmd():
    """Toggle Safety Pin mode (safe vs autonomous)."""
    from sysfixai.sandbox import get_safety_pin_status, toggle_safety_pin
    current = get_safety_pin_status()
    print_section("Safety Pin")
    print_info(f"Current: {current['label']}")
    print_info(f"  {current['description']}")
    if click.confirm("Toggle mode?"):
        new = toggle_safety_pin()
        print_success(f"Switched to: {new['label']}")
        print_info(f"  {new['description']}")
    else:
        print_info("No change.")


@cli.command("sentinel")
@click.option("--start", "action", flag_value="start", help="Start eBPF Sentinel")
@click.option("--stop", "action", flag_value="stop", help="Stop eBPF Sentinel")
@click.option("--status", "action", flag_value="status", default=True, help="Show sentinel status (default)")
def sentinel_cmd(action):
    """eBPF Sentinel — real-time process and network monitoring."""
    from sysfixai.ebpf_sentinel import start_sentinel, stop_sentinel, sentinel_report
    if action == "start":
        print_section("Starting eBPF Sentinel")
        msg = start_sentinel()
        if "✓" in msg:
            print_success(msg)
        else:
            print_warning(msg)
    elif action == "stop":
        print_section("Stopping eBPF Sentinel")
        msg = stop_sentinel()
        print_info(msg)
    else:
        print_section("eBPF Sentinel Status")
        for line in sentinel_report():
            if "✓" in line:
                print_success(line)
            elif "⚠" in line:
                print_warning(line)
            elif "🔴" in line or "🟠" in line:
                print_error(line)
            else:
                print_info(line)


@cli.command("microvm")
@click.argument("commands", nargs=-1)
@click.option("--status", "show_status", is_flag=True, help="Show micro-VM backend status")
@click.option("--setup", is_flag=True, help="Set up Firecracker VM environment")
def microvm_cmd(commands, show_status, setup):
    """Run commands in a Firecracker micro-VM sandbox."""
    if show_status:
        from sysfixai.microvm import microvm_report
        print_section("Micro-VM Status")
        for line in microvm_report():
            if "✓" in line:
                print_success(line)
            elif "⚠" in line:
                print_warning(line)
            else:
                print_info(line)
    elif setup:
        from sysfixai.microvm import setup_vm_environment
        print_section("Setting up Micro-VM Environment")
        for line in setup_vm_environment():
            if "✓" in line:
                print_success(line)
            elif "⚠" in line:
                print_warning(line)
            else:
                print_info(line)
    elif commands:
        from sysfixai.microvm import microvm_run
        print_section("Micro-VM Dry-Run")
        results = microvm_run(list(commands))
        for line in results:
            if "PASS" in line:
                print_success(line)
            elif "FAIL" in line:
                print_error(line)
            else:
                print_info(line)
    else:
        print_info("Usage: sysfix microvm <command> ... | sysfix microvm --status | sysfix microvm --setup")


@cli.command("npu")
def npu_cmd():
    """Check NPU (Neural Processing Unit) status and offloading capability."""
    from sysfixai.npu import npu_report
    print_section("NPU Status")
    for line in npu_report():
        if "✓" in line:
            print_success(line)
        elif "⚠" in line:
            print_warning(line)
        elif "●" in line:
            print_info(line)
        else:
            print_info(line)


@cli.command("pulse")
@click.option("--start", "action", flag_value="start", help="Start the System Pulse telemetry daemon.")
@click.option("--stop", "action", flag_value="stop", help="Stop the System Pulse telemetry daemon.")
@click.option("--status", "action", flag_value="status", default=True, help="Show current pulse status and report.")
def pulse_cmd(action):
    """Manage the real-time System Pulse telemetry daemon."""
    from sysfixai.system_pulse import start_pulse, stop_pulse, pulse_status, pulse_report
    print_section("System Pulse")
    if action == "start":
        msg = start_pulse(interval=5.0)
        if "✓" in msg:
            print_success(msg)
        else:
            print_warning(msg)
    elif action == "stop":
        msg = stop_pulse()
        print_info(msg)
    else:
        status = pulse_status()
        running = status.get("running", False)
        tag = "[green]running[/green]" if running else "[yellow]stopped[/yellow]"
        console.print(f"  Pulse daemon: {tag}")
        if status.get("snapshots"):
            console.print(f"  Snapshots collected: {status['snapshots']}")
        console.print()
        for line in pulse_report():
            if "✓" in line or "→" in line:
                print_info(line)
            elif "⚠" in line or "↑" in line:
                print_warning(line)
            elif "✗" in line or "ALERT" in line:
                print_error(line)
            else:
                print_info(line)


@cli.command("agent-status")
def agent_status_cmd():
    """Show the agentic reasoning engine (1.1.0) capability report."""
    from sysfixai.reasoning_loop import agent_report
    print_section("Agentic Engine (1.1.0)")
    for line in agent_report():
        if "✓" in line:
            print_success(line)
        elif "⚠" in line:
            print_warning(line)
        elif "●" in line:
            print_info(line)
        else:
            print_info(line)


@cli.command("safety-log")
def safety_log_cmd():
    """Show the Safety Intercept audit log and pending approvals."""
    from sysfixai.safety_intercept import intercept_report
    print_section("Safety Intercept Log")
    for line in intercept_report():
        if "BLOCKED" in line or "DENIED" in line:
            print_error(line)
        elif "APPROVED" in line or "SAFE" in line:
            print_success(line)
        elif "PENDING" in line or "⚠" in line:
            print_warning(line)
        else:
            print_info(line)


@cli.command("sentinel-av")
@click.option("--start", "action", flag_value="start", help="Start Sentinel AV kernel-level antivirus")
@click.option("--stop", "action", flag_value="stop", help="Stop Sentinel AV")
@click.option("--status", "action", flag_value="status", default=True, help="Show AV status report (default)")
def sentinel_av_cmd(action):
    """Sentinel AV — real-time kernel-level antivirus via eBPF."""
    from sysfixai.sentinel_av import start_av, stop_av, av_status, av_report
    if action == "start":
        print_section("Starting Sentinel AV")
        msg = start_av()
        if "✓" in msg or "started" in msg.lower():
            print_success(msg)
        else:
            print_warning(msg)
    elif action == "stop":
        print_section("Stopping Sentinel AV")
        msg = stop_av()
        print_info(msg)
    else:
        print_section("Sentinel AV Status")
        for line in av_report():
            if "✓" in line:
                print_success(line)
            elif "⚠" in line:
                print_warning(line)
            elif "🔴" in line or "CRITICAL" in line or "THREAT" in line:
                print_error(line)
            elif "🦠" in line:
                print_error(line)
            else:
                print_info(line)


@cli.command("av-threats")
def av_threats_cmd():
    """List all threats detected by Sentinel AV."""
    from sysfixai.sentinel_av import av_threats, format_threat_for_display
    print_section("Sentinel AV — Detected Threats")
    threats = av_threats()
    if not threats:
        print_success("No threats detected. System is clean.")
        return
    for t in threats:
        lines = format_threat_for_display(t)
        severity = t.severity.upper()
        if severity in ("CRITICAL", "HIGH"):
            print_error(lines)
        elif severity == "MEDIUM":
            print_warning(lines)
        else:
            print_info(lines)
        console.print()


@cli.command("av-threat-map")
def av_threat_map_cmd():
    """Display a visual threat map from Sentinel AV."""
    from sysfixai.sentinel_av import av_threats
    print_section("Sentinel AV — Threat Map")
    threats = av_threats()
    if not threats:
        print_success("No threats detected. Threat map is empty.")
        return
    for t in threats:
        if not t.threat_map:
            continue
        tm = t.threat_map
        console.print(f"\n[bold red]🦠 Threat: {t.threat_type}[/bold red] — PID {t.pid} ({t.comm})")
        console.print(f"  [dim]Risk Score: {tm.risk_score}/100[/dim]")
        if tm.process_tree:
            console.print("  [cyan bold]Process Tree:[/cyan bold]")
            for proc in tm.process_tree:
                console.print(f"    └─ {proc}")
        if tm.file_access_map:
            console.print("  [yellow bold]Files Touched:[/yellow bold]")
            for path, cat in tm.file_access_map.items():
                tag = f"[red]{cat}[/red]" if cat != "normal" else f"[dim]{cat}[/dim]"
                console.print(f"    {path}  ({tag})")
        if tm.network_map:
            console.print("  [magenta bold]Network Connections:[/magenta bold]")
            for addr, info in tm.network_map.items():
                mal = "[red bold]MALICIOUS[/red bold]" if info.get("malicious") else "[green]clean[/green]"
                console.print(f"    {addr}  — {mal}")
        console.print()


@cli.command("pipeline")
@click.argument("target", required=False, default=None)
@click.option("--status", "show_status", is_flag=True, help="Show pipeline capability report")
@click.option("--update-yara", "update_yara", is_flag=True, help="Update YARA community rules from GitHub")
def pipeline_cmd(target, show_status, update_yara):
    """Malware Verification Pipeline — multi-stage deep scan.

    Runs ClamAV + YARA + VirusTotal concurrently, aggregates a Threat
    Profile, and asks Fyxa AI for a plain-English risk assessment.
    """
    from sysfixai.malware_pipeline import (
        run_pipeline, pipeline_report, format_profile_for_display,
        ai_interpret_profile, _update_yara_rules,
    )

    if update_yara:
        print_section("Updating YARA Rules")
        msg = _update_yara_rules()
        if "✓" in msg:
            print_success(msg)
        else:
            print_warning(msg)
        return

    if show_status:
        print_section("Malware Verification Pipeline")
        for line in pipeline_report():
            if "✓" in line:
                print_success(line)
            elif "✗" in line or "not" in line.lower():
                print_error(line)
            elif "⚠" in line:
                print_warning(line)
            else:
                print_info(line)
        return

    if not target:
        path = Prompt.ask(
            "[cyan bold]File to scan[/cyan bold]",
            default=os.path.expanduser("~/Downloads"),
        )
        if not path:
            return
        target = os.path.expanduser(path)

    if not os.path.exists(target):
        print_error(f"File not found: {target}")
        return

    print_section(f"Deep Scan: {target}")
    console.print("[dim]Stages: ClamAV → YARA → VirusTotal → AI[/dim]\n")

    def _on_stage(name, result):
        icons = {"clamav": "🦠", "yara": "📐", "virustotal": "🌐"}
        console.print(f"  {icons.get(name, '✓')} Stage complete: [cyan]{name}[/cyan]")

    with Progress(SpinnerColumn(style="green"),
                  TextColumn("[green]Pipeline running…[/green]"),
                  console=console) as p:
        p.add_task("", total=None)
        profile = run_pipeline(target, on_stage_complete=_on_stage)

    console.print()

    # Display formatted results
    for line in format_profile_for_display(profile):
        low = line.lower()
        if "🔴" in line or "💀" in line or "infected" in low:
            print_error(line)
        elif "🟡" in line or "⚠" in line or "suspicious" in low:
            print_warning(line)
        elif "🟢" in line or "clean" in low:
            print_success(line)
        else:
            print_info(line)

    # AI interpretation if available
    if not profile.ai_assessment:
        console.print()
        with Progress(SpinnerColumn(style="green"),
                      TextColumn("[green]Fyxa is interpreting…[/green]"),
                      console=console) as p:
            p.add_task("", total=None)
            assessment, confidence = ai_interpret_profile(profile)
        if assessment:
            console.print()
            console.print(Panel(
                assessment,
                title="[green bold]Fyxa AI Assessment[/green bold]",
                border_style="green",
                padding=(1, 2),
            ))
            console.print(f"  [dim]Confidence: {confidence}%[/dim]")
    elif profile.ai_assessment:
        console.print()
        console.print(Panel(
            profile.ai_assessment,
            title="[green bold]Fyxa AI Assessment[/green bold]",
            border_style="green",
            padding=(1, 2),
        ))
        console.print(f"  [dim]Confidence: {profile.ai_confidence}%[/dim]")

    # JSON export hint
    console.print()
    console.print("[dim]Threat Profile JSON: sysfix pipeline <file> | json output[/dim]")


# ═══════════════════════════════════════════════════════════════════════════
# Sentinel Bridge
# ═══════════════════════════════════════════════════════════════════════════

@cli.command("bridge")
@click.option("--processes", "scan_procs", is_flag=True, help="Scan processes for anomalies")
@click.option("--network", "scan_net", is_flag=True, help="Scan network for threats")
@click.option("--status", "show_status", is_flag=True, help="Show Sentinel Bridge status")
def bridge_cmd(scan_procs, scan_net, show_status):
    """Sentinel Bridge — AI-linked security scanner (free tier).

    Runs a read-only security scan using /proc and eBPF (via ebpfcat).
    Always available — no root required for basic scans.
    """
    from sysfixai.sentinel_bridge import (
        read_only_ebpf_scan, scan_process_anomalies,
        check_network_threats, sentinel_bridge_report,
    )

    if show_status:
        print_section("Sentinel Bridge Status")
        for line in sentinel_bridge_report():
            if "✓" in line:
                print_success(line)
            elif "✗" in line or "🔒" in line:
                print_error(line)
            elif "⚠" in line or "●" in line:
                print_warning(line)
            else:
                print_info(line)
        return

    if scan_procs:
        print_section("Process Anomaly Scan")
        with Progress(SpinnerColumn(style="green"),
                      TextColumn("[green]Scanning processes…[/green]"),
                      console=console) as p:
            p.add_task("", total=None)
            result = scan_process_anomalies()
        console.print()
        for line in result.splitlines():
            if "🔴" in line or "⚠" in line:
                print_error(line)
            elif "🟠" in line:
                print_warning(line)
            elif "🟡" in line:
                print_warning(line)
            elif "✓" in line:
                print_success(line)
            else:
                print_info(line)
        return

    if scan_net:
        print_section("Network Threat Scan")
        with Progress(SpinnerColumn(style="green"),
                      TextColumn("[green]Scanning network…[/green]"),
                      console=console) as p:
            p.add_task("", total=None)
            result = check_network_threats()
        console.print()
        for line in result.splitlines():
            if "🔴" in line or "⚠" in line:
                print_error(line)
            elif "🟡" in line:
                print_warning(line)
            elif "✓" in line:
                print_success(line)
            else:
                print_info(line)
        return

    # Default: full security scan
    print_section("Sentinel Security Scan")
    console.print("[dim]Read-only scan: processes + network + files[/dim]\n")

    with Progress(SpinnerColumn(style="green"),
                  TextColumn("[green]Running security scan…[/green]"),
                  console=console) as p:
        p.add_task("", total=None)
        result = read_only_ebpf_scan()

    console.print()
    for line in result.splitlines():
        if "🔴" in line or "CRITICAL" in line:
            print_error(line)
        elif "🟠" in line or "HIGH" in line:
            print_warning(line)
        elif "🟡" in line or "MEDIUM" in line:
            print_warning(line)
        elif "🟢" in line or "✅" in line or "clean" in line.lower():
            print_success(line)
        else:
            print_info(line)


# ═══════════════════════════════════════════════════════════════════════════
# Interactive menu
# ═══════════════════════════════════════════════════════════════════════════

@cli.command()
def interactive():
    """Enter interactive menu mode — full access to every feature."""
    print_banner()

    ollama_running = is_ollama_running()
    ai_tag = "[green bold]✓ Available[/green bold]" if ollama_running else "[yellow bold]⚠ Unavailable[/yellow bold]"
    console.print(Panel(f"[cyan]AI Assistant Status: {ai_tag}[/cyan]",
                        title="[bold cyan]System Ready[/bold cyan]", border_style="cyan"))

    while True:
        menu = Text.assemble(
            "\n",
            (" [1] ", "cyan bold"), ("Run Diagnostics\n", "white"),
            (" [2] ", "cyan bold"), ("Fast Sweep AI Fix", "white"), ("  (Ollama)\n", "dim cyan"),
            (" [3] ", "cyan bold"), ("Deep Dive Troubleshooting", "white"), ("  (Ollama)\n", "dim cyan"),
            (" [4] ", "cyan bold"), ("Security Audit\n", "white"),
            (" [5] ", "cyan bold"), ("Network Diagnostics\n", "white"),
            (" [6] ", "cyan bold"), ("System Health\n", "white"),
            (" [7] ", "cyan bold"), ("Virus / Malware Scan\n", "white"),
            (" [8] ", "cyan bold"), ("Check for Updates\n", "white"),
            (" [9] ", "cyan bold"), ("Fyxa AI Chat", "white"), ("  (Ollama)\n", "dim cyan"),
            (" [a] ", "cyan bold"), ("Advanced Diagnostics\n", "white"),
            (" [p] ", "cyan bold"), ("Prescriptive Analysis\n", "white"),
            (" [g] ", "cyan bold"), ("Golden State (Drift Check)\n", "white"),
            (" [l] ", "cyan bold"), ("Log Search\n", "white"),
            (" [x] ", "cyan bold"), ("Sandbox Dry-Run\n", "white"),
            (" [e] ", "cyan bold"), ("eBPF Sentinel\n", "white"),
            (" [m] ", "cyan bold"), ("Micro-VM Sandbox\n", "white"),
            (" [n] ", "cyan bold"), ("NPU Status\n", "white"),
            (" [t] ", "cyan bold"), ("System Pulse (Telemetry)\n", "white"),
            (" [z] ", "cyan bold"), ("Agentic Engine Status\n", "white"),
            (" [y] ", "cyan bold"), ("Safety Intercept Log\n", "white"),
            (" [v] ", "cyan bold"), ("Sentinel AV (Kernel Antivirus)\n", "white"),
            (" [d] ", "cyan bold"), ("Deep Scan (Malware Pipeline)\n", "white"),
            (" [j] ", "cyan bold"), ("Sentinel Bridge (AI Security Scanner)\n", "white"),
            (" [b] ", "cyan bold"), ("Brain (Memory)\n", "white"),
            (" [s] ", "cyan bold"), ("System Status\n", "white"),
            (" [h] ", "cyan bold"), ("Hardware Tuning", "white"), ("  (DANGEROUS)\n", "dim red"),
            (" [q] ", "cyan bold"), ("Quit\n", "white"),
        )
        console.print(Panel(menu, title="[bold cyan]Main Menu[/bold cyan]",
                            border_style="cyan", padding=(1, 2)))

        choice = Prompt.ask(
            "[cyan bold]Choice[/cyan bold]",
            choices=["1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "p", "g", "l", "x", "e", "m", "n", "t", "z", "y", "v", "d", "j", "b", "s", "h", "q"],
        ).lower()

        if choice == "1":
            print_banner()
            print_section("System Diagnostics")
            issues = scan_with_progress()
            console.print()
            display_issues(issues)
            _pause()

        elif choice == "2":
            if not ollama_running:
                print_error("Ollama is not running"); _pause(); continue
            print_banner()
            print_section("Fast Sweep Mode")
            print_info("Analysing system for quick fixes…")
            issues = diagnose()
            if issues and issues[0] != "No issues detected.":
                ai_auto_fix(issues)
            else:
                print_success("System is healthy!")
            _pause()

        elif choice == "3":
            if not ollama_running:
                print_error("Ollama is not running"); _pause(); continue
            print_banner()
            print_section("Deep Dive Troubleshooting")
            ai_deep_dive()
            _pause()

        elif choice == "4":
            print_banner()
            from sysfixai.diagnostics import security_scan_full
            print_section("Security Audit")
            results = _spinner("Running security checks…", security_scan_full)
            console.print()
            for line in results:
                low = line.lower()
                if any(k in low for k in ("warning", "fail", "suspicious", "concern")):
                    print_error(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "5":
            print_banner()
            from sysfixai.diagnostics import network_diagnostics
            print_section("Network Diagnostics")
            results = _spinner("Testing network…", network_diagnostics)
            console.print()
            for line in results:
                low = line.lower()
                if any(k in low for k in ("ok", "pass", "success", "reachable", "active")):
                    print_success(line)
                elif any(k in low for k in ("fail", "error", "unreachable")):
                    print_error(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "6":
            print_banner()
            from sysfixai.diagnostics import (
                check_boot_time, check_systemd_failed, check_journal_errors,
                check_usb_devices, check_smart_health,
            )
            print_section("System Health")
            for label, fn in [
                ("Boot time", check_boot_time),
                ("Systemd services", check_systemd_failed),
                ("Journal errors", check_journal_errors),
                ("USB devices", check_usb_devices),
                ("SMART health", check_smart_health),
            ]:
                res = _spinner(label, fn)
                for line in res:
                    print_info(line)
                console.print()
            _pause()

        elif choice == "7":
            print_banner()
            print_section("Malware Hash Scan")
            path = Prompt.ask("[cyan bold]Path to scan (file or dir)[/cyan bold]",
                             default=os.path.expanduser("~/Downloads"))
            from sysfixai.diagnostics import scan_file_hash, scan_directory_hashes
            from sysfixai.config import get_setting
            vt_key = get_setting("virustotal_api_key", "")
            path = os.path.expanduser(path)

            if os.path.isfile(path):
                results = _spinner("Scanning…", scan_file_hash, path, vt_key)
            elif os.path.isdir(path):
                results = _spinner("Scanning…", scan_directory_hashes, path, vt_key)
            else:
                print_error(f"Not found: {path}"); _pause(); continue

            console.print()
            for line in results:
                if any(k in line.lower() for k in ("clean", "not found", "no match")):
                    print_success(line)
                elif any(k in line.lower() for k in ("malware", "malicious", "detected", "threat")):
                    print_error(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "8":
            print_banner()
            from sysfixai.diagnostics import check_pending_updates, check_sysfix_update
            print_section("Update Check")
            for label, fn in [
                ("Checking sysfix-ai…", check_sysfix_update),
                ("Checking system packages…", check_pending_updates),
            ]:
                res = _spinner(label, fn)
                for line in res:
                    if "behind" in line.lower() or "available" in line.lower():
                        print_warning(line)
                    else:
                        print_info(line)
                console.print()
            _pause()

        elif choice == "9":
            if not ollama_running:
                print_error("Ollama is not running"); _pause(); continue
            _interactive_chat()

        elif choice == "a":
            print_banner()
            from sysfixai.advanced_diagnostics import advanced_diagnostics_full
            print_section("Advanced Diagnostics")
            results = _spinner("Running advanced diagnostics…", advanced_diagnostics_full)
            console.print()
            for line in results:
                low = line.lower()
                if "danger" in low or "critical" in low:
                    print_error(line)
                elif "warn" in low:
                    print_warning(line)
                elif "ok:" in low:
                    print_success(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "p":
            print_banner()
            from sysfixai.sandbox import prescriptive_analysis
            print_section("Prescriptive Analysis")
            results = _spinner("Analysing trends…", prescriptive_analysis)
            console.print()
            for line in results:
                if "🔴" in line:
                    print_error(line)
                elif "🟡" in line:
                    print_warning(line)
                elif "✓" in line:
                    print_success(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "g":
            print_banner()
            from sysfixai.sandbox import golden_state_drift_check, capture_current_as_golden
            sub = Prompt.ask(
                "[cyan]Golden State: [d]rift check or [c]apture new baseline?[/cyan]",
                choices=["d", "c"], default="d",
            )
            if sub == "c":
                print_section("Capture Golden State")
                results = _spinner("Capturing baseline…", capture_current_as_golden)
            else:
                print_section("Golden State Drift Check")
                results = _spinner("Checking drift…", golden_state_drift_check)
            console.print()
            for line in results:
                if "⚠" in line:
                    print_warning(line)
                elif "✓" in line:
                    print_success(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "l":
            print_banner()
            from sysfixai.sandbox import semantic_log_search
            print_section("Semantic Log Search")
            query = Prompt.ask("[cyan]What do you want to find in the logs?[/cyan]")
            if query:
                results = _spinner("Searching logs…", lambda: semantic_log_search(query))
                console.print()
                for line in results:
                    print_info(line)
            _pause()

        elif choice == "x":
            print_banner()
            from sysfixai.sandbox import sandbox_dry_run
            print_section("Sandbox Dry-Run")
            cmd = Prompt.ask("[cyan]Command to test in sandbox[/cyan]")
            if cmd:
                results = _spinner("Running in sandbox…", lambda: sandbox_dry_run([cmd]))
                console.print()
                for line in results:
                    if "PASS" in line:
                        print_success(line)
                    elif "FAIL" in line:
                        print_error(line)
                    else:
                        print_info(line)
            _pause()

        elif choice == "e":
            print_banner()
            from sysfixai.ebpf_sentinel import sentinel_status, start_sentinel, stop_sentinel, sentinel_report
            print_section("eBPF Sentinel")
            status = sentinel_status()
            if status.get("running"):
                print_info("Sentinel is [green]running[/green].")
                act = Prompt.ask("Action", choices=["stop", "alerts", "back"], default="alerts")
                if act == "stop":
                    msg = stop_sentinel()
                    print_info(msg)
                elif act == "alerts":
                    for line in sentinel_report():
                        if "🔴" in line or "🟠" in line:
                            print_error(line)
                        elif "⚠" in line:
                            print_warning(line)
                        elif "✓" in line:
                            print_success(line)
                        else:
                            print_info(line)
            else:
                print_info("Sentinel is [yellow]stopped[/yellow].")
                act = Prompt.ask("Start sentinel? (requires root + bcc)", choices=["yes", "no"], default="no")
                if act == "yes":
                    msg = start_sentinel()
                    if "✓" in msg:
                        print_success(msg)
                    else:
                        print_warning(msg)
            _pause()

        elif choice == "m":
            print_banner()
            from sysfixai.microvm import microvm_run, microvm_report
            print_section("Micro-VM Sandbox")
            for line in microvm_report():
                if "✓" in line:
                    print_success(line)
                elif "⚠" in line:
                    print_warning(line)
                else:
                    print_info(line)
            console.print()
            cmd = Prompt.ask("[cyan]Command to run in micro-VM (blank to skip)[/cyan]", default="")
            if cmd.strip():
                results = _spinner("Running in micro-VM…", lambda: microvm_run([cmd.strip()]))
                console.print()
                for line in results:
                    if "PASS" in line:
                        print_success(line)
                    elif "FAIL" in line:
                        print_error(line)
                    else:
                        print_info(line)
            _pause()

        elif choice == "n":
            print_banner()
            from sysfixai.npu import npu_report
            print_section("NPU Status")
            report = _spinner("Detecting NPU…", npu_report)
            console.print()
            for line in report:
                if "✓" in line:
                    print_success(line)
                elif "⚠" in line:
                    print_warning(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "t":
            print_banner()
            from sysfixai.system_pulse import (
                start_pulse, stop_pulse, pulse_status, pulse_report as pr
            )
            print_section("System Pulse")
            status = pulse_status()
            if status.get("running"):
                print_info("System Pulse is [green]running[/green].")
                act = Prompt.ask("Action", choices=["stop", "report", "back"], default="report")
                if act == "stop":
                    msg = stop_pulse()
                    print_info(msg)
                elif act == "report":
                    for line in pr():
                        if "↑" in line or "⚠" in line:
                            print_warning(line)
                        elif "✓" in line:
                            print_success(line)
                        else:
                            print_info(line)
            else:
                print_info("System Pulse is [yellow]stopped[/yellow].")
                act = Prompt.ask("Start pulse?", choices=["yes", "no"], default="yes")
                if act == "yes":
                    msg = start_pulse(interval=5.0)
                    if "✓" in msg:
                        print_success(msg)
                    else:
                        print_warning(msg)
            _pause()

        elif choice == "z":
            print_banner()
            from sysfixai.reasoning_loop import agent_report as ar
            print_section("Agentic Engine (1.1.0)")
            report = _spinner("Checking engine…", ar)
            console.print()
            for line in report:
                if "✓" in line:
                    print_success(line)
                elif "⚠" in line:
                    print_warning(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "y":
            print_banner()
            from sysfixai.safety_intercept import intercept_report as ir
            print_section("Safety Intercept Log")
            report = _spinner("Loading audit log…", ir)
            console.print()
            for line in report:
                if "BLOCKED" in line or "DENIED" in line:
                    print_error(line)
                elif "APPROVED" in line or "SAFE" in line:
                    print_success(line)
                elif "PENDING" in line or "⚠" in line:
                    print_warning(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "v":
            print_banner()
            from sysfixai.sentinel_av import (
                start_av, stop_av, av_status, av_report as avr,
                av_threats, format_threat_for_display,
            )
            print_section("Sentinel AV (Kernel Antivirus)")
            status = av_status()
            if status.get("running"):
                print_info("Sentinel AV is [green]running[/green].")
                act = Prompt.ask("Action", choices=["stop", "report", "threats", "back"], default="report")
                if act == "stop":
                    msg = stop_av()
                    print_info(msg)
                elif act == "report":
                    for line in avr():
                        if "🔴" in line or "CRITICAL" in line or "🦠" in line:
                            print_error(line)
                        elif "⚠" in line:
                            print_warning(line)
                        elif "✓" in line:
                            print_success(line)
                        else:
                            print_info(line)
                elif act == "threats":
                    threats = av_threats()
                    if not threats:
                        print_success("No threats. System is clean.")
                    else:
                        for t in threats:
                            lines = format_threat_for_display(t)
                            sev = t.severity.upper()
                            if sev in ("CRITICAL", "HIGH"):
                                print_error(lines)
                            elif sev == "MEDIUM":
                                print_warning(lines)
                            else:
                                print_info(lines)
                            console.print()
            else:
                print_info("Sentinel AV is [yellow]stopped[/yellow].")
                act = Prompt.ask("Start Sentinel AV? (requires root + bcc)", choices=["yes", "no"], default="no")
                if act == "yes":
                    msg = start_av()
                    if "✓" in msg or "started" in msg.lower():
                        print_success(msg)
                    else:
                        print_warning(msg)
            _pause()

        elif choice == "d":
            print_banner()
            from sysfixai.malware_pipeline import (
                run_pipeline, pipeline_report as pr_report,
                format_profile_for_display, ai_interpret_profile,
            )
            print_section("Deep Scan (Malware Pipeline)")
            sub = Prompt.ask(
                "[cyan]Deep Scan: [s]can file or [r]eport pipeline status?[/cyan]",
                choices=["s", "r"], default="s",
            )
            if sub == "r":
                for line in pr_report():
                    if "✓" in line:
                        print_success(line)
                    elif "✗" in line:
                        print_error(line)
                    elif "⚠" in line:
                        print_warning(line)
                    else:
                        print_info(line)
            else:
                path = Prompt.ask("[cyan]File to scan[/cyan]",
                                  default=os.path.expanduser("~/Downloads"))
                path = os.path.expanduser(path)
                if not os.path.exists(path):
                    print_error(f"Not found: {path}")
                else:
                    def _on_stage_d(name, result):
                        icons = {"clamav": "🦠", "yara": "📐", "virustotal": "🌐"}
                        console.print(f"  {icons.get(name, '✓')} {name} complete")
                    profile = _spinner(
                        "Running pipeline…",
                        lambda: run_pipeline(path, on_stage_complete=_on_stage_d),
                    )
                    console.print()
                    for line in format_profile_for_display(profile):
                        low = line.lower()
                        if "🔴" in line or "💀" in line or "infected" in low:
                            print_error(line)
                        elif "🟡" in line or "⚠" in line:
                            print_warning(line)
                        elif "🟢" in line or "clean" in low:
                            print_success(line)
                        else:
                            print_info(line)
            _pause()

        elif choice == "j":
            print_banner()
            from sysfixai.sentinel_bridge import (
                read_only_ebpf_scan, scan_process_anomalies,
                check_network_threats, sentinel_bridge_report,
            )
            print_section("Sentinel Bridge (AI Security Scanner)")
            sub = Prompt.ask(
                "[cyan]Bridge: [s]ecurity scan, [p]rocess scan, [n]etwork scan, or s[t]atus?[/cyan]",
                choices=["s", "p", "n", "t"], default="s",
            )
            if sub == "t":
                for line in sentinel_bridge_report():
                    if "✓" in line:
                        print_success(line)
                    elif "✗" in line or "🔒" in line:
                        print_error(line)
                    elif "⚠" in line:
                        print_warning(line)
                    else:
                        print_info(line)
            elif sub == "p":
                result = _spinner("Scanning processes…", scan_process_anomalies)
                console.print()
                for line in result.splitlines():
                    if "🔴" in line or "⚠" in line:
                        print_error(line)
                    elif "🟠" in line or "🟡" in line:
                        print_warning(line)
                    elif "✓" in line:
                        print_success(line)
                    else:
                        print_info(line)
            elif sub == "n":
                result = _spinner("Scanning network…", check_network_threats)
                console.print()
                for line in result.splitlines():
                    if "🔴" in line or "⚠" in line:
                        print_error(line)
                    elif "🟡" in line:
                        print_warning(line)
                    elif "✓" in line:
                        print_success(line)
                    else:
                        print_info(line)
            else:
                result = _spinner("Running security scan…", read_only_ebpf_scan)
                console.print()
                for line in result.splitlines():
                    if "🔴" in line or "CRITICAL" in line:
                        print_error(line)
                    elif "🟠" in line or "HIGH" in line:
                        print_warning(line)
                    elif "🟡" in line or "MEDIUM" in line:
                        print_warning(line)
                    elif "🟢" in line or "✅" in line:
                        print_success(line)
                    else:
                        print_info(line)
            _pause()

        elif choice == "b":
            _interactive_brain()

        elif choice == "s":
            print_banner()
            print_section("Quick Status")
            issues = _spinner("Analysing…", diagnose)
            console.print()
            categorized = categorize_issues(issues)
            if categorized["problems"]:
                print_error(f"Problems: {len(categorized['problems'])}")
            if categorized["warnings"]:
                print_warning(f"Warnings: {len(categorized['warnings'])}")
            if categorized["info"]:
                print_info(f"Info items: {len(categorized['info'])}")
            if not categorized["problems"] and not categorized["warnings"]:
                print_success("System is healthy!")
            _pause()

        elif choice == "h":
            print_banner()
            sudo_mode()
            _pause()

        elif choice == "q":
            console.print(Panel(
                "[green bold]Thank you for using Sysfix-AI![/green bold]\n"
                "[cyan]Stay secure! 🔒[/cyan]",
                border_style="green", padding=(1, 2),
            ))
            break

        console.print()


# ── Interactive sub-menus ───────────────────────────────────────────────


def _interactive_chat():
    """Chat loop for use inside the interactive menu."""
    from sysfixai.ai import get_deep_dive, get_system_snapshot, get_active_model

    print_banner()
    print_section("Fyxa AI Chat")
    model = get_active_model()
    print_success(f"Model: {model}")
    console.print("[dim]Type 'exit' to return to the menu.[/dim]\n")

    system_context = get_system_snapshot()
    history: List[Dict[str, str]] = []

    while True:
        try:
            user_input = console.input("[cyan bold]You ❯ [/cyan bold]").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not user_input or user_input.lower() in ("exit", "quit", "q", "back"):
            break

        history.append({"role": "user", "content": user_input})

        with Progress(SpinnerColumn(style="green"),
                      TextColumn("[green]Fyxa is thinking…[/green]"),
                      console=console) as p:
            p.add_task("", total=None)
            response = get_deep_dive(user_input, gui_mode=True,
                                     chat_history=history, system_context=system_context)

        history.append({"role": "assistant", "content": response})
        console.print()
        console.print(Panel(response, title="[green bold]Fyxa[/green bold]",
                            border_style="green", padding=(1, 2)))
        console.print()


def _interactive_brain():
    """Brain submenu for use inside the interactive menu."""
    while True:
        menu = Text.assemble(
            "\n",
            (" [1] ", "cyan bold"), ("View Brain\n", "white"),
            (" [2] ", "cyan bold"), ("Brain Stats\n", "white"),
            (" [3] ", "cyan bold"), ("Learn System (quick)\n", "white"),
            (" [4] ", "cyan bold"), ("Deep Learn (dotfiles, projects, tools)\n", "white"),
            (" [5] ", "cyan bold"), ("Export Brain\n", "white"),
            (" [6] ", "cyan bold"), ("Import Brain\n", "white"),
            (" [7] ", "cyan bold"), ("Clear Brain\n", "white"),
            (" [b] ", "cyan bold"), ("Back\n", "white"),
        )
        console.print(Panel(menu, title="[cyan bold]Brain Menu[/cyan bold]",
                            border_style="cyan", padding=(1, 2)))
        choice = Prompt.ask("[cyan bold]Choice[/cyan bold]",
                           choices=["1", "2", "3", "4", "5", "6", "7", "b"]).lower()

        if choice == "1":
            from sysfixai.memory import get_brain_dump
            print_section("Brain Dump")
            for line in get_brain_dump():
                if line.startswith("═══"):
                    console.print(f"\n[cyan bold]{line}[/cyan bold]")
                elif line.startswith("  ✓"):
                    console.print(f"[green]{line}[/green]")
                elif line.startswith("  ✗"):
                    console.print(f"[red]{line}[/red]")
                elif line.startswith("  "):
                    console.print(f"[white]{line}[/white]")
                else:
                    console.print(f"[dim]{line}[/dim]")
            _pause()

        elif choice == "2":
            from sysfixai.memory import get_brain_stats, get_brain_size_kb
            stats = get_brain_stats()
            size = get_brain_size_kb()
            print_section("Brain Stats")
            console.print(f"  [cyan]System facts:[/cyan]      {stats.get('system_facts', 0)}")
            console.print(f"  [cyan]Observations:[/cyan]      {stats.get('observations', 0)}")
            console.print(f"  [cyan]Insights:[/cyan]          {stats.get('insights', 0)}")
            console.print(f"  [cyan]Solutions:[/cyan]         {stats.get('solutions', 0)}")
            console.print(f"  [cyan]Scans:[/cyan]             {stats.get('system_scans', 0)}")
            console.print(f"  [cyan]File size:[/cyan]         {size:.1f} KB")
            _pause()

        elif choice == "3":
            from sysfixai.memory import observe_system
            res = _spinner("Learning system…", observe_system, deep=False)
            console.print()
            for line in res:
                print_info(line)
            print_success(f"Learned {len(res)} facts.")
            _pause()

        elif choice == "4":
            from sysfixai.memory import observe_system
            res = _spinner("Deep learning…", observe_system, deep=True)
            console.print()
            for line in res:
                print_info(line)
            print_success(f"Learned {len(res)} facts.")
            _pause()

        elif choice == "5":
            from sysfixai.advanced_diagnostics import export_brain
            path = Prompt.ask("[cyan]Export path[/cyan]", default="")
            results = export_brain(path)
            for line in results:
                if "OK" in line:
                    print_success(line)
                else:
                    print_info(line)
            _pause()

        elif choice == "6":
            from sysfixai.advanced_diagnostics import import_brain
            path = Prompt.ask("[cyan]Import file path[/cyan]")
            if path and os.path.exists(path):
                merge = Confirm.ask("Merge with existing brain?", default=True)
                results = import_brain(path, merge=merge)
                for line in results:
                    if "OK" in line:
                        print_success(line)
                    else:
                        print_info(line)
            else:
                print_error(f"File not found: {path}")
            _pause()

        elif choice == "7":
            if Confirm.ask("[red bold]Erase ALL brain memory?[/red bold]", default=False):
                from sysfixai.memory import clear_brain
                clear_brain()
                print_success("Brain cleared.")
            else:
                print_info("Cancelled.")
            _pause()

        elif choice == "b":
            break


if __name__ == "__main__":
    cli()
