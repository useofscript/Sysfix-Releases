"""
Agent Mode: opt-in automated execution with allowlist, dry-run, and logging.
"""
import json
import time
from pathlib import Path
from typing import List, Dict, Any
from sysfixai.config import CONFIG_DIR, load_config, save_config, set_setting
from sysfixai.executor import run_commands

AGENT_LOG = CONFIG_DIR / "agent_runs.log"


def _now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def is_enabled() -> bool:
    cfg = load_config()
    return bool(cfg.get("agent_mode_enabled", False))


def enable(phrase: str) -> bool:
    cfg = load_config()
    required = cfg.get("agent_mode_require_phrase", "ENABLE_AGENT")
    if phrase != required:
        return False
    # Agent Mode no longer requires a pre-populated allowlist to enable.
    cfg["agent_mode_enabled"] = True
    save_config(cfg)
    return True


def disable():
    cfg = load_config()
    cfg["agent_mode_enabled"] = False
    save_config(cfg)
    return True


def set_allowlist(items: List[str]):
    cfg = load_config()
    cfg["agent_mode_allowlist"] = list(items)
    save_config(cfg)


def get_allowlist() -> List[str]:
    cfg = load_config()
    return cfg.get("agent_mode_allowlist", []) or []


def _log(entry: Dict[str, Any]):
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(AGENT_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


def can_run_commands(commands: List[str]) -> bool:
    """Previously enforced an allowlist. That check is deprecated —
    Agent Mode will instead require explicit user approval for each run.
    Returning True here for backward compatibility."""
    return True


def run_agent_commands(description: str, commands: List[str], cwd: str = None) -> Dict[str, Any]:
    """Run commands in agent mode: respects dry-run, logs actions, and requires
    explicit interactive approval before executing real commands.

    Note: allowlist enforcement has been removed; the user will be prompted
    to approve each set of commands when dry-run is disabled.
    """
    cfg = load_config()
    dry = cfg.get("agent_mode_dry_run", True)
    out: Dict[str, Any] = {"timestamp": _now_iso(), "description": description, "commands": commands, "dry_run": dry}

    # agent-mode no longer enforces an allowlist; mark allowed for compatibility
    out["allowed"] = True

    if dry:
        out["results"] = [{"cmd": c, "returncode": 0, "stdout": "(dry-run)"} for c in commands]
        _log(out)
        return out

    # require interactive confirmation for safety (will prompt on CLI)
    try:
        results = run_commands(commands, cwd=cwd, use_sudo=False, require_confirmation=True)
        out["results"] = results
        _log(out)
        return out
    except Exception as e:
        out["error"] = str(e)
        _log(out)
        return out