"""
System Pulse — continuous real-time system telemetry stream.

Provides a persistent, auto-refreshing snapshot of system state that gets
injected into every AI prompt context. Unlike the one-shot get_system_snapshot()
in ai.py, System Pulse runs as a background daemon thread and maintains a
rolling window of metrics so the AI can detect *trends* (rising temps, memory
pressure climbing, disk I/O spikes) rather than just point-in-time values.

Features:
- Background daemon thread polls every N seconds (default 5)
- Rolling window of last 60 snapshots (~5 minutes at default interval)
- Trend detection: rising/stable/falling for CPU, RAM, temps, disk I/O
- dmesg tail: last 20 kernel messages, filtered for actionable content
- Active window detection (X11/Wayland) for situational awareness
- Disk I/O counters (read/write bytes per interval)
- Thread-safe access to latest pulse and formatted prompt header

Public API:
- start_pulse(interval=5)       → start the background poller
- stop_pulse()                  → stop the background poller
- get_pulse()                   → latest PulseSnapshot dataclass
- get_pulse_prompt_header()     → formatted string for system prompt injection
- pulse_status()                → dict with running state, snapshot count, etc.
"""

from __future__ import annotations

import os
import re
import subprocess
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class PulseSnapshot:
    """Single point-in-time system telemetry reading."""
    timestamp: float = 0.0

    # CPU
    cpu_percent: float = 0.0
    cpu_freq_mhz: float = 0.0
    cpu_count: int = 0
    load_avg_1: float = 0.0
    load_avg_5: float = 0.0
    load_avg_15: float = 0.0

    # Memory
    ram_total_gb: float = 0.0
    ram_used_gb: float = 0.0
    ram_percent: float = 0.0
    swap_used_gb: float = 0.0
    swap_percent: float = 0.0

    # Disk
    disk_read_bytes: int = 0
    disk_write_bytes: int = 0
    disk_free_gb: float = 0.0
    disk_percent: float = 0.0

    # Thermals
    cpu_temp_c: float = 0.0
    gpu_temp_c: float = 0.0
    max_temp_c: float = 0.0
    temps: Dict[str, float] = field(default_factory=dict)

    # GPU (nvidia-smi)
    gpu_util_percent: float = 0.0
    gpu_vram_used_mb: float = 0.0
    gpu_vram_total_mb: float = 0.0
    gpu_power_w: float = 0.0

    # Process
    top_cpu_processes: List[str] = field(default_factory=list)
    top_ram_processes: List[str] = field(default_factory=list)
    process_count: int = 0
    zombie_count: int = 0

    # Kernel / logs
    dmesg_tail: List[str] = field(default_factory=list)
    uptime_hours: float = 0.0

    # Active window (situational awareness)
    active_window: str = ""
    active_pid: int = 0

    # Network
    net_bytes_sent: int = 0
    net_bytes_recv: int = 0


@dataclass
class PulseTrend:
    """Trend analysis across the rolling window."""
    cpu_trend: str = "stable"       # rising / stable / falling
    ram_trend: str = "stable"
    temp_trend: str = "stable"
    disk_io_trend: str = "stable"
    swap_trend: str = "stable"

    # Alerts generated from trend analysis
    alerts: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Telemetry collection
# ---------------------------------------------------------------------------

def _collect_snapshot() -> PulseSnapshot:
    """Gather a single telemetry snapshot. Never raises."""
    snap = PulseSnapshot(timestamp=time.time())

    if not _HAS_PSUTIL:
        return snap

    try:
        snap.cpu_percent = psutil.cpu_percent(interval=0.2)
        snap.cpu_count = psutil.cpu_count() or 0
        freq = psutil.cpu_freq()
        if freq:
            snap.cpu_freq_mhz = round(freq.current, 0)
    except Exception:
        pass

    try:
        load = os.getloadavg()
        snap.load_avg_1, snap.load_avg_5, snap.load_avg_15 = (
            round(load[0], 2), round(load[1], 2), round(load[2], 2)
        )
    except Exception:
        pass

    try:
        mem = psutil.virtual_memory()
        snap.ram_total_gb = round(mem.total / (1024**3), 1)
        snap.ram_used_gb = round(mem.used / (1024**3), 1)
        snap.ram_percent = mem.percent
    except Exception:
        pass

    try:
        swap = psutil.swap_memory()
        snap.swap_used_gb = round(swap.used / (1024**3), 2)
        snap.swap_percent = swap.percent
    except Exception:
        pass

    try:
        import shutil as _shutil
        disk = _shutil.disk_usage("/")
        snap.disk_free_gb = round(disk.free / (1024**3), 1)
        snap.disk_percent = round(100 * disk.used / disk.total, 1)
    except Exception:
        pass

    try:
        dio = psutil.disk_io_counters()
        if dio:
            snap.disk_read_bytes = dio.read_bytes
            snap.disk_write_bytes = dio.write_bytes
    except Exception:
        pass

    # Thermals
    try:
        sensors = psutil.sensors_temperatures()
        all_temps: Dict[str, float] = {}
        for name, entries in sensors.items():
            for e in entries:
                label = e.label or name
                all_temps[label] = e.current
        snap.temps = all_temps
        if all_temps:
            snap.max_temp_c = max(all_temps.values())
            # Try to find a CPU-specific temp
            for key in ("Tctl", "Package id 0", "Core 0", "cpu_thermal"):
                if key in all_temps:
                    snap.cpu_temp_c = all_temps[key]
                    break
            else:
                snap.cpu_temp_c = snap.max_temp_c
    except Exception:
        pass

    # GPU via nvidia-smi
    try:
        nv = subprocess.run(
            ["nvidia-smi", "--query-gpu=temperature.gpu,utilization.gpu,"
             "memory.used,memory.total,power.draw",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3, stdin=subprocess.DEVNULL,
        )
        if nv.returncode == 0 and nv.stdout.strip():
            parts = [p.strip() for p in nv.stdout.strip().split(",")]
            if len(parts) >= 5:
                snap.gpu_temp_c = float(parts[0])
                snap.gpu_util_percent = float(parts[1])
                snap.gpu_vram_used_mb = float(parts[2])
                snap.gpu_vram_total_mb = float(parts[3])
                snap.gpu_power_w = float(parts[4])
    except (FileNotFoundError, Exception):
        pass

    # Top processes
    try:
        procs = list(psutil.process_iter(["name", "cpu_percent", "memory_percent", "status"]))
        snap.process_count = len(procs)
        snap.zombie_count = sum(1 for p in procs if p.info.get("status") == "zombie")

        by_cpu = sorted(procs, key=lambda p: p.info.get("cpu_percent", 0) or 0, reverse=True)[:5]
        snap.top_cpu_processes = [
            f"{p.info['name']} ({p.info.get('cpu_percent', 0):.0f}%)"
            for p in by_cpu if p.info.get("name")
        ]

        by_ram = sorted(procs, key=lambda p: p.info.get("memory_percent", 0) or 0, reverse=True)[:5]
        snap.top_ram_processes = [
            f"{p.info['name']} ({p.info.get('memory_percent', 0):.1f}%)"
            for p in by_ram if p.info.get("name")
        ]
    except Exception:
        pass

    # Uptime
    try:
        snap.uptime_hours = round((time.time() - psutil.boot_time()) / 3600, 1)
    except Exception:
        pass

    # Network I/O
    try:
        net = psutil.net_io_counters()
        if net:
            snap.net_bytes_sent = net.bytes_sent
            snap.net_bytes_recv = net.bytes_recv
    except Exception:
        pass

    # dmesg tail (last 20 actionable lines)
    snap.dmesg_tail = _get_dmesg_tail()

    # Active window
    snap.active_window, snap.active_pid = _get_active_window()

    return snap


def _get_dmesg_tail(max_lines: int = 20) -> List[str]:
    """Read recent dmesg entries, filtered for actionable content."""
    try:
        result = subprocess.run(
            ["dmesg", "--time-format=reltime", "-l", "err,warn,crit,alert,emerg"],
            capture_output=True, text=True, timeout=3,
            stdin=subprocess.DEVNULL,
        )
        if result.returncode != 0:
            # Try without --time-format (older kernels)
            result = subprocess.run(
                ["dmesg", "-l", "err,warn,crit,alert,emerg"],
                capture_output=True, text=True, timeout=3,
                stdin=subprocess.DEVNULL,
            )
        if result.returncode == 0 and result.stdout.strip():
            lines = result.stdout.strip().splitlines()
            # Take last N lines
            return [l.strip() for l in lines[-max_lines:] if l.strip()]
    except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
        pass

    # Fallback: try reading /dev/kmsg or journalctl
    try:
        result = subprocess.run(
            ["journalctl", "-k", "-p", "warning", "-n", str(max_lines),
             "--no-pager", "-q"],
            capture_output=True, text=True, timeout=3,
            stdin=subprocess.DEVNULL,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().splitlines()[-max_lines:]
    except Exception:
        pass

    return []


def _get_active_window() -> Tuple[str, int]:
    """Detect the currently focused window title and PID.

    Tries X11 (xdotool) first, then Wayland (swaymsg/hyprctl), then
    falls back to reading /proc for the terminal foreground process.
    """
    # X11 via xdotool
    try:
        wid = subprocess.run(
            ["xdotool", "getactivewindow"],
            capture_output=True, text=True, timeout=2,
            stdin=subprocess.DEVNULL,
        )
        if wid.returncode == 0 and wid.stdout.strip():
            win_id = wid.stdout.strip()
            name = subprocess.run(
                ["xdotool", "getactivewindow", "getwindowname"],
                capture_output=True, text=True, timeout=2,
                stdin=subprocess.DEVNULL,
            )
            pid = subprocess.run(
                ["xdotool", "getactivewindow", "getwindowpid"],
                capture_output=True, text=True, timeout=2,
                stdin=subprocess.DEVNULL,
            )
            title = name.stdout.strip() if name.returncode == 0 else ""
            p = int(pid.stdout.strip()) if pid.returncode == 0 and pid.stdout.strip().isdigit() else 0
            return title, p
    except (FileNotFoundError, Exception):
        pass

    # Wayland: swaymsg
    try:
        result = subprocess.run(
            ["swaymsg", "-t", "get_tree"],
            capture_output=True, text=True, timeout=2,
            stdin=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            import json
            tree = json.loads(result.stdout)
            focused = _find_focused_sway(tree)
            if focused:
                return focused.get("name", ""), focused.get("pid", 0)
    except (FileNotFoundError, Exception):
        pass

    # Wayland: hyprctl
    try:
        result = subprocess.run(
            ["hyprctl", "activewindow", "-j"],
            capture_output=True, text=True, timeout=2,
            stdin=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            import json
            win = json.loads(result.stdout)
            return win.get("title", ""), win.get("pid", 0)
    except (FileNotFoundError, Exception):
        pass

    return "", 0


def _find_focused_sway(node: dict) -> Optional[dict]:
    """Recursively find the focused node in a sway tree."""
    if node.get("focused"):
        return node
    for child in node.get("nodes", []) + node.get("floating_nodes", []):
        found = _find_focused_sway(child)
        if found:
            return found
    return None


# ---------------------------------------------------------------------------
# Trend analysis
# ---------------------------------------------------------------------------

def _analyze_trends(window: Deque[PulseSnapshot]) -> PulseTrend:
    """Analyze the rolling window for trends and generate proactive alerts."""
    trend = PulseTrend()
    if len(window) < 6:
        return trend  # Not enough data yet

    recent = list(window)
    first_half = recent[:len(recent) // 2]
    second_half = recent[len(recent) // 2:]

    def avg(snaps: List[PulseSnapshot], attr: str) -> float:
        vals = [getattr(s, attr, 0) for s in snaps]
        return sum(vals) / len(vals) if vals else 0

    # CPU trend
    cpu_early = avg(first_half, "cpu_percent")
    cpu_late = avg(second_half, "cpu_percent")
    if cpu_late > cpu_early + 15:
        trend.cpu_trend = "rising"
    elif cpu_late < cpu_early - 15:
        trend.cpu_trend = "falling"

    # RAM trend
    ram_early = avg(first_half, "ram_percent")
    ram_late = avg(second_half, "ram_percent")
    if ram_late > ram_early + 10:
        trend.ram_trend = "rising"
    elif ram_late < ram_early - 10:
        trend.ram_trend = "falling"

    # Temperature trend
    temp_early = avg(first_half, "max_temp_c")
    temp_late = avg(second_half, "max_temp_c")
    if temp_late > temp_early + 5:
        trend.temp_trend = "rising"
    elif temp_late < temp_early - 5:
        trend.temp_trend = "falling"

    # Disk I/O trend (bytes delta per interval)
    if len(recent) >= 4:
        early_io = (recent[len(recent)//2].disk_write_bytes - recent[0].disk_write_bytes)
        late_io = (recent[-1].disk_write_bytes - recent[len(recent)//2].disk_write_bytes)
        if late_io > early_io * 2 and late_io > 50 * 1024 * 1024:  # >50MB more
            trend.disk_io_trend = "rising"
        elif early_io > late_io * 2:
            trend.disk_io_trend = "falling"

    # Swap trend
    swap_early = avg(first_half, "swap_percent")
    swap_late = avg(second_half, "swap_percent")
    if swap_late > swap_early + 10:
        trend.swap_trend = "rising"

    # --- Proactive alerts ---
    latest = recent[-1]

    if latest.cpu_percent > 90 and trend.cpu_trend == "rising":
        trend.alerts.append("⚠ CPU load is high and rising — possible runaway process")
    if latest.ram_percent > 85 and trend.ram_trend == "rising":
        trend.alerts.append("⚠ RAM pressure is high and climbing — OOM risk")
    if latest.max_temp_c > 85:
        trend.alerts.append(f"⚠ Temperature critical: {latest.max_temp_c}°C — thermal throttling likely")
    elif latest.max_temp_c > 75 and trend.temp_trend == "rising":
        trend.alerts.append(f"⚠ Temperature rising: {latest.max_temp_c}°C — check cooling")
    if latest.swap_percent > 50 and trend.swap_trend == "rising":
        trend.alerts.append("⚠ Swap usage climbing — system may lag")
    if latest.disk_percent > 90:
        trend.alerts.append(f"⚠ Disk {latest.disk_percent}% full — running low on space")
    if latest.zombie_count > 5:
        trend.alerts.append(f"⚠ {latest.zombie_count} zombie processes detected")
    if latest.load_avg_1 > latest.cpu_count * 2:
        trend.alerts.append(f"⚠ Load average ({latest.load_avg_1}) well above core count ({latest.cpu_count})")

    # dmesg alerts
    for line in latest.dmesg_tail[-5:]:
        lower = line.lower()
        if any(kw in lower for kw in ("oom", "out of memory", "killed process")):
            trend.alerts.append(f"🔴 Kernel OOM detected: {line[:120]}")
        elif any(kw in lower for kw in ("hardware error", "mce:", "machine check")):
            trend.alerts.append(f"🔴 Hardware error in dmesg: {line[:120]}")
        elif "i/o error" in lower:
            trend.alerts.append(f"🟠 Disk I/O error: {line[:120]}")

    return trend


# ---------------------------------------------------------------------------
# Background poller (daemon thread)
# ---------------------------------------------------------------------------

_lock = threading.Lock()
_running = False
_thread: Optional[threading.Thread] = None
_window: Deque[PulseSnapshot] = deque(maxlen=60)
_latest: Optional[PulseSnapshot] = None
_trend: PulseTrend = PulseTrend()
_interval: float = 5.0
_callbacks: List = []  # List of callables(PulseSnapshot, PulseTrend)


def _poller_loop():
    global _latest, _trend, _running
    while _running:
        try:
            snap = _collect_snapshot()
            with _lock:
                _window.append(snap)
                _latest = snap
                if len(_window) >= 6:
                    _trend = _analyze_trends(_window)

            # Notify callbacks
            for cb in _callbacks:
                try:
                    cb(snap, _trend)
                except Exception:
                    pass

        except Exception:
            pass

        # Sleep in small increments so stop_pulse() is responsive
        deadline = time.time() + _interval
        while _running and time.time() < deadline:
            time.sleep(0.5)


def start_pulse(interval: float = 5.0) -> str:
    """Start the System Pulse background poller."""
    global _running, _thread, _interval
    with _lock:
        if _running and _thread and _thread.is_alive():
            return "✓ System Pulse already running"
        _interval = max(interval, 1.0)
        _running = True
        _thread = threading.Thread(target=_poller_loop, daemon=True, name="SystemPulse")
        _thread.start()
    return f"✓ System Pulse started (interval: {_interval}s)"


def stop_pulse() -> str:
    """Stop the System Pulse background poller."""
    global _running
    with _lock:
        if not _running:
            return "System Pulse was not running"
        _running = False
    if _thread:
        _thread.join(timeout=_interval + 2)
    return "✓ System Pulse stopped"


def register_callback(cb) -> None:
    """Register a callback(snapshot, trend) called on each pulse tick."""
    _callbacks.append(cb)


def unregister_callback(cb) -> None:
    """Remove a previously registered callback."""
    try:
        _callbacks.remove(cb)
    except ValueError:
        pass


# ---------------------------------------------------------------------------
# Public accessors
# ---------------------------------------------------------------------------

def get_pulse() -> Optional[PulseSnapshot]:
    """Return the latest pulse snapshot, or None if pulse hasn't started."""
    return _latest


def get_trend() -> PulseTrend:
    """Return the current trend analysis."""
    return _trend


def get_pulse_history(n: int = 60) -> List[PulseSnapshot]:
    """Return the last N snapshots from the rolling window."""
    with _lock:
        return list(_window)[-n:]


def pulse_status() -> Dict[str, Any]:
    """Return pulse state as a dict."""
    return {
        "running": _running,
        "interval": _interval,
        "snapshots": len(_window),
        "latest_timestamp": _latest.timestamp if _latest else None,
        "has_psutil": _HAS_PSUTIL,
    }


# ---------------------------------------------------------------------------
# Prompt header formatter — the core of situational awareness
# ---------------------------------------------------------------------------

def get_pulse_prompt_header() -> str:
    """Format the System Pulse data as a compact prompt header for AI injection.

    This is the 'System Status' header that gets prepended to the hidden
    system prompt so the AI is always aware of the machine's current state
    and can proactively suggest fixes.
    """
    snap = _latest
    if not snap:
        return ""

    trend = _trend
    lines: List[str] = ["--- SYSTEM PULSE (live) ---"]

    # Timestamp & uptime
    lines.append(f"Sampled: {time.strftime('%H:%M:%S', time.localtime(snap.timestamp))} | "
                 f"Uptime: {snap.uptime_hours}h")

    # CPU
    cpu_arrow = {"rising": "↑", "falling": "↓", "stable": "→"}.get(trend.cpu_trend, "→")
    lines.append(
        f"CPU: {snap.cpu_percent}% {cpu_arrow} | "
        f"Load: {snap.load_avg_1}/{snap.load_avg_5}/{snap.load_avg_15} | "
        f"{snap.cpu_count} cores @ {snap.cpu_freq_mhz:.0f} MHz"
    )

    # RAM
    ram_arrow = {"rising": "↑", "falling": "↓", "stable": "→"}.get(trend.ram_trend, "→")
    lines.append(
        f"RAM: {snap.ram_used_gb}/{snap.ram_total_gb} GB ({snap.ram_percent}%) {ram_arrow}"
    )
    if snap.swap_percent > 1:
        swap_arrow = {"rising": "↑", "stable": "→"}.get(trend.swap_trend, "→")
        lines.append(f"Swap: {snap.swap_used_gb} GB ({snap.swap_percent}%) {swap_arrow}")

    # Disk
    lines.append(f"Disk: {snap.disk_free_gb} GB free ({snap.disk_percent}% used)")

    # Thermals
    if snap.max_temp_c > 0:
        temp_arrow = {"rising": "↑", "falling": "↓", "stable": "→"}.get(trend.temp_trend, "→")
        lines.append(f"Temp: {snap.cpu_temp_c}°C (CPU) / {snap.max_temp_c}°C (max) {temp_arrow}")
        if snap.gpu_temp_c > 0:
            lines.append(f"GPU Temp: {snap.gpu_temp_c}°C")

    # GPU
    if snap.gpu_util_percent > 0 or snap.gpu_vram_total_mb > 0:
        lines.append(
            f"GPU: {snap.gpu_util_percent}% util | "
            f"VRAM: {snap.gpu_vram_used_mb:.0f}/{snap.gpu_vram_total_mb:.0f} MB | "
            f"Power: {snap.gpu_power_w:.0f}W"
        )

    # Top processes
    if snap.top_cpu_processes:
        lines.append(f"Top CPU: {', '.join(snap.top_cpu_processes[:3])}")
    if snap.top_ram_processes:
        lines.append(f"Top RAM: {', '.join(snap.top_ram_processes[:3])}")
    if snap.zombie_count > 0:
        lines.append(f"Zombies: {snap.zombie_count}")

    # Active window
    if snap.active_window:
        lines.append(f"Active window: {snap.active_window[:80]}")

    # dmesg (last 3 actionable entries only for prompt brevity)
    if snap.dmesg_tail:
        lines.append("Recent kernel warnings:")
        for entry in snap.dmesg_tail[-3:]:
            lines.append(f"  {entry[:120]}")

    # Proactive alerts
    if trend.alerts:
        lines.append("PROACTIVE ALERTS:")
        for alert in trend.alerts[:5]:
            lines.append(f"  {alert}")

    lines.append("---")
    return "\n".join(lines)


def pulse_report() -> List[str]:
    """Human-readable report for CLI/GUI display."""
    report: List[str] = []
    status = pulse_status()

    if status["running"]:
        report.append(f"✓ System Pulse is running (interval: {status['interval']}s)")
        report.append(f"  Snapshots collected: {status['snapshots']}")
    else:
        report.append("⚠ System Pulse is not running")
        report.append("  Start it with: sysfix pulse --start")
        return report

    snap = _latest
    if not snap:
        report.append("  No data yet — waiting for first poll")
        return report

    report.append(f"  CPU: {snap.cpu_percent}% | RAM: {snap.ram_percent}% | "
                  f"Disk: {snap.disk_percent}%")
    if snap.max_temp_c > 0:
        report.append(f"  Temp: {snap.max_temp_c}°C (max)")
    report.append(f"  Processes: {snap.process_count} | Zombies: {snap.zombie_count}")
    if snap.active_window:
        report.append(f"  Active window: {snap.active_window[:60]}")

    trend = _trend
    if trend.alerts:
        report.append("")
        report.append("  Proactive alerts:")
        for alert in trend.alerts:
            report.append(f"    {alert}")

    # Trend summary
    trends = []
    for attr, label in [("cpu_trend", "CPU"), ("ram_trend", "RAM"),
                        ("temp_trend", "Temp"), ("disk_io_trend", "Disk I/O"),
                        ("swap_trend", "Swap")]:
        val = getattr(trend, attr, "stable")
        if val != "stable":
            trends.append(f"{label}: {val}")
    if trends:
        report.append(f"  Trends: {', '.join(trends)}")

    return report
