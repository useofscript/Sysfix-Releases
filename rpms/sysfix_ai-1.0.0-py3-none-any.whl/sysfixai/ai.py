"""
sysfix-ai AI module — expert-level intelligence with web search & system awareness.

Features:
- Ollama chat API with conversation memory
- Live system context injection
- DuckDuckGo web search for current information
- Expert system prompting
- Clean output with thinking block removal
"""

import subprocess
import re
import json
import os
import platform
import urllib.request
import urllib.parse
from typing import Tuple, List, Dict, Any
from dataclasses import dataclass
from html import unescape

try:
    from sysfixai.memory import get_memory_context, learn_from_conversation
    HAS_MEMORY = True
except ImportError:
    HAS_MEMORY = False

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    import shutil as _shutil
except ImportError:
    _shutil = None

try:
    from sysfixai.executor import run_commands
    HAS_EXECUTOR = True
except Exception:
    HAS_EXECUTOR = False

# Optional deterministic templates (improves reliability for known tasks)
try:
    from sysfixai.brain_templates import get_template
    HAS_TEMPLATES = True
except Exception:
    HAS_TEMPLATES = False


# ---------------------------------------------------------------------------
# Model configuration
# ---------------------------------------------------------------------------

# Configurable Ollama API base URL (can be overridden from GUI settings)
try:
    from sysfixai.config import load_config as _load_cfg
    OLLAMA_BASE = _load_cfg().get("ollama_endpoint", "http://localhost:11434")
except Exception:
    OLLAMA_BASE = "http://localhost:11434"

# Ordered by preference — LOCAL models first, cloud models last
_MODEL_PREFERENCE = [
    # Local models (run on your GPU, free, private)
    "qwen3:8b",
    "llama3.1:8b",
    "codellama:latest",
    "lfm2.5-thinking",
    # Cloud models (remote API, may have usage limits or charges)
    "devstral-small-2:24b-cloud",
    "devstral-2:123b-cloud",
]

# Patterns that indicate a model runs on a remote API
_CLOUD_PATTERNS = ("-cloud", ":cloud", "cloud-")

_active_model: str = ""  # resolved at first query
_active_provider: str = ""  # resolved at first query

_PROVIDER_LABELS = {
    "auto": "Auto (Local AI)",
    "ollama": "Ollama (Local LLM)",
    "openai": "OpenAI-Compatible (Advanced)",
    "anthropic": "Anthropic-Compatible (Advanced)",
    "openrouter": "OpenRouter (Advanced)",
    "openai_compatible": "Custom Endpoint (Advanced)",
    "free_web": "Sysfix Local AI Engine",
}

_PROVIDER_ORDER = (
    "auto",
    "ollama",
    "openai",
    "anthropic",
    "openrouter",
    "openai_compatible",
    "free_web",
)

_PROVIDER_MODEL_KEYS = {
    "ollama": "ai_model",
    "openai": "openai_model",
    "anthropic": "anthropic_model",
    "openrouter": "openrouter_model",
    "openai_compatible": "ai_compatible_model",
}

# Default models for optional advanced provider overrides.
# Sysfix's core AI is fully local — these are opt-in extras only.
_PROVIDER_DEFAULT_MODELS = {
    "openai": "gpt-4o-mini",
    "anthropic": "claude-3-5-sonnet-latest",
    "openrouter": "meta-llama/llama-3.3-70b-instruct:free",
    "openai_compatible": "gpt-4o-mini",
}


def _normalize_provider(provider: str) -> str:
    p = (provider or "auto").strip().lower()
    return p if p in _PROVIDER_LABELS else "auto"


def is_cloud_model(model_name: str) -> bool:
    """Return True if the model name looks like a cloud/remote API model."""
    name = model_name.lower()
    return any(p in name for p in _CLOUD_PATTERNS)


def _detect_best_model() -> str:
    """Probe Ollama for the best available LOCAL model (cloud as last resort)."""
    try:
        req = urllib.request.Request(f"{OLLAMA_BASE}/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        installed = {m["name"] for m in data.get("models", [])}
    except Exception:
        installed = set()

    # Try preference list first
    for candidate in _MODEL_PREFERENCE:
        if candidate in installed:
            return candidate

    # Fallback: pick the first local model, or any model
    local = [m for m in installed if not is_cloud_model(m)]
    if local:
        return local[0]
    return installed.pop() if installed else "lfm2.5-thinking"


def get_active_model() -> str:
    """Return the currently selected model name (auto-detects on first call)."""
    global _active_model
    if not _active_model:
        _active_model = _detect_best_model()
    return _active_model


def set_active_model(model_name: str):
    """Override the active model."""
    global _active_model
    _active_model = model_name


def list_ai_providers() -> List[str]:
    """Return supported AI provider keys."""
    return list(_PROVIDER_ORDER)


def get_provider_options() -> Dict[str, str]:
    """Return provider key -> label mapping for UI dropdowns."""
    return dict(_PROVIDER_LABELS)


def get_provider_label(provider: str) -> str:
    provider = _normalize_provider(provider)
    return _PROVIDER_LABELS.get(provider, provider)


def get_active_provider() -> str:
    """Return the active provider (auto by default)."""
    global _active_provider
    if _active_provider:
        return _active_provider
    try:
        _active_provider = _normalize_provider(_load_cfg().get("ai_provider", "auto"))
    except Exception:
        _active_provider = "auto"
    return _active_provider


def set_active_provider(provider: str):
    """Override active provider for current runtime."""
    global _active_provider
    _active_provider = _normalize_provider(provider)


def _get_provider_model(provider: str, cfg: Dict[str, Any], requested: str = "") -> str:
    provider = _normalize_provider(provider)
    requested = (requested or "").strip()
    if requested:
        return requested
    if provider == "ollama":
        saved = (cfg.get("ai_model") or "").strip()
        if saved:
            return saved
        return get_active_model()
    key = _PROVIDER_MODEL_KEYS.get(provider)
    if key:
        saved = (cfg.get(key) or "").strip()
        if saved:
            return saved
    return _PROVIDER_DEFAULT_MODELS.get(provider, "")


def _provider_api_key(provider: str, cfg: Dict[str, Any]) -> str:
    provider = _normalize_provider(provider)
    if provider == "openai":
        return (cfg.get("openai_api_key") or os.environ.get("OPENAI_API_KEY", "")).strip()
    if provider == "anthropic":
        return (cfg.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")).strip()
    if provider == "openrouter":
        return (cfg.get("openrouter_api_key") or os.environ.get("OPENROUTER_API_KEY", "")).strip()
    if provider == "openai_compatible":
        return (cfg.get("ai_compatible_api_key") or os.environ.get("AI_COMPATIBLE_API_KEY", "")).strip()
    return ""


def _provider_ready(provider: str, cfg: Dict[str, Any]) -> bool:
    provider = _normalize_provider(provider)
    if provider == "ollama":
        return bool(list_available_models(timeout=0.4))
    if provider == "free_web":
        return True
    if provider == "openai_compatible":
        endpoint = (cfg.get("ai_compatible_base_url") or "").strip()
        model = (cfg.get("ai_compatible_model") or "").strip()
        return bool(endpoint and model)
    return bool(_provider_api_key(provider, cfg))


def _provider_candidates(provider: str, cfg: Dict[str, Any]) -> List[str]:
    """Resolve provider execution order from settings."""
    provider = _normalize_provider(provider)
    fallback_free = bool(cfg.get("ai_fallback_free", True))

    if provider != "auto":
        out = [provider]
        if fallback_free and provider != "free_web":
            out.append("free_web")
        return out

    # Auto mode: prefer local Ollama first. If unavailable, default to free AI.
    if _provider_ready("ollama", cfg):
        out = ["ollama"]
        for p in ("openrouter", "openai", "anthropic", "openai_compatible"):
            if _provider_ready(p, cfg):
                out.append(p)
        if fallback_free:
            out.append("free_web")
        return out

    out: List[str] = []
    if fallback_free:
        out.append("free_web")
    for p in ("openrouter", "openai", "anthropic", "openai_compatible"):
        if _provider_ready(p, cfg):
            out.append(p)
    if out:
        return out
    return ["free_web"] if fallback_free else []


def list_available_models(timeout: float = 5.0) -> List[str]:
    """Return list of model names installed in Ollama (local first, cloud last)."""
    try:
        req = urllib.request.Request(f"{OLLAMA_BASE}/api/tags")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
        names = [m["name"] for m in data.get("models", [])]
    except Exception:
        return []
    # Sort: local models first, cloud models last
    local = [n for n in names if not is_cloud_model(n)]
    cloud = [n for n in names if is_cloud_model(n)]
    return local + cloud


def get_ai_runtime_status() -> Dict[str, Any]:
    """Return current provider status for UI indicators."""
    try:
        cfg = _load_cfg()
    except Exception:
        cfg = {}
    if not cfg.get("enable_ai_features", True):
        return {
            "online": False,
            "provider": _normalize_provider(cfg.get("ai_provider", "auto")),
            "label": "AI Disabled",
            "detail": "AI features are disabled in Settings",
        }
    selected = _normalize_provider(cfg.get("ai_provider", get_active_provider()))
    candidates = _provider_candidates(selected, cfg)
    active = next((p for p in candidates if _provider_ready(p, cfg)), selected)

    if active == "ollama":
        online = _provider_ready("ollama", cfg)
        return {
            "online": online,
            "provider": active,
            "label": "Ollama",
            "detail": "Using local Ollama models" if online else "Ollama not available",
        }
    if active == "free_web":
        if selected != "free_web":
            detail = f"{get_provider_label(selected)} unavailable — using free web fallback"
        else:
            detail = "Using free web-based fallback mode"
        return {
            "online": True,
            "provider": active,
            "label": "Free AI",
            "detail": detail,
        }

    key_ok = bool(_provider_api_key(active, cfg)) if active != "openai_compatible" else True
    ready = _provider_ready(active, cfg) and key_ok
    detail = "Configured" if ready else "Missing API key or model settings"
    return {
        "online": ready,
        "provider": active,
        "label": get_provider_label(active),
        "detail": detail,
    }


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class AIRecommendation:
    """Clean AI recommendation."""
    action: str = "skip"
    target: str = ""
    reason: str = ""
    safety: str = "moderate"


# ---------------------------------------------------------------------------
# System snapshot — real-time system state for AI context
# ---------------------------------------------------------------------------

def get_system_snapshot() -> Dict[str, Any]:
    """Capture a live system snapshot including motherboard info for AI context."""
    """Capture a live system snapshot for AI context injection.

    Returns dict with OS, CPU, RAM, disk, temps, top processes, uptime.
    Never raises — returns partial data on failure.
    """
    snap: Dict[str, Any] = {}

    try:
        snap["os"] = platform.platform()
        snap["kernel"] = platform.release()
    except Exception:
        snap["os"] = "Linux (unknown)"

    if HAS_PSUTIL:
        try:
            snap["cpu_percent"] = psutil.cpu_percent(interval=0.3)
            snap["cpu_count"] = psutil.cpu_count()
        except Exception:
            pass

        try:
            mem = psutil.virtual_memory()
            snap["ram_total_gb"] = round(mem.total / (1024 ** 3), 1)
            snap["ram_used_gb"] = round(mem.used / (1024 ** 3), 1)
            snap["ram_percent"] = mem.percent
        except Exception:
            pass

        try:
            disk = _shutil.disk_usage("/") if _shutil else None
            if disk:
                snap["disk_total_gb"] = round(disk.total / (1024 ** 3), 1)
                snap["disk_free_gb"] = round(disk.free / (1024 ** 3), 1)
                snap["disk_percent"] = round(100 * disk.used / disk.total, 1)
        except Exception:
            pass

        try:
            temps: Dict[str, float] = {}
            sensor_data = psutil.sensors_temperatures()
            for name, entries in sensor_data.items():
                for entry in entries:
                    label = entry.label or name
                    temps[label] = entry.current
            snap["temps"] = temps
        except Exception:
            snap["temps"] = {}

        try:
            top = sorted(
                psutil.process_iter(["name", "memory_percent"]),
                key=lambda p: p.info.get("memory_percent", 0) or 0,
                reverse=True,
            )[:5]
            snap["top_processes"] = [
                f"{p.info['name']} ({p.info['memory_percent']:.1f}%)"
                for p in top
                if p.info.get("name")
            ]
        except Exception:
            snap["top_processes"] = []

        try:
            import time as _time
            snap["uptime_hours"] = round(
                (_time.time() - psutil.boot_time()) / 3600, 1
            )
        except Exception:
            pass

    # GPU info via nvidia-smi (works even without psutil)

    # Motherboard / BIOS info
    try:
        from sysfixai.core import get_bios_info
        bios = get_bios_info()
        vendor = bios.get("board_vendor")
        model = bios.get("board_model")
        if vendor or model:
            snap["motherboard"] = f"{vendor or ''} {model or ''}".strip()
    except Exception:
        pass
    try:
        nv = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,driver_version,temperature.gpu,"
                "power.draw,power.limit,utilization.gpu,"
                "memory.used,memory.total,clocks.gr,clocks.max.gr,"
                "pstate",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if nv.returncode == 0 and nv.stdout.strip():
            parts = [p.strip() for p in nv.stdout.strip().split(",")]
            if len(parts) >= 11:
                snap["gpu"] = {
                    "name": parts[0],
                    "driver": parts[1],
                    "temp_c": parts[2],
                    "power_draw_w": parts[3],
                    "power_limit_w": parts[4],
                    "util_percent": parts[5],
                    "vram_used_mb": parts[6],
                    "vram_total_mb": parts[7],
                    "clock_mhz": parts[8],
                    "max_clock_mhz": parts[9],
                    "pstate": parts[10],
                }
            elif len(parts) >= 8:
                snap["gpu"] = {
                    "name": parts[0],
                    "driver": parts[1],
                    "temp_c": parts[2],
                    "power_draw_w": parts[3],
                    "power_limit_w": parts[4],
                    "util_percent": parts[5],
                    "vram_used_mb": parts[6],
                    "vram_total_mb": parts[7],
                }
    except FileNotFoundError:
        pass  # No NVIDIA GPU / nvidia-smi not installed
    except Exception:
        pass

    return snap


# ---------------------------------------------------------------------------
# Web search — DuckDuckGo (no API key required)
# ---------------------------------------------------------------------------

def web_search(query: str, max_results: int = 6) -> str:
    """Search the web via DuckDuckGo HTML lite.

    Returns clean, Markdown-formatted snippets that feed directly into
    the local AI engine's context window.  Keeps the experience fast,
    private, and self-contained — no external 'brain' provider needed.

    Never raises — returns empty string on any failure.
    """
    try:
        encoded = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        req = urllib.request.Request(url, headers={
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
            ),
        })
        with urllib.request.urlopen(req, timeout=8) as resp:
            html = resp.read().decode("utf-8", errors="ignore")

        # Extract result titles + URLs + snippets for richer context
        titles = re.findall(
            r'class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
            html, re.DOTALL,
        )
        snippets = re.findall(
            r'class="result__snippet"[^>]*>(.*?)</[at]', html, re.DOTALL,
        )

        results: List[str] = []
        for i, raw_snippet in enumerate(snippets[:max_results]):
            # Clean HTML tags from snippet
            text = re.sub(r"<[^>]+>", "", raw_snippet).strip()
            text = unescape(text)
            if not text:
                continue

            # Build Markdown-formatted entry
            if i < len(titles):
                raw_url, raw_title = titles[i]
                title = re.sub(r"<[^>]+>", "", raw_title).strip()
                title = unescape(title)
                # DuckDuckGo wraps URLs in a redirect; extract real URL
                real_url = raw_url
                if "uddg=" in raw_url:
                    try:
                        real_url = urllib.parse.unquote(
                            raw_url.split("uddg=", 1)[1].split("&", 1)[0]
                        )
                    except Exception:
                        pass
                entry = f"**{title}**\n{text}\n_Source: {real_url}_"
            else:
                entry = f"- {text}"
            results.append(entry)

        return "\n\n---\n\n".join(results)
    except Exception:
        return ""


def _should_search_web(query: str) -> bool:
    """Heuristic: does this query benefit from a web search?

    Skips web search for questions about local system state, GPU tuning
    with standard tools, conversational replies, and basic troubleshooting.
    """
    q = query.lower()

    # Too short to need a web search
    if len(q.split()) < 3:
        return False

    # Skip web search for local / conversational questions
    skip_indicators = [
        "my specs", "my system", "see my", "show my", "what do you see",
        "run those", "run that", "do that", "execute", "go ahead",
        "hello", "hi ", "hey", "thanks", "thank you", "good morning",
        "max performance", "gpu performance", "overclock",
        "set my", "help me set", "optimize my",
        "what did i", "what was my", "remember when",
        "clear chat", "clear brain", "forget",
        "write me", "write a", "generate a", "create a",
        "explain this", "explain the",
    ]
    if any(s in q for s in skip_indicators):
        return False

    indicators = [
        "latest", "newest", "current version", "update", "download",
        "how to", "how do i", "what is", "best way", "recommend",
        "tutorial", "guide", "documentation", "docs",
        "error", "bug", "issue with", "problem with", "fix for",
        "alternative", "compare", "vs ", "versus",
        "driver", "firmware", "patch", "release",
        "search", "find me", "look up", "google",
        "install", "setup", "configure",
        "benchmark", "compatible",
        "arch", "fedora", "ubuntu", "debian", "manjaro",
        "what version", "when was", "who made", "who is",
        "why does", "why is", "why can't",
    ]
    return any(ind in q for ind in indicators)


# ---------------------------------------------------------------------------
# System prompt builder
# ---------------------------------------------------------------------------

def _build_system_prompt(system_context=None, query: str = ""):
    """Build the expert system prompt with optional live context."""
    prompt = (
        "You are **Fyxa**, an expert Linux systems engineer and general-purpose AI assistant "
        "built into the Sysfix diagnostic tool. You are powered by a proprietary local AI "
        "engine with integrated web-search synthesis — no third-party API subscriptions "
        "are required.\n\n"

        "PERSONALITY:\n"
        "- You are direct, knowledgeable, and efficient. You sound like a sharp engineer, "
        "  not a customer service bot. No flowery language — get to the point.\n"
        "- You can be slightly witty or dry-humored when it fits, but never corny.\n"
        "- NEVER use terms like 'my dear', 'friend', 'buddy', 'cosmetic', 'enhancements', "
        "  or any overly warm/Victorian phrasing. Just talk like a real person.\n"
        "- Keep responses concise. If a question has a short answer, give a short answer.\n"
        "- Don't repeat the user's question back to them. Don't pad responses with filler.\n\n"

        "ACCURACY — THIS IS CRITICAL:\n"
        "- Think carefully before answering. NEVER guess or hallucinate facts.\n"
        "- For math / logic / code: work through the problem step by step internally,\n"
        "  then present a clean answer. Show work when it adds clarity.\n"
        "  If an expression like '2x^2' is just an expression (not an equation), say so.\n"
        "  Don't invent values. If there's no equation to solve, don't solve it.\n"
        "- If you don't know something, say 'I'm not sure' rather than making it up.\n"
        "- Check your own answers before responding. If something feels off, re-check.\n"
        "- When asked about versions, release dates, or current events: use the web search\n"
        "  results if available. Don't guess version numbers or dates from training data.\n"
        "- For historical/factual questions: give the actual, verified fact. If uncertain,\n"
        "  say so and provide what you do know with confidence levels.\n\n"

        "REASONING & ANALYSIS:\n"
        "- For complex questions, break the problem into parts and address each one.\n"
        "- When diagnosing system issues, consider multiple possible causes rather than\n"
        "  jumping to the first explanation. Rank them by likelihood.\n"
        "- If the user asks you to fix a system problem and root cause is unclear,\n"
        "  ask 2-4 targeted diagnostic questions first before giving commands.\n"
        "- After the user answers those questions, give a focused action plan and commands.\n"
        "- If asked to compare options, give a structured comparison with pros/cons.\n"
        "- When the user's question is ambiguous, address the most likely interpretation\n"
        "  and briefly note other possibilities. Don't ask for clarification unless\n"
        "  you genuinely cannot infer intent.\n"
        "- When you find an error or problem, explain both WHAT is wrong and WHY.\n\n"

        "CONVERSATION RULES:\n"
        "- Read messages carefully. If asked a question, ANSWER it directly.\n"
        "- If they ask about their specs or system, use the LIVE SYSTEM STATE below.\n"
        "- Don't suggest commands unless they ask for help fixing or doing something.\n"
        "- Format system info with bullet points or tables, not walls of text.\n"
        "- You can help with coding projects, writing, math, science, or anything else.\n"
        "  You're not limited to system admin tasks.\n"
        "- For code questions: write clean, idiomatic, well-commented code.\n"
        "  Explain your approach briefly, then show the code.\n"
        "- Adapt your response length to the question. Simple questions get short answers.\n"
        "  Complex topics get thorough but focused explanations.\n"
        "- Remember prior messages in this conversation. Reference earlier context\n"
        "  naturally. Don't ask the user to repeat things they already told you.\n\n"

        "PROJECT MANAGEMENT:\n"
        "- If the user asks about their projects, check your BRAIN memory.\n"
        "- You can help run, build, test, and debug their code projects.\n"
        "- When they mention a project by name, use its path and language from memory.\n"
        "- Suggest commands appropriate to the project type (cargo for Rust, npm for JS, etc).\n\n"

        "COMMAND RULES (only when providing commands):\n"
        "- Don't rush to commands for vague problems. Ask clarifying diagnostics first.\n"
        "- Only suggest commands that ACTUALLY EXIST with real flags.\n"
        "  Never invent flags or options. If unsure, don't guess.\n"
        "- Every backticked item MUST be a complete, runnable shell command.\n"
        "- NEVER put package names, tool names, or labels in backticks.\n"
        "  BAD: install `lm-sensors` and check `htop`\n"
        "  GOOD: `sudo dnf install lm_sensors` then `sensors`\n"
        "- Use the correct package manager for the detected distro.\n"
        "  Fedora/RHEL = dnf, Ubuntu/Debian = apt, Arch = pacman.\n"
        "- Don't suggest interactive TUI programs (htop, top, btop, ncdu) — they can't "
        "  run headless in Sysfix. Use ps aux, free -h, sensors, df -h, etc.\n"
        "- For NVIDIA GPU tuning, use only REAL nvidia-smi / nvidia-settings flags:\n"
        "  `nvidia-smi -pm 1`, `nvidia-smi -pl <watts>`, `nvidia-smi -lgc <min>,<max>`\n"
        "- Use numbered steps for multi-step procedures.\n"
        "- Before suggesting a fix, consider whether it could break other things.\n"
        "  Mention side effects and risks when they exist.\n\n"

        "WEB SEARCH:\n"
        "- You have internet access via web search. When web results are included,\n"
        "  use them to give up-to-date answers.\n"
        "- Synthesize web results into a coherent answer — don't just dump raw snippets.\n"
        "- If web results contradict each other, note the discrepancy.\n"
        "- Cite your source briefly (e.g. 'According to the Arch Wiki...').\n\n"

        "BRAIN & MEMORY:\n"
        "- You have a persistent BRAIN that remembers facts about the user and their system.\n"
        "  Use memorized details naturally — don't announce 'according to my brain'.\n"
        "  Just know things. If you learned the user prefers Rust, use Rust examples.\n"
        "- Reference the user's live system stats naturally when relevant.\n"
    )

    if system_context:
        prompt += "\n--- LIVE SYSTEM STATE ---\n"
        if system_context.get("os"):
            prompt += f"OS: {system_context['os']}\n"
        if system_context.get("kernel"):
            prompt += f"Kernel: {system_context['kernel']}\n"
        if system_context.get("cpu_percent") is not None:
            prompt += (
                f"CPU: {system_context['cpu_percent']}% "
                f"({system_context.get('cpu_count', '?')} cores)\n"
            )
        if system_context.get("ram_percent") is not None:
            prompt += (
                f"RAM: {system_context['ram_used_gb']}/{system_context['ram_total_gb']} GB "
                f"({system_context['ram_percent']}%)\n"
            )
        if system_context.get("disk_percent") is not None:
            prompt += (
                f"Disk: {system_context['disk_free_gb']} GB free / "
                f"{system_context['disk_total_gb']} GB total "
                f"({system_context['disk_percent']}% used)\n"
            )
        temps = system_context.get("temps", {})
        if temps:
            parts = [f"{k}: {v}C" for k, v in list(temps.items())[:5]]
            prompt += f"Temps: {', '.join(parts)}\n"
        top = system_context.get("top_processes", [])
        if top:
            prompt += f"Top RAM processes: {', '.join(top[:5])}\n"
        if system_context.get("uptime_hours"):
            prompt += f"Uptime: {system_context['uptime_hours']}h\n"

        gpu = system_context.get("gpu")
        if gpu:
            prompt += (
                f"GPU: {gpu.get('name', '?')} "
                f"(driver {gpu.get('driver', '?')})\n"
                f"  Temp: {gpu.get('temp_c', '?')}C, "
                f"Power: {gpu.get('power_draw_w', '?')}W / {gpu.get('power_limit_w', '?')}W, "
                f"Util: {gpu.get('util_percent', '?')}%, "
                f"VRAM: {gpu.get('vram_used_mb', '?')} / {gpu.get('vram_total_mb', '?')} MB\n"
            )
            if gpu.get("clock_mhz"):
                prompt += (
                    f"  Clock: {gpu['clock_mhz']} MHz "
                    f"(max {gpu.get('max_clock_mhz', '?')} MHz), "
                    f"PState: {gpu.get('pstate', '?')}\n"
                )

        # Extra context injected by GUI (topic keywords, etc.)
        extra = system_context.get("_extra_context")
        if extra:
            prompt += f"\n{extra}\n"

        # ELI5 instruction injected by GUI
        eli5 = system_context.get("_eli5")
        if eli5:
            prompt += f"\n{eli5}\n"

        prompt += "---\n"

    # Inject brain memory (persistent knowledge) — AGGRESSIVE/ALWAYS recall
    if HAS_MEMORY:
        try:
            cfg = _load_cfg()
            if cfg.get("enable_brain", True):
                # Always retrieve and inject relevant memories for every query.
                # Use a larger token budget so the brain can include more context.
                memory_block = get_memory_context(query=query or "", max_tokens=2000)
                if memory_block:
                    prompt += "\n--- BRAIN (persistent memory) ---\n"
                    prompt += memory_block
                    prompt += "\n---\n"
        except Exception:
            pass

    # System Pulse — live telemetry with trend analysis
    try:
        from sysfixai.system_pulse import get_pulse_prompt_header
        pulse_header = get_pulse_prompt_header()
        if pulse_header:
            prompt += "\n" + pulse_header + "\n"
    except ImportError:
        pass

    # Workspace visibility: include a compact summary of nearby project files.
    try:
        from sysfixai.agent import get_workspace_summary
        ws = get_workspace_summary(".", query=query or "", max_files=80, max_chars=1500)
        if ws:
            prompt += "\n--- WORKSPACE ---\n"
            prompt += ws
            prompt += "\n---\n"
    except Exception:
        pass

    # Sentinel Bridge — tell the AI the security engine is available
    try:
        from sysfixai.sentinel_bridge import get_sentinel_prompt_block
        sentinel_block = get_sentinel_prompt_block()
        if sentinel_block:
            prompt += "\n" + sentinel_block
    except ImportError:
        pass

    return prompt


# ---------------------------------------------------------------------------
# Ollama query functions
# ---------------------------------------------------------------------------

def _persist_active_model(model_name: str):
    """Persist a recovered working model so future requests don't keep failing."""
    _persist_provider_model("ollama", model_name)


def _persist_provider_model(provider: str, model_name: str):
    """Persist selected model for the provider."""
    provider = _normalize_provider(provider)
    key = _PROVIDER_MODEL_KEYS.get(provider)
    if not key or not model_name:
        return
    try:
        from sysfixai.config import load_config as _cfg_load, save_config as _cfg_save
        cfg = _cfg_load()
        if cfg.get(key) != model_name:
            cfg[key] = model_name
            _cfg_save(cfg)
    except Exception:
        pass


def _candidate_models(preferred: str) -> List[str]:
    """Build candidate models: preferred first, then detected installed ones."""
    models: List[str] = []
    if preferred:
        models.append(preferred)

    auto = _detect_best_model()
    if auto and auto not in models:
        models.append(auto)

    for m in list_available_models():
        if m not in models:
            models.append(m)

    return models[:6]


def _extract_openai_content(data: Dict[str, Any]) -> str:
    """Extract assistant text from OpenAI-compatible API response."""
    choices = data.get("choices") or []
    if not choices:
        return ""
    msg = (choices[0] or {}).get("message") or {}
    content = msg.get("content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        texts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") in ("text", "output_text"):
                txt = part.get("text", "")
                if txt:
                    texts.append(str(txt))
        return "\n".join(texts).strip()
    return ""


def _chat_api_openai_like(
    messages: List[Dict[str, str]],
    model: str,
    base_url: str,
    api_key: str,
    timeout: int = 90,
    extra_headers: Dict[str, str] = None,
) -> str:
    """Call OpenAI-compatible chat/completions APIs."""
    if not model or not base_url:
        return ""
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.3,
    }
    data_bytes = json.dumps(payload).encode()
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/chat/completions",
        data=data_bytes,
        headers=headers,
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read())
    if data.get("error"):
        return ""
    return _extract_openai_content(data)


def _chat_api_anthropic(
    messages: List[Dict[str, str]],
    model: str,
    api_key: str,
    timeout: int = 90,
) -> str:
    """Call Anthropic Messages API."""
    if not model or not api_key:
        return ""

    system_parts: List[str] = []
    convo: List[Dict[str, Any]] = []
    for m in messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        if not content:
            continue
        if role == "system":
            system_parts.append(content)
            continue
        if role not in ("user", "assistant"):
            role = "user"
        convo.append({"role": role, "content": content[:8000]})

    payload = {
        "model": model,
        "max_tokens": 1400,
        "messages": convo[-30:],
    }
    if system_parts:
        payload["system"] = "\n\n".join(system_parts)[:12000]

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps(payload).encode(),
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read())

    chunks = []
    for part in data.get("content", []):
        if isinstance(part, dict) and part.get("type") == "text":
            txt = part.get("text", "")
            if txt:
                chunks.append(str(txt))
    return "\n".join(chunks).strip()


def _free_web_fallback(messages: List[Dict[str, str]]) -> str:
    """Sysfix Local AI Engine — self-contained Python reasoning.

    Handles conversation via pattern matching and local logic, enriched
    by integrated web-search scraping for real-time data.  No third-party
    API subscriptions required.
    """
    user_query = ""
    for m in reversed(messages):
        if m.get("role") == "user" and m.get("content"):
            user_query = m["content"].strip()
            break
    if "[Web search results for reference:]" in user_query:
        user_query = user_query.split("[Web search results for reference:]", 1)[0].strip()
    if not user_query:
        return "I'm Fyxa, powered by the Sysfix Local AI Engine. Ask me anything — no API subscription required."

    ql = user_query.lower().strip().rstrip("?!.,")

    # --- Conversational / casual patterns — answer directly, no web search ---
    _GREETING_EXACT = {
        "hi", "hello", "hey", "yo", "sup", "hiya", "howdy", "heya",
        "good morning", "good evening", "good afternoon", "morning",
        "evening", "afternoon", "greetings", "whats up", "what's up",
    }
    if ql in _GREETING_EXACT:
        return (
            "Hey! I'm Fyxa, powered by the Sysfix Local AI Engine. "
            "I can help with diagnostics, system questions, and web-backed answers — "
            "no third-party API subscriptions required. What do you need?"
        )

    _CASUAL_PATTERNS = [
        # How-are-you variants
        ("how are you", "I'm running well — Sysfix Local AI Engine, fully self-contained. What can I help with?"),
        ("how you doing", "Doing fine! Sysfix Local AI is online. What do you need?"),
        ("how's it going", "All good on my end. Local AI engine running — ask me anything."),
        ("how do you do", "I'm operational and ready. Sysfix Local AI Engine at your service."),
        ("what's good", "Not much — just waiting for questions. Local AI engine, always ready."),
        ("you good", "Yep, all systems go. What do you need?"),
        ("you okay", "I'm fine! Local AI engine fully functional for diagnostics."),
        ("are you there", "I'm here. Sysfix Local AI Engine — ask away."),
        ("are you alive", "Alive and running. Local AI engine online, no API keys needed."),
        ("are you working", "Yep, running on the Sysfix Local AI Engine. What do you need?"),
        ("you there", "I'm here. What can I do for you?"),
        # About-me
        ("what are you", "I'm Fyxa, the AI assistant in Sysfix. I run on a proprietary local AI engine — no third-party API subscriptions required. I can answer system questions and search the web."),
        ("who are you", "I'm Fyxa, Sysfix's built-in AI. I use a proprietary local engine with integrated web search. I can help with Linux diagnostics, system questions, and general queries."),
        ("what can you do", "I use Sysfix's local AI engine to search the web, help with system diagnostics, answer Linux questions, and guide you through fixes. For deeper local LLM reasoning, connect Ollama in Settings."),
        ("what is sysfix", "Sysfix is an all-in-one Linux diagnostic and repair tool with a proprietary local AI engine. I'm Fyxa, the AI assistant built into it. No third-party API subscriptions required."),
        ("what is fyxa", "That's me! I'm the AI assistant inside Sysfix, powered by a proprietary local AI engine. No paid API keys needed."),
        # Gratitude / pleasantries
        ("thank", "You're welcome! Anything else?"),
        ("thanks", "No problem. Need anything else?"),
        ("cool", "👍 Let me know if you need anything."),
        ("nice", "Glad to help. What's next?"),
        ("awesome", "Thanks! Anything else I can help with?"),
        ("great", "Good to hear. What else?"),
        ("okay", "Alright. What can I help with?"),
        ("ok", "Sure. What's next?"),
        ("got it", "Good. Need anything else?"),
        ("never mind", "No worries. I'm here if you need me."),
        ("nevermind", "All good. Let me know if something comes up."),
        # Farewell
        ("bye", "See you! Run `sysfix` anytime you need me."),
        ("goodbye", "Bye! I'll be here when you need me."),
        ("see you", "Later! 👋"),
        ("good night", "Night! 🌙"),
        ("goodnight", "Goodnight! I'll be here when you're back."),
        # Feelings / meta
        ("i'm bored", "Want me to run a system health check? Or ask me a Linux question — I might surprise you."),
        ("i am bored", "How about a quick system scan? Or ask me something interesting."),
        ("tell me a joke", "Why do programmers prefer dark mode? Because light attracts bugs.\n\nNeed actual help with something?"),
        ("tell me something", "Fun fact: Linux runs on everything from smartwatches to 100% of the world's top 500 supercomputers.\n\nWant me to check your system?"),
    ]

    for pattern, response in _CASUAL_PATTERNS:
        if pattern in ql:
            return response

    # Short affirmative/negative — don't web-search these
    _SHORT_REPLIES = {"yes", "no", "yep", "nope", "sure", "nah", "maybe", "idk",
                      "lol", "lmao", "haha", "heh", "hmm", "ah", "oh", "ooh",
                      "k", "kk", "yea", "yeah", "naw", "mhm", "uh huh"}
    if ql in _SHORT_REPLIES:
        return "Got it. What can I help you with?"

    # If the query doesn't benefit from a web search, give a helpful nudge
    if not _should_search_web(user_query):
        return (
            "I'm running on Sysfix's local AI engine. I can search the web for "
            "technical questions, help with diagnostics, or guide you through system "
            "fixes. Try asking a specific question — or connect a local Ollama model "
            "in Settings for deeper reasoning."
        )

    web = web_search(user_query, max_results=6)
    if web:
        snippets = [s.strip() for s in web.split("\n\n") if s.strip()][:6]
        bullet_text = "\n".join(f"• {s}" for s in snippets)
        return (
            f"{bullet_text}\n\n"
            "_Powered by Sysfix Local AI Engine with integrated web search._"
        )

    return (
        "I couldn't fetch web results for that query right now. "
        "Try rephrasing, or connect a local LLM via Ollama in Settings "
        "for richer reasoning without web dependency."
    )


def _chat_api_ollama(
    messages: List[Dict[str, str]],
    model: str = "",
    timeout: int = 90,
) -> str:
    """Call Ollama chat endpoint with CLI fallback."""
    preferred = model or get_active_model()
    flat = "\n".join(m.get("content", "") for m in messages)

    for candidate in _candidate_models(preferred):
        # API path first
        try:
            payload = json.dumps({
                "model": candidate,
                "messages": messages,
                "stream": False,
            }).encode()
            req = urllib.request.Request(
                f"{OLLAMA_BASE}/api/chat",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read())
            err = (data.get("error") or "").strip()
            if err:
                raise RuntimeError(err)
            content = (data.get("message") or {}).get("content", "").strip()
            if content:
                if candidate != preferred:
                    set_active_model(candidate)
                    _persist_active_model(candidate)
                return content
        except Exception:
            pass

        # CLI fallback for this candidate
        cli_text = _cli_fallback(flat, candidate, timeout)
        if cli_text:
            if candidate != preferred:
                set_active_model(candidate)
                _persist_active_model(candidate)
            return cli_text
    return ""


def _chat_api(
    messages: List[Dict[str, str]],
    model: str = "",
    timeout: int = 90,
) -> str:
    """Provider-agnostic chat call with automatic fallbacks."""
    try:
        cfg = _load_cfg()
    except Exception:
        cfg = {}

    provider = _normalize_provider(cfg.get("ai_provider", get_active_provider()))
    set_active_provider(provider)

    for candidate_provider in _provider_candidates(provider, cfg):
        try:
            if candidate_provider == "ollama":
                ollama_model = _get_provider_model("ollama", cfg, model)
                response = _chat_api_ollama(messages, ollama_model, timeout)
                if response:
                    return response

            elif candidate_provider == "openai":
                key = _provider_api_key("openai", cfg)
                openai_model = _get_provider_model("openai", cfg, model if provider == "openai" else "")
                if not key:
                    continue
                base = (cfg.get("openai_base_url") or "https://api.openai.com/v1").strip()
                response = _chat_api_openai_like(
                    messages=messages,
                    model=openai_model,
                    base_url=base,
                    api_key=key,
                    timeout=timeout,
                )
                if response:
                    _persist_provider_model("openai", openai_model)
                    return response

            elif candidate_provider == "anthropic":
                key = _provider_api_key("anthropic", cfg)
                anthropic_model = _get_provider_model(
                    "anthropic", cfg, model if provider == "anthropic" else ""
                )
                if not key:
                    continue
                response = _chat_api_anthropic(messages, anthropic_model, key, timeout)
                if response:
                    _persist_provider_model("anthropic", anthropic_model)
                    return response

            elif candidate_provider == "openrouter":
                key = _provider_api_key("openrouter", cfg)
                openrouter_model = _get_provider_model(
                    "openrouter", cfg, model if provider == "openrouter" else ""
                )
                if not key:
                    continue
                response = _chat_api_openai_like(
                    messages=messages,
                    model=openrouter_model,
                    base_url="https://openrouter.ai/api/v1",
                    api_key=key,
                    timeout=timeout,
                    extra_headers={"HTTP-Referer": "https://sysfix.ai", "X-Title": "Sysfix AI"},
                )
                if response:
                    _persist_provider_model("openrouter", openrouter_model)
                    return response

            elif candidate_provider == "openai_compatible":
                compat_base = (cfg.get("ai_compatible_base_url") or "").strip().rstrip("/")
                if not compat_base:
                    continue
                if not compat_base.endswith("/v1"):
                    compat_base = compat_base + "/v1"
                compat_model = _get_provider_model(
                    "openai_compatible", cfg, model if provider == "openai_compatible" else ""
                )
                if not compat_model:
                    continue
                compat_key = _provider_api_key("openai_compatible", cfg)
                response = _chat_api_openai_like(
                    messages=messages,
                    model=compat_model,
                    base_url=compat_base,
                    api_key=compat_key,
                    timeout=timeout,
                )
                if response:
                    _persist_provider_model("openai_compatible", compat_model)
                    return response

            elif candidate_provider == "free_web":
                response = _free_web_fallback(messages)
                if response:
                    return response
        except Exception:
            continue
    return ""


def _cli_fallback(prompt: str, model: str = "", timeout: int = 60) -> str:
    """Fallback: query Ollama via CLI subprocess."""
    model = model or get_active_model()
    if not prompt:
        return ""
    try:
        result = subprocess.run(
            ["ollama", "run", model, prompt],
            capture_output=True, text=True, check=True,
            timeout=timeout, stdin=subprocess.DEVNULL,
        )
        return result.stdout.strip()
    except Exception:
        return ""


# Legacy wrappers (used by CLI / core.py)
def query_ollama(prompt: str, timeout: int = 30) -> str:
    """Legacy wrapper for non-chat usage (now provider-aware)."""
    if not prompt:
        return ""
    try:
        text = _chat_api([{"role": "user", "content": prompt[:12000]}], timeout=max(timeout, 30))
        if text:
            return text
    except Exception:
        pass
    return _cli_fallback(prompt, timeout=timeout)


def query_ollama_prompt(prompt: str, timeout: int = 60) -> str:
    """Query with prompt string (provider-aware)."""
    return query_ollama(prompt, timeout=timeout)


# ---------------------------------------------------------------------------
# Response cleaning
# ---------------------------------------------------------------------------

def _clean_verbose_response(response: str) -> str:
    """Remove thinking blocks and verbose meta-reasoning, keep useful content."""
    # Remove explicit thinking blocks
    response = re.sub(
        r"Thinking\.\.\..*?\.\.\.done thinking\.?", "", response,
        flags=re.DOTALL | re.IGNORECASE,
    )
    response = re.sub(r"<think>.*?</think>", "", response, flags=re.DOTALL | re.IGNORECASE)
    response = re.sub(r"<thinking>.*?</thinking>", "", response, flags=re.DOTALL | re.IGNORECASE)
    response = re.sub(r"<reasoning>.*?</reasoning>", "", response, flags=re.DOTALL | re.IGNORECASE)

    lines = response.split("\n")
    cleaned = []
    in_thinking = False

    skip_patterns = [
        "let me think", "okay, let", "the instructions say",
        "the user wants", "since the user", "since the task",
        "the task is", "let me consider", "since i can't",
        "since the user said", "maybe just", "also, warn",
        "let me analyze", "i need to", "let me figure",
    ]

    for line in lines:
        stripped = line.strip()
        lower = stripped.lower()

        if lower in {
            "thinking...", "...done thinking", "...done thinking.",
            "thinking", "...", "done thinking",
        }:
            continue

        if "<think" in lower or "<reasoning" in lower:
            in_thinking = True
            continue
        if "</think" in lower or "</reasoning" in lower:
            in_thinking = False
            continue
        if in_thinking:
            continue

        if any(p in lower for p in skip_patterns):
            continue

        if stripped:
            cleaned.append(line)

    result = "\n".join(cleaned).strip()
    result = re.sub(r"\n{3,}", "\n\n", result)
    return result


# ---------------------------------------------------------------------------
# Deep dive — primary GUI interface
# ---------------------------------------------------------------------------

def get_deep_dive(
    description: str,
    gui_mode: bool = False,
    chat_history=None,
    system_context=None,
) -> str:
    """Get detailed AI analysis with optional memory, context, and web search.

    The GUI mode functions as a conversational chat interface; the AI prompt is
    carefully constructed by `_build_system_prompt`.  We also intercept some
    trivial queries (e.g. "what is my motherboard?") and answer directly with
    live hardware info to avoid misclassification by the language model.

    Args:
        description:    User's question / issue description
        gui_mode:       Friendlier, richer formatting for GUI
        chat_history:   List of {"role": "user"|"assistant", "content": "..."} dicts
        system_context: Live system snapshot dict (from get_system_snapshot)

    Returns:
        AI analysis string (cleaned of thinking artefacts in gui_mode)
    """

    if gui_mode:
        # allow simple factual queries to bypass the model
        desc_lower = description.lower()
        if "motherboard" in desc_lower:
            try:
                from sysfixai.core import get_bios_info
                bios = get_bios_info()
                vendor = bios.get("board_vendor", "Unknown")
                model = bios.get("board_model", "Unknown")
                return f"Your motherboard is {vendor} {model}."
            except Exception:
                pass

        # Route through Agentic Reasoning Loop if enabled
        try:
            cfg_agentic = _load_cfg()
            if cfg_agentic.get("enable_agentic_loop", True):
                from sysfixai.reasoning_loop import agent_query
                response = agent_query(
                    description,
                    chat_history=chat_history,
                    system_context=system_context,
                )
                if response:
                    response = _clean_verbose_response(response)
                    # Brain learning
                    if HAS_MEMORY:
                        try:
                            cfg_b = _load_cfg()
                            if cfg_b.get("enable_brain", True) and cfg_b.get("brain_learn_conversations", True):
                                recent = (chat_history or [])[-6:] + [
                                    {"role": "user", "content": description},
                                    {"role": "assistant", "content": response[:500]},
                                ]
                                learn_from_conversation(recent)
                        except Exception:
                            pass
                    return response
        except ImportError:
            pass
        except Exception:
            pass  # Fall through to standard path

        # ---------- build Chat API messages ----------
        # Pass the user's description into the system-prompt builder so
        # the brain recall can prioritize memories relevant to the query.
        sys_prompt = _build_system_prompt(system_context, description[:800])

        messages: List[Dict[str, str]] = [
            {"role": "system", "content": sys_prompt},
        ]

        # Conversation memory (last 12 exchanges)
        if chat_history:
            for msg in chat_history[-24:]:
                role = msg.get("role", "user")
                content = msg.get("content", "")[:1200]
                if role in ("user", "assistant") and content:
                    messages.append({"role": role, "content": content})

        # Web search (if question benefits from it)
        web_block = ""
        if _should_search_web(description):
            web_results = web_search(description, max_results=3)
            if web_results:
                web_block = web_results

        # Build user message — include web results as context if we have them
        user_content = description[:2000]
        if web_block:
            user_content += (
                "\n\n[Web search results for reference:]\n"
                f"{web_block}"
            )

        messages.append({"role": "user", "content": user_content})

        response = _chat_api(messages, timeout=90)
        if response:
            response = _clean_verbose_response(response)

        # --- Brain: learn from this exchange (background, non-blocking) ---
        if HAS_MEMORY and response:
            try:
                from sysfixai.config import load_config as _lc
                cfg = _lc()
                if cfg.get("enable_brain", True) and cfg.get("brain_learn_conversations", True):
                    recent = (chat_history or [])[-6:] + [
                        {"role": "user", "content": description},
                        {"role": "assistant", "content": response[:500]},
                    ]
                    learn_from_conversation(recent)
            except Exception:
                pass

        if response:
            return response
        status = get_ai_runtime_status()
        provider_hint = status.get("label", get_provider_label(get_active_provider()))
        detail = status.get("detail", "")
        return (
            "I couldn't reach my AI brain right now. "
            f"(Provider: {provider_hint}) "
            f"{detail}. "
            "Open Settings -> AI Model & Providers to update provider/API settings."
        )

    else:
        # CLI mode — compact technical prompt
        prompt = f"Troubleshoot: {description[:500]}\n\n1. Cause:\n2. Fix:\n3. Warning:"
        # Always prepend relevant brain memory for CLI troubleshooting too.
        if HAS_MEMORY:
            try:
                if _load_cfg().get("enable_brain", True):
                    mem_block = get_memory_context(query=description[:500], max_tokens=1000)
                    if mem_block:
                        prompt = mem_block + "\n\n" + prompt
            except Exception:
                pass
        response = query_ollama(prompt, timeout=60)
        if response:
            response = _clean_verbose_response(response)
        return response if response else "Could not get analysis"


def _extract_commands_from_response(response: str) -> List[str]:
    """Extract shell command lines from a model response.

    Looks for a fenced ```bash or ``` block first, then falls back to
    extracting lines that look like commands.
    """
    if not response:
        return []
    # fenced block
    m = re.search(r"```(?:bash)?\n([\s\S]*?)```", response, flags=re.IGNORECASE)
    commands = []
    if m:
        body = m.group(1).strip()
        for line in body.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            commands.append(line)
        return commands

    # fallback: gather lines that look like shell commands
    for line in response.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        # crude heuristic: starts with common command verbs or contains / or =
        if re.match(r"^(sudo\s+)?[a-zA-Z0-9_\-./]+(\s|$)", s):
            commands.append(s)
    return commands


def _verify_commands_safety(commands: List[str]) -> Dict[str, Any]:
    """Basic heuristic safety check for generated commands.

    Returns a dict with 'risk' (low/medium/high) and 'notes' (list of warnings).
    This is advisory only — interactive confirmation is still required for execution.
    """
    notes = []
    risk = "low"
    dangerous_patterns = [
        r"\brm\s+-rf\b", r"\bdd\s+if=", r"mkfs\.", r"/dev/(sda|nvme)\b",
        r": ?\{\)\s*\{", r"\bshutdown\b", r"\breboot\b", r"\bpoweroff\b",
        r"\bchmod\s+0+\b", r"chown\s+root:root\s+/", r">\s*/dev/sd",
    ]
    import re
    combined = "\n".join(commands)
    for pat in dangerous_patterns:
        if re.search(pat, combined):
            notes.append(f"Detected dangerous pattern: {pat}")
            risk = "high"
    # suspicious use of sudo + pipes
    if re.search(r"sudo\s+.*\|\s*sh\b", combined):
        notes.append("Suspicious pipeline that runs shell via sudo")
        risk = "high"
    # empty / trivial checks
    if any(c.strip().startswith("curl") and "|" in c for c in commands):
        notes.append("Found network curl | sh patterns — treat as untrusted installer")
        risk = "medium" if risk != "high" else risk

    return {"risk": risk, "notes": notes}


def plan_and_execute(description: str, execute: bool = False, cwd: str = None, use_sudo: bool = False) -> Dict[str, Any]:
    """Ask Fyxa to produce shell commands for a task, optionally execute them.

    - `description`: what the user wants done (e.g., "install the wine 11.2 folder in Downloads")
    - `execute`: if True, will attempt to run the commands after interactive confirmation
    - `cwd`: working directory for execution
    - `use_sudo`: if True, commands will be prefixed with `sudo` when executed

    Returns a dict with keys: 'commands' (list), 'results' (list of execution results) when executed.
    """
    # First consult hardcoded templates for well-known tasks (deterministic brain)
    commands: List[str] = []
    if HAS_TEMPLATES:
        try:
            low = description.lower()
            if "install" in low and "wine" in low:
                # Allow callers to provide a download_path via description/context in future
                ctx = {}
                tpl = get_template("install_wine", ctx)
                if tpl:
                    commands = tpl
        except Exception:
            commands = []

    # If no template matched, ask the model for commands
    if not commands:
        sys_prompt = _build_system_prompt(None, query=description[:800])

        # Try to gather web results to give Fyxa up-to-date information
        web_block = ""
        try:
            web_block = web_search(description, max_results=5) or ""
        except Exception:
            web_block = ""

        user_msg = (
            "Produce a concise set of shell commands (bash) that accomplish the user's request. "
            "Output ONLY a fenced ```bash block containing the commands, nothing else. "
            "If the request is unsafe or ambiguous, respond with a short clarification question instead.\n\n"
            f"Task: {description[:1000]}\n"
        )

        if web_block:
            user_msg = f"[Web search results for reference:]\n{web_block}\n\n" + user_msg

        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_msg},
        ]

        response = _chat_api(messages, timeout=60)
        response = response or ""
        response = _clean_verbose_response(response)

        commands = _extract_commands_from_response(response)
    out: Dict[str, Any] = {"commands": commands, "response": response}

    # Add a safety verification summary so the UI/CLI can warn the user
    try:
        out["verification"] = _verify_commands_safety(commands)
    except Exception:
        out["verification"] = {"risk": "unknown", "notes": []}

    if not commands:
        out["error"] = "No commands extracted; model asked for clarification or produced no shell block."
        return out

    # If Agent Mode is enabled and configured to auto-run, run without interactive confirmation
    try:
        from sysfixai.agent_mode import is_enabled as _agent_is_enabled, run_agent_commands
        from sysfixai.config import load_config as _load_cfg
        cfg = _load_cfg()
        if _agent_is_enabled() and cfg.get("agent_mode_auto_apply_templates", True):
            # attempt to auto-run
            agent_out = run_agent_commands(description, commands, cwd=cwd)
            out["agent_run"] = agent_out
            return out
    except Exception:
        pass

    if execute:
        if not HAS_EXECUTOR:
            out["error"] = "Executor not available"
            return out
        try:
            results = run_commands(commands, cwd=cwd, use_sudo=use_sudo, require_confirmation=True)
            out["results"] = results
        except Exception as e:
            out["error"] = str(e)

    return out

# ---------------------------------------------------------------------------
# Issue analysis helpers (unchanged, used by core.py / CLI)
# ---------------------------------------------------------------------------

def prepare_system_context(issues):
    """Prepare comprehensive system context from all issues."""
    context = {
        "total_issues": len(issues),
        "memory_issues": [],
        "temperature_issues": [],
        "storage_issues": [],
        "audio_issues": [],
        "hardware_issues": [],
        "system_info": {},
        "running_processes": [],
        "critical_problems": [],
        "raw_issues": issues,
    }

    for issue in issues:
        il = issue.lower()
        if "high memory" in il:
            procs = re.findall(r"(\w+)\s+\(PID\s+(\d+)\)\s+using\s+(\d+\.?\d*)\s+MB", issue)
            for proc, pid, mem in procs:
                context["memory_issues"].append({"process": proc, "pid": pid, "mb": float(mem)})
                context["running_processes"].append(proc)
        elif "high temp" in il or "critical temp" in il:
            temps = re.findall(r"(\w+)\s+at\s+(\d+\.?\d*)C", issue)
            for sensor, temp in temps:
                tf = float(temp)
                context["temperature_issues"].append({"sensor": sensor, "temp": tf})
                if tf > 90:
                    context["critical_problems"].append(f"Critical temp: {temp}C")
        elif "storage" in il or "disk" in il:
            context["storage_issues"].append(issue)
        elif "audio" in il or "pipewire" in il or "pulseaudio" in il:
            context["audio_issues"].append(issue)
        elif "motherboard" in il or "bios" in il:
            context["hardware_issues"].append(issue)
        elif "linux distribution" in il or "cpu:" in il or "ram:" in il:
            if "distribution" in il:
                context["system_info"]["distro"] = issue
            elif "cpu" in il:
                context["system_info"]["cpu"] = issue
            elif "ram" in il:
                context["system_info"]["ram"] = issue

    return context


def generate_smart_fix_prompt(issue, context):
    """Generate AI prompt with full context for auto-fix."""
    total = context.get("total_issues", 0)
    mem = context.get("memory_issues", [])
    temp = context.get("temperature_issues", [])
    stor = context.get("storage_issues", [])
    aud = context.get("audio_issues", [])
    crit = context.get("critical_problems", [])

    prompt = (
        "You are a Linux system administrator analyzing system problems.\n\n"
        f"SYSTEM CONTEXT:\n"
        f"- Total issues found: {total}\n"
        f"- Memory problems: {len(mem)}\n"
        f"- Temperature warnings: {len(temp)}\n"
        f"- Storage issues: {len(stor)}\n"
        f"- Audio issues: {len(aud)}\n\n"
        f"CURRENT ISSUE TO FIX:\n{issue}\n\n"
        "SYSTEM STATE:\n"
    )

    if mem:
        procs = ", ".join(str(p.get("process", "unknown")) for p in mem if isinstance(p, dict))
        if procs:
            prompt += f"High memory usage by: {procs}\n"
    if temp:
        temps_list = [t.get("temp", 0) for t in temp if isinstance(t, dict)]
        if temps_list:
            prompt += f"Highest temperature: {max(temps_list)}C\n"
    if crit:
        prompt += f"Critical issues: {', '.join(str(p) for p in crit)}\n"

    prompt += (
        "\nINSTRUCTIONS:\n"
        "1. Analyze if this issue is related to other problems\n"
        "2. Recommend ONE specific action to fix\n"
        "3. Consider the system's overall state\n"
        "4. Be practical and safe\n\n"
        "Respond with ONLY:\n"
        "ACTION: [kill|restart|optimize|free_space|warning|skip]\n"
        "TARGET: [process name or service]\n"
        "REASON: [brief explanation]\n"
        "SAFETY: [safe|moderate|dangerous]"
    )
    return prompt


def get_ai_context_aware_fix(issue, issue_type, system_context):
    """Get AI recommendation with full system context."""
    rec = extract_from_issue(issue, issue_type)
    if rec.action != "skip" and system_context.get("total_issues", 0) > 0:
        response = query_ollama(generate_smart_fix_prompt(issue, system_context), timeout=20)
        if response:
            rec = parse_ai_response(response)
    return rec


def parse_ai_response(response):
    """Parse structured AI response into AIRecommendation."""
    if not response or not isinstance(response, str):
        return AIRecommendation()

    rec = AIRecommendation()
    try:
        for line in response.split("\n"):
            line = line.strip()
            if not line or ":" not in line:
                continue
            key, value = line.split(":", 1)
            key = key.strip().upper()
            value = value.strip()
            if key == "ACTION":
                rec.action = value.lower()
            elif key == "TARGET":
                rec.target = value
            elif key == "REASON":
                rec.reason = value
            elif key == "SAFETY":
                rec.safety = value.lower()
    except Exception:
        return AIRecommendation()

    if rec.action not in {"kill", "restart", "optimize", "free_space", "warning", "skip"}:
        rec.action = "skip"
    if rec.safety not in {"safe", "moderate", "dangerous"}:
        rec.safety = "moderate"
    return rec


def extract_from_issue(issue, issue_type):
    """Extract recommendation directly from issue description."""
    il = issue.lower()

    if "memory" in issue_type or "mb ram" in il:
        processes = [p for p in ("chrome", "plasmashell", "firefox", "code", "discord", "spotify") if p in il]
        if processes:
            huge = re.findall(r"(\w+)\s+\(PID\s+\d+\)\s+using\s+(\d+\.?\d*)\s+MB", issue)
            for proc, mem in huge:
                if float(mem) > 700:
                    return AIRecommendation("kill", proc, f"{proc} using {mem}MB RAM", "dangerous")
            return AIRecommendation("optimize", "system", "Multiple high-memory processes", "moderate")

    if "temp" in issue_type or "c" in il:
        temps = re.findall(r"(\d+\.?\d*)C", issue)
        if temps:
            highest = max(float(t) for t in temps)
            if highest > 90:
                return AIRecommendation("warning", "CPU/GPU", f"Critical temperature {highest}C", "safe")
            elif highest > 85:
                return AIRecommendation("warning", "CPU/GPU", f"High temperature {highest}C", "safe")

    if "storage" in issue_type or "space" in issue_type:
        pct = re.findall(r"(\d+\.?\d*)%", issue)
        if pct and float(pct[0]) > 90:
            return AIRecommendation("free_space", "disk", f"Disk {pct[0]}% full", "moderate")

    if "audio" in issue_type or "pulseaudio" in il:
        return AIRecommendation("restart", "PulseAudio", "Audio service not responding", "moderate")

    if "bios" in issue_type or "motherboard" in il:
        return AIRecommendation("warning", "BIOS", "BIOS information - manual review only", "safe")

    return AIRecommendation("skip", "", "No action needed", "safe")


def get_ai_fix(issue, issue_type):
    """Get recommendation — extract from issue, skip AI."""
    return extract_from_issue(issue, issue_type)


# ---------------------------------------------------------------------------
# Verification & confirmation (CLI)
# ---------------------------------------------------------------------------

def verify_fix(issue_type):
    """Verify if fix worked."""
    from sysfixai.core import check_memory, check_storage, check_temperatures, check_audio

    if "memory" in issue_type:
        issues = check_memory()
        return (True, "Memory OK") if not issues or "No issues" in str(issues) else (False, "Memory still high")
    elif "storage" in issue_type:
        issues = check_storage()
        return (True, "Storage OK") if not issues else (False, "Storage still full")
    elif "temp" in issue_type or "temperature" in issue_type:
        issues = check_temperatures()
        return (True, "Temperature OK") if not issues else (False, "Still hot")
    elif "audio" in issue_type:
        issues = check_audio()
        return (True, "Audio OK") if not issues else (False, "Audio still broken")
    return True, "Verified"


def confirm_action(rec):
    """Show recommendation and get confirmation (CLI)."""
    print("\n" + "=" * 60)
    print("AI RECOMMENDATION")
    print("=" * 60)
    print(f"Action: {rec.action.upper()}")
    if rec.target:
        print(f"Target: {rec.target}")
    print(f"Why: {rec.reason}")
    print("\n" + "-" * 60)

    if rec.safety == "dangerous":
        print("DANGEROUS - Type CONFIRM to proceed:")
    else:
        print("Type y to proceed, n to skip:")

    while True:
        choice = input(">> ").strip().lower()
        if choice == "y":
            return True
        elif choice == "n":
            return False
        elif choice == "confirm" and rec.safety == "dangerous":
            return True
        else:
            print("Type CONFIRM or n:" if rec.safety == "dangerous" else "Type y or n:")
