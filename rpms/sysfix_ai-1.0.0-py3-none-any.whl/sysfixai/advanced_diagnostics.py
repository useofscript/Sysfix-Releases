"""
Advanced diagnostics module — predictive maintenance, zombie processes,
kernel optimisation, network self-healing, hardware health scoring,
repository auditing, log pattern analysis, energy profiling, and
data scrubbing.

Every public function returns ``List[str]`` and never raises.
"""

import os
import re
import subprocess
import json
import time
import hashlib
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


# ──────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────

def _run(cmd: List[str], timeout: int = 15) -> str:
    """Run a command quietly, return stdout or empty string."""
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def _run_lines(cmd: List[str], timeout: int = 15) -> List[str]:
    out = _run(cmd, timeout)
    return out.splitlines() if out else []


# ══════════════════════════════════════════════════════════════════════════
#  1.  Predictive Maintenance  (S.M.A.R.T. trend + pre-failure analysis)
# ══════════════════════════════════════════════════════════════════════════

def smart_predictive_analysis() -> List[str]:
    """Analyse S.M.A.R.T. attributes for trend-based failure prediction.

    Goes beyond pass/fail — examines reallocated sectors, wear levelling,
    temperature, power-on hours, and calculates remaining lifespan for NVMe.
    """
    results: List[str] = []
    if not shutil.which("smartctl"):
        results.append("INFO: smartctl not installed — install smartmontools for predictive disk analysis")
        return results

    # Discover block devices
    devs = []
    for line in _run_lines(["lsblk", "-dnpo", "NAME,TYPE"]):
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "disk":
            devs.append(parts[0])

    if not devs:
        results.append("INFO: No block devices found for S.M.A.R.T. analysis")
        return results

    for dev in devs:
        # Get full SMART data (needs sudo)
        raw = _run(["sudo", "smartctl", "-A", "-i", dev], timeout=15)
        if not raw:
            raw = _run(["sudo", "smartctl", "-a", dev], timeout=15)
        if not raw:
            results.append(f"INFO: Could not read S.M.A.R.T. data for {dev}")
            continue

        dev_short = dev.split("/")[-1]
        is_nvme = "NVMe" in raw or "/nvme" in dev

        if is_nvme:
            results.extend(_analyse_nvme(dev_short, raw))
        else:
            results.extend(_analyse_sata(dev_short, raw))

    if not results:
        results.append("All disks look healthy — no predictive warnings.")
    return results


def _analyse_nvme(dev: str, raw: str) -> List[str]:
    """Analyse NVMe SMART data for lifespan, temperature, and wear."""
    findings: List[str] = []

    # Percentage used
    m = re.search(r"Percentage Used:\s*(\d+)%", raw)
    pct_used = int(m.group(1)) if m else None

    # Data units written → TBW
    m = re.search(r"Data Units Written:\s*([\d,]+)", raw)
    tbw = None
    if m:
        units = int(m.group(1).replace(",", ""))
        tbw = units * 512000 / 1e12  # units × 512 KB → TB

    # Power-on hours
    m = re.search(r"Power On Hours:\s*([\d,]+)", raw)
    poh = int(m.group(1).replace(",", "")) if m else None

    # Temperature
    m = re.search(r"Temperature:\s*(\d+)\s*(?:Celsius|C)", raw)
    temp = int(m.group(1)) if m else None

    # Critical warnings
    m = re.search(r"Critical Warning:\s*(0x[0-9a-fA-F]+|\d+)", raw)
    crit = m.group(1) if m else None

    # Report
    header = f"NVMe {dev}:"
    if pct_used is not None:
        if pct_used >= 90:
            findings.append(f"WARN: {header} {pct_used}% lifespan used — SSD nearing end-of-life!")
        elif pct_used >= 70:
            findings.append(f"WARN: {header} {pct_used}% lifespan used — plan replacement within 6-12 months")
        else:
            findings.append(f"OK: {header} {pct_used}% lifespan used")

    if tbw is not None:
        findings.append(f"  Total Written: {tbw:.1f} TB")
        if poh and poh > 0:
            tb_per_month = tbw / (poh / 730)
            findings.append(f"  Write rate: ~{tb_per_month:.2f} TB/month")
            if pct_used is not None and pct_used < 100:
                remaining_pct = 100 - pct_used
                months_left = remaining_pct / max(tb_per_month * 0.7, 0.01)  # rough estimate
                if months_left < 6:
                    findings.append(f"  WARN: Estimated ~{months_left:.0f} months remaining at current write rate")
                else:
                    findings.append(f"  Estimated ~{months_left:.0f} months remaining")

    if temp is not None:
        if temp >= 70:
            findings.append(f"  WARN: Temperature {temp}°C — too hot! Check cooling")
        elif temp >= 55:
            findings.append(f"  Temperature: {temp}°C (warm — monitor)")
        else:
            findings.append(f"  Temperature: {temp}°C (OK)")

    if crit and crit not in ("0", "0x00"):
        findings.append(f"  DANGER: Critical warning flag: {crit} — check immediately!")

    return findings


def _analyse_sata(dev: str, raw: str) -> List[str]:
    """Analyse SATA/SAS SMART attributes for wear indicators."""
    findings: List[str] = []
    header = f"SATA {dev}:"

    # Parse attribute table
    attrs = {}
    for line in raw.splitlines():
        m = re.match(r"\s*(\d+)\s+(\S+)\s+\S+\s+(\d+)\s+(\d+)\s+(\d+)\s+\S+\s+\S+\s+\S+\s+(\d+)", line)
        if m:
            attr_id = int(m.group(1))
            name = m.group(2)
            value = int(m.group(3))
            worst = int(m.group(4))
            thresh = int(m.group(5))
            raw_val = int(m.group(6))
            attrs[attr_id] = {"name": name, "value": value, "worst": worst, "thresh": thresh, "raw": raw_val}

    # Critical attributes to watch
    # 5 = Reallocated_Sector_Ct
    if 5 in attrs and attrs[5]["raw"] > 0:
        ct = attrs[5]["raw"]
        if ct > 100:
            findings.append(f"DANGER: {header} {ct} reallocated sectors — disk is failing!")
        elif ct > 10:
            findings.append(f"WARN: {header} {ct} reallocated sectors — disk degrading, back up now!")
        else:
            findings.append(f"WARN: {header} {ct} reallocated sector(s) detected — monitor closely")

    # 197 = Current_Pending_Sector
    if 197 in attrs and attrs[197]["raw"] > 0:
        findings.append(f"WARN: {header} {attrs[197]['raw']} pending sector(s) — impending failure indicator")

    # 198 = Offline_Uncorrectable
    if 198 in attrs and attrs[198]["raw"] > 0:
        findings.append(f"WARN: {header} {attrs[198]['raw']} uncorrectable sector(s)")

    # 194 = Temperature
    if 194 in attrs:
        temp = attrs[194]["raw"]
        # Raw value sometimes encodes min/max; take lower byte
        temp = temp & 0xFF
        if temp >= 55:
            findings.append(f"WARN: {header} temperature {temp}°C — hot!")
        else:
            findings.append(f"  {header} temperature {temp}°C")

    # 9 = Power_On_Hours
    if 9 in attrs:
        hours = attrs[9]["raw"]
        years = hours / 8760
        if years > 5:
            findings.append(f"  {header} {hours:,} power-on hours ({years:.1f} years) — aging drive")
        else:
            findings.append(f"  {header} {hours:,} power-on hours ({years:.1f} years)")

    # 177/233 = Wear_Leveling_Count (SSDs)
    for wl_id in (177, 233):
        if wl_id in attrs:
            findings.append(f"  {header} wear levelling: {attrs[wl_id]['value']}% remaining")

    if not findings:
        findings.append(f"OK: {header} no concerning S.M.A.R.T. indicators")

    return findings


# ══════════════════════════════════════════════════════════════════════════
#  2.  Zombie Process Hunter
# ══════════════════════════════════════════════════════════════════════════

def zombie_process_hunter() -> List[str]:
    """Find zombie (Z) and uninterruptible-sleep (D) processes.

    Zombies leak PID table entries; D-state processes often indicate
    I/O hangs (dead NFS mount, failing disk).
    """
    results: List[str] = []
    if not HAS_PSUTIL:
        results.append("INFO: psutil not installed — cannot hunt zombies")
        return results

    zombies: List[Dict[str, Any]] = []
    d_state: List[Dict[str, Any]] = []

    for proc in psutil.process_iter(["pid", "name", "status", "ppid", "username", "cpu_percent", "create_time"]):
        try:
            info = proc.info
            if info["status"] == psutil.STATUS_ZOMBIE:
                zombies.append(info)
            elif info["status"] == psutil.STATUS_DISK_SLEEP:
                d_state.append(info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if zombies:
        results.append(f"WARN: {len(zombies)} zombie process(es) found:")
        for z in zombies[:15]:
            age = ""
            if z.get("create_time"):
                age_s = time.time() - z["create_time"]
                age = f", age {timedelta(seconds=int(age_s))}"
            results.append(f"  PID {z['pid']} ({z['name']}) parent={z['ppid']} user={z['username']}{age}")
        if len(zombies) > 15:
            results.append(f"  ... and {len(zombies) - 15} more")
        results.append("  TIP: Kill the parent process to reap zombies (kill -SIGCHLD <ppid>)")
    else:
        results.append("OK: No zombie processes found")

    if d_state:
        results.append(f"WARN: {len(d_state)} process(es) in uninterruptible sleep (D-state):")
        for d in d_state[:10]:
            results.append(f"  PID {d['pid']} ({d['name']}) user={d['username']}")
        results.append("  TIP: D-state usually means I/O hang — check dmesg for disk or NFS errors")

    return results


def kill_zombie_parents() -> List[str]:
    """Send SIGCHLD to parent processes of zombies to reap them."""
    results: List[str] = []
    if not HAS_PSUTIL:
        return ["INFO: psutil not available"]

    import signal
    parents_signaled = set()
    for proc in psutil.process_iter(["pid", "name", "status", "ppid"]):
        try:
            if proc.info["status"] == psutil.STATUS_ZOMBIE:
                ppid = proc.info["ppid"]
                if ppid > 1 and ppid not in parents_signaled:
                    os.kill(ppid, signal.SIGCHLD)
                    parents_signaled.add(ppid)
                    results.append(f"Sent SIGCHLD to PID {ppid} (parent of zombie {proc.info['pid']})")
        except Exception:
            continue

    if parents_signaled:
        results.append(f"Signaled {len(parents_signaled)} parent(s). Re-check in a few seconds.")
    else:
        results.append("No zombies to clean up.")
    return results


# ══════════════════════════════════════════════════════════════════════════
#  3.  Kernel Parameter Optimizer
# ══════════════════════════════════════════════════════════════════════════

def kernel_param_audit() -> List[str]:
    """Audit sysctl parameters and suggest optimisations.

    Compares current values against recommended defaults for desktop/server.
    """
    results: List[str] = []

    # Recommendations: (sysctl key, recommended value, description, comparison)
    # comparison: "ge" = current should be >= rec, "le" = <=, "eq" = ==
    desktop_recs = [
        ("vm.swappiness", 10, "Reduce swap aggressiveness (better for SSDs & desktops)", "le"),
        ("vm.vfs_cache_pressure", 50, "Keep directory/inode caches longer", "le"),
        ("vm.dirty_ratio", 20, "Max dirty pages before forced write-back", "le"),
        ("vm.dirty_background_ratio", 5, "Start background write-back earlier", "le"),
        ("net.core.rmem_max", 16777216, "Max receive socket buffer (16 MB)", "ge"),
        ("net.core.wmem_max", 16777216, "Max send socket buffer (16 MB)", "ge"),
        ("net.core.netdev_max_backlog", 5000, "Network device input queue length", "ge"),
        ("net.ipv4.tcp_fastopen", 3, "Enable TCP Fast Open (client + server)", "ge"),
        ("net.ipv4.tcp_congestion_control", "bbr", "Use BBR congestion control for better throughput", "eq"),
        ("net.ipv4.tcp_mtu_probing", 1, "Enable MTU probing to avoid PMTUD black holes", "ge"),
        ("kernel.sched_autogroup_enabled", 1, "Auto-group processes for desktop responsiveness", "eq"),
        ("fs.inotify.max_user_watches", 524288, "Increase inotify watches (for IDEs, file watchers)", "ge"),
        ("net.ipv4.tcp_slow_start_after_idle", 0, "Disable slow-start after idle (better for bursty traffic)", "eq"),
    ]

    results.append("Kernel parameter audit:")
    optimisations = []
    for key, rec, desc, cmp in desktop_recs:
        try:
            sysctl_path = f"/proc/sys/{key.replace('.', '/')}"
            with open(sysctl_path) as f:
                current_raw = f.read().strip()
            # Numeric or string comparison
            if isinstance(rec, int):
                current = int(current_raw)
                ok = (
                    (cmp == "ge" and current >= rec) or
                    (cmp == "le" and current <= rec) or
                    (cmp == "eq" and current == rec)
                )
                if not ok:
                    optimisations.append((key, current_raw, str(rec), desc))
            else:
                if cmp == "eq" and current_raw != rec:
                    optimisations.append((key, current_raw, rec, desc))
        except Exception:
            continue

    if optimisations:
        results.append(f"  {len(optimisations)} optimisation(s) suggested:")
        for key, cur, rec, desc in optimisations:
            results.append(f"  • {key}: {cur} → {rec}")
            results.append(f"    {desc}")
        results.append("")
        results.append("  Apply temporarily:  sudo sysctl -w key=value")
        results.append("  Apply permanently:  echo 'key=value' | sudo tee -a /etc/sysctl.d/99-sysfix.conf && sudo sysctl -p")
    else:
        results.append("  All checked parameters look good!")

    return results


def apply_kernel_optimisation(key: str, value: str) -> List[str]:
    """Apply a single sysctl parameter (requires sudo)."""
    results: List[str] = []
    try:
        r = subprocess.run(
            ["sudo", "sysctl", "-w", f"{key}={value}"],
            capture_output=True, text=True, timeout=10,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            results.append(f"OK: Applied {key} = {value}")
        else:
            results.append(f"ERROR: Failed to apply {key}: {r.stderr.strip()}")
    except Exception as e:
        results.append(f"ERROR: {e}")
    return results


# ══════════════════════════════════════════════════════════════════════════
#  4.  Network Self-Healing
# ══════════════════════════════════════════════════════════════════════════

def network_self_heal() -> List[str]:
    """Comprehensive network healing: MTU tuning, congestion control,
    DNS audit, ghost interface cleanup, and connectivity repair."""
    results: List[str] = []
    results.extend(check_congestion_control())
    results.extend(check_dns_privacy())
    results.extend(check_ghost_interfaces())
    results.extend(check_mtu_issues())
    return results


def check_congestion_control() -> List[str]:
    """Check and report TCP congestion control algorithm."""
    results: List[str] = []
    try:
        current = _run(["sysctl", "-n", "net.ipv4.tcp_congestion_control"])
        available_raw = _run(["sysctl", "-n", "net.ipv4.tcp_available_congestion_control"])
        available = available_raw.split() if available_raw else []

        if current:
            if current == "bbr":
                results.append(f"OK: TCP congestion control: BBR (optimal)")
            elif "bbr" in available:
                results.append(f"WARN: TCP congestion: {current} — BBR is available and generally better")
                results.append("  TIP: sudo sysctl -w net.ipv4.tcp_congestion_control=bbr")
            else:
                results.append(f"INFO: TCP congestion: {current} (BBR not available on this kernel)")
    except Exception:
        pass
    return results


def check_dns_privacy() -> List[str]:
    """Check if DNS queries might be intercepted (plain DNS vs DoH/DoT)."""
    results: List[str] = []
    try:
        resolv = Path("/etc/resolv.conf").read_text()
        nameservers = re.findall(r"nameserver\s+([\d.:a-fA-F]+)", resolv)

        isp_dns = True
        privacy_dns = {"1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4",
                        "9.9.9.9", "149.112.112.112", "208.67.222.222",
                        "208.67.220.220", "127.0.0.1", "::1"}

        for ns in nameservers:
            if ns in privacy_dns:
                isp_dns = False

        if nameservers:
            results.append(f"DNS servers: {', '.join(nameservers)}")
            if isp_dns and "127.0.0.53" not in nameservers:
                results.append("WARN: Using ISP DNS — queries may be logged or hijacked")
                results.append("  TIP: Consider Cloudflare (1.1.1.1), Google (8.8.8.8), or Quad9 (9.9.9.9)")

        # Check for systemd-resolved DoT
        resolved_conf = Path("/etc/systemd/resolved.conf")
        if resolved_conf.exists():
            conf = resolved_conf.read_text()
            if "DNSOverTLS=yes" in conf or "DNSOverTLS=opportunistic" in conf:
                results.append("OK: DNS-over-TLS is enabled via systemd-resolved")
            else:
                results.append("INFO: DNS-over-TLS not enabled in systemd-resolved")
                results.append("  TIP: Set DNSOverTLS=opportunistic in /etc/systemd/resolved.conf")
    except Exception:
        pass
    return results


def check_ghost_interfaces() -> List[str]:
    """Detect zombie/ghost network interfaces (orphaned Docker, VPN, etc.)."""
    results: List[str] = []
    if not HAS_PSUTIL:
        return results

    ghost_prefixes = ("veth", "br-", "docker", "virbr", "tun", "tap", "wg")
    try:
        ifaces = psutil.net_if_stats()
        addrs = psutil.net_if_addrs()
        ghosts = []

        for name, stats in ifaces.items():
            if any(name.startswith(p) for p in ghost_prefixes):
                if not stats.isup:
                    ghosts.append((name, "down"))
                elif name.startswith("veth"):
                    # veth without a running container is a ghost
                    ghosts.append((name, "up but possibly orphaned"))

        if ghosts:
            results.append(f"WARN: {len(ghosts)} potential ghost interface(s):")
            for name, status in ghosts[:10]:
                results.append(f"  {name} ({status})")
            results.append("  TIP: Clean up with: sudo ip link delete <interface>")
        else:
            results.append("OK: No ghost network interfaces detected")
    except Exception:
        pass
    return results


def check_mtu_issues() -> List[str]:
    """Check for MTU mismatches that can cause silent packet drops."""
    results: List[str] = []
    if not HAS_PSUTIL:
        return results

    try:
        ifaces = psutil.net_if_stats()
        for name, stats in ifaces.items():
            if not stats.isup or name == "lo":
                continue
            if stats.mtu < 1280:
                results.append(f"WARN: {name} MTU={stats.mtu} — below IPv6 minimum (1280)")
            elif stats.mtu > 1500 and not name.startswith(("docker", "br-", "virbr")):
                results.append(f"INFO: {name} MTU={stats.mtu} — jumbo frames enabled")

        # Test PMTUD with a ping
        r = subprocess.run(
            ["ping", "-c", "1", "-M", "do", "-s", "1472", "8.8.8.8"],
            capture_output=True, text=True, timeout=10,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode != 0:
            results.append("WARN: PMTU test failed — packets >1500 bytes may be silently dropped")
            results.append("  TIP: Enable MTU probing: sudo sysctl -w net.ipv4.tcp_mtu_probing=1")
    except Exception:
        pass
    return results


def apply_bbr() -> List[str]:
    """Enable BBR congestion control (requires sudo)."""
    results: List[str] = []
    available = _run(["sysctl", "-n", "net.ipv4.tcp_available_congestion_control"])
    if "bbr" not in (available or ""):
        results.append("ERROR: BBR not available on this kernel")
        return results

    r1 = _run(["sudo", "sysctl", "-w", "net.ipv4.tcp_congestion_control=bbr"])
    r2 = _run(["sudo", "sysctl", "-w", "net.core.default_qdisc=fq"])
    if r1 and r2:
        results.append("OK: BBR congestion control enabled")
        results.append("  For persistence: add to /etc/sysctl.d/99-sysfix-network.conf")
    else:
        results.append("ERROR: Failed to enable BBR (need sudo?)")
    return results


# ══════════════════════════════════════════════════════════════════════════
#  5.  Hardware Health Score
# ══════════════════════════════════════════════════════════════════════════

def hardware_health_score() -> List[str]:
    """Compute a comprehensive hardware health score (0-100).

    Categories: CPU thermal, RAM usage, disk health, battery, fan status.
    """
    results: List[str] = []
    if not HAS_PSUTIL:
        results.append("INFO: psutil required for hardware health score")
        return results

    scores: Dict[str, int] = {}
    details: Dict[str, str] = {}

    # CPU thermal
    try:
        temps = psutil.sensors_temperatures()
        if temps:
            max_temp = 0
            for name, entries in temps.items():
                for e in entries:
                    if e.current > max_temp:
                        max_temp = e.current
            if max_temp > 0:
                if max_temp < 50:
                    scores["thermal"] = 100
                elif max_temp < 70:
                    scores["thermal"] = int(100 - (max_temp - 50) * 2)
                elif max_temp < 85:
                    scores["thermal"] = int(60 - (max_temp - 70) * 3)
                else:
                    scores["thermal"] = max(0, int(15 - (max_temp - 85) * 2))
                details["thermal"] = f"{max_temp:.0f}°C"
    except Exception:
        pass

    # RAM pressure
    try:
        mem = psutil.virtual_memory()
        pct_used = mem.percent
        if pct_used < 60:
            scores["memory"] = 100
        elif pct_used < 80:
            scores["memory"] = int(100 - (pct_used - 60) * 2.5)
        elif pct_used < 95:
            scores["memory"] = int(50 - (pct_used - 80) * 3)
        else:
            scores["memory"] = max(0, int(5 - (pct_used - 95)))
        details["memory"] = f"{pct_used:.0f}% used ({mem.used // (1024**3)}/{mem.total // (1024**3)} GB)"
    except Exception:
        pass

    # CPU load
    try:
        load1, load5, load15 = psutil.getloadavg()
        cores = psutil.cpu_count() or 1
        load_ratio = load5 / cores
        if load_ratio < 0.5:
            scores["cpu_load"] = 100
        elif load_ratio < 1.0:
            scores["cpu_load"] = int(100 - (load_ratio - 0.5) * 80)
        elif load_ratio < 2.0:
            scores["cpu_load"] = int(60 - (load_ratio - 1.0) * 40)
        else:
            scores["cpu_load"] = max(0, int(20 - (load_ratio - 2.0) * 10))
        details["cpu_load"] = f"load {load5:.1f} / {cores} cores (ratio {load_ratio:.2f})"
    except Exception:
        pass

    # Disk usage
    try:
        disk = psutil.disk_usage("/")
        pct = disk.percent
        if pct < 70:
            scores["disk"] = 100
        elif pct < 85:
            scores["disk"] = int(100 - (pct - 70) * 4)
        elif pct < 95:
            scores["disk"] = int(40 - (pct - 85) * 3)
        else:
            scores["disk"] = max(0, int(10 - (pct - 95) * 2))
        details["disk"] = f"{pct:.0f}% used ({disk.free // (1024**3)} GB free)"
    except Exception:
        pass

    # Battery health
    try:
        bat = psutil.sensors_battery()
        if bat:
            if bat.percent > 30:
                scores["battery"] = min(100, bat.percent)
            else:
                scores["battery"] = max(0, bat.percent)
            plugged = "plugged in" if bat.power_plugged else "on battery"
            secs = bat.secsleft
            time_str = ""
            if secs and secs > 0 and not bat.power_plugged:
                time_str = f", ~{secs // 3600}h{(secs % 3600) // 60}m left"
            details["battery"] = f"{bat.percent}% ({plugged}{time_str})"
    except Exception:
        pass

    # Fan status
    try:
        fans = psutil.sensors_fans()
        if fans:
            max_rpm = 0
            for name, entries in fans.items():
                for e in entries:
                    if e.current > max_rpm:
                        max_rpm = e.current
            if max_rpm > 0:
                if max_rpm < 2000:
                    scores["fans"] = 100
                elif max_rpm < 4000:
                    scores["fans"] = int(100 - (max_rpm - 2000) / 40)
                else:
                    scores["fans"] = max(20, int(50 - (max_rpm - 4000) / 100))
                details["fans"] = f"{max_rpm} RPM max"
    except Exception:
        pass

    # Overall score
    if scores:
        overall = sum(scores.values()) // len(scores)
        if overall >= 85:
            grade = "Excellent"
            icon = "🟢"
        elif overall >= 70:
            grade = "Good"
            icon = "🟢"
        elif overall >= 50:
            grade = "Fair"
            icon = "🟡"
        elif overall >= 30:
            grade = "Poor"
            icon = "🟠"
        else:
            grade = "Critical"
            icon = "🔴"

        results.append(f"Hardware Health Score: {overall}/100 — {grade} {icon}")
        results.append("")
        for cat, score in sorted(scores.items(), key=lambda x: x[1]):
            detail = details.get(cat, "")
            bar = "█" * (score // 10) + "░" * (10 - score // 10)
            results.append(f"  {cat:<12} [{bar}] {score:>3}/100  {detail}")
    else:
        results.append("INFO: Could not compute hardware health score")

    return results


# ══════════════════════════════════════════════════════════════════════════
#  6.  Repository & Dependency Auditing
# ══════════════════════════════════════════════════════════════════════════

def repo_audit() -> List[str]:
    """Audit package repositories and detect orphaned packages / conflicts."""
    results: List[str] = []

    # Detect package manager
    pm = _detect_package_manager()
    if not pm:
        results.append("INFO: Could not detect package manager")
        return results

    results.append(f"Package manager: {pm}")

    if pm == "dnf":
        results.extend(_audit_dnf())
    elif pm == "apt":
        results.extend(_audit_apt())
    elif pm == "pacman":
        results.extend(_audit_pacman())

    return results


def _detect_package_manager() -> str:
    for pm in ("dnf", "apt", "pacman"):
        if shutil.which(pm):
            return pm
    return ""


def _audit_dnf() -> List[str]:
    results: List[str] = []

    # Check for orphaned packages
    orphans = _run_lines(["dnf", "list", "--extras", "-q"], timeout=30)
    if orphans:
        # Filter header lines
        pkgs = [l for l in orphans if not l.startswith("Extra") and l.strip()]
        if pkgs:
            results.append(f"WARN: {len(pkgs)} extra/orphaned package(s):")
            for p in pkgs[:10]:
                results.append(f"  {p.split()[0] if p.split() else p}")
            if len(pkgs) > 10:
                results.append(f"  ... and {len(pkgs) - 10} more")

    # Check for duplicate packages
    dupes = _run_lines(["dnf", "list", "--duplicates", "-q"], timeout=30)
    if dupes:
        pkgs = [l for l in dupes if not l.startswith("Installed") and l.strip()]
        if pkgs:
            results.append(f"WARN: {len(pkgs)} duplicate package version(s) installed")

    # Check repo health
    repos = _run_lines(["dnf", "repolist", "--enabled", "-q"], timeout=15)
    if repos:
        results.append(f"Enabled repos: {len(repos)}")

    # Check for broken deps
    broken = _run(["dnf", "check", "-q"], timeout=30)
    if broken:
        results.append(f"WARN: Dependency issues detected:\n  {broken[:300]}")
    else:
        results.append("OK: No dependency issues found")

    return results


def _audit_apt() -> List[str]:
    results: List[str] = []

    # Orphaned packages
    orphans = _run_lines(["apt", "list", "--installed", "-qq"], timeout=30)

    # Check for broken packages
    broken = _run(["dpkg", "--audit"], timeout=15)
    if broken:
        results.append(f"WARN: Package integrity issues:\n  {broken[:300]}")
    else:
        results.append("OK: dpkg audit clean")

    # Check for obsolete PPAs
    sources_dir = Path("/etc/apt/sources.list.d")
    if sources_dir.exists():
        ppas = list(sources_dir.glob("*.list")) + list(sources_dir.glob("*.sources"))
        if ppas:
            results.append(f"APT sources: {len(ppas)} third-party source(s)")
            for ppa in ppas:
                results.append(f"  {ppa.name}")

    # Autoremovable
    auto = _run(["apt", "list", "--autoremovable", "-qq"], timeout=15)
    if auto:
        count = len(auto.splitlines())
        results.append(f"INFO: {count} auto-removable package(s) — run 'sudo apt autoremove'")

    return results


def _audit_pacman() -> List[str]:
    results: List[str] = []

    # Orphaned packages
    orphans = _run_lines(["pacman", "-Qdtq"], timeout=15)
    if orphans:
        results.append(f"WARN: {len(orphans)} orphaned package(s):")
        for o in orphans[:10]:
            results.append(f"  {o}")

    # Foreign packages (AUR, manual)
    foreign = _run_lines(["pacman", "-Qmq"], timeout=15)
    if foreign:
        results.append(f"INFO: {len(foreign)} foreign/AUR package(s)")

    # Check integrity
    broken = _run(["pacman", "-Dk", "-q"], timeout=30)
    if broken and "no errors" not in broken.lower():
        results.append(f"WARN: Package integrity issues: {broken[:200]}")

    return results


# ══════════════════════════════════════════════════════════════════════════
#  7.  Log Pattern Analysis (pre-failure detection)
# ══════════════════════════════════════════════════════════════════════════

def log_pattern_analysis() -> List[str]:
    """Scan system logs for pre-failure warning patterns.

    Looks for: ECC memory errors, filesystem retries, disk I/O errors,
    thermal throttling, OOM events, segfaults, kernel panics, GPU errors.
    """
    results: List[str] = []

    # Patterns to search for in journal (last 24h)
    patterns = [
        ("Hardware Error|Machine Check|mce:|EDAC", "Hardware/ECC memory error", "danger"),
        ("I/O error|Buffer I/O error|blk_update_request", "Disk I/O error", "danger"),
        ("EXT4-fs error|XFS.*error|btrfs.*error|filesystem.*error", "Filesystem error", "danger"),
        ("thermal.*throttl|CPU.*throttl|temperature above threshold", "Thermal throttling", "warn"),
        ("Out of memory|oom-killer|oom_reaper", "Out-of-memory event", "warn"),
        ("segfault|general protection fault", "Application crash / segfault", "warn"),
        ("kernel panic|BUG:|Oops:", "Kernel error", "danger"),
        ("GPU.*hang|gpu.*error|drm.*error|amdgpu.*error|nouveau.*error|i915.*error", "GPU error", "warn"),
        ("ACPI.*error|ACPI.*warn", "ACPI / power management error", "info"),
        ("USB.*disconnect|usb.*error|xhci.*error", "USB error", "info"),
        ("link is not ready|carrier lost|link down", "Network link failure", "warn"),
        ("audit.*denied|apparmor.*DENIED|SELinux.*denied", "Security policy denial", "info"),
    ]

    for pattern, desc, level in patterns:
        try:
            r = subprocess.run(
                ["journalctl", "--since", "24 hours ago", "--no-pager",
                 "-g", pattern, "-q", "--output", "short-monotonic"],
                capture_output=True, text=True, timeout=15,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0 and r.stdout.strip():
                lines = r.stdout.strip().splitlines()
                count = len(lines)
                prefix = "DANGER" if level == "danger" else ("WARN" if level == "warn" else "INFO")

                if count > 0:
                    results.append(f"{prefix}: {desc} — {count} occurrence(s) in last 24h")
                    # Show last 3 entries
                    for entry in lines[-3:]:
                        # Trim to reasonable length
                        results.append(f"  {entry[:120]}")
        except Exception:
            continue

    if not results:
        results.append("OK: No concerning log patterns detected in last 24 hours")

    return results


# ══════════════════════════════════════════════════════════════════════════
#  8.  Data Scrubbing (PII masking)
# ══════════════════════════════════════════════════════════════════════════

_PII_PATTERNS = [
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"), "[EMAIL]"),
    (re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"), "[IPv4]"),
    (re.compile(r"\b([0-9a-fA-F]{1,4}:){3,7}[0-9a-fA-F]{1,4}\b"), "[IPv6]"),
    (re.compile(r"\b([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b"), "[MAC]"),
    (re.compile(r"/home/[a-zA-Z0-9._-]+"), "/home/[USER]"),
    (re.compile(r"user\s*=\s*[a-zA-Z0-9._-]+", re.IGNORECASE), "user=[USER]"),
    (re.compile(r"\bpassw(?:ord|d)\s*[:=]\s*\S+", re.IGNORECASE), "password=[REDACTED]"),
    (re.compile(r"\b(ssh-rsa|ssh-ed25519|ecdsa-sha2-nistp\d+)\s+\S+"), r"\1 [KEY_REDACTED]"),
    (re.compile(r"\bsk-[A-Za-z0-9_-]{20,}"), "[API_KEY]"),
    (re.compile(r"\bghp_[A-Za-z0-9]{36,}"), "[GITHUB_TOKEN]"),
    (re.compile(r"\bAIza[A-Za-z0-9_-]{35}"), "[GOOGLE_API_KEY]"),
]


def scrub_pii(text: str) -> str:
    """Remove personally identifiable information from text.

    Masks: emails, IPs, MACs, home paths, passwords, SSH keys, API tokens.
    """
    for pattern, replacement in _PII_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def scrub_log_lines(lines: List[str]) -> List[str]:
    """Scrub PII from a list of log lines."""
    return [scrub_pii(line) for line in lines]


# ══════════════════════════════════════════════════════════════════════════
#  9.  Config Versioning & Rollback
# ══════════════════════════════════════════════════════════════════════════

_CONFIG_REPO = Path.home() / ".config" / "sysfix" / "config_history"


def config_snapshot(filepath: str, label: str = "") -> List[str]:
    """Create a versioned snapshot of a config file before modification.

    Stores timestamped copies in ~/.config/sysfix/config_history/.
    """
    results: List[str] = []
    src = Path(filepath)
    if not src.exists():
        results.append(f"WARN: File not found: {filepath}")
        return results

    _CONFIG_REPO.mkdir(parents=True, exist_ok=True)

    # Create safe filename
    safe_name = src.name.replace("/", "_")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    label_safe = re.sub(r"[^a-zA-Z0-9_-]", "", label)[:30] if label else "snapshot"
    dest = _CONFIG_REPO / f"{safe_name}.{ts}.{label_safe}"

    try:
        import shutil as _sh
        _sh.copy2(str(src), str(dest))

        # Write metadata
        meta = {
            "original": str(src),
            "snapshot": str(dest),
            "timestamp": ts,
            "label": label,
            "size": src.stat().st_size,
            "checksum": hashlib.sha256(src.read_bytes()).hexdigest(),
        }
        meta_path = dest.with_suffix(dest.suffix + ".meta.json")
        meta_path.write_text(json.dumps(meta, indent=2))

        results.append(f"OK: Snapshot saved → {dest.name}")
    except Exception as e:
        results.append(f"ERROR: Could not create snapshot: {e}")
    return results


def list_snapshots(filename: str = "") -> List[Dict[str, Any]]:
    """List all config snapshots, optionally filtered by filename."""
    snapshots = []
    if not _CONFIG_REPO.exists():
        return snapshots

    for meta_file in sorted(_CONFIG_REPO.glob("*.meta.json"), reverse=True):
        try:
            meta = json.loads(meta_file.read_text())
            if filename and filename not in meta.get("original", ""):
                continue
            snapshots.append(meta)
        except Exception:
            continue
    return snapshots


def rollback_config(snapshot_path: str) -> List[str]:
    """Restore a config file from a snapshot."""
    results: List[str] = []
    snap = Path(snapshot_path)
    meta_path = snap.with_suffix(snap.suffix + ".meta.json")

    if not snap.exists():
        results.append(f"ERROR: Snapshot not found: {snapshot_path}")
        return results

    try:
        meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
        original = meta.get("original", "")
        if not original:
            results.append("ERROR: Cannot determine original file path from metadata")
            return results

        # Snapshot the current version first (safety net)
        config_snapshot(original, label="pre-rollback")

        # Restore
        import shutil as _sh
        _sh.copy2(str(snap), original)
        results.append(f"OK: Restored {original} from {snap.name}")
    except Exception as e:
        results.append(f"ERROR: Rollback failed: {e}")
    return results


# ══════════════════════════════════════════════════════════════════════════
#  10.  Brain Export / Import
# ══════════════════════════════════════════════════════════════════════════

def export_brain(dest_path: str = "") -> List[str]:
    """Export the entire brain to a portable JSON file.

    Includes: brain.json, settings.json, and metadata.
    """
    results: List[str] = []
    brain_dir = Path.home() / ".config" / "sysfix"
    brain_file = brain_dir / "brain.json"
    settings_file = brain_dir / "settings.json"

    if not dest_path:
        dest_path = str(Path.home() / f"sysfix-brain-export-{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")

    export_data: Dict[str, Any] = {
        "export_version": 1,
        "exported_at": datetime.now().isoformat(),
        "hostname": os.uname().nodename,
    }

    # Brain data
    if brain_file.exists():
        try:
            export_data["brain"] = json.loads(brain_file.read_text())
        except Exception as e:
            results.append(f"WARN: Could not read brain: {e}")

    # Settings (scrub sensitive keys)
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text())
            # Remove secrets
            for key in list(settings.keys()):
                if "key" in key.lower() or "token" in key.lower() or "password" in key.lower():
                    settings[key] = ""
            export_data["settings"] = settings
        except Exception:
            pass

    try:
        Path(dest_path).write_text(json.dumps(export_data, indent=2, default=str))
        results.append(f"OK: Brain exported to {dest_path}")
        size_kb = Path(dest_path).stat().st_size / 1024
        results.append(f"  Size: {size_kb:.1f} KB")
    except Exception as e:
        results.append(f"ERROR: Export failed: {e}")

    return results


def import_brain(src_path: str, merge: bool = True) -> List[str]:
    """Import a brain export into the current system.

    Args:
        src_path: Path to the exported JSON file.
        merge:    If True, merge with existing brain. If False, replace entirely.
    """
    results: List[str] = []
    brain_dir = Path.home() / ".config" / "sysfix"
    brain_file = brain_dir / "brain.json"

    try:
        import_data = json.loads(Path(src_path).read_text())
    except Exception as e:
        results.append(f"ERROR: Could not read import file: {e}")
        return results

    if "brain" not in import_data:
        results.append("ERROR: No brain data found in import file")
        return results

    # Back up current brain first
    if brain_file.exists():
        config_snapshot(str(brain_file), label="pre-import")
        results.append("Backed up current brain before import")

    try:
        if merge and brain_file.exists():
            current = json.loads(brain_file.read_text())
            imported = import_data["brain"]

            # Merge: combine observations, solutions, insights
            for key in ("observations", "solutions", "insights"):
                if key in imported:
                    if key not in current:
                        current[key] = []
                    if isinstance(current[key], list) and isinstance(imported[key], list):
                        # Deduplicate by string representation
                        existing = {json.dumps(x, sort_keys=True) for x in current[key]}
                        for item in imported[key]:
                            if json.dumps(item, sort_keys=True) not in existing:
                                current[key].append(item)

            # Merge key-value categories
            for key in ("hardware", "software", "preferences", "projects"):
                if key in imported:
                    if key not in current:
                        current[key] = {}
                    if isinstance(current[key], dict) and isinstance(imported[key], dict):
                        current[key].update(imported[key])

            brain_file.write_text(json.dumps(current, indent=2, default=str))
            results.append("OK: Brain merged successfully")
        else:
            brain_file.write_text(json.dumps(import_data["brain"], indent=2, default=str))
            results.append("OK: Brain replaced with import data")

        # Optionally import settings (non-destructive merge)
        if "settings" in import_data:
            results.append(f"INFO: Import contains settings from {import_data.get('hostname', 'unknown')} — use Settings tab to apply")

        results.append(f"Source: {import_data.get('hostname', 'unknown')} @ {import_data.get('exported_at', '?')}")
    except Exception as e:
        results.append(f"ERROR: Import failed: {e}")

    return results


# ══════════════════════════════════════════════════════════════════════════
#  11.  Energy / Battery Optimiser
# ══════════════════════════════════════════════════════════════════════════

def energy_profile() -> List[str]:
    """Analyse current power usage and suggest optimisations."""
    results: List[str] = []
    if not HAS_PSUTIL:
        results.append("INFO: psutil required for energy profiling")
        return results

    # Battery status
    try:
        bat = psutil.sensors_battery()
        if bat:
            plugged = "AC power" if bat.power_plugged else "battery"
            results.append(f"Power source: {plugged} ({bat.percent}%)")
            if bat.secsleft and bat.secsleft > 0 and not bat.power_plugged:
                h = bat.secsleft // 3600
                m = (bat.secsleft % 3600) // 60
                results.append(f"  Estimated time remaining: {h}h {m}m")
        else:
            results.append("Power: Desktop (no battery detected)")
    except Exception:
        pass

    # CPU governor
    try:
        governors = set()
        for cpu_dir in Path("/sys/devices/system/cpu/").glob("cpu[0-9]*"):
            gov_file = cpu_dir / "cpufreq" / "scaling_governor"
            if gov_file.exists():
                governors.add(gov_file.read_text().strip())
        if governors:
            gov_str = ", ".join(governors)
            results.append(f"CPU governor: {gov_str}")
            if "performance" in governors:
                try:
                    bat = psutil.sensors_battery()
                    if bat and not bat.power_plugged:
                        results.append("  WARN: 'performance' governor on battery — consider 'powersave'")
                        results.append("  TIP: sudo cpupower frequency-set -g powersave")
                except Exception:
                    pass
    except Exception:
        pass

    # Top power consumers (by CPU usage)
    try:
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent"]):
            try:
                if p.info["cpu_percent"] and p.info["cpu_percent"] > 5:
                    procs.append(p.info)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        if procs:
            procs.sort(key=lambda x: x["cpu_percent"], reverse=True)
            results.append(f"Top power consumers ({len(procs)} active):")
            for p in procs[:5]:
                results.append(f"  PID {p['pid']} {p['name']}: {p['cpu_percent']:.1f}% CPU")
    except Exception:
        pass

    # Display brightness (if available)
    try:
        bl_dir = Path("/sys/class/backlight")
        if bl_dir.exists():
            for bl in bl_dir.iterdir():
                cur = int((bl / "brightness").read_text().strip())
                maxb = int((bl / "max_brightness").read_text().strip())
                pct = (cur / maxb * 100) if maxb > 0 else 0
                results.append(f"Display brightness: {pct:.0f}% ({bl.name})")
                if pct > 70:
                    results.append("  TIP: Reducing brightness saves significant battery")
    except Exception:
        pass

    # TLP / power-profiles-daemon status
    if shutil.which("powerprofilesctl"):
        profile = _run(["powerprofilesctl", "get"])
        if profile:
            results.append(f"Power profile: {profile}")
    elif shutil.which("tlp-stat"):
        mode = _run(["tlp-stat", "-s"])
        if mode and "Mode" in mode:
            for line in mode.splitlines():
                if "Mode" in line:
                    results.append(f"TLP: {line.strip()}")
                    break

    # Suggestions
    try:
        bat = psutil.sensors_battery()
        if bat and not bat.power_plugged and bat.percent < 30:
            results.append("")
            results.append("⚡ LOW BATTERY TIPS:")
            results.append("  • Reduce screen brightness")
            results.append("  • Close unused browser tabs")
            results.append("  • Switch to powersave governor")
            results.append("  • Disable Bluetooth/Wi-Fi if not needed")
    except Exception:
        pass

    if not results:
        results.append("Energy profiling: no data available")
    return results


# ══════════════════════════════════════════════════════════════════════════
#  12.  Snapshot / Rollback (Timeshift / Snapper integration)
# ══════════════════════════════════════════════════════════════════════════

def check_snapshot_support() -> Dict[str, Any]:
    """Detect available snapshot tools and filesystem support."""
    info: Dict[str, Any] = {
        "available": False,
        "tool": None,
        "filesystem": None,
    }

    # Check filesystem
    try:
        r = subprocess.run(
            ["stat", "-f", "-c", "%T", "/"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            fs = r.stdout.strip()
            info["filesystem"] = fs
    except Exception:
        pass

    # Check for snapshot tools
    if shutil.which("timeshift"):
        info["tool"] = "timeshift"
        info["available"] = True
    elif shutil.which("snapper"):
        info["tool"] = "snapper"
        info["available"] = True

    # Btrfs native
    if info.get("filesystem") in ("btrfs",):
        if shutil.which("btrfs"):
            if not info["tool"]:
                info["tool"] = "btrfs"
                info["available"] = True

    return info


def create_system_snapshot(label: str = "sysfix-auto") -> List[str]:
    """Create a system snapshot using the best available tool."""
    results: List[str] = []
    support = check_snapshot_support()

    if not support["available"]:
        results.append("WARN: No snapshot tool available (install timeshift or snapper)")
        results.append("  Falling back to config-file-only snapshots")
        return results

    tool = support["tool"]
    if tool == "timeshift":
        r = _run(["sudo", "timeshift", "--create", f"--comments", f"Sysfix: {label}"], timeout=120)
        if r:
            results.append(f"OK: Timeshift snapshot created: {label}")
        else:
            results.append("ERROR: Timeshift snapshot failed (need sudo?)")
    elif tool == "snapper":
        r = _run(["sudo", "snapper", "create", "-d", f"Sysfix: {label}", "-t", "single"], timeout=60)
        if r or True:  # snapper may return empty on success
            results.append(f"OK: Snapper snapshot created: {label}")
    elif tool == "btrfs":
        snap_dir = Path("/.snapshots/sysfix")
        snap_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        snap_path = snap_dir / f"{label}_{ts}"
        r = _run(["sudo", "btrfs", "subvolume", "snapshot", "/", str(snap_path)], timeout=60)
        if r:
            results.append(f"OK: Btrfs snapshot created: {snap_path}")
        else:
            results.append("ERROR: Btrfs snapshot failed")

    return results


# ══════════════════════════════════════════════════════════════════════════
#  Summary — run all advanced diagnostics
# ══════════════════════════════════════════════════════════════════════════

def advanced_diagnostics_full() -> List[str]:
    """Run all advanced diagnostic checks and return a unified report."""
    results: List[str] = []

    sections = [
        ("Hardware Health Score", hardware_health_score),
        ("Predictive Disk Analysis", smart_predictive_analysis),
        ("Zombie Process Hunter", zombie_process_hunter),
        ("Kernel Optimisation Audit", kernel_param_audit),
        ("Network Self-Healing", network_self_heal),
        ("Log Pattern Analysis", log_pattern_analysis),
        ("Repository Audit", repo_audit),
        ("Energy Profile", energy_profile),
    ]

    for title, func in sections:
        results.append(f"\n{'─' * 50}")
        results.append(f"  {title}")
        results.append(f"{'─' * 50}")
        try:
            results.extend(func())
        except Exception as e:
            results.append(f"ERROR: {title} failed: {e}")

    return results
