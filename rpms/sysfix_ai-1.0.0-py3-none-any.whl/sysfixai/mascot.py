"""
This module handles loading or generating the mascot images.
Users can provide custom PNG files in the assets folder, or the system will generate placeholders.
"""

from pathlib import Path


def find_custom_mascot(output_path=None):
    """Find any custom PNG in the assets folder (looks for any .png file)."""
    if output_path is None:
        output_path = Path(__file__).parent.parent / "assets"
    else:
        output_path = Path(output_path)
    
    # Look for any PNG file (user's custom mascot)
    png_files = list(output_path.glob("*.png"))
    # Filter out the generated ones we create
    custom_files = [f for f in png_files if f.name not in ['icon_64.png', 'icon_128.png', 'icon_256.png', 'logo.png']]
    
    if custom_files:
        return custom_files[0]  # Return the first custom PNG found
    return None


def mascot_files_exist(output_path=None):
    """Check if mascot files already exist (either custom or generated)."""
    if output_path is None:
        output_path = Path(__file__).parent.parent / "assets"
    else:
        output_path = Path(output_path)
    
    required_files = ['icon_64.png', 'icon_128.png', 'icon_256.png', 'logo.png']
    return all((output_path / filename).exists() for filename in required_files)


def load_or_generate_mascot(output_path=None):
    """
    Load custom mascot PNG and resize it, or generate placeholders.
    
    Users can provide a custom PNG file (any name) in the assets folder.
    The system will automatically resize it to all required sizes.
    
    If no custom PNG is found, generates the placeholder robot mascot.
    """
    if output_path is None:
        output_path = Path(__file__).parent.parent / "assets"
    else:
        output_path = Path(output_path)
    
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Check for custom mascot PNG
    custom_png = find_custom_mascot(output_path)
    
    if custom_png:
        print(f"Found custom mascot: {custom_png.name}")
        return _process_custom_mascot(custom_png, output_path)
    
    # Check if generated mascots already exist
    if mascot_files_exist(output_path):
        print("Using existing mascot images from assets folder")
        return output_path / 'logo.png'
    
    # Generate placeholder mascot images
    print("Generating placeholder mascot images...")
    return _generate_placeholder_mascot(output_path)


def _process_custom_mascot(custom_png, output_path):
    """
    Load a custom PNG and resize it to all required sizes.
    """
    try:
        from PIL import Image
        
        # Load the custom image
        original = Image.open(custom_png)
        print(f"Loaded custom mascot: {original.size}")
        
        # Define target sizes
        sizes = {
            'icon_64.png': 64,
            'icon_128.png': 128,
            'icon_256.png': 256,
            'logo.png': 256,
        }
        
        # Resize and save at each size
        for filename, size in sizes.items():
            # Resize with high-quality resampling
            resized = original.resize((size, size), Image.Resampling.LANCZOS)
            filepath = output_path / filename
            resized.save(filepath, 'PNG')
            print(f"Created: {filepath}")
        
        print(f"Custom mascot processed successfully!")
        return output_path / 'logo.png'
        
    except Exception as e:
        print(f"Error processing custom mascot: {e}")
        print("Falling back to placeholder generation...")
        return _generate_placeholder_mascot(output_path)


def save_mascot(output_path=None):
    """
    Alias for load_or_generate_mascot for backward compatibility.
    """
    return load_or_generate_mascot(output_path)


def _generate_placeholder_mascot(output_path):
    """Generate placeholder robot mascot images."""
    # Create the mascot with PIL
    try:
        from PIL import Image, ImageDraw
        
        sizes = {
            'icon_64.png': 64,
            'icon_128.png': 128,
            'icon_256.png': 256,
            'logo.png': 256,
        }
        
        for filename, size in sizes.items():
            img = Image.new('RGB', (size, size), color=(240, 240, 245))  # Light background
            draw = ImageDraw.Draw(img)
            
            center_x = size // 2
            center_y = size // 2
            
            # Head - rounded circle
            head_radius = int(size * 0.20)
            head_color = (220, 220, 235)  # Light blue-gray
            draw.ellipse(
                [(center_x - head_radius, center_y - int(head_radius * 0.8)),
                 (center_x + head_radius, center_y + head_radius)],
                fill=head_color,
                outline=(100, 100, 150),
                width=max(1, int(size * 0.01))
            )
            
            # Left bunny ear
            ear_width = int(size * 0.08)
            ear_height = int(size * 0.18)
            left_ear_x = int(center_x - head_radius * 0.7)
            ear_top = int(center_y - head_radius * 1.1)
            draw.ellipse(
                [(left_ear_x - ear_width//2, ear_top),
                 (left_ear_x + ear_width//2, ear_top + ear_height)],
                fill=head_color,
                outline=(100, 100, 150),
                width=max(1, int(size * 0.01))
            )
            
            # Right bunny ear
            right_ear_x = int(center_x + head_radius * 0.7)
            draw.ellipse(
                [(right_ear_x - ear_width//2, ear_top),
                 (right_ear_x + ear_width//2, ear_top + ear_height)],
                fill=head_color,
                outline=(100, 100, 150),
                width=max(1, int(size * 0.01))
            )
            
            # Left eye - large blue
            eye_radius = int(size * 0.09)
            left_eye_x = int(center_x - head_radius * 0.5)
            eye_y = int(center_y - head_radius * 0.3)
            draw.ellipse(
                [(left_eye_x - eye_radius, eye_y - eye_radius),
                 (left_eye_x + eye_radius, eye_y + eye_radius)],
                fill=(100, 180, 255),  # Bright blue
                outline=(50, 100, 200),
                width=max(1, int(size * 0.01))
            )
            
            # Left pupil
            pupil_radius = int(eye_radius * 0.5)
            draw.ellipse(
                [(left_eye_x - pupil_radius, eye_y - pupil_radius),
                 (left_eye_x + pupil_radius, eye_y + pupil_radius)],
                fill=(20, 20, 20)
            )
            
            # Right eye - large blue
            right_eye_x = int(center_x + head_radius * 0.5)
            draw.ellipse(
                [(right_eye_x - eye_radius, eye_y - eye_radius),
                 (right_eye_x + eye_radius, eye_y + eye_radius)],
                fill=(100, 180, 255),
                outline=(50, 100, 200),
                width=max(1, int(size * 0.01))
            )
            
            # Right pupil
            draw.ellipse(
                [(right_eye_x - pupil_radius, eye_y - pupil_radius),
                 (right_eye_x + pupil_radius, eye_y + pupil_radius)],
                fill=(20, 20, 20)
            )
            
            # Jagged/zigzag mouth
            mouth_y = int(center_y + head_radius * 0.4)
            mouth_width = int(size * 0.12)
            mouth_left = int(center_x - mouth_width // 2)
            
            # Create jagged mouth line - zigzag pattern
            mouth_points = []
            segments = 5
            for i in range(segments + 1):
                x = mouth_left + (mouth_width // segments) * i
                # Alternate up and down for zigzag
                offset = int(size * 0.03) if i % 2 == 0 else -int(size * 0.03)
                y = mouth_y + offset
                mouth_points.append((x, y))
            
            # Draw jagged mouth
            if len(mouth_points) > 1:
                draw.line(mouth_points, fill=(150, 100, 150), width=max(2, int(size * 0.02)))
            
            # Body - rectangle shape
            body_width = int(size * 0.18)
            body_height = int(size * 0.22)
            body_top = int(center_y + head_radius)
            body_left = int(center_x - body_width // 2)
            
            draw.rectangle(
                [(body_left, body_top),
                 (body_left + body_width, body_top + body_height)],
                fill=(200, 200, 220),
                outline=(100, 100, 150),
                width=max(1, int(size * 0.01))
            )
            
            # Chest panel (accent)
            panel_height = int(body_height * 0.4)
            draw.rectangle(
                [(body_left + int(body_width * 0.15), body_top + int(body_height * 0.1)),
                 (body_left + int(body_width * 0.85), body_top + int(body_height * 0.1) + panel_height)],
                fill=(180, 180, 210),
                outline=(100, 100, 150),
                width=max(1, int(size * 0.01))
            )
            
            # Button details on chest
            button_size = int(size * 0.025)
            button_x = int(center_x)
            button_y = int(body_top + body_height * 0.25)
            draw.ellipse(
                [(button_x - button_size, button_y - button_size),
                 (button_x + button_size, button_y + button_size)],
                fill=(100, 180, 255)
            )
            
            filepath = output_path / filename
            img.save(filepath, 'PNG')
            print(f"Created: {filepath}")
        
        return output_path / 'logo.png'
        
    except ImportError:
        print("Warning: PIL not available, cannot create mascot images")
        return None


if __name__ == '__main__':
    logo_path = save_mascot()
    if logo_path:
        print(f"\nMascot loaded/created successfully at: {logo_path}")
    else:
        print("Could not create mascot images")
