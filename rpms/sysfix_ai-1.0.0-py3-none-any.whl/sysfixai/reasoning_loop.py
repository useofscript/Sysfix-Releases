"""
Agentic Reasoning Loop — Think-Act-Observe cycle for Fyxa AI.

Shifts Fyxa from a passive chatbot to an environment-aware system architect.
The loop maintains a stateful cycle:

  1. THINK — AI analyzes the user's request + system context + tool results
  2. ACT   — AI decides to call a tool, generate commands, or respond
  3. OBSERVE — Tool results or system feedback are collected and fed back

The loop continues until the AI produces a final text response (no more
tool calls) or hits the max iteration limit.

Key integration points:
- System Pulse: live telemetry injected into every prompt
- Tool Calling: registered Python functions the AI can invoke
- Safety Intercept: commands pass through classification before execution
- Sandbox: risky commands are tested in isolation first

Configuration:
- max_iterations: cap on Think-Act-Observe cycles (default 8)
- model: target model (default: qwen2.5-coder:7b for tool-calling, falls back)
- sandbox_mode: auto-sandbox commands before execution (default True)
- tool_calling_mode: "native" | "prompt" | "auto" (default "auto")

Public API:
- run_agent_loop(query, chat_history, system_context, callbacks) → AgentResult
- AgentResult: final_response, steps, tool_calls_made, commands_proposed
"""

from __future__ import annotations

import json
import re
import time
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class AgentStep:
    """One iteration of the Think-Act-Observe cycle."""
    iteration: int = 0
    phase: str = ""              # think / act / observe
    thought: str = ""            # AI's internal reasoning
    action_type: str = ""        # tool_call / respond / command / sandbox
    action_detail: str = ""      # Tool name, command text, or ""
    tool_name: str = ""
    tool_args: Dict[str, Any] = field(default_factory=dict)
    tool_result: str = ""
    observation: str = ""        # What the AI learned from this step
    timestamp: float = 0.0
    duration_ms: int = 0


@dataclass
class AgentResult:
    """Final result of an agent loop execution."""
    final_response: str = ""
    steps: List[AgentStep] = field(default_factory=list)
    tool_calls_made: int = 0
    commands_proposed: List[str] = field(default_factory=list)
    iterations: int = 0
    total_duration_ms: int = 0
    model_used: str = ""
    sandbox_results: Dict[str, str] = field(default_factory=dict)
    intercept_ids: List[str] = field(default_factory=list)
    error: str = ""


@dataclass
class AgentConfig:
    """Configuration for the agent loop."""
    max_iterations: int = 8
    model: str = ""                    # Empty = auto-detect
    sandbox_mode: bool = True          # Auto-sandbox commands
    tool_calling_mode: str = "auto"    # native / prompt / auto
    timeout_per_call: int = 90
    enable_pulse: bool = True          # Inject System Pulse data
    enable_tools: bool = True
    enable_safety_intercept: bool = True
    on_thought: Optional[Callable[[str, int], None]] = None     # callback(thought, iteration)
    on_tool_call: Optional[Callable[[str, Dict], None]] = None  # callback(tool_name, args)
    on_observe: Optional[Callable[[str, int], None]] = None     # callback(observation, iteration)
    on_intercept: Optional[Callable[[Any], None]] = None        # callback(InterceptResult)


# ---------------------------------------------------------------------------
# Prompt construction for the agentic loop
# ---------------------------------------------------------------------------

def _build_agent_system_prompt(
    system_context: Optional[Dict] = None,
    query: str = "",
    tool_mode: str = "prompt",
) -> str:
    """Build the system prompt for the agentic loop."""

    prompt_parts: List[str] = []

    # Base identity
    prompt_parts.append(
        "You are **Fyxa**, an expert Linux systems engineer running inside the Sysfix diagnostic tool.\n"
        "You operate in an AGENTIC REASONING LOOP with a Think-Act-Observe cycle.\n\n"
        "CYCLE RULES:\n"
        "1. THINK — Analyze the user's request, available system data, and past observations.\n"
        "   Output your thinking in a <think>...</think> block.\n"
        "2. ACT — Either:\n"
        "   a) Call a tool to gather more information or test something\n"
        "   b) Propose shell commands to fix the issue\n"
        "   c) Give your final response if you have enough information\n"
        "3. OBSERVE — Review tool results and decide if another cycle is needed.\n\n"
        "IMPORTANT:\n"
        "- You can call tools to gather live system data. Don't guess when you can check.\n"
        "- If proposing shell commands, they will be sandboxed and safety-checked first.\n"
        "- Always think before acting. Don't rush to commands without understanding the problem.\n"
        "- When you have enough information, give a clear, actionable final response.\n"
        "- Keep tool calls purposeful — don't loop unnecessarily.\n"
        "- If a tool returns an error, adapt and try a different approach.\n"
    )

    # System Pulse injection
    pulse_header = ""
    try:
        from sysfixai.system_pulse import get_pulse_prompt_header
        pulse_header = get_pulse_prompt_header()
    except ImportError:
        pass

    if pulse_header:
        prompt_parts.append(pulse_header)
    elif system_context:
        # Fall back to static snapshot
        ctx_lines = ["\n--- SYSTEM STATE ---"]
        for k, v in system_context.items():
            if k.startswith("_"):
                continue
            if isinstance(v, dict):
                ctx_lines.append(f"{k}: {json.dumps(v, default=str)[:200]}")
            elif isinstance(v, list):
                ctx_lines.append(f"{k}: {', '.join(str(x) for x in v[:5])}")
            else:
                ctx_lines.append(f"{k}: {v}")
        ctx_lines.append("---")
        prompt_parts.append("\n".join(ctx_lines))

    # Tool descriptions (for prompt-based tool calling)
    if tool_mode == "prompt":
        try:
            from sysfixai.tool_calling import get_tool_descriptions_text
            prompt_parts.append("\n" + get_tool_descriptions_text())
        except ImportError:
            pass

    # Brain memory
    try:
        from sysfixai.memory import get_memory_context
        from sysfixai.config import load_config
        cfg = load_config()
        if cfg.get("enable_brain", True):
            mem = get_memory_context(query=query[:500], max_tokens=1500)
            if mem:
                prompt_parts.append(f"\n--- BRAIN (persistent memory) ---\n{mem}\n---")
    except Exception:
        pass

    # Sentinel Bridge — security engine visibility
    try:
        from sysfixai.sentinel_bridge import get_sentinel_prompt_block
        sb = get_sentinel_prompt_block()
        if sb:
            prompt_parts.append(sb)
    except ImportError:
        pass

    # Extra context from GUI (topic keywords, ELI5)
    if system_context:
        extra = system_context.get("_extra_context")
        if extra:
            prompt_parts.append(f"\n{extra}")
        eli5 = system_context.get("_eli5")
        if eli5:
            prompt_parts.append(f"\n{eli5}")

    return "\n".join(prompt_parts)


# ---------------------------------------------------------------------------
# Tool-calling protocol detection
# ---------------------------------------------------------------------------

def _detect_tool_mode(model: str) -> str:
    """Detect whether a model supports native tool-calling.

    Returns "native" for models known to support Ollama tools parameter,
    "prompt" for models that need prompt-based instructions.
    """
    model_lower = model.lower()

    # Models known to support native tool-calling
    native_models = [
        "qwen2.5-coder", "qwen2.5", "qwen3",
        "llama3.1", "llama3.2", "llama3.3",
        "mistral", "mixtral",
        "command-r", "command-r-plus",
        "firefunction",
        "hermes",
    ]

    for nm in native_models:
        if nm in model_lower:
            return "native"

    return "prompt"


def _try_native_tool_call(
    messages: List[Dict[str, str]],
    model: str,
    timeout: int = 90,
) -> Optional[Dict[str, Any]]:
    """Attempt an Ollama chat call with native tool-calling.

    Returns the raw response dict if successful, None otherwise.
    """
    import urllib.request

    try:
        from sysfixai.tool_calling import get_tool_definitions
        tools = get_tool_definitions()
    except ImportError:
        return None

    if not tools:
        return None

    try:
        from sysfixai.ai import OLLAMA_BASE
    except ImportError:
        OLLAMA_BASE = "http://127.0.0.1:11434"

    try:
        payload = json.dumps({
            "model": model,
            "messages": messages,
            "tools": tools,
            "stream": False,
        }).encode()

        req = urllib.request.Request(
            f"{OLLAMA_BASE}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())

        err = (data.get("error") or "").strip()
        if err:
            return None

        return data
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Core agentic loop
# ---------------------------------------------------------------------------

def run_agent_loop(
    query: str,
    chat_history: Optional[List[Dict[str, str]]] = None,
    system_context: Optional[Dict[str, Any]] = None,
    config: Optional[AgentConfig] = None,
) -> AgentResult:
    """Execute the full Think-Act-Observe agentic reasoning loop.

    Args:
        query:          User's question or task description
        chat_history:   Previous conversation messages
        system_context: Live system snapshot dict
        config:         Agent configuration (uses defaults if None)

    Returns:
        AgentResult with final response, steps taken, and metadata
    """
    if config is None:
        config = AgentConfig()

    result = AgentResult()
    start_time = time.time()

    # Resolve model
    model = config.model
    if not model:
        try:
            from sysfixai.ai import get_active_model
            model = get_active_model()
        except Exception:
            model = "qwen2.5-coder:7b"
    result.model_used = model

    # Determine tool-calling mode
    tool_mode = config.tool_calling_mode
    if tool_mode == "auto":
        tool_mode = _detect_tool_mode(model)

    # Build system prompt
    sys_prompt = _build_agent_system_prompt(system_context, query, tool_mode)

    # Build messages
    messages: List[Dict[str, str]] = [
        {"role": "system", "content": sys_prompt},
    ]

    # Append chat history (last 16 messages)
    if chat_history:
        for msg in chat_history[-16:]:
            role = msg.get("role", "user")
            content = msg.get("content", "")[:1200]
            if role in ("user", "assistant") and content:
                messages.append({"role": role, "content": content})

    # Web search enrichment
    web_block = ""
    try:
        from sysfixai.ai import web_search, _should_search_web
        if _should_search_web(query):
            web_block = web_search(query, max_results=3) or ""
    except Exception:
        pass

    # Build user message
    user_content = query[:2000]
    if web_block:
        user_content += f"\n\n[Web search results for reference:]\n{web_block}"
    messages.append({"role": "user", "content": user_content})

    # --- Main loop ---
    for iteration in range(1, config.max_iterations + 1):
        result.iterations = iteration
        step = AgentStep(iteration=iteration, timestamp=time.time())

        # --- THINK + ACT phase: call the model ---
        step.phase = "think"
        if config.on_thought:
            try:
                config.on_thought(f"Iteration {iteration}: Analyzing...", iteration)
            except Exception:
                pass

        step_start = time.time()
        response_text = ""
        native_tool_calls = []

        # Try native tool-calling first
        if tool_mode == "native" and config.enable_tools:
            raw_response = _try_native_tool_call(messages, model, config.timeout_per_call)
            if raw_response:
                msg_obj = raw_response.get("message", {})
                response_text = msg_obj.get("content", "") or ""
                # Check for native tool calls in the response
                tool_calls_raw = msg_obj.get("tool_calls", [])
                for tc in tool_calls_raw:
                    fn = tc.get("function", {})
                    name = fn.get("name", "")
                    args = fn.get("arguments", {})
                    if name:
                        native_tool_calls.append((name, args))

        # Fallback to regular chat API if native didn't work
        if not response_text and not native_tool_calls:
            try:
                from sysfixai.ai import _chat_api
                response_text = _chat_api(messages, model=model, timeout=config.timeout_per_call)
                response_text = response_text or ""
            except Exception as e:
                result.error = f"Model call failed: {e}"
                break

        step.duration_ms = int((time.time() - step_start) * 1000)

        # Extract thinking blocks
        think_match = re.search(r'<think>(.*?)</think>', response_text, re.DOTALL)
        if think_match:
            step.thought = think_match.group(1).strip()
            # Remove thinking from visible response
            clean_response = re.sub(r'<think>.*?</think>', '', response_text, flags=re.DOTALL).strip()
        else:
            clean_response = response_text.strip()

        # --- Check for tool calls ---
        tool_calls = native_tool_calls
        if not tool_calls and config.enable_tools:
            try:
                from sysfixai.tool_calling import parse_tool_calls
                tool_calls = parse_tool_calls(clean_response)
            except ImportError:
                pass

        if tool_calls:
            # --- ACT: Execute tool call ---
            step.phase = "act"
            tc_name, tc_args = tool_calls[0]  # Process one tool call per iteration
            step.action_type = "tool_call"
            step.action_detail = tc_name
            step.tool_name = tc_name
            step.tool_args = tc_args

            result.tool_calls_made += 1

            if config.on_tool_call:
                try:
                    config.on_tool_call(tc_name, tc_args)
                except Exception:
                    pass

            # Execute the tool
            try:
                from sysfixai.tool_calling import execute_tool_call
                tool_result = execute_tool_call(tc_name, tc_args)
            except ImportError:
                tool_result = "Tool calling module not available."
            except Exception as e:
                tool_result = f"Error: {e}"

            step.tool_result = tool_result[:3000]

            # --- OBSERVE: Feed result back ---
            step.phase = "observe"
            step.observation = f"Tool '{tc_name}' returned {len(tool_result)} chars"

            if config.on_observe:
                try:
                    config.on_observe(step.observation, iteration)
                except Exception:
                    pass

            # Add tool result to conversation for next iteration
            messages.append({"role": "assistant", "content": clean_response})
            messages.append({
                "role": "user",
                "content": f"[Tool result from {tc_name}:]\n{tool_result[:3000]}\n\n"
                           "Continue your analysis. If you need more information, call another tool. "
                           "If you have enough, give your final response.",
            })

            result.steps.append(step)
            continue

        # --- Check for commands in the response ---
        commands = _extract_commands(clean_response)
        if commands and config.enable_safety_intercept:
            step.action_type = "command"
            step.action_detail = "; ".join(commands[:3])
            result.commands_proposed.extend(commands)

            # Run through safety intercept
            try:
                from sysfixai.safety_intercept import intercept
                intercept_result = intercept(commands, source="agent_loop")
                result.intercept_ids.append(intercept_result.intercept_id)

                if config.on_intercept:
                    try:
                        config.on_intercept(intercept_result)
                    except Exception:
                        pass

                if intercept_result.record and intercept_result.record.classification == "blocked":
                    # Blocked — tell the AI
                    messages.append({"role": "assistant", "content": clean_response})
                    messages.append({
                        "role": "user",
                        "content": f"[SAFETY INTERCEPT] The following commands were BLOCKED: "
                                   f"{'; '.join(commands[:3])}. "
                                   f"Reason: {intercept_result.message}. "
                                   "Please suggest safer alternatives.",
                    })
                    result.steps.append(step)
                    continue
            except ImportError:
                pass

            # Sandbox test if enabled
            if config.sandbox_mode and commands:
                try:
                    from sysfixai.sandbox import sandbox_dry_run
                    sandbox_out = sandbox_dry_run(commands[:5])
                    result.sandbox_results[step.action_detail] = "\n".join(sandbox_out)
                except Exception:
                    pass

        # --- No tool calls = final response ---
        step.phase = "respond"
        step.action_type = "respond"

        # Clean the response of any thinking artifacts
        try:
            from sysfixai.ai import _clean_verbose_response
            clean_response = _clean_verbose_response(clean_response)
        except ImportError:
            pass

        result.final_response = clean_response
        result.steps.append(step)
        break
    else:
        # Hit max iterations
        result.final_response = clean_response if clean_response else (
            "I've reached my analysis limit. Here's what I found so far based on "
            "the tools I called. Let me know if you need me to dig deeper into "
            "any specific area."
        )
        if result.steps:
            result.steps[-1].observation = "Max iterations reached"

    result.total_duration_ms = int((time.time() - start_time) * 1000)

    # Learn from this conversation
    try:
        from sysfixai.memory import learn_from_conversation
        from sysfixai.config import load_config
        cfg = load_config()
        if cfg.get("enable_brain", True) and cfg.get("brain_learn_conversations", True):
            learn_msgs = (chat_history or [])[-4:] + [
                {"role": "user", "content": query},
                {"role": "assistant", "content": result.final_response[:500]},
            ]
            learn_from_conversation(learn_msgs)
    except Exception:
        pass

    return result


def _extract_commands(text: str) -> List[str]:
    """Extract shell commands from AI response text."""
    commands: List[str] = []

    # Fenced bash blocks
    m = re.search(r'```(?:bash|sh|shell)?\s*\n(.*?)```', text, re.DOTALL)
    if m:
        for line in m.group(1).splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                commands.append(line)
        return commands

    # Lines starting with $
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("$ "):
            commands.append(stripped[2:])

    return commands


# ---------------------------------------------------------------------------
# Convenience wrappers
# ---------------------------------------------------------------------------

def agent_query(
    query: str,
    chat_history: Optional[List[Dict[str, str]]] = None,
    system_context: Optional[Dict[str, Any]] = None,
    on_thought: Optional[Callable] = None,
    on_tool_call: Optional[Callable] = None,
) -> str:
    """Simple wrapper that returns just the final response string.

    For use by get_deep_dive() when agentic mode is enabled.
    """
    config = AgentConfig(
        on_thought=on_thought,
        on_tool_call=on_tool_call,
    )
    result = run_agent_loop(query, chat_history, system_context, config)
    return result.final_response or result.error or "No response generated."


def agent_status() -> Dict[str, Any]:
    """Return agent loop capability status."""
    status: Dict[str, Any] = {
        "available": True,
        "tool_calling": False,
        "system_pulse": False,
        "safety_intercept": False,
        "sandbox": False,
    }

    try:
        from sysfixai.tool_calling import get_tool_registry
        reg = get_tool_registry()
        status["tool_calling"] = len(reg) > 0
        status["tool_count"] = len(reg)
        status["tools"] = list(reg.keys())
    except ImportError:
        pass

    try:
        from sysfixai.system_pulse import pulse_status
        ps = pulse_status()
        status["system_pulse"] = ps.get("running", False)
        status["pulse_snapshots"] = ps.get("snapshots", 0)
    except ImportError:
        pass

    try:
        from sysfixai.safety_intercept import get_pending, get_audit_log
        status["safety_intercept"] = True
        status["pending_intercepts"] = len(get_pending())
        status["audit_entries"] = len(get_audit_log())
    except ImportError:
        pass

    try:
        from sysfixai.sandbox import detect_sandbox_backend
        backends = detect_sandbox_backend()
        status["sandbox"] = bool(backends)
        status["sandbox_backends"] = list(backends.keys()) if backends else []
    except ImportError:
        pass

    try:
        from sysfixai.ai import get_active_model
        status["model"] = get_active_model()
    except Exception:
        status["model"] = "unknown"

    status["tool_mode"] = _detect_tool_mode(status.get("model", ""))

    # Sentinel Bridge
    try:
        from sysfixai.sentinel_bridge import sentinel_bridge_status
        sb = sentinel_bridge_status()
        status["sentinel_bridge"] = True
        status["sentinel_tier"] = sb.get("tier", "unknown")
        status["sentinel_free_tools"] = sb.get("free_tier_tools", [])
        status["sentinel_paid_tools"] = sb.get("paid_tier_tools", [])
    except ImportError:
        status["sentinel_bridge"] = False

    return status


def agent_report() -> List[str]:
    """Human-readable report of agent loop capabilities."""
    report: List[str] = []
    status = agent_status()

    report.append("═══ AGENTIC REASONING LOOP ═══")
    report.append("")
    report.append(f"Model: {status.get('model', 'unknown')}")
    report.append(f"Tool-calling mode: {status.get('tool_mode', 'unknown')}")
    report.append("")

    # Tools
    if status.get("tool_calling"):
        report.append(f"✓ Tool Calling: {status.get('tool_count', 0)} tools registered")
        for tool in status.get("tools", []):
            report.append(f"    • {tool}")
    else:
        report.append("⚠ Tool Calling: not available")

    # Pulse
    if status.get("system_pulse"):
        report.append(f"✓ System Pulse: running ({status.get('pulse_snapshots', 0)} snapshots)")
    else:
        report.append("⚠ System Pulse: not running")

    # Safety
    if status.get("safety_intercept"):
        report.append(f"✓ Safety Intercept: active (pending: {status.get('pending_intercepts', 0)}, "
                      f"audited: {status.get('audit_entries', 0)})")
    else:
        report.append("⚠ Safety Intercept: not available")

    # Sandbox
    if status.get("sandbox"):
        report.append(f"✓ Sandbox: {', '.join(status.get('sandbox_backends', []))}")
    else:
        report.append("⚠ Sandbox: no backend available")

    # Sentinel Bridge
    if status.get("sentinel_bridge"):
        tier = status.get('sentinel_tier', '?')
        free = status.get('sentinel_free_tools', [])
        report.append(f"✓ Sentinel Bridge: tier={tier}, {len(free)} free tools")
        for t in free:
            report.append(f"    • {t}")
    else:
        report.append("⚠ Sentinel Bridge: not available")

    return report
