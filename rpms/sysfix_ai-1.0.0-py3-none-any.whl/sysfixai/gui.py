"""
Sysfix Professional GUI — themeable diagnostic & security interface.

Features:
  - Live system gauges (CPU / RAM / Disk / Temp / GPU)
  - 7-tab layout: Dashboard, Quick Fix, Security, Network, AI Chat, Brain, Settings
  - 4 built-in themes: Frutiger Aero, Light, Dark, Cyberpunk
  - Security scanner: firewall, ports, SUID, rootkit checks
  - Network diagnostics: interfaces, DNS, gateway, connectivity
  - Conversation memory & web-search AI (Fyxa)
  - Animated thinking indicator with code-block rendering
  - Button hover effects, tooltips, keyboard shortcuts
  - Thread-safe widget updates & status bar
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import logging
import threading
import subprocess
import shutil
import sys
import os
import signal
import re
import random
import shlex
import math
import webbrowser
from datetime import datetime
from pathlib import Path
import time
from uuid import uuid4

log = logging.getLogger("sysfix.gui")

try:
    from PIL import Image, ImageTk, ImageDraw, ImageFilter, ImageFont
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

from sysfixai.core import (
    diagnose,
    categorize_issues,
    is_ollama_running,
)
from sysfixai.ai import (
    get_deep_dive, get_system_snapshot, web_search,
    get_active_model, set_active_model, list_available_models,
    is_cloud_model, get_ai_runtime_status, get_provider_options,
    get_active_provider, set_active_provider, get_provider_label,
)
from sysfixai.diagnostics import (
    security_scan_full,
    network_diagnostics,
    check_pending_updates,
    check_systemd_failed,
    check_boot_time,
    check_journal_errors,
    check_usb_devices,
    check_smart_health,
    check_sysfix_update,
    apply_sysfix_update,
    apply_system_updates,
    is_autostart_enabled,
    enable_autostart,
    disable_autostart,
    scan_file_hash,
    scan_directory_hashes,
    check_wifi_info,
    check_public_ip,
    check_traceroute,
    check_active_connections,
    check_bandwidth_usage,
    check_ping,
    check_firewall_brief,
    check_network_interfaces,
    check_dns_resolution,
    check_gateway_latency,
    check_internet_connectivity,
    check_pending_updates_detailed,
    check_sysfix_integrity,
    optimize_wifi_connection,
)
from sysfixai.config import load_config, save_config, CONFIG_FILE
from sysfixai.memory import (
    observe_system, learn_from_conversation, get_memory_context,
    get_brain_stats, get_brain_dump, clear_brain, get_brain_size_kb,
    add_observation, add_solution, get_cache, set_cache, delete_cache,
)
from sysfixai.advanced_diagnostics import (
    smart_predictive_analysis,
    zombie_process_hunter, kill_zombie_parents,
    kernel_param_audit, apply_kernel_optimisation,
    network_self_heal, apply_bbr,
    hardware_health_score,
    repo_audit,
    log_pattern_analysis,
    energy_profile,
    scrub_pii,
    config_snapshot, list_snapshots, rollback_config,
    export_brain, import_brain,
    create_system_snapshot, check_snapshot_support,
    advanced_diagnostics_full,
)
from sysfixai.sandbox import (
    sandbox_dry_run, detect_sandbox_backend,
    capture_current_as_golden, golden_state_drift_check,
    golden_state_reconcile_services,
    prescriptive_analysis,
    semantic_log_search, semantic_log_search_ai,
    get_safety_pin_status, toggle_safety_pin, is_action_safe,
    full_sandbox_report,
)
from sysfixai.ebpf_sentinel import (
    start_sentinel, stop_sentinel, sentinel_status, sentinel_report,
    get_sentinel, check_bcc_available,
)
from sysfixai.microvm import (
    microvm_run, microvm_report, microvm_status,
    check_firecracker_available, detect_vm_backend, setup_vm_environment,
)
from sysfixai.npu import npu_report, npu_status, detect_npu
from sysfixai.ui_enhancements import (
    UIPhysics, SpringAnimator, Spring,
    has_customtkinter, has_pymunk,
    ui_enhancements_report,
)
from sysfixai.system_pulse import (
    start_pulse, stop_pulse, get_pulse, get_trend,
    pulse_status, pulse_report, register_callback,
)
from sysfixai.reasoning_loop import agent_status, agent_report
from sysfixai.safety_intercept import (
    intercept, approve, deny, get_pending, get_audit_log,
    format_intercept_for_display, intercept_report,
    classify_commands,
)
from sysfixai.sentinel_av import (
    get_av, start_av, stop_av, av_status, av_threats,
    av_report, delete_threat as av_delete_threat,
    jail_threat as av_jail_threat, release_threat as av_release_threat,
    format_threat_for_display, ThreatEvent, ThreatMap,
)
from sysfixai.malware_pipeline import (
    run_pipeline as mvp_run_pipeline,
    pipeline_report as mvp_pipeline_report,
    format_profile_for_display as mvp_format_profile,
    ai_interpret_profile as mvp_ai_interpret,
    pipeline_capabilities as mvp_capabilities,
    _update_yara_rules as mvp_update_yara,
)
from sysfixai.sentinel_bridge import (
    get_bridge as sb_get_bridge,
    read_only_ebpf_scan as sb_scan,
    scan_process_anomalies as sb_proc_scan,
    check_network_threats as sb_net_scan,
    sentinel_bridge_report as sb_report,
)
from sysfixai.polkit import (
    check_polkit, polkit_status, polkit_report, polkit_status as pk_status,
    elevate as pk_elevate, worker_run as pk_worker_run,
    ElevationError, AuditLog as PkAuditLog,
    install_policy as pk_install_policy, session_type as pk_session_type,
)
from sysfixai.heartbeat import (
    get_heartbeat, start_heartbeat, stop_heartbeat,
    heartbeat_awareness, heartbeat_alerts, heartbeat_status,
    heartbeat_report, Heartbeat, Alert as HeartbeatAlert,
)
from sysfixai.polar import (
    is_licence_valid, get_licence_info, get_checkout_url,
    activate_premium, create_checkout_session, verify_order_by_id,
    verify_order_by_key, deactivate_premium, polar_status,
)

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    import fcntl
except Exception:
    fcntl = None


# ---------------------------------------------------------------------------
# Theme definitions
# ---------------------------------------------------------------------------

THEMES = {
    "frutiger_aero": {
        "label":            "Frutiger Aero",
        "bg_color":         "#eaf2fb",
        "bg_secondary":     "#dce8f5",
        "bg_tertiary":      "#e6eff9",
        "header_color":     "#102a4a",
        "accent_color":     "#2b7de9",
        "accent_secondary": "#1a5fc4",
        "metallic_light":   "#1e2d3d",
        "success_color":    "#22b573",
        "warning_color":    "#e8a317",
        "danger_color":     "#e04040",
        "button_hover":     "#4a9af5",
        "text_color":       "#1e2d3d",
        "text_dim":         "#6b849e",
        "border_color":     "#b8d0e8",
        "glass_white":      "#f8fbff",
        "glass_tint":       "#e0f0ff",
        "button_fg":        "#ffffff",
        "hdr_title_fg":     "#eaf4ff",
        "hdr_subtitle_fg":  "#8ab4d8",
        "hdr_ai_on":        "#5ae0a0",
        "hdr_ai_off":       "#f87070",
        "hdr_web_fg":       "#7ec8f8",
        "hdr_admin_fg":     "#5ae0a0",
        "hdr_user_fg":      "#f0d060",
        "tooltip_bg":       "#f0f6ff",
        "tooltip_fg":       "#1e2d3d",
        "tab_selected_bg":  "#f8fbff",
        "chat_fyxa_fg":     "#1a6040",
        "window_alpha":     0.97,
        "texture_strength": 0.22,
    },
    "light": {
        "label":            "Light",
        "bg_color":         "#ffffff",
        "bg_secondary":     "#f7f7f8",
        "bg_tertiary":      "#f0f0f2",
        "header_color":     "#2d3748",
        "accent_color":     "#4a90d9",
        "accent_secondary": "#3571b8",
        "metallic_light":   "#1a202c",
        "success_color":    "#2f855a",
        "warning_color":    "#c77c10",
        "danger_color":     "#c53030",
        "button_hover":     "#5da0e6",
        "text_color":       "#1a202c",
        "text_dim":         "#a0aec0",
        "border_color":     "#e2e8f0",
        "glass_white":      "#ffffff",
        "glass_tint":       "#f7fafc",
        "button_fg":        "#ffffff",
        "hdr_title_fg":     "#ffffff",
        "hdr_subtitle_fg":  "#a0aec0",
        "hdr_ai_on":        "#68d391",
        "hdr_ai_off":       "#fc8181",
        "hdr_web_fg":       "#90cdf4",
        "hdr_admin_fg":     "#68d391",
        "hdr_user_fg":      "#f6e05e",
        "tooltip_bg":       "#ffffff",
        "tooltip_fg":       "#2d3748",
        "tab_selected_bg":  "#ffffff",
        "chat_fyxa_fg":     "#22543d",
        "window_alpha":     0.99,
        "texture_strength": 0.12,
    },
    "dark": {
        "label":            "Dark",
        "bg_color":         "#0f1218",
        "bg_secondary":     "#151b28",
        "bg_tertiary":      "#1a2235",
        "header_color":     "#080c14",
        "accent_color":     "#58b8f0",
        "accent_secondary": "#3da0e0",
        "metallic_light":   "#d8e0e8",
        "success_color":    "#50d88a",
        "warning_color":    "#f0a830",
        "danger_color":     "#f05050",
        "button_hover":     "#78ccff",
        "text_color":       "#d8e0e8",
        "text_dim":         "#607080",
        "border_color":     "#1e2e48",
        "glass_white":      "#161e2c",
        "glass_tint":       "#1a2838",
        "button_fg":        "#080c14",
        "hdr_title_fg":     "#d8e8f0",
        "hdr_subtitle_fg":  "#607888",
        "hdr_ai_on":        "#50d88a",
        "hdr_ai_off":       "#f05050",
        "hdr_web_fg":       "#58b8f0",
        "hdr_admin_fg":     "#50d88a",
        "hdr_user_fg":      "#f0a830",
        "tooltip_bg":       "#1a2238",
        "tooltip_fg":       "#d8e0e8",
        "tab_selected_bg":  "#161e2c",
        "chat_fyxa_fg":     "#68d898",
        "window_alpha":     0.98,
        "texture_strength": 0.14,
    },
    "cyberpunk": {
        "label":            "Cyberpunk",
        "bg_color":         "#060818",
        "bg_secondary":     "#0a0e28",
        "bg_tertiary":      "#0e1438",
        "header_color":     "#080c30",
        "accent_color":     "#00d8ff",
        "accent_secondary": "#0098e8",
        "metallic_light":   "#e0f0f8",
        "success_color":    "#00ff80",
        "warning_color":    "#ff9900",
        "danger_color":     "#ff2060",
        "button_hover":     "#00b0e0",
        "text_color":       "#e0f0f8",
        "text_dim":         "#5888a0",
        "border_color":     "#142048",
        "glass_white":      "#0a1028",
        "glass_tint":       "#101838",
        "button_fg":        "#060818",
        "hdr_title_fg":     "#00d8ff",
        "hdr_subtitle_fg":  "#5888a0",
        "hdr_ai_on":        "#00ff80",
        "hdr_ai_off":       "#ff2060",
        "hdr_web_fg":       "#00d8ff",
        "hdr_admin_fg":     "#00ff80",
        "hdr_user_fg":      "#ff9900",
        "tooltip_bg":       "#142048",
        "tooltip_fg":       "#e0f0f8",
        "tab_selected_bg":  "#0a1028",
        "chat_fyxa_fg":     "#00ff80",
        "window_alpha":     0.97,
        "texture_strength": 0.18,
    },
    "glass": {
        "label":            "Glass",
        "bg_color":         "#f4f7fb",
        "bg_secondary":     "#e8edf5",
        "bg_tertiary":      "#eff2f8",
        "header_color":     "#18202e",
        "accent_color":     "#6366f1",
        "accent_secondary": "#4f46e5",
        "metallic_light":   "#1a1e2c",
        "success_color":    "#10b981",
        "warning_color":    "#f59e0b",
        "danger_color":     "#ef4444",
        "button_hover":     "#818cf8",
        "text_color":       "#1e293b",
        "text_dim":         "#94a3b8",
        "border_color":     "#cbd5e1",
        "glass_white":      "#ffffff",
        "glass_tint":       "#f0f4ff",
        "button_fg":        "#ffffff",
        "hdr_title_fg":     "#f0f4ff",
        "hdr_subtitle_fg":  "#94a3b8",
        "hdr_ai_on":        "#34d399",
        "hdr_ai_off":       "#f87171",
        "hdr_web_fg":       "#a5b4fc",
        "hdr_admin_fg":     "#34d399",
        "hdr_user_fg":      "#fbbf24",
        "tooltip_bg":       "#f8fafc",
        "tooltip_fg":       "#1e293b",
        "tab_selected_bg":  "#ffffff",
        "chat_fyxa_fg":     "#065f46",
        "window_alpha":     0.96,
        "texture_strength": 0.30,
    },
    "brutalist": {
        "label":            "Brutalist HUD",
        "bg_color":         "#08080c",
        "bg_secondary":     "#0c0c12",
        "bg_tertiary":      "#101018",
        "header_color":     "#04040a",
        "accent_color":     "#00ffa3",
        "accent_secondary": "#00cc82",
        "metallic_light":   "#c8d0d8",
        "success_color":    "#00ffa3",
        "warning_color":    "#ffaa00",
        "danger_color":     "#ff003c",
        "button_hover":     "#00cc82",
        "text_color":       "#b8c0c8",
        "text_dim":         "#484858",
        "border_color":     "#1a1a28",
        "glass_white":      "#0a0a10",
        "glass_tint":       "#0e0e18",
        "button_fg":        "#08080c",
        "hdr_title_fg":     "#00ffa3",
        "hdr_subtitle_fg":  "#484858",
        "hdr_ai_on":        "#00ffa3",
        "hdr_ai_off":       "#ff003c",
        "hdr_web_fg":       "#00d4ff",
        "hdr_admin_fg":     "#00ffa3",
        "hdr_user_fg":      "#ffaa00",
        "tooltip_bg":       "#101018",
        "tooltip_fg":       "#b8c0c8",
        "tab_selected_bg":  "#0e0e18",
        "chat_fyxa_fg":     "#00ffa3",
        "window_alpha":     0.98,
        "texture_strength": 0.06,
    },
}

THEME_NAMES = list(THEMES.keys())

SPLASH_TIPS = [
    "Tip: Sysfix diagnostics are read-only by default, so checks stay safe.",
    "Tip: Fyxa can remember useful context between chats when Brain is enabled.",
    "Tip: Use Ctrl+1..Ctrl+7 to jump between tabs quickly.",
    "Tip: You can switch AI providers in Settings without restarting Sysfix.",
    "Tip: Brain data stays local on your machine in ~/.config/sysfix/.",
    "Tip: Use the Security tab for quick malware-hash scans of files or folders.",
    "Tip: The Network tab can run traceroute, DNS checks, and live connection audits.",
]


# ---------------------------------------------------------------------------
# Overlay scrollbar — thin, modern, auto-hiding scrollbar
# ---------------------------------------------------------------------------

class OverlayScrollbar(tk.Canvas):
    """A thin, modern scrollbar drawn as a Canvas overlay on the right edge.

    Features:
      - Thin track (6px), expands on hover (10px)
      - Rounded thumb with opacity fade
      - Auto-hides after inactivity
      - Smooth drag support
    """

    THIN = 6
    WIDE = 10
    MIN_THUMB = 24
    FADE_MS = 1200       # hide after this idle time
    ANIM_MS = 16         # animation frame interval

    def __init__(self, parent, target, bg_color="#f8fbff",
                 thumb_color="#b0b8c8", thumb_hover="#8090a8",
                 track_color=None, **kw):
        super().__init__(parent, width=self.THIN, highlightthickness=0,
                         bd=0, bg=bg_color, **kw)
        self._target = target
        self._bg = bg_color
        self._thumb_color = thumb_color
        self._thumb_hover = thumb_hover
        self._track_color = track_color or bg_color
        self._width = self.THIN
        self._visible = False
        self._dragging = False
        self._drag_y0 = 0
        self._drag_top0 = 0.0
        self._fade_id = None
        self._hover = False

        # Draw elements
        self._thumb_id = self.create_rectangle(0, 0, 0, 0, fill=thumb_color,
                                                outline="", width=0)

        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_press)
        self.bind("<B1-Motion>", self._on_drag)
        self.bind("<ButtonRelease-1>", self._on_release)

        # Hook into the target widget's scroll
        self._orig_yscrollcommand = target.cget("yscrollcommand")
        target.configure(yscrollcommand=self._on_scroll)

    def _on_scroll(self, first, last):
        """Called by the text widget whenever scroll position changes."""
        first, last = float(first), float(last)
        if last - first >= 1.0:
            # All content visible — hide thumb
            self.itemconfig(self._thumb_id, fill="", outline="")
            self._visible = False
            return
        self._visible = True
        h = self.winfo_height()
        w = self._width
        thumb_h = max(self.MIN_THUMB, int((last - first) * h))
        y0 = int(first * h)
        y1 = min(y0 + thumb_h, h)
        pad = max(1, (w - 4) // 2)
        self.coords(self._thumb_id, pad, y0, w - pad, y1)
        color = self._thumb_hover if self._hover else self._thumb_color
        self.itemconfig(self._thumb_id, fill=color, outline="")
        self._schedule_fade()

    def _schedule_fade(self):
        if self._fade_id:
            self.after_cancel(self._fade_id)
        if not self._dragging:
            self._fade_id = self.after(self.FADE_MS, self._fade_out)

    def _fade_out(self):
        if not self._hover and not self._dragging:
            self.itemconfig(self._thumb_id, fill="", outline="")

    def _on_enter(self, _e):
        self._hover = True
        if self._visible:
            self.configure(width=self.WIDE)
            self._width = self.WIDE
            self.itemconfig(self._thumb_id, fill=self._thumb_hover)
            self._refresh_position()

    def _on_leave(self, _e):
        self._hover = False
        if not self._dragging:
            self.configure(width=self.THIN)
            self._width = self.THIN
            if self._visible:
                self.itemconfig(self._thumb_id, fill=self._thumb_color)
                self._refresh_position()
            self._schedule_fade()

    def _refresh_position(self):
        try:
            first, last = self._target.yview()
            self._on_scroll(str(first), str(last))
        except Exception:
            pass

    def _on_press(self, event):
        self._dragging = True
        self._drag_y0 = event.y
        try:
            self._drag_top0 = self._target.yview()[0]
        except Exception:
            self._drag_top0 = 0.0

    def _on_drag(self, event):
        if not self._dragging:
            return
        h = self.winfo_height()
        if h < 1:
            return
        dy = (event.y - self._drag_y0) / h
        new_top = max(0.0, min(1.0, self._drag_top0 + dy))
        self._target.yview_moveto(new_top)

    def _on_release(self, _e):
        self._dragging = False
        if not self._hover:
            self.configure(width=self.THIN)
            self._width = self.THIN
            self._refresh_position()
            self._schedule_fade()


# ---------------------------------------------------------------------------
# Smooth scrolling helper
# ---------------------------------------------------------------------------

class SmoothScroller:
    """Adds momentum-based smooth scrolling to any tkinter scrollable widget.

    Supports both ScrolledText widgets (yview_scroll) and Canvas widgets (yview_scroll).
    Call `bind_smooth_scroll(widget)` to enable.
    """

    _FRICTION = 0.90       # velocity decay per frame
    _MIN_VEL  = 0.03       # stop threshold
    _FRAME_MS = 12         # ~83 fps
    _IMPULSE  = 1.15       # scroll units per wheel notch
    _MAX_VEL  = 12.0       # clamp very fast touchpad input
    _states = {}
    _hover_widget = None
    _bound_roots = set()

    @classmethod
    def bind_smooth_scroll(cls, widget):
        """Bind smooth scrolling to a widget (ScrolledText or Canvas)."""
        cls._states[widget] = {"vel": 0.0, "carry": 0.0, "anim_id": None}
        widget.bind("<Enter>", lambda _e, w=widget: cls._set_hover(w), add=True)
        widget.bind("<Leave>", lambda _e, w=widget: cls._clear_hover(w), add=True)
        widget.bind("<Destroy>", lambda _e, w=widget: cls._cleanup_widget(w), add=True)

        # Direct wheel bindings for focused/hovered widgets.
        widget.bind("<Button-4>", lambda e, w=widget: cls._queue_scroll(w, e), add=True)
        widget.bind("<Button-5>", lambda e, w=widget: cls._queue_scroll(w, e), add=True)
        widget.bind("<MouseWheel>", lambda e, w=widget: cls._queue_scroll(w, e), add=True)

        # Global fallback so nested children still scroll smoothly.
        cls.enable_global(widget.winfo_toplevel())

    @classmethod
    def enable_global(cls, root):
        rid = str(root)
        if rid in cls._bound_roots:
            return
        cls._bound_roots.add(rid)
        root.bind_all("<MouseWheel>", cls._on_global_wheel, add=True)
        root.bind_all("<Button-4>", cls._on_global_wheel, add=True)
        root.bind_all("<Button-5>", cls._on_global_wheel, add=True)

    @classmethod
    def _set_hover(cls, widget):
        if widget in cls._states:
            cls._hover_widget = widget

    @classmethod
    def _clear_hover(cls, widget):
        if cls._hover_widget is widget:
            cls._hover_widget = None

    @classmethod
    def _cleanup_widget(cls, widget):
        state = cls._states.pop(widget, None)
        if state and state.get("anim_id"):
            try:
                widget.after_cancel(state["anim_id"])
            except Exception:
                pass
        if cls._hover_widget is widget:
            cls._hover_widget = None

    @classmethod
    def _extract_delta(cls, event):
        num = getattr(event, "num", None)
        if num == 4:
            return -1.0
        if num == 5:
            return 1.0
        raw = float(getattr(event, "delta", 0.0))
        if raw == 0.0:
            return 0.0
        scale = 120.0 if abs(raw) >= 120.0 else 80.0
        return -(raw / scale)

    @classmethod
    def _resolve_widget(cls, event_widget):
        # Walk up widget parents to find a smooth-scroll registered container.
        w = event_widget
        while w is not None:
            if w in cls._states:
                return w
            w = getattr(w, "master", None)
        if cls._hover_widget in cls._states:
            return cls._hover_widget
        return None

    @classmethod
    def _on_global_wheel(cls, event):
        target = cls._resolve_widget(getattr(event, "widget", None))
        if target is None:
            return None
        return cls._queue_scroll(target, event)

    @classmethod
    def _queue_scroll(cls, widget, event):
        state = cls._states.get(widget)
        if not state:
            return None
        delta = cls._extract_delta(event)
        if delta == 0.0:
            return None
        state["vel"] += delta * cls._IMPULSE
        state["vel"] = max(-cls._MAX_VEL, min(cls._MAX_VEL, state["vel"]))
        if state["anim_id"] is None:
            cls._animate(widget)
        return "break"

    @classmethod
    def _animate(cls, widget):
        state = cls._states.get(widget)
        if not state:
            return
        vel = state["vel"]
        if abs(vel) < cls._MIN_VEL and abs(state["carry"]) < 0.01:
            state["vel"] = 0.0
            state["carry"] = 0.0
            state["anim_id"] = None
            return
        try:
            state["carry"] += vel
            step = int(state["carry"])
            if step != 0:
                widget.yview_scroll(step, "units")
                state["carry"] -= step
        except Exception:
            state["vel"] = 0.0
            state["carry"] = 0.0
            state["anim_id"] = None
            return
        state["vel"] = vel * cls._FRICTION
        state["anim_id"] = widget.after(cls._FRAME_MS, lambda: cls._animate(widget))


# ---------------------------------------------------------------------------
# Tooltip helper
# ---------------------------------------------------------------------------

class ToolTip:
    """Lightweight hover tooltip for any widget."""

    def __init__(self, widget, text, bg="#ffffff", fg="#2d3748"):
        self.widget = widget
        self.text = text
        self.bg = bg
        self.fg = fg
        self.tw = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)

    def _show(self, _event=None):
        if self.tw:
            return
        x = self.widget.winfo_rootx() + self.widget.winfo_width() // 2
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.tw = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tk.Label(
            tw, text=self.text, bg=self.bg, fg=self.fg,
            font=("Noto Sans", 9), relief="solid", borderwidth=1,
            padx=10, pady=5,
        ).pack()

    def _hide(self, _event=None):
        if self.tw:
            self.tw.destroy()
            self.tw = None


class StartupSplash:
    """Small startup overlay shown while the main UI initializes."""

    def __init__(self, root):
        self.root = root
        self._running = True
        self._angle = 0
        self._logo_image = None
        self._shown_at = time.monotonic()
        self._tips = list(SPLASH_TIPS)
        self._tip_index = random.randrange(len(self._tips)) if self._tips else 0

        self.win = tk.Toplevel(root)
        self.win.configure(bg="#081828")
        self.win.resizable(False, False)
        # Keep this independent from the hidden root so it always appears.
        self.win.protocol("WM_DELETE_WINDOW", lambda: None)
        try:
            self.win.attributes("-topmost", True)
        except Exception:
            pass
        try:
            self.win.overrideredirect(True)
        except Exception:
            pass

        panel = tk.Frame(
            self.win,
            bg="#0e2438",
            bd=1,
            relief="solid",
            highlightthickness=1,
            highlightbackground="#2b4f6a",
        )
        panel.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        top = tk.Frame(panel, bg="#0e2438")
        top.pack(fill=tk.X, padx=26, pady=(24, 12))

        logo = self._load_logo_image()
        if logo:
            self._logo_image = logo
            tk.Label(top, image=logo, bg="#0e2438").pack()
        else:
            tk.Label(
                top,
                text="FYXA",
                bg="#0e2438",
                fg="#d5ecff",
                font=("Noto Sans", 21, "bold"),
            ).pack()

        tk.Label(
            panel,
            text="Starting Sysfix",
            bg="#0e2438",
            fg="#e8f7ff",
            font=("Noto Sans", 13, "bold"),
        ).pack(padx=26)

        self.detail_var = tk.StringVar(value="Preparing Fyxa...")
        tk.Label(
            panel,
            textvariable=self.detail_var,
            bg="#0e2438",
            fg="#9fc7df",
            font=("Noto Sans", 10),
            wraplength=280,
            justify="center",
        ).pack(padx=26, pady=(4, 10))

        self.spinner = tk.Canvas(
            panel, width=44, height=44, bg="#0e2438", highlightthickness=0, bd=0
        )
        self.spinner.pack(pady=(2, 10))
        self._spinner_arc = self.spinner.create_arc(
            6,
            6,
            38,
            38,
            start=0,
            extent=300,
            style=tk.ARC,
            width=4,
            outline="#65c4ff",
        )

        style = ttk.Style(self.win)
        style.configure(
            "Splash.Horizontal.TProgressbar",
            troughcolor="#15334a",
            background="#68c8ff",
            bordercolor="#15334a",
            lightcolor="#68c8ff",
            darkcolor="#68c8ff",
        )
        self.progress = ttk.Progressbar(
            panel,
            mode="indeterminate",
            length=250,
            style="Splash.Horizontal.TProgressbar",
        )
        self.progress.pack(padx=26, pady=(0, 8), fill=tk.X)
        self.progress.start(11)

        self.tip_var = tk.StringVar(value="")
        self.tip_label = tk.Label(
            panel,
            textvariable=self.tip_var,
            bg="#0e2438",
            fg="#82b8d8",
            font=("Noto Sans", 8, "italic"),
            wraplength=280,
            justify="center",
        )
        self.tip_label.pack(padx=26, pady=(0, 16))
        self._rotate_tip()

        self._center(320, 300)
        self._tick_spinner()
        self._flush()

    def _load_logo_image(self):
        if not HAS_PIL:
            return None
        try:
            assets_dir = Path(__file__).parent.parent / "assets"
            for name in ("Fyxa.png", "icon_256.png", "logo.png"):
                path = assets_dir / name
                if not path.exists():
                    continue
                img = Image.open(path).convert("RGBA")
                img.thumbnail((112, 112), Image.Resampling.LANCZOS)
                return ImageTk.PhotoImage(img)
        except Exception:
            return None
        return None

    def _detect_monitors(self):
        monitors = []

        # Prefer xrandr monitor geometries when available (multi-monitor aware).
        try:
            r = subprocess.run(
                ["xrandr", "--listmonitors"],
                capture_output=True,
                text=True,
                timeout=1.2,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0 and r.stdout:
                for line in r.stdout.splitlines():
                    line = line.strip()
                    if not line or ":" not in line:
                        continue
                    parts = line.split()
                    if len(parts) < 3:
                        continue
                    flags_name = parts[1]
                    geo = parts[2]
                    m = re.match(r"(\d+)/\d+x(\d+)/\d+\+(-?\d+)\+(-?\d+)", geo)
                    if not m:
                        continue
                    monitors.append(
                        {
                            "x": int(m.group(3)),
                            "y": int(m.group(4)),
                            "w": int(m.group(1)),
                            "h": int(m.group(2)),
                            "primary": "*" in flags_name,
                        }
                    )
        except Exception:
            monitors = []

        # Fallback parser for systems where --listmonitors is missing/incomplete.
        if not monitors:
            try:
                r = subprocess.run(
                    ["xrandr", "--query"],
                    capture_output=True,
                    text=True,
                    timeout=1.2,
                    stdin=subprocess.DEVNULL,
                )
                if r.returncode == 0 and r.stdout:
                    for line in r.stdout.splitlines():
                        if " connected " not in line:
                            continue
                        m = re.search(
                            r" connected (primary )?(\d+)x(\d+)\+(-?\d+)\+(-?\d+)",
                            line,
                        )
                        if not m:
                            continue
                        monitors.append(
                            {
                                "x": int(m.group(4)),
                                "y": int(m.group(5)),
                                "w": int(m.group(2)),
                                "h": int(m.group(3)),
                                "primary": bool(m.group(1)),
                            }
                        )
            except Exception:
                monitors = []

        if not monitors:
            monitors = [
                {
                    "x": 0,
                    "y": 0,
                    "w": int(self.win.winfo_screenwidth()),
                    "h": int(self.win.winfo_screenheight()),
                    "primary": True,
                }
            ]
        return monitors

    @staticmethod
    def _pick_monitor(monitors, px, py):
        for mon in monitors:
            x0 = mon["x"]
            y0 = mon["y"]
            x1 = x0 + mon["w"]
            y1 = y0 + mon["h"]
            if x0 <= px < x1 and y0 <= py < y1:
                return mon
        for mon in monitors:
            if mon.get("primary"):
                return mon
        return monitors[0]

    def _center(self, width, height):
        try:
            self.win.update_idletasks()
            px = int(self.win.winfo_pointerx())
            py = int(self.win.winfo_pointery())
            monitor = self._pick_monitor(self._detect_monitors(), px, py)
            x = monitor["x"] + (monitor["w"] - width) // 2
            y = monitor["y"] + (monitor["h"] - height) // 2
            self.win.geometry(f"{width}x{height}+{x}+{y}")
        except Exception:
            pass

    def _tick_spinner(self):
        if not self._running:
            return
        try:
            self._angle = (self._angle + 16) % 360
            self.spinner.itemconfigure(self._spinner_arc, start=self._angle)
            self.win.after(40, self._tick_spinner)
        except Exception:
            pass

    def _rotate_tip(self):
        if not self._running or not self._tips:
            return
        self.tip_var.set(self._tips[self._tip_index % len(self._tips)])
        self._tip_index += 1
        try:
            self.win.after(2400, self._rotate_tip)
        except Exception:
            pass

    def _flush(self):
        try:
            self.win.update_idletasks()
            self.win.update()
        except Exception:
            pass

    def set_message(self, message):
        if not self._running:
            return
        self.detail_var.set(str(message))
        self._flush()

    def run_task(self, message, fn):
        """Run a blocking task while keeping splash animations responsive."""
        result = {"value": None, "error": None}
        done = threading.Event()

        def _worker():
            try:
                result["value"] = fn()
            except Exception as e:
                result["error"] = e
            finally:
                done.set()

        self.set_message(message)
        threading.Thread(target=_worker, daemon=True).start()
        while not done.wait(0.04):
            self._flush()
        if result["error"] is not None:
            raise result["error"]
        return result["value"]

    def close(self, min_visible_ms=700):
        if min_visible_ms and self._running:
            elapsed_ms = (time.monotonic() - self._shown_at) * 1000.0
            remaining = int(max(0, min_visible_ms - elapsed_ms))
            if remaining > 0:
                end = time.monotonic() + (remaining / 1000.0)
                while time.monotonic() < end:
                    self._flush()
                    time.sleep(0.01)
        self._running = False
        try:
            self.progress.stop()
        except Exception:
            pass
        try:
            self.win.destroy()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Main application
# ---------------------------------------------------------------------------

class SysfixApp:
    """Professional feature-rich Sysfix GUI."""

    _CHAT_CACHE_KEY = "gui_chat_threads_v1"
    _MAX_CHAT_THREADS = 18
    _MAX_CHAT_MESSAGES = 80

    # ── Initialization ──────────────────────────────────────────────────

    def __init__(self, root, startup_feedback=None, startup_data=None):
        self.root = root
        if is_licence_valid():
            self.root.title("Sysfix Pro — Diagnostics \u2022 Security \u2022 AI Repair")
        else:
            self.root.title("Sysfix — Diagnostics \u2022 Security \u2022 AI Repair")
        self.root.geometry("1200x800")
        self.root.minsize(1000, 700)
        self._startup_feedback = startup_feedback
        self._startup_data = startup_data if isinstance(startup_data, dict) else {}
        self._startup_step("Loading Fyxa assets...")

        self.load_mascot()
        self._startup_step("Loading settings...")
        self.config = load_config()
        self.settings_vars = {}
        self.is_sudo = os.geteuid() == 0 if hasattr(os, "geteuid") else False

        # Theme
        self._current_theme = self.config.get("theme", "frutiger_aero")
        if self._current_theme not in THEMES:
            self._current_theme = "frutiger_aero"

        # Restore saved model preference (respect user's choice, including cloud)
        saved_model = self.config.get("ai_model", "")
        if saved_model:
            set_active_model(saved_model)
        set_active_provider(self.config.get("ai_provider", "auto"))
        self._startup_step("Restoring conversations...")

        # Chat state
        self._conversations = {}
        self._conversation_order = []
        self._active_chat_id = None
        self._conversation_lock = threading.Lock()
        self.chat_history = []          # {"role": "user"|"assistant", "content": str}
        self._is_thinking = False
        self._thinking_frame = 0
        self._is_processing = False     # guard against concurrent sends
        self._last_ai_response = ""     # for command extraction from history
        self._chat_selector_labels = {}
        self._chat_selector_var = None
        self._chat_selector = None
        self._chat_listbox = None
        self._suspend_chat_select_events = False
        self._chat_context_menu = None
        self._link_tag_counter = 0
        self._active_tasks = 0
        self._command_auto_accept = False
        self._pending_command_requests = {}
        self._pending_command_order = []
        self._command_request_widgets = {}
        self._last_exec_by_chat = {}
        self._revert_widgets = {}
        self._command_execution_active = False
        self._status_reset_after_id = None
        self._stats_after_id = None
        self._gauge_anim_after_id = None
        self._gauge_targets = {}
        self._gauge_display = {}
        self._quick_actions = {}
        # Sidebar state
        self._sidebar_expanded = True
        self._sidebar_width_expanded = 200
        self._sidebar_width_collapsed = 48
        self._sidebar_alert_after_ids = {}  # tab_index → after_id for pulsing
        self._init_conversations()

        self._startup_step("Applying visual theme...")
        self.configure_styles()
        self._apply_material_effects()
        self._startup_step("Building interface...")
        self.create_header()
        self.create_update_banner()
        self.create_notebook()
        self.create_status_bar()
        self._setup_quick_actions()

        self._startup_step("Binding shortcuts...")
        # Keyboard shortcuts
        self.root.bind("<Control-d>", lambda _e: self._run_threaded(self.scan_issues))
        self.root.bind("<Control-l>", lambda _e: self.clear_chat())
        self.root.bind("<Control-q>", lambda _e: self.root.quit())
        self.root.bind("<Control-k>", lambda _e: self._open_command_palette())
        self.root.bind("<Control-K>", lambda _e: self._open_command_palette())
        self.root.bind("<F5>", lambda _e: self.check_initial_status())
        for idx in range(1, 8):
            self.root.bind(
                f"<Control-Key-{idx}>",
                lambda _e, tab_index=idx - 1: self._select_tab(tab_index),
            )

        self._startup_step("Starting diagnostics...")
        self.check_initial_status()
        self._start_live_stats()
        self._start_realtime_antivirus()
        self._start_system_pulse()
        self._start_heartbeat()
        self._apply_startup_preflight_results()
        self._check_pro_on_startup()
        self._startup_step("Ready")

    def _start_realtime_antivirus(self):
        """Start a background thread that periodically monitors ~/Downloads for new files
        and scans them against malware hash databases."""
        self._realtime_av_running = True
        self._realtime_av_seen = set()

        def _monitor():
            downloads = Path.home() / "Downloads"
            if not downloads.is_dir():
                return
            # Seed with existing files so we only scan NEW arrivals
            try:
                self._realtime_av_seen = {str(p) for p in downloads.iterdir() if p.is_file()}
            except Exception:
                pass
            while self._realtime_av_running:
                try:
                    time.sleep(8)
                    if not downloads.is_dir():
                        continue
                    current = {str(p) for p in downloads.iterdir() if p.is_file()}
                    new_files = current - self._realtime_av_seen
                    self._realtime_av_seen = current
                    for fpath in new_files:
                        try:
                            results = scan_file_hash(fpath)
                            threats = [r for r in results if "MALWARE" in r or "THREAT" in r.upper()]
                            if threats:
                                self._safe(
                                    self._notify,
                                    "Threat Detected",
                                    f"Suspicious file in Downloads:\n{Path(fpath).name}\n" + "\n".join(threats[:3]),
                                    level="danger",
                                )
                            else:
                                self._safe(
                                    self._set_status,
                                    f"Scanned new download: {Path(fpath).name} — clean",
                                    "ok",
                                    3000,
                                )
                        except Exception:
                            pass
                except Exception:
                    time.sleep(15)

        self._realtime_av_thread = threading.Thread(target=_monitor, daemon=True)
        self._realtime_av_thread.start()

    def _start_system_pulse(self):
        """Auto-start the System Pulse telemetry daemon on GUI launch."""
        try:
            start_pulse(interval=5.0)
            register_callback(self._on_pulse_update)
        except Exception:
            pass  # Non-critical — pulse is best-effort

    def _start_heartbeat(self):
        """Start the Heartbeat system-awareness daemon and wire proactive alerts."""
        try:
            hb = get_heartbeat()
            hb.register_alert_cb(self._on_heartbeat_alert)
            start_heartbeat(interval=3.0)
        except Exception:
            pass  # Non-critical

    def _on_heartbeat_alert(self, alert):
        """Callback from Heartbeat: pulse the relevant sidebar icon."""
        try:
            self._safe(lambda: self._pulse_sidebar_icon(
                alert.tab_index, alert.severity, alert.message
            ))
        except Exception:
            pass

    def _pulse_sidebar_icon(self, tab_index, severity, message):
        """Animate a pulsing neon glow on a sidebar nav button for an active alert."""
        if not hasattr(self, "_nav_buttons") or tab_index >= len(self._nav_buttons):
            return

        row = self._nav_buttons[tab_index]
        children = row.winfo_children()
        icon_lbl = children[0] if children else None
        text_lbl = (self._nav_labels[tab_index]
                    if hasattr(self, "_nav_labels") and tab_index < len(self._nav_labels)
                    else None)
        glow_color = {
            "critical": self.danger_color,
            "warn": self.warning_color,
            "info": self.accent_color,
        }.get(severity, self.accent_color)

        # Cancel any existing pulse on this button
        old_id = self._sidebar_alert_after_ids.get(tab_index)
        if old_id:
            try:
                self.root.after_cancel(old_id)
            except Exception:
                pass

        # Pulse animation: alternate glow colour 6 times over 3 seconds
        pulse_count = [0]

        def _set_nav_colors(bg, fg):
            row.config(bg=bg)
            if icon_lbl:
                icon_lbl.config(bg=bg)
                # Swap PIL icon to the new colour
                if hasattr(self, "_nav_icon_names") and tab_index < len(self._nav_icon_names):
                    photo = self._get_nav_icon(self._nav_icon_names[tab_index], fg)
                    if photo:
                        icon_lbl.config(image=photo)
                else:
                    try:
                        icon_lbl.config(fg=fg)
                    except tk.TclError:
                        pass
            if text_lbl:
                text_lbl.config(bg=bg, fg=fg)

        def _do_pulse():
            if pulse_count[0] >= 8:
                # Restore normal state
                try:
                    active_idx = self.notebook.index(self.notebook.select())
                except Exception:
                    active_idx = -1
                if tab_index == active_idx:
                    _set_nav_colors(
                        self._mix_hex(self.bg_secondary, self.accent_color, 0.70),
                        self.accent_color,
                    )
                else:
                    _set_nav_colors(self.bg_secondary, self.text_dim)
                self._sidebar_alert_after_ids.pop(tab_index, None)
                return
            if pulse_count[0] % 2 == 0:
                _set_nav_colors(
                    self._mix_hex(self.bg_secondary, glow_color, 0.40),
                    glow_color,
                )
            else:
                _set_nav_colors(self.bg_secondary, self.text_dim)
            pulse_count[0] += 1
            after_id = self.root.after(375, _do_pulse)
            self._sidebar_alert_after_ids[tab_index] = after_id

        _do_pulse()

    def _startup_step(self, message):
        if not callable(self._startup_feedback):
            return
        try:
            self._startup_feedback(message)
        except Exception:
            pass

    @staticmethod
    def _extract_update_banner_message(results):
        entries = [str(x) for x in (results or [])]
        hit = next((r for r in entries if "update available" in r.lower()), "")
        return hit.strip() or ""

    def _apply_startup_preflight_results(self):
        """Consume startup checks done during the splash screen."""
        startup = self._startup_data or {}
        self._startup_data = {}

        integrity = [str(x) for x in (startup.get("integrity_results") or [])]
        update_results = [str(x) for x in (startup.get("update_results") or [])]

        # Integrity warnings/errors should be visible immediately.
        integrity_problems = [
            line for line in integrity
            if line.startswith("WARN:") or line.startswith("ERROR:")
        ]
        if integrity_problems:
            preview = "\n".join(integrity_problems[:6])
            self.root.after(
                450,
                lambda: messagebox.showwarning(
                    "Sysfix File Integrity",
                    "Startup integrity check found potential issues:\n\n"
                    f"{preview}",
                ),
            )
            self._set_status("Integrity check reported warnings", "warn", timeout=4200)
        elif integrity:
            self._set_status("Integrity check passed", "ok", timeout=1800)

        # Use startup update results if available; otherwise use background check.
        banner_msg = self._extract_update_banner_message(update_results)
        if banner_msg:
            self._show_update_banner(banner_msg)
        elif self.config.get("auto_check_updates_on_startup", True):
            self._check_for_updates_on_startup()

    # ── Mascot ──────────────────────────────────────────────────────────

    def load_mascot(self):
        if not HAS_PIL:
            self.header_icon = None
            return
        try:
            assets_dir = Path(__file__).parent.parent / "assets"
            icon_path = assets_dir / "icon_256.png"
            if not icon_path.exists():
                from sysfixai.mascot import save_mascot
                save_mascot()
            if icon_path.exists():
                icon_image = Image.open(icon_path)
                icon_photo = ImageTk.PhotoImage(icon_image)
                self.root.iconphoto(False, icon_photo)
                self.icon_photo = icon_photo
                header_icon = Image.open(icon_path).resize((56, 56), Image.Resampling.LANCZOS)
                self.header_icon = ImageTk.PhotoImage(header_icon)
            else:
                self.header_icon = None
        except Exception:
            self.header_icon = None

    # ── Styles ──────────────────────────────────────────────────────────

    def configure_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        # Load colours from selected theme
        t = THEMES.get(self._current_theme, THEMES["frutiger_aero"])
        self.bg_color         = t["bg_color"]
        self.bg_secondary     = t["bg_secondary"]
        self.bg_tertiary      = t["bg_tertiary"]
        self.header_color     = t["header_color"]
        self.accent_color     = t["accent_color"]
        self.accent_secondary = t["accent_secondary"]
        self.metallic_light   = t["metallic_light"]
        self.success_color    = t["success_color"]
        self.warning_color    = t["warning_color"]
        self.danger_color     = t["danger_color"]
        self.button_hover     = t["button_hover"]
        self.text_color       = t["text_color"]
        self.text_dim         = t["text_dim"]
        self.border_color     = t["border_color"]
        self.glass_white      = t["glass_white"]
        self.glass_tint       = t["glass_tint"]
        self.button_fg        = t["button_fg"]
        self.hdr_title_fg     = t["hdr_title_fg"]
        self.hdr_subtitle_fg  = t["hdr_subtitle_fg"]
        self.hdr_ai_on        = t["hdr_ai_on"]
        self.hdr_ai_off       = t["hdr_ai_off"]
        self.hdr_web_fg       = t["hdr_web_fg"]
        self.hdr_admin_fg     = t["hdr_admin_fg"]
        self.hdr_user_fg      = t["hdr_user_fg"]
        self.tooltip_bg       = t["tooltip_bg"]
        self.tooltip_fg       = t["tooltip_fg"]
        self.tab_selected_bg  = t["tab_selected_bg"]
        self.chat_fyxa_fg     = t["chat_fyxa_fg"]
        self.window_alpha     = float(t.get("window_alpha", 1.0))
        self.texture_strength = float(t.get("texture_strength", 0.18))
        self.glass_panel_bg   = self._mix_hex(self.glass_white, self.bg_color, 0.84)

        # Brutalist theme uses monospace fonts for the HUD aesthetic
        self._is_brutalist = (self._current_theme == "brutalist")
        _tab_font = ("Noto Sans Mono", 10, "bold") if self._is_brutalist else ("Noto Sans", 11)
        _label_font = ("Noto Sans Mono", 10) if self._is_brutalist else ("Noto Sans", 10)

        self.root.configure(bg=self.bg_color)

        style.configure("TNotebook",     background=self.bg_color, borderwidth=0, relief="flat")
        style.configure("TNotebook.Tab", padding=[18, 10], font=_tab_font,
                        relief="flat", borderwidth=0,
                        background=self.bg_color, foreground=self.text_dim)
        style.map("TNotebook.Tab",
                  background=[("selected", self.tab_selected_bg)],
                  foreground=[("selected", self.accent_color)])
        style.configure("TFrame", background=self.bg_color, relief="flat", borderwidth=0)
        style.configure("TLabel", background=self.bg_color, foreground=self.metallic_light,
                        font=_label_font)
        style.configure("Vertical.TScrollbar",
                        background=self._mix_hex(self.border_color, self.bg_color, 0.50),
                        troughcolor=self.bg_color,
                        borderwidth=0, relief="flat", width=8,
                        arrowsize=0)
        style.map("Vertical.TScrollbar",
                  background=[("active", self._mix_hex(self.accent_color, self.border_color, 0.50))])
        style.configure(
            "Quick.TCombobox",
            fieldbackground=self.glass_white,
            background=self.glass_white,
            foreground=self.text_color,
            arrowcolor=self.accent_color,
            arrowsize=13,
        )
        style.map(
            "Quick.TCombobox",
            fieldbackground=[("readonly", self.glass_white)],
            selectbackground=[("readonly", self.glass_white)],
            selectforeground=[("readonly", self.text_color)],
        )

    # ── Helper: thread-safe widget updates ──────────────────────────────

    def _safe(self, func, *args, **kwargs):
        """Schedule *func* on the Tk main-loop (thread-safe)."""
        self.root.after(0, lambda: func(*args, **kwargs))

    def _task_label(self, func):
        name = getattr(func, "__name__", "task")
        friendly = {
            "scan_issues": "Running diagnostics",
            "_run_security_scan": "Running security scan",
            "_run_update_check": "Checking updates",
            "_run_apply_updates": "Applying updates",
            "_run_sysfix_update_check": "Checking Sysfix updates",
            "_run_network_diag": "Running network diagnostics",
            "_run_full_network_report": "Building full network report",
            "_run_system_health": "Checking system health",
            "_get_ai_response": "Fyxa is thinking",
            "_run_commands": "Executing commands",
        }
        if name in friendly:
            return friendly[name]
        return name.strip("_").replace("_", " ").capitalize()

    def _run_threaded(self, func, *args, task_label=None):
        label = task_label or self._task_label(func)

        def _worker():
            self._safe(self._task_started, label)
            ok = True
            try:
                func(*args)
            except Exception as e:
                ok = False
                self._safe(self._set_status, f"Error: {e}", "err", 4500)
            finally:
                self._safe(self._task_finished, label, ok)

        threading.Thread(target=_worker, daemon=True).start()

    def _set_status(self, text, level="info", timeout=0):
        colors = {
            "info": self.text_dim,
            "ok": self.success_color,
            "warn": self.warning_color,
            "err": self.danger_color,
            "working": self.accent_color,
        }
        if hasattr(self, "_sb_status"):
            self._sb_status.config(text=text, fg=colors.get(level, self.text_dim))
        if self._status_reset_after_id:
            try:
                self.root.after_cancel(self._status_reset_after_id)
            except Exception:
                pass
            self._status_reset_after_id = None
        if timeout and hasattr(self, "_sb_status"):
            self._status_reset_after_id = self.root.after(
                timeout, lambda: self._set_status("Ready", "info")
            )

    def _refresh_ai_status_label(self):
        """Refresh header AI provider status indicator."""
        try:
            state = get_ai_runtime_status()
            online = bool(state.get("online"))
            label = state.get("label", "AI")
            text = f"● {label}" if online else f"● {label} Offline"
            self._ai_status_label.config(
                text=text,
                fg=self.hdr_ai_on if online else self.hdr_ai_off,
            )
            if hasattr(self, "_ai_status_tip"):
                self._ai_status_tip.text = state.get("detail", "AI provider status")
        except Exception:
            pass

    # ── Desktop notifications ───────────────────────────────────────────

    def _notify(self, title, message, level="info", timeout=6000):
        """Show a desktop notification (toast) using notify-send, plus a status bar update.

        Also displays an in-app toast with spring slide-in animation for
        immediate feedback when the GUI is focused.
        """
        level_map = {"info": "info", "ok": "ok", "warn": "warn", "danger": "err", "err": "err"}
        self._set_status(f"{title}: {message[:80]}", level_map.get(level, "info"), timeout=timeout)
        # In-app toast overlay with spring animation
        self._show_toast_overlay(title, message, level, timeout)
        # Try native desktop notification
        try:
            urgency = {"danger": "critical", "err": "critical", "warn": "normal"}.get(level, "low")
            subprocess.Popen(
                ["notify-send", "-u", urgency, "-a", "Sysfix", title, message[:256]],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass  # notify-send may not be installed; status bar is the fallback

    def _show_toast(self, message, level="info", timeout=5000):
        """Convenience wrapper — shows a toast with an auto-generated title."""
        title_map = {
            "info": "Info",
            "ok": "Success",
            "warn": "Warning",
            "danger": "Error",
            "err": "Error",
        }
        title = title_map.get(level, "Notice")
        self._show_toast_overlay(title, message, level=level, timeout=timeout)

    def _show_toast_overlay(self, title, message, level="info", timeout=5000):
        """Display an in-app toast notification with spring slide-in."""
        try:
            color_map = {
                "info":   self.accent_color,
                "ok":     self.success_color,
                "warn":   self.warning_color,
                "danger": self.danger_color,
                "err":    self.danger_color,
            }
            accent = color_map.get(level, self.accent_color)

            toast = tk.Toplevel(self.root)
            toast.overrideredirect(True)
            toast.attributes("-topmost", True)
            toast.configure(bg=accent)

            tw = 380
            th = 64
            rx = self.root.winfo_x() + self.root.winfo_width() - tw - 24
            ry = self.root.winfo_y() + 92
            toast.geometry(f"{tw}x{th}+{rx}+{ry}")

            inner = tk.Frame(toast, bg=self.bg_secondary)
            inner.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

            tk.Label(
                inner, text=title, font=("Noto Sans", 9, "bold"),
                bg=self.bg_secondary, fg=accent, anchor="w",
            ).pack(fill=tk.X, padx=10, pady=(8, 0))
            tk.Label(
                inner, text=message[:120], font=("Noto Sans", 8),
                bg=self.bg_secondary, fg=self.text_color, anchor="w",
                wraplength=tw - 30,
            ).pack(fill=tk.X, padx=10, pady=(0, 8))

            # Spring slide-in from right
            try:
                from sysfixai.ui_enhancements import UIPhysics
                UIPhysics.fade_in(toast, stiffness=340, damping=16)
            except Exception:
                toast.attributes("-alpha", 1.0)

            # Auto-dismiss
            def _dismiss():
                try:
                    from sysfixai.ui_enhancements import UIPhysics
                    UIPhysics.fade_out(toast, on_complete=lambda: toast.destroy())
                except Exception:
                    toast.destroy()

            toast.after(min(timeout, 8000), _dismiss)
            toast.bind("<Button-1>", lambda _e: toast.destroy())
        except Exception:
            pass  # Best-effort — status bar is always the fallback

    # ── AI keyword intelligence ─────────────────────────────────────────

    _TOPIC_KEYWORDS = {
        "wifi": {
            "triggers": ("wifi", "wi-fi", "wireless", "wlan", "ssid", "bssid", "signal", "router", "hotspot", "access point"),
            "context_fn": "_get_wifi_context",
        },
        "network": {
            "triggers": ("network", "internet", "dns", "gateway", "ping", "latency", "bandwidth", "firewall", "vpn", "proxy"),
            "context_fn": "_get_network_context",
        },
        "security": {
            "triggers": ("security", "virus", "malware", "firewall", "rootkit", "suid", "antivirus", "vulnerability", "hack"),
            "context_fn": "_get_security_context",
        },
        "performance": {
            "triggers": ("slow", "lag", "freeze", "hang", "performance", "cpu", "ram", "memory", "swap", "overheat", "thermal", "temperature"),
            "context_fn": "_get_performance_context",
        },
        "disk": {
            "triggers": ("disk", "storage", "ssd", "hdd", "nvme", "partition", "mount", "space", "full disk"),
            "context_fn": "_get_disk_context",
        },
        "gpu": {
            "triggers": ("gpu", "nvidia", "amd", "radeon", "graphics", "vulkan", "opengl", "cuda", "mesa"),
            "context_fn": "_get_gpu_context",
        },
    }

    def _detect_topic_keywords(self, message):
        """Detect relevant topics from user message and gather extra system context."""
        msg_lower = message.lower()
        extra_contexts = []
        for topic, info in self._TOPIC_KEYWORDS.items():
            if any(kw in msg_lower for kw in info["triggers"]):
                fn = getattr(self, info["context_fn"], None)
                if callable(fn):
                    try:
                        ctx = fn()
                        if ctx:
                            extra_contexts.append(f"[Auto-detected topic: {topic}]\n{ctx}")
                    except Exception:
                        pass
        return "\n\n".join(extra_contexts)

    def _get_wifi_context(self):
        try:
            results = check_wifi_info()
            return "\n".join(results) if results else ""
        except Exception:
            return ""

    def _get_network_context(self):
        try:
            parts = []
            parts.extend(check_network_interfaces())
            parts.extend(check_dns_resolution())
            parts.extend(check_internet_connectivity())
            return "\n".join(parts[:20]) if parts else ""
        except Exception:
            return ""

    def _get_security_context(self):
        try:
            from sysfixai.diagnostics import check_firewall_status, check_listening_ports
            parts = []
            parts.extend(check_firewall_status())
            parts.extend(check_listening_ports())
            return "\n".join(parts[:15]) if parts else ""
        except Exception:
            return ""

    def _get_performance_context(self):
        if not HAS_PSUTIL:
            return ""
        try:
            cpu = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            temps = psutil.sensors_temperatures() if hasattr(psutil, 'sensors_temperatures') else {}
            parts = [
                f"CPU: {cpu}%",
                f"RAM: {mem.percent}% used ({mem.used // (1024**2)}MB / {mem.total // (1024**2)}MB)",
                f"Swap: {psutil.swap_memory().percent}% used",
            ]
            for name, entries in temps.items():
                for e in entries[:2]:
                    parts.append(f"Temp {name}/{e.label or 'core'}: {e.current}°C")
            return "\n".join(parts)
        except Exception:
            return ""

    def _get_disk_context(self):
        if not HAS_PSUTIL:
            return ""
        try:
            parts = []
            for p in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(p.mountpoint)
                    pct = usage.percent
                    parts.append(f"{p.mountpoint}: {pct}% used ({usage.used // (1024**3)}GB / {usage.total // (1024**3)}GB) [{p.fstype}]")
                except Exception:
                    pass
            return "\n".join(parts[:8]) if parts else ""
        except Exception:
            return ""

    def _get_gpu_context(self):
        try:
            r = subprocess.run(["nvidia-smi", "--query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total", "--format=csv,noheader"],
                               capture_output=True, text=True, timeout=5, stdin=subprocess.DEVNULL)
            if r.returncode == 0 and r.stdout.strip():
                return f"NVIDIA GPU: {r.stdout.strip()}"
        except Exception:
            pass
        try:
            r = subprocess.run(["lspci"], capture_output=True, text=True, timeout=5, stdin=subprocess.DEVNULL)
            if r.returncode == 0:
                gpus = [l for l in r.stdout.splitlines() if "VGA" in l or "3D" in l or "Display" in l]
                return "\n".join(gpus[:3]) if gpus else ""
        except Exception:
            return ""
        except Exception:
            try:
                self._ai_status_label.config(text="● AI Offline", fg=self.hdr_ai_off)
            except Exception:
                pass

    def _task_started(self, label):
        self._active_tasks += 1
        if hasattr(self, "_sb_busy"):
            try:
                self._sb_busy.start(12)
            except Exception:
                pass
        self._set_status(label, "working")

    def _task_finished(self, label, ok):
        self._active_tasks = max(0, self._active_tasks - 1)
        if self._active_tasks == 0 and hasattr(self, "_sb_busy"):
            try:
                self._sb_busy.stop()
            except Exception:
                pass
        if ok:
            if self._active_tasks == 0:
                self._set_status(f"{label} complete", "ok", timeout=1600)
            else:
                self._set_status(f"{self._active_tasks} task(s) still running", "working")
        else:
            self._set_status(f"{label} failed", "err", timeout=4500)

    def _add_hover(self, btn, normal_bg, hover_bg):
        btn.bind("<Enter>", lambda _: btn.config(bg=hover_bg))
        btn.bind("<Leave>", lambda _: btn.config(bg=normal_bg))

    def _make_button(self, parent, text, command, bg=None, tooltip=None, **kw):
        """Create a styled, hover-enabled button with optional tooltip."""
        # Pop potentially duplicated kwargs before merging to avoid
        # "got multiple values for keyword argument" crashes.
        bg = kw.pop("bg", None) or bg or self.accent_color
        fg = kw.pop("fg", self.button_fg)
        font = kw.pop("font", ("Noto Sans", 9, "bold"))
        padx = kw.pop("padx", 12)
        pady = kw.pop("pady", 8)
        hover = self._lighter(bg)
        btn_opts = {
            "text": text,
            "command": command,
            "bg": bg,
            "fg": fg,
            "font": font,
            "padx": padx,
            "pady": pady,
            "relief": "flat",
            "cursor": "hand2",
            "bd": 0,
            "highlightthickness": 0,
            "overrelief": "flat",
            "activebackground": hover,
            "activeforeground": fg,
        }
        # Allow callers to override any remaining defaults safely.
        btn_opts.update(kw)
        btn = tk.Button(parent, **btn_opts)
        self._add_hover(btn, bg, hover)
        # NOTE: UIPhysics.hover_bounce → spring_scale uses
        # configure(width=...) which is in text units for tk.Button,
        # not pixels — calling it with winfo_width() (pixels) makes
        # buttons grow to hundreds of characters.  Disabled.
        if tooltip:
            ToolTip(btn, tooltip, bg=self.tooltip_bg, fg=self.tooltip_fg)
        return btn

    @staticmethod
    def _lighter(hex_color, amount=30):
        """Return a slightly lighter shade of *hex_color*."""
        r, g, b = int(hex_color[1:3], 16), int(hex_color[3:5], 16), int(hex_color[5:7], 16)
        r = min(255, r + amount)
        g = min(255, g + amount)
        b = min(255, b + amount)
        return f"#{r:02x}{g:02x}{b:02x}"

    @staticmethod
    def _hex_to_rgb(hex_color):
        h = hex_color.lstrip("#")
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

    @staticmethod
    def _rgb_to_hex(rgb):
        r, g, b = rgb
        return f"#{int(r):02x}{int(g):02x}{int(b):02x}"

    @classmethod
    def _mix_hex(cls, c1, c2, ratio=0.5):
        ratio = max(0.0, min(1.0, float(ratio)))
        a = cls._hex_to_rgb(c1)
        b = cls._hex_to_rgb(c2)
        mixed = (
            a[0] * ratio + b[0] * (1.0 - ratio),
            a[1] * ratio + b[1] * (1.0 - ratio),
            a[2] * ratio + b[2] * (1.0 - ratio),
        )
        return cls._rgb_to_hex(mixed)

    def _apply_material_effects(self):
        self._apply_window_alpha()
        self._setup_liquid_glass_background()

    def _apply_window_alpha(self):
        try:
            self.root.wm_attributes("-alpha", self.window_alpha)
        except Exception:
            pass

    def _setup_liquid_glass_background(self):
        if hasattr(self, "_bg_texture_job") and self._bg_texture_job:
            try:
                self.root.after_cancel(self._bg_texture_job)
            except Exception:
                pass
            self._bg_texture_job = None

        if not hasattr(self, "_bg_texture_label") or not self._bg_texture_label.winfo_exists():
            self._bg_texture_label = tk.Label(self.root, bg=self.bg_color, bd=0, highlightthickness=0)
            self._bg_texture_label.place(x=0, y=0, relwidth=1, relheight=1)

        self._bg_texture_label.lower()

        if not getattr(self, "_bg_texture_bound", False):
            self.root.bind("<Configure>", self._on_root_configure_material, add=True)
            self._bg_texture_bound = True

        self._refresh_liquid_glass_background()

    def _on_root_configure_material(self, event):
        if event.widget is not self.root:
            return
        if hasattr(self, "_bg_texture_job") and self._bg_texture_job:
            try:
                self.root.after_cancel(self._bg_texture_job)
            except Exception:
                pass
        self._bg_texture_job = self.root.after(80, self._refresh_liquid_glass_background)

    def _refresh_liquid_glass_background(self):
        self._bg_texture_job = None
        if not hasattr(self, "_bg_texture_label"):
            return
        if not HAS_PIL:
            self._bg_texture_label.config(bg=self.bg_color, image="")
            self._bg_texture_label.lower()
            return

        w = max(640, int(self.root.winfo_width() or 0))
        h = max(480, int(self.root.winfo_height() or 0))
        try:
            image = self._build_liquid_glass_texture(w, h)
            self._bg_texture_photo = ImageTk.PhotoImage(image)
            self._bg_texture_label.config(image=self._bg_texture_photo, bg=self.bg_color)
            self._bg_texture_label.lower()
        except Exception:
            self._bg_texture_label.config(bg=self.bg_color, image="")
            self._bg_texture_label.lower()

    def _build_liquid_glass_texture(self, w, h):
        top = self._hex_to_rgb(self._lighter(self.bg_color, 18))
        mid = self._hex_to_rgb(self.glass_tint)
        bottom = self._hex_to_rgb(self.bg_secondary)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 255))
        draw = ImageDraw.Draw(img)
        for y in range(h):
            t = y / max(1, h - 1)
            if t < 0.58:
                k = t / 0.58
                rgb = (
                    int(top[0] * (1 - k) + mid[0] * k),
                    int(top[1] * (1 - k) + mid[1] * k),
                    int(top[2] * (1 - k) + mid[2] * k),
                )
            else:
                k = (t - 0.58) / 0.42
                rgb = (
                    int(mid[0] * (1 - k) + bottom[0] * k),
                    int(mid[1] * (1 - k) + bottom[1] * k),
                    int(mid[2] * (1 - k) + bottom[2] * k),
                )
            draw.line([(0, y), (w, y)], fill=(*rgb, 255))

        overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        accent = self._hex_to_rgb(self.accent_color)
        od.ellipse(
            (-int(0.24 * w), -int(0.28 * h), int(0.62 * w), int(0.50 * h)),
            fill=(255, 255, 255, 70),
        )
        od.ellipse(
            (int(0.30 * w), -int(0.22 * h), int(1.26 * w), int(0.56 * h)),
            fill=(accent[0], accent[1], accent[2], 36),
        )
        od.ellipse(
            (-int(0.10 * w), int(0.44 * h), int(0.96 * w), int(1.24 * h)),
            fill=(255, 255, 255, 28),
        )
        blur_r = max(14, min(w, h) // 34)
        overlay = overlay.filter(ImageFilter.GaussianBlur(blur_r))
        img.alpha_composite(overlay)

        # Fine grain for tactile "liquid glass" texture.
        noise_alpha = int(16 + 44 * self.texture_strength)
        noise = Image.effect_noise((w, h), 6.5)
        noise = noise.point(lambda p: max(105, min(150, int(122 + (p - 128) * 0.45))))
        noise_rgba = Image.merge("RGBA", (noise, noise, noise, Image.new("L", (w, h), noise_alpha)))
        img.alpha_composite(noise_rgba)

        return img.convert("RGB")

    def _apply_glass_grain(self, parent, base_color=None):
        """Add subtle procedural grain/highlight overlays to a frame."""
        base = base_color or self.glass_panel_bg
        layer = tk.Canvas(parent, bg=base, highlightthickness=0, bd=0)
        layer.place(relx=0, rely=0, relwidth=1, relheight=1)
        # Canvas.lower() is for canvas items; lower the canvas widget itself via Tk.
        try:
            layer.tk.call("lower", layer._w)
        except Exception:
            pass

        hi = self._mix_hex(self.glass_white, base, 0.82)
        lo = self._mix_hex(self.bg_secondary, base, 0.72)

        def _redraw(_event=None):
            w = max(2, int(parent.winfo_width()))
            h = max(2, int(parent.winfo_height()))
            layer.delete("grain")
            layer.create_rectangle(0, 0, w, h, fill=base, outline="", tags="grain")
            try:
                layer.create_rectangle(0, 0, w, h, fill=hi, outline="", stipple="gray50", tags="grain")
                layer.create_rectangle(0, 0, w, h, fill=lo, outline="", stipple="gray75", tags="grain")
                layer.create_oval(
                    -int(0.25 * w), -int(0.85 * h), int(0.80 * w), int(0.38 * h),
                    fill=self._lighter(self.glass_white, 18), outline="", stipple="gray25", tags="grain",
                )
            except Exception:
                # Some Tk builds may not support stipple patterns consistently.
                layer.create_rectangle(0, 0, w, max(2, int(0.22 * h)),
                                       fill=self._lighter(self.glass_white, 14),
                                       outline="", tags="grain")

        parent.bind("<Configure>", _redraw, add=True)
        _redraw()
        return layer

    def _create_action_deck(self, parent, title, actions, run_bg=None, hint=None, default=None):
        """Create a compact action picker to reduce button clutter.

        actions: list of tuples (label, callback, tooltip_text)
        """
        if not actions:
            return None

        deck = tk.Frame(parent, bg=self._mix_hex(self.border_color, self.accent_color, 0.75))
        deck.pack(fill=tk.X, padx=20, pady=(0, 10))

        inner = tk.Frame(deck, bg=self.glass_panel_bg)
        inner.pack(fill=tk.X, padx=1, pady=1)
        self._apply_glass_grain(inner, self.glass_panel_bg)
        tk.Frame(inner, bg=self._lighter(self.glass_white, 16), height=2).pack(fill=tk.X)
        tk.Frame(inner, bg=self._mix_hex(self.glass_tint, self.accent_color, 0.86), height=1).pack(fill=tk.X)

        header = tk.Frame(inner, bg=self.glass_panel_bg)
        header.pack(fill=tk.X, padx=12, pady=(10, 6))
        tk.Label(
            header,
            text=title,
            font=("Noto Sans", 10, "bold"),
            bg=self.glass_panel_bg,
            fg=self.metallic_light,
        ).pack(side=tk.LEFT)

        row = tk.Frame(inner, bg=self.glass_panel_bg)
        row.pack(fill=tk.X, padx=12, pady=(0, 10))

        labels = [x[0] for x in actions]
        action_map = {x[0]: (x[1], x[2] if len(x) > 2 else "") for x in actions}

        var = tk.StringVar(value=default or labels[0])
        combo = ttk.Combobox(
            row,
            textvariable=var,
            state="readonly",
            values=labels,
            style="Quick.TCombobox",
            font=("Noto Sans", 10),
        )
        combo.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))

        def _run_selected():
            selected = var.get().strip()
            if not selected:
                return
            action = action_map.get(selected)
            if not action:
                return
            fn = action[0]
            self._set_status(f"{selected} started", "working", timeout=1800)
            try:
                fn()
            except Exception as e:
                self._set_status(f"{selected} failed: {e}", "err", timeout=4200)

        run_btn = self._make_button(
            row,
            "Run",
            _run_selected,
            bg=run_bg or self.accent_color,
            tooltip="Run selected action",
            padx=18,
        )
        run_btn.pack(side=tk.LEFT)

        if hint:
            hint_row = tk.Frame(inner, bg=self.glass_panel_bg)
            hint_row.pack(fill=tk.X, padx=12, pady=(0, 10))
            tk.Label(
                hint_row,
                text=hint,
                font=("Noto Sans", 8),
                bg=self.glass_panel_bg,
                fg=self.text_dim,
            ).pack(anchor="w")

        return {"frame": deck, "var": var, "combo": combo, "run": run_btn}

    def _create_glass_log_container(self, parent, padx=20, pady=(0, 10), manager="pack", grid_opts=None):
        shell = tk.Frame(parent, bg=self._mix_hex(self.border_color, self.accent_color, 0.72))
        if manager == "grid":
            opts = {"padx": padx, "pady": pady, "sticky": "nsew"}
            if grid_opts:
                opts.update(grid_opts)
            shell.grid(**opts)
        else:
            shell.pack(fill=tk.BOTH, expand=True, padx=padx, pady=pady)

        glass = tk.Frame(shell, bg=self.glass_panel_bg)
        glass.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)
        self._apply_glass_grain(glass, self.glass_panel_bg)
        tk.Frame(glass, bg=self._lighter(self.glass_white, 16), height=2).pack(fill=tk.X)
        tk.Frame(glass, bg=self._mix_hex(self.glass_tint, self.accent_color, 0.86), height=1).pack(fill=tk.X)

        body = tk.Frame(glass, bg=self.glass_white)
        body.pack(fill=tk.BOTH, expand=True)
        return body

    def _create_modern_text(self, parent, *, font=("Noto Sans Mono", 10),
                            height=None, padx_text=8, pady_text=6,
                            spacing1=0, spacing2=0, spacing3=0,
                            state=tk.DISABLED):
        """Create a tk.Text with a thin overlay scrollbar instead of the
        clunky classic ScrolledText scrollbar.

        Returns the Text widget (already packed inside *parent*).
        """
        # Container frame so the overlay scrollbar can sit on top
        container = tk.Frame(parent, bg=self.glass_white)
        container.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        text = tk.Text(
            container, font=font, bg=self.glass_white,
            fg=self.text_color, relief="flat", borderwidth=0,
            wrap=tk.WORD, insertbackground=self.accent_color,
            padx=padx_text, pady=pady_text,
            spacing1=spacing1, spacing2=spacing2, spacing3=spacing3,
            selectbackground=self._mix_hex(self.accent_color, self.glass_white, 0.35),
            selectforeground=self.text_color,
            highlightthickness=0,
        )
        if height is not None:
            text.configure(height=height)
        text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Thin overlay scrollbar
        thumb_clr = self._mix_hex(self.border_color, self.text_dim, 0.55)
        thumb_hov = self._mix_hex(self.accent_color, self.text_dim, 0.50)
        scrollbar = OverlayScrollbar(
            container, text,
            bg_color=self.glass_white,
            thumb_color=thumb_clr,
            thumb_hover=thumb_hov,
        )
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        text.config(state=state)
        SmoothScroller.bind_smooth_scroll(text)
        return text

    # ── Scrollable tab wrapper ──────────────────────────────────────────

    def _create_scrollable_tab(self, parent):
        """Create a Canvas+Scrollbar scrollable container that wraps an entire
        tab's content.  Returns the inner ``scrollable`` Frame — pack widgets
        into that frame.  The canvas auto-tracks width and scrollregion."""
        outer = tk.Frame(parent, bg=self.bg_color)
        outer.pack(fill=tk.BOTH, expand=True)

        canvas = tk.Canvas(outer, bg=self.bg_color, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        scrollable = tk.Frame(canvas, bg=self.bg_color)

        scrollable.bind(
            "<Configure>",
            lambda _e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        cwin = canvas.create_window((0, 0), window=scrollable, anchor="nw")
        canvas.bind(
            "<Configure>",
            lambda e: canvas.itemconfig(cwin, width=e.width),
        )
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        SmoothScroller.bind_smooth_scroll(canvas)

        return scrollable, canvas

    # ── Collapsible action deck ─────────────────────────────────────────

    def _create_collapsible_deck(self, parent, title, actions, run_bg=None,
                                 hint=None, default=None, collapsed=False):
        """Create an action picker that can be collapsed/expanded.

        When *collapsed* is True the deck starts in compact (title-only)
        mode and expands on click.  A spring animation drives the
        expand/collapse transition.
        """
        if not actions:
            return None

        deck = tk.Frame(parent, bg=self._mix_hex(self.border_color, self.accent_color, 0.75))
        deck.pack(fill=tk.X, padx=20, pady=(0, 6))

        inner = tk.Frame(deck, bg=self.glass_panel_bg)
        inner.pack(fill=tk.X, padx=1, pady=1)
        self._apply_glass_grain(inner, self.glass_panel_bg)
        # Top accent lines
        tk.Frame(inner, bg=self._lighter(self.glass_white, 16), height=2).pack(fill=tk.X)
        tk.Frame(inner, bg=self._mix_hex(self.glass_tint, self.accent_color, 0.86), height=1).pack(fill=tk.X)

        # ── Header row (always visible) ──
        header = tk.Frame(inner, bg=self.glass_panel_bg, cursor="hand2")
        header.pack(fill=tk.X, padx=12, pady=(8, 4))

        chevron_var = tk.StringVar(value="▶" if collapsed else "▼")
        chevron = tk.Label(
            header, textvariable=chevron_var,
            font=("Noto Sans", 8), bg=self.glass_panel_bg, fg=self.accent_color,
        )
        chevron.pack(side=tk.LEFT, padx=(0, 6))

        tk.Label(
            header, text=title,
            font=("Noto Sans", 10, "bold"),
            bg=self.glass_panel_bg, fg=self.metallic_light,
        ).pack(side=tk.LEFT)

        action_count = tk.Label(
            header, text=f"({len(actions)} actions)",
            font=("Noto Sans", 8), bg=self.glass_panel_bg, fg=self.text_dim,
        )
        action_count.pack(side=tk.LEFT, padx=(8, 0))

        # ── Body (collapsible) ──
        body = tk.Frame(inner, bg=self.glass_panel_bg)
        if not collapsed:
            body.pack(fill=tk.X, padx=12, pady=(0, 8))

        row = tk.Frame(body, bg=self.glass_panel_bg)
        row.pack(fill=tk.X)

        labels = [x[0] for x in actions]
        action_map = {x[0]: (x[1], x[2] if len(x) > 2 else "") for x in actions}

        var = tk.StringVar(value=default or labels[0])
        combo = ttk.Combobox(
            row, textvariable=var, state="readonly", values=labels,
            style="Quick.TCombobox", font=("Noto Sans", 10),
        )
        combo.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))

        def _run_selected():
            selected = var.get().strip()
            if not selected:
                return
            action = action_map.get(selected)
            if not action:
                return
            fn = action[0]
            self._set_status(f"{selected} started", "working", timeout=1800)
            try:
                fn()
            except Exception as e:
                self._set_status(f"{selected} failed: {e}", "err", timeout=4200)

        run_btn = self._make_button(
            row, "Run", _run_selected,
            bg=run_bg or self.accent_color, tooltip="Run selected action", padx=18,
        )
        run_btn.pack(side=tk.LEFT)

        if hint:
            hint_lbl = tk.Label(
                body, text=hint, font=("Noto Sans", 8),
                bg=self.glass_panel_bg, fg=self.text_dim,
            )
            hint_lbl.pack(anchor="w", pady=(4, 0))

        # ── Toggle logic with spring animation ──
        _is_open = [not collapsed]

        def _toggle(_event=None):
            if _is_open[0]:
                body.pack_forget()
                chevron_var.set("▶")
                _is_open[0] = False
            else:
                body.pack(fill=tk.X, padx=12, pady=(0, 8))
                chevron_var.set("▼")
                _is_open[0] = True
            # pack/pack_forget handles the expand/collapse instantly.
            # Spring height animation is incompatible with pack geometry
            # (pack ignores configure(height=...) when fill is active).

        for w in (header, chevron):
            w.bind("<Button-1>", _toggle)
        for child in header.winfo_children():
            child.bind("<Button-1>", _toggle)

        return {"frame": deck, "var": var, "combo": combo, "run": run_btn,
                "toggle": _toggle, "is_open": _is_open}

    # ── Header ──────────────────────────────────────────────────────────

    def create_header(self):
        hdr = tk.Frame(self.root, bg=self.header_color, height=80)
        hdr.pack(side=tk.TOP, fill=tk.X)
        hdr.pack_propagate(False)

        inner = tk.Frame(hdr, bg=self.header_color)
        inner.pack(fill=tk.BOTH, expand=True, padx=24, pady=10)

        left = tk.Frame(inner, bg=self.header_color)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        if self.header_icon:
            tk.Label(left, image=self.header_icon, bg=self.header_color).pack(side=tk.LEFT, padx=(0, 14))

        title_f = tk.Frame(left, bg=self.header_color)
        title_f.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Title row with inline PRO badge
        title_row = tk.Frame(title_f, bg=self.header_color)
        title_row.pack(anchor="w")
        tk.Label(title_row, text="SYSFIX", font=("Noto Sans", 20, "bold"),
                 bg=self.header_color, fg=self.hdr_title_fg).pack(side=tk.LEFT)
        self._pro_badge = tk.Label(
            title_row,
            text=" PRO ",
            font=("Noto Sans", 10, "bold"),
            bg="#00BFFF",
            fg="#ffffff",
            padx=6,
            pady=1,
            relief="flat",
            bd=0,
        )
        if is_licence_valid():
            self._pro_badge.pack(side=tk.LEFT, padx=(8, 0), pady=(4, 0))
        ToolTip(self._pro_badge, "Sysfix Pro — all features unlocked",
                bg=self.tooltip_bg, fg=self.tooltip_fg)

        tk.Label(title_f, text="Diagnostics  \u2022  Security  \u2022  AI-Powered Repair",
                 font=("Noto Sans", 9), bg=self.header_color, fg=self.hdr_subtitle_fg).pack(anchor="w")

        right = tk.Frame(inner, bg=self.header_color)
        right.pack(side=tk.RIGHT, fill=tk.Y, padx=(20, 0))

        # AI status
        ai_state = get_ai_runtime_status()
        ai_ok = bool(ai_state.get("online"))
        ai_label = ai_state.get("label", "AI")
        self._ai_status_label = tk.Label(
            right,
            text=f"● {ai_label}" if ai_ok else f"● {ai_label} Offline",
            font=("Noto Sans", 9, "bold"),
            bg=self.header_color,
            fg=self.hdr_ai_on if ai_ok else self.hdr_ai_off,
        )
        self._ai_status_label.pack(anchor="e", pady=(0, 3))
        self._ai_status_tip = ToolTip(
            self._ai_status_label,
            ai_state.get("detail", "AI provider status"),
            bg=self.tooltip_bg,
            fg=self.tooltip_fg,
        )
        self._refresh_ai_status_label()

        # Internet indicator
        self._net_label = tk.Label(
            right, text="● Web Search",
            font=("Noto Sans", 9, "bold"),
            bg=self.header_color, fg=self.hdr_web_fg,
        )
        self._net_label.pack(anchor="e", pady=(0, 3))
        ToolTip(self._net_label, "DuckDuckGo web search enabled", bg=self.tooltip_bg, fg=self.tooltip_fg)

        mode_text = "Admin" if self.is_sudo else "User"
        mode_clr  = self.hdr_admin_fg if self.is_sudo else self.hdr_user_fg
        lbl = tk.Label(right, text=f"● {mode_text}", font=("Noto Sans", 9, "bold"),
                       bg=self.header_color, fg=mode_clr)
        lbl.pack(anchor="e")
        ToolTip(lbl, "Run with sudo for full repair capabilities", bg=self.tooltip_bg, fg=self.tooltip_fg)

        quick_row = tk.Frame(right, bg=self.header_color)
        quick_row.pack(anchor="e", pady=(8, 0))
        tk.Label(
            quick_row, text="Quick:", font=("Noto Sans", 8, "bold"),
            bg=self.header_color, fg=self.hdr_subtitle_fg,
        ).pack(side=tk.LEFT, padx=(0, 6))
        self._quick_action_var = tk.StringVar(value="Quick Actions")
        self._quick_action_menu = ttk.Combobox(
            quick_row,
            textvariable=self._quick_action_var,
            state="readonly",
            width=22,
            style="Quick.TCombobox",
            font=("Noto Sans", 8),
            values=("Quick Actions",),
        )
        self._quick_action_menu.pack(side=tk.LEFT)
        self._quick_action_menu.bind(
            "<<ComboboxSelected>>", self._on_quick_action_selected
        )

        # ── Global AI search bar (persistent in header) ──
        search_row = tk.Frame(left, bg=self.header_color)
        search_row.pack(side=tk.RIGHT, padx=(20, 0))

        search_border = tk.Frame(
            search_row,
            bg=self._mix_hex(self.header_color, self.accent_color, 0.50),
        )
        search_border.pack(side=tk.LEFT)

        self._global_search_var = tk.StringVar()
        self._global_search = tk.Entry(
            search_border,
            textvariable=self._global_search_var,
            font=("Noto Sans", 9),
            bg=self._mix_hex(self.header_color, "#ffffff", 0.12),
            fg=self.hdr_title_fg,
            insertbackground=self.accent_color,
            relief="flat", bd=0, width=24,
        )
        self._global_search.pack(padx=2, pady=2, ipady=4)
        self._global_search.insert(0, "")
        self._global_search.bind("<FocusIn>", self._on_search_focus_in)
        self._global_search.bind("<FocusOut>", self._on_search_focus_out)
        self._global_search.bind("<Return>", self._on_global_search_submit)
        self._global_search.bind("<Escape>", lambda _e: self.root.focus_set())
        # Placeholder
        self._search_placeholder = tk.Label(
            search_border, text="🔍 Search or ask Fyxa…",
            font=("Noto Sans", 8), bg=self._mix_hex(self.header_color, "#ffffff", 0.12),
            fg=self.hdr_subtitle_fg, cursor="xterm",
        )
        self._search_placeholder.place(x=6, y=4)
        self._search_placeholder.bind(
            "<Button-1>", lambda _e: self._global_search.focus_set()
        )

        # Subtle gradient line
        tk.Frame(hdr, bg=self.accent_color, height=3).pack(side=tk.BOTTOM, fill=tk.X)

    def _setup_quick_actions(self):
        if not hasattr(self, "_quick_action_menu"):
            return
        self._quick_actions = {
            "Run Diagnostics": lambda: self._run_threaded(
                self.scan_issues, task_label="Running diagnostics"
            ),
            "Fast Sweep": lambda: self._run_threaded(
                self.fast_sweep, task_label="Running fast sweep"
            ),
            "Security Scan": lambda: self._run_threaded(
                self._run_security_scan, task_label="Running security scan"
            ),
            "Full Network Check": lambda: self._run_threaded(
                self._run_network_diag, task_label="Running network check"
            ),
            "System Health": lambda: self._run_threaded(
                self._run_system_health, task_label="Checking system health"
            ),
            "Open AI Chat": lambda: self._select_tab(4),
            "Open Settings": lambda: self._select_tab(6),
            "Start Ollama": self._start_ollama_serve,
        }
        values = ["Quick Actions"] + list(self._quick_actions.keys())
        self._quick_action_menu.configure(values=values)
        self._quick_action_var.set(values[0])

    def _on_quick_action_selected(self, _event=None):
        label = self._quick_action_var.get().strip()
        if not label or label == "Quick Actions":
            return
        action = self._quick_actions.get(label)
        if action:
            try:
                action()
                self._set_status(f"{label} started", "working", timeout=2200)
            except Exception as e:
                self._set_status(f"Quick action failed: {e}", "err", timeout=4500)
        self.root.after(60, lambda: self._quick_action_var.set("Quick Actions"))

    # ── Global search bar event handlers ────────────────────────────────

    def _on_search_focus_in(self, _event=None):
        """Hide placeholder when the search bar gains focus."""
        try:
            self._search_placeholder.place_forget()
        except Exception:
            pass

    def _on_search_focus_out(self, _event=None):
        """Restore placeholder if query is empty."""
        try:
            if not self._global_search_var.get().strip():
                self._search_placeholder.place(x=6, y=4)
        except Exception:
            pass

    def _on_global_search_submit(self, _event=None):
        """Handle Enter in the global search bar.

        Tries to match a palette command first; if no match, sends
        the query to Fyxa AI via the chat tab.
        """
        query = self._global_search_var.get().strip()
        if not query:
            return

        # Try to fuzzy-match a palette command
        matched_cmd = self._match_palette_command(query)
        if matched_cmd:
            self._global_search_var.set("")
            self.root.focus_set()
            self._palette_dispatch(matched_cmd)
            return

        # No command match — send to Fyxa as a question
        self._global_search_var.set("")
        self.root.focus_set()
        self._select_tab(5)  # AI Chat tab
        self.root.after(150, lambda: self._palette_ask_fyxa(query))

    def _match_palette_command(self, query):
        """Fuzzy-match a query against command palette entries.

        Returns the cmd_id if a sufficiently close match is found,
        else None.
        """
        q = query.lower().strip()
        _PALETTE_ALIASES = {
            "diagnostics": ("diagnostics", "scan", "diag"),
            "fast_sweep": ("sweep", "fast", "quick fix"),
            "security": ("security", "firewall", "audit"),
            "network": ("network", "dns", "gateway", "ping"),
            "health_score": ("health", "score"),
            "predict_disk": ("disk", "predictive", "smart"),
            "zombies": ("zombie",),
            "kernel": ("kernel", "sysctl", "tuning"),
            "log_analysis": ("log", "logs"),
            "repo_audit": ("repo", "package"),
            "energy": ("energy", "power", "battery"),
            "prescriptive": ("prescriptive", "predict"),
            "sentinel": ("sentinel", "ebpf"),
            "av_toggle": ("antivirus", "av"),
            "pipeline_scan": ("deep scan", "pipeline", "clam", "yara"),
            "bridge_scan": ("bridge", "bridge scan"),
            "pulse_toggle": ("pulse", "telemetry"),
            "agent_report": ("agent", "agentic"),
            "settings": ("settings", "config", "preferences"),
            "brain_stats": ("brain", "memory"),
            "updates": ("update",),
        }
        for cmd_id, aliases in _PALETTE_ALIASES.items():
            if any(alias in q for alias in aliases):
                return cmd_id
        return None

    # ── Update notification banner ──────────────────────────────────────

    def create_update_banner(self):
        """Create a banner that shows when an update is available."""
        self.update_banner = tk.Frame(self.root, bg=self.warning_color, height=0)
        self.update_banner.pack(side=tk.TOP, fill=tk.X)
        self.update_banner.pack_forget()  # Hidden by default

        inner = tk.Frame(self.update_banner, bg=self.warning_color)
        inner.pack(fill=tk.X, padx=15, pady=8)

        # Icon
        tk.Label(inner, text="⚠", font=("Noto Sans", 14),
                 bg=self.warning_color, fg="#ffffff").pack(side=tk.LEFT, padx=(0, 10))

        # Message
        self.update_message = tk.Label(
            inner, text="Sysfix update available!",
            font=("Noto Sans", 10, "bold"),
            bg=self.warning_color, fg="#ffffff"
        )
        self.update_message.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Button
        btn = tk.Button(
            inner, text="Update & Restart",
            font=("Noto Sans", 9, "bold"),
            bg="#ffffff", fg=self.warning_color,
            relief="flat", cursor="hand2", padx=12, pady=6,
            command=self._update_and_restart
        )
        btn.pack(side=tk.RIGHT, padx=(10, 0))

        # Dismiss button
        dismiss = tk.Button(
            inner, text="✕",
            font=("Noto Sans", 12, "bold"),
            bg=self.warning_color, fg="#ffffff",
            relief="flat", cursor="hand2", padx=8, pady=4,
            bd=0, highlightthickness=0,
            command=self._hide_update_banner
        )
        dismiss.pack(side=tk.RIGHT)

    def _show_update_banner(self, message: str = ""):
        """Show the update banner with an optional custom message."""
        if message:
            self.update_message.config(text=message)
        self.update_banner.pack(side=tk.TOP, fill=tk.X, after=self.root.winfo_children()[0])

    def _hide_update_banner(self):
        """Hide the update banner."""
        self.update_banner.pack_forget()

    def _update_and_restart(self):
        """Update Sysfix and restart the application."""
        if not messagebox.askyesno("Update Sysfix",
                "This will update Sysfix to the latest version and restart the application.\n\n"
                "Continue?"):
            return
        
        # Run update in a thread
        def _do_update():
            from sysfixai.diagnostics import apply_sysfix_update
            results = apply_sysfix_update()
            
            # Show results
            success = any("success" in r.lower() or "updated" in r.lower() for r in results)
            if success:
                self._safe(lambda: messagebox.showinfo("Update Complete",
                    "Sysfix has been updated!\n\nThe application will now restart."))
                # Restart
                import subprocess, sys
                exe = shutil.which("sysfix") or sys.executable
                if self.is_sudo:
                    subprocess.Popen([exe, "gui"])
                else:
                    subprocess.Popen([exe, "gui"])
                self.root.after(500, self.root.destroy)
            else:
                msg = "\n".join(results[:10])
                self._safe(lambda: messagebox.showerror("Update Failed",
                    f"Update failed:\n\n{msg[:300]}"))
        
        threading.Thread(target=_do_update, daemon=True).start()

    def _check_for_updates_on_startup(self):
        """Check for updates in the background and show banner if available."""
        if not self.config.get("auto_check_updates_on_startup", True):
            return

        def _check():
            try:
                import time
                time.sleep(2)  # Wait a moment for the UI to settle
                results = check_sysfix_update()

                version_line = self._extract_update_banner_message(results)
                if version_line:
                    self._safe(lambda: self._show_update_banner(version_line))
            except Exception:
                pass  # Silently fail — don't annoy users with update check errors
        
        threading.Thread(target=_check, daemon=True).start()

    # ── Notebook (tabs) ─────────────────────────────────────────────────

    def create_notebook(self):
        container = tk.Frame(self.root, bg=self.glass_panel_bg)
        container.pack(fill=tk.BOTH, expand=True)

        # ── Collapsible vertical sidebar (ChatGPT / Gemini style) ──
        self._sidebar_container = tk.Frame(container, bg=self.bg_secondary)
        self._sidebar_container.pack(side=tk.LEFT, fill=tk.Y)
        self._sidebar_container.pack_propagate(False)
        self._sidebar_container.configure(
            width=self._sidebar_width_expanded if self._sidebar_expanded
            else self._sidebar_width_collapsed,
        )

        self._nav_sidebar = tk.Frame(self._sidebar_container, bg=self.bg_secondary)
        self._nav_sidebar.pack(fill=tk.BOTH, expand=True)

        self.notebook = ttk.Notebook(container)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        # Hide the notebook tab bar — sidebar is the sole navigation
        style = ttk.Style()
        style.layout("TNotebook.Tab", [])  # empty layout hides tab headers

        self.dashboard_frame = tk.Frame(self.notebook, bg=self.glass_panel_bg)
        self.quick_fix_frame = tk.Frame(self.notebook, bg=self.glass_panel_bg)
        self.security_frame  = tk.Frame(self.notebook, bg=self.glass_panel_bg)
        self.network_frame   = tk.Frame(self.notebook, bg=self.glass_panel_bg)
        self.health_frame    = tk.Frame(self.notebook, bg=self.glass_panel_bg)
        self.analysis_frame  = tk.Frame(self.notebook, bg=self.glass_panel_bg)
        self.brain_frame     = tk.Frame(self.notebook, bg=self.glass_panel_bg)
        self.settings_frame  = tk.Frame(self.notebook, bg=self.glass_panel_bg)

        self.notebook.add(self.dashboard_frame, text=" Dashboard ")
        self.notebook.add(self.quick_fix_frame, text=" Quick Fix ")
        self.notebook.add(self.security_frame,  text=" Security ")
        self.notebook.add(self.network_frame,   text=" Network ")
        self.notebook.add(self.health_frame,    text=" Health ")
        self.notebook.add(self.analysis_frame,  text=" AI Chat ")
        self.notebook.add(self.brain_frame,     text=" Brain ")
        self.notebook.add(self.settings_frame,  text=" Settings ")
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)

        # Populate sidebar nav buttons
        self._build_nav_sidebar()

        self.create_dashboard_tab()
        self.create_quick_fix_tab()
        self.create_security_tab()
        self.create_network_tab()
        self.create_health_tab()
        self.create_analysis_tab()
        self.create_brain_tab()
        self.create_settings_tab()

    # ── PIL-based sidebar icons ──────────────────────────────────────

    def _draw_nav_icon(self, name, fg_hex, size=22):
        """Draw a monochrome sidebar icon with PIL and return a PhotoImage."""
        if not HAS_PIL:
            return None
        s = size * 3          # draw at 3× for anti-aliased down-scale
        img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        r, g, b = int(fg_hex[1:3], 16), int(fg_hex[3:5], 16), int(fg_hex[5:7], 16)
        fill = (r, g, b, 255)
        ol = (r, g, b, 200)   # slightly transparent for outlines
        lw = max(2, s // 12)  # line width

        if name == "dashboard":
            # Three vertical bars (bar-chart)
            bw = s // 6
            gap = s // 10
            x1 = s // 5
            d.rectangle([x1, s * 55 // 100, x1 + bw, s - gap], fill=fill)
            d.rectangle([s // 2 - bw // 2, s * 30 // 100, s // 2 + bw // 2, s - gap], fill=fill)
            d.rectangle([s - x1 - bw, s * 45 // 100, s - x1, s - gap], fill=fill)
        elif name == "quickfix":
            # Lightning bolt
            pts = [
                (s * 0.55, s * 0.05), (s * 0.22, s * 0.48),
                (s * 0.46, s * 0.48), (s * 0.42, s * 0.95),
                (s * 0.78, s * 0.48), (s * 0.54, s * 0.48),
            ]
            d.polygon([(int(x), int(y)) for x, y in pts], fill=fill)
        elif name == "security":
            # Shield shape
            cx = s // 2
            pts = [
                (cx, s * 8 // 100),
                (s - s // 7, s * 25 // 100),
                (s - s // 7, s * 58 // 100),
                (cx, s - s // 10),
                (s // 7, s * 58 // 100),
                (s // 7, s * 25 // 100),
            ]
            d.polygon(pts, fill=fill)
        elif name == "network":
            # Globe: circle + horizontal line + vertical ellipse
            pad = s // 7
            d.ellipse([pad, pad, s - pad, s - pad], outline=fill, width=lw)
            d.ellipse([s // 3, pad, s * 2 // 3, s - pad], outline=fill, width=lw)
            d.line([pad, s // 2, s - pad, s // 2], fill=fill, width=lw)
        elif name == "health":
            # Heart
            cx, cy = s // 2, s // 2
            r1 = s // 4
            d.ellipse([cx - r1 * 2, cy - r1, cx, cy + r1 // 2], fill=fill)
            d.ellipse([cx, cy - r1, cx + r1 * 2, cy + r1 // 2], fill=fill)
            d.polygon([
                (cx - r1 * 2 + lw, cy + r1 // 4),
                (cx, s - s // 8),
                (cx + r1 * 2 - lw, cy + r1 // 4),
            ], fill=fill)
        elif name == "chat":
            # Speech bubble
            pad = s // 7
            bx1, by1, bx2, by2 = pad, pad, s - pad, s * 70 // 100
            d.rounded_rectangle([bx1, by1, bx2, by2], radius=s // 8, fill=fill)
            # Tail triangle
            d.polygon([
                (s // 3, by2 - 1),
                (s // 5, s - pad),
                (s // 2, by2 - 1),
            ], fill=fill)
        elif name == "brain":
            # Stylised brain: two bumpy half-circles
            cx = s // 2
            pad = s // 6
            # Left hemisphere
            d.arc([pad, pad + s // 8, cx + pad // 2, s - pad - s // 8],
                  start=90, end=270, fill=fill, width=lw + 1)
            d.arc([pad + s // 10, pad, cx - pad // 2, s * 45 // 100],
                  start=180, end=360, fill=fill, width=lw)
            # Right hemisphere
            d.arc([cx - pad // 2, pad + s // 8, s - pad, s - pad - s // 8],
                  start=270, end=90, fill=fill, width=lw + 1)
            d.arc([cx + pad // 2, s * 50 // 100, s - pad - s // 10, s - pad],
                  start=0, end=180, fill=fill, width=lw)
            # Stem
            d.line([cx, s - pad - s // 8, cx, s - pad // 2], fill=fill, width=lw)
        elif name == "settings":
            # Gear: circle + radiating teeth
            import math
            cx, cy = s // 2, s // 2
            r_outer = s // 2 - s // 8
            r_inner = s // 3
            r_center = s // 5
            teeth = 8
            tooth_half = math.pi / teeth / 2.2
            pts = []
            for i in range(teeth):
                a = 2 * math.pi * i / teeth - math.pi / 2
                # Outer tooth
                pts.append((cx + int(r_outer * math.cos(a - tooth_half)),
                            cy + int(r_outer * math.sin(a - tooth_half))))
                pts.append((cx + int(r_outer * math.cos(a + tooth_half)),
                            cy + int(r_outer * math.sin(a + tooth_half))))
                # Inner notch
                a_next = a + math.pi / teeth
                pts.append((cx + int(r_inner * math.cos(a + tooth_half + 0.05)),
                            cy + int(r_inner * math.sin(a + tooth_half + 0.05))))
                pts.append((cx + int(r_inner * math.cos(a_next - tooth_half - 0.05)),
                            cy + int(r_inner * math.sin(a_next - tooth_half - 0.05))))
            d.polygon(pts, fill=fill)
            # Centre hole
            d.ellipse([cx - r_center, cy - r_center, cx + r_center, cy + r_center],
                      fill=(0, 0, 0, 0))
        elif name == "search":
            # Magnifying glass
            pad = s // 6
            r = s * 35 // 100
            cx, cy = s // 2 - pad // 2, s // 2 - pad // 2
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=fill, width=lw + 1)
            # Handle
            hx = cx + int(r * 0.7)
            hy = cy + int(r * 0.7)
            d.line([hx, hy, s - pad, s - pad], fill=fill, width=lw + 2)
        elif name == "key":
            # Key shape
            pad = s // 5
            r = s // 4
            cx, cy = s // 3, s // 3
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=fill, width=lw + 1)
            d.line([cx + r - lw, cy, s - pad, cy], fill=fill, width=lw)
            d.line([s - pad, cy, s - pad, cy + s // 6], fill=fill, width=lw)
            d.line([s - pad - s // 8, cy, s - pad - s // 8, cy + s // 8], fill=fill, width=lw)

        img = img.resize((size, size), Image.LANCZOS)
        photo = ImageTk.PhotoImage(img)
        return photo

    def _get_nav_icon(self, name, fg_hex, size=22):
        """Return a cached or freshly drawn nav icon PhotoImage."""
        if not HAS_PIL:
            return None
        # Lazy-init the icon cache and keep-alive list
        if not hasattr(self, "_nav_icon_cache"):
            self._nav_icon_cache = {}
            self._nav_icon_refs = []
        key = (name, fg_hex, size)
        if key in self._nav_icon_cache:
            return self._nav_icon_cache[key]
        photo = self._draw_nav_icon(name, fg_hex, size)
        if photo:
            self._nav_icon_cache[key] = photo
            self._nav_icon_refs.append(photo)
        return photo

    def _build_nav_sidebar(self):
        """Build a stateful, vertical sidebar with icons + labels (collapsible)."""
        nav_items = [
            ("dashboard",  "Dashboard",   0, "Ctrl+1"),
            ("quickfix",   "Quick Fix",   1, "Ctrl+2"),
            ("security",   "Security",    2, "Ctrl+3"),
            ("network",    "Network",     3, "Ctrl+4"),
            ("health",     "Health",      4, "Ctrl+5"),
            ("chat",       "AI Chat",     5, "Ctrl+6"),
            ("brain",      "Brain",       6, "Ctrl+7"),
            ("settings",   "Settings",    7, ""),
        ]
        self._nav_buttons = []
        self._nav_labels = []
        self._nav_icon_labels = []   # keep refs for colour swaps
        self._nav_icon_names = []    # icon name per tab (for re-draw)
        sb = self._nav_sidebar

        # Top accent line
        tk.Frame(sb, bg=self.accent_color, height=2).pack(fill=tk.X)

        # Collapse / expand toggle
        self._sidebar_toggle = tk.Label(
            sb, text="◀", font=("Noto Sans", 10),
            bg=self.bg_secondary, fg=self.text_dim,
            cursor="hand2", pady=4,
        )
        self._sidebar_toggle.pack(fill=tk.X, pady=(4, 2))
        self._sidebar_toggle.bind("<Button-1>", lambda _e: self._toggle_sidebar())

        for icon_name, label, tab_idx, shortcut in nav_items:
            row = tk.Frame(sb, bg=self.bg_secondary, cursor="hand2")
            row.pack(fill=tk.X, pady=(1, 0))

            icon_photo = self._get_nav_icon(icon_name, self.text_dim)
            if icon_photo:
                icon_lbl = tk.Label(
                    row, image=icon_photo,
                    bg=self.bg_secondary,
                    cursor="hand2", width=30, anchor="center",
                )
            else:
                icon_lbl = tk.Label(
                    row, text="●", font=("Noto Sans", 13),
                    bg=self.bg_secondary, fg=self.text_dim,
                    cursor="hand2", width=3, anchor="center",
                )
            icon_lbl.pack(side=tk.LEFT, padx=(4, 0), pady=5)

            tip = f"{label} ({shortcut})" if shortcut else label
            text_lbl = tk.Label(
                row, text=label, font=("Noto Sans", 10),
                bg=self.bg_secondary, fg=self.text_dim,
                cursor="hand2", anchor="w",
            )
            if self._sidebar_expanded:
                text_lbl.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(4, 8), pady=5)

            # Click bindings on both icon and label
            for w in (row, icon_lbl, text_lbl):
                w.bind("<Button-1>", lambda _e, i=tab_idx: self._nav_sidebar_select(i))
                w.bind("<Enter>", lambda _e, r=row, il=icon_lbl, tl=text_lbl, idx=tab_idx: self._nav_hover_enter(r, il, tl, idx))
                w.bind("<Leave>", lambda _e, r=row, il=icon_lbl, tl=text_lbl, i=tab_idx: self._nav_hover_leave(r, il, tl, i))

            ToolTip(row, tip, bg=self.tooltip_bg, fg=self.tooltip_fg)
            self._nav_buttons.append(row)
            self._nav_labels.append(text_lbl)
            self._nav_icon_labels.append(icon_lbl)
            self._nav_icon_names.append(icon_name)

        # Spacer
        tk.Frame(sb, bg=self.bg_secondary).pack(fill=tk.BOTH, expand=True)

        # Heartbeat status indicator
        self._heartbeat_indicator = tk.Label(
            sb, text="♥ —", font=("Noto Sans Mono", 8),
            bg=self.bg_secondary, fg=self.text_dim, anchor="w",
        )
        if self._sidebar_expanded:
            self._heartbeat_indicator.pack(fill=tk.X, padx=8, pady=(0, 2))
        self._update_heartbeat_indicator()

        # Search shortcut at bottom
        search_row = tk.Frame(sb, bg=self.bg_secondary, cursor="hand2")
        search_row.pack(fill=tk.X, pady=(0, 4))
        search_photo = self._get_nav_icon("search", self.text_dim)
        if search_photo:
            search_icon = tk.Label(
                search_row, image=search_photo,
                bg=self.bg_secondary,
                cursor="hand2", width=30, anchor="center",
            )
        else:
            search_icon = tk.Label(
                search_row, text="⌕", font=("Noto Sans", 13),
                bg=self.bg_secondary, fg=self.text_dim,
                cursor="hand2", width=3, anchor="center",
            )
        search_icon.pack(side=tk.LEFT, padx=(4, 0), pady=4)
        self._search_label = tk.Label(
            search_row, text="Search", font=("Noto Sans", 10),
            bg=self.bg_secondary, fg=self.text_dim,
            cursor="hand2", anchor="w",
        )
        if self._sidebar_expanded:
            self._search_label.pack(side=tk.LEFT, padx=(4, 8), pady=4)
        for w in (search_row, search_icon, self._search_label):
            w.bind("<Button-1>", lambda _e: self._open_command_palette())
        ToolTip(search_row, "Search / Command Palette (Ctrl+K)",
                bg=self.tooltip_bg, fg=self.tooltip_fg)

        # Polkit status at bottom
        pk = polkit_status()
        key_photo = self._get_nav_icon("key", self.success_color if pk["available"] else self.text_dim, size=14)
        pk_text = " Polkit ✓" if pk["available"] else " Polkit ✗"
        self._polkit_label = tk.Label(
            sb, text=pk_text, font=("Noto Sans Mono", 7),
            bg=self.bg_secondary,
            fg=self.success_color if pk["available"] else self.text_dim,
            anchor="w", compound=tk.LEFT,
        )
        if key_photo:
            self._polkit_label.config(image=key_photo)
        if self._sidebar_expanded:
            self._polkit_label.pack(fill=tk.X, padx=8, pady=(0, 2))

        # Bottom accent line
        tk.Frame(sb, bg=self.accent_color, height=2).pack(fill=tk.X, side=tk.BOTTOM)

        # Select first tab
        self._update_nav_sidebar_highlight(0)

    def _nav_hover_enter(self, row, icon_lbl, text_lbl, tab_idx=None):
        """Hover-in effect for sidebar nav items."""
        hover_bg = self._mix_hex(self.bg_secondary, self.accent_color, 0.80)
        for w in (row, icon_lbl, text_lbl):
            w.config(bg=hover_bg)
        text_lbl.config(fg=self.accent_color)
        # Swap icon image to accent colour
        if tab_idx is not None and hasattr(self, "_nav_icon_names") and tab_idx < len(self._nav_icon_names):
            photo = self._get_nav_icon(self._nav_icon_names[tab_idx], self.accent_color)
            if photo:
                icon_lbl.config(image=photo)
        else:
            try:
                icon_lbl.config(fg=self.accent_color)
            except tk.TclError:
                pass

    def _nav_hover_leave(self, row, icon_lbl, text_lbl, tab_idx):
        """Hover-out: restore correct state depending on active tab."""
        try:
            active = self.notebook.index(self.notebook.select())
        except Exception:
            active = -1
        if tab_idx == active:
            active_bg = self._mix_hex(self.bg_secondary, self.accent_color, 0.70)
            for w in (row, icon_lbl, text_lbl):
                w.config(bg=active_bg)
            text_lbl.config(fg=self.accent_color)
            if hasattr(self, "_nav_icon_names") and tab_idx < len(self._nav_icon_names):
                photo = self._get_nav_icon(self._nav_icon_names[tab_idx], self.accent_color)
                if photo:
                    icon_lbl.config(image=photo)
        else:
            for w in (row, icon_lbl, text_lbl):
                w.config(bg=self.bg_secondary)
            text_lbl.config(fg=self.text_dim)
            if hasattr(self, "_nav_icon_names") and tab_idx < len(self._nav_icon_names):
                photo = self._get_nav_icon(self._nav_icon_names[tab_idx], self.text_dim)
                if photo:
                    icon_lbl.config(image=photo)

    def _toggle_sidebar(self):
        """Collapse or expand the navigation sidebar."""
        self._sidebar_expanded = not self._sidebar_expanded
        if self._sidebar_expanded:
            self._sidebar_container.configure(width=self._sidebar_width_expanded)
            self._sidebar_toggle.config(text="◀")
            for lbl in self._nav_labels:
                lbl.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(4, 8), pady=5)
            if hasattr(self, "_search_label"):
                self._search_label.pack(side=tk.LEFT, padx=(4, 8), pady=4)
            if hasattr(self, "_heartbeat_indicator"):
                self._heartbeat_indicator.pack(fill=tk.X, padx=8, pady=(0, 2))
            if hasattr(self, "_polkit_label"):
                self._polkit_label.pack(fill=tk.X, padx=8, pady=(0, 2))
        else:
            self._sidebar_container.configure(width=self._sidebar_width_collapsed)
            self._sidebar_toggle.config(text="▶")
            for lbl in self._nav_labels:
                lbl.pack_forget()
            if hasattr(self, "_search_label"):
                self._search_label.pack_forget()
            if hasattr(self, "_heartbeat_indicator"):
                self._heartbeat_indicator.pack_forget()
            if hasattr(self, "_polkit_label"):
                self._polkit_label.pack_forget()

    def _update_heartbeat_indicator(self):
        """Periodically update the sidebar heartbeat status indicator."""
        try:
            st = heartbeat_status()
            if st.get("running"):
                alerts = heartbeat_alerts()
                if alerts:
                    worst = max(alerts, key=lambda a: {"critical": 3, "warn": 2, "info": 1}.get(a.severity, 0))
                    self._heartbeat_indicator.config(
                        text=f"♥ {worst.message[:22]}",
                        fg={"critical": self.danger_color, "warn": self.warning_color}.get(worst.severity, self.accent_color),
                    )
                else:
                    awareness = get_heartbeat().awareness_dict()
                    cpu = awareness.get("cpu", "?")
                    ram = awareness.get("ram", "?")
                    self._heartbeat_indicator.config(
                        text=f"♥ CPU {cpu}% RAM {ram}%",
                        fg=self.success_color,
                    )
            else:
                self._heartbeat_indicator.config(text="♥ —", fg=self.text_dim)
        except Exception:
            pass
        # Repeat every 4 seconds
        try:
            self.root.after(4000, self._update_heartbeat_indicator)
        except Exception:
            pass

    def _nav_sidebar_select(self, index):
        """Select a tab from the sidebar and highlight the active button."""
        self._select_tab(index)
        self._update_nav_sidebar_highlight(index)

    def _update_nav_sidebar_highlight(self, active_index):
        """Update sidebar button colours to reflect the active tab."""
        active_bg = self._mix_hex(self.bg_secondary, self.accent_color, 0.70)
        for i, row in enumerate(self._nav_buttons):
            children = row.winfo_children()
            icon_lbl = children[0] if children else None
            text_lbl = self._nav_labels[i] if hasattr(self, "_nav_labels") and i < len(self._nav_labels) else None
            if i == active_index:
                row.config(bg=active_bg)
                if icon_lbl:
                    icon_lbl.config(bg=active_bg)
                    if hasattr(self, "_nav_icon_names") and i < len(self._nav_icon_names):
                        photo = self._get_nav_icon(self._nav_icon_names[i], self.accent_color)
                        if photo:
                            icon_lbl.config(image=photo)
                    else:
                        try:
                            icon_lbl.config(fg=self.accent_color)
                        except tk.TclError:
                            pass
                if text_lbl:
                    text_lbl.config(bg=active_bg, fg=self.accent_color)
            else:
                row.config(bg=self.bg_secondary)
                if icon_lbl:
                    icon_lbl.config(bg=self.bg_secondary)
                    if hasattr(self, "_nav_icon_names") and i < len(self._nav_icon_names):
                        photo = self._get_nav_icon(self._nav_icon_names[i], self.text_dim)
                        if photo:
                            icon_lbl.config(image=photo)
                    else:
                        try:
                            icon_lbl.config(fg=self.text_dim)
                        except tk.TclError:
                            pass
                if text_lbl:
                    text_lbl.config(bg=self.bg_secondary, fg=self.text_dim)

    def _select_tab(self, index):
        if not hasattr(self, "notebook"):
            return
        tabs = self.notebook.tabs()
        if 0 <= index < len(tabs):
            self.notebook.select(tabs[index])

    def _on_tab_changed(self, _event=None):
        try:
            tab_id = self.notebook.select()
            tab_text = self.notebook.tab(tab_id, "text").strip()
            self._set_status(f"{tab_text} ready", "info", timeout=1700)
            # Update sidebar highlight
            try:
                tab_idx = self.notebook.index(tab_id)
                self._update_nav_sidebar_highlight(tab_idx)
            except Exception:
                pass
            # Spring-animated fade-in for the active tab frame
            self._spring_tab_transition(tab_id)
        except Exception:
            pass

    def _spring_tab_transition(self, tab_id):
        """Apply a subtle spring fade-in animation when switching tabs.

        Note: slide_in uses place() which conflicts with Notebook's
        internal geometry management.  Use alpha fade on a transparent
        Toplevel overlay instead — or simply skip animation for now.
        """
        # Notebook child frames are geometry-managed internally;
        # calling place()/slide_in on them tears the layout.  Disabled.
        pass

    # ── Dashboard ───────────────────────────────────────────────────────

    def create_dashboard_tab(self):
        main, _canvas = self._create_scrollable_tab(self.dashboard_frame)

        # ── Gauge section (grid-based rigid layout) ──
        gauge_frame = tk.Frame(main, bg=self.bg_color)
        gauge_frame.pack(fill=tk.X, padx=20, pady=(15, 5))

        tk.Label(gauge_frame, text="System Overview", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(anchor="w", pady=(0, 8))

        # Grid container for gauge cards
        self._gauge_grid = tk.Frame(gauge_frame, bg=self.bg_color)
        self._gauge_grid.pack(fill=tk.X)
        # Configure 3-column grid
        for col in range(3):
            self._gauge_grid.columnconfigure(col, weight=1, uniform="gauge")
        for row in range(2):
            self._gauge_grid.rowconfigure(row, weight=1)

        self._gauge_card_widgets = {}
        gauge_names = ["CPU", "RAM", "Disk", "Temp", "GPU", "GPU T"]
        for i, name in enumerate(gauge_names):
            row, col = divmod(i, 3)
            card = tk.Frame(
                self._gauge_grid,
                bg=self.glass_white, relief="flat", bd=0,
                highlightbackground=self.border_color, highlightthickness=1,
            )
            card.grid(row=row, column=col, padx=4, pady=4, sticky="nsew")

            lbl = tk.Label(
                card, text=name, font=("Noto Sans", 9, "bold"),
                bg=self.glass_white, fg=self.text_dim,
            )
            lbl.pack(anchor="w", padx=10, pady=(8, 0))

            val_lbl = tk.Label(
                card, text="—", font=("Noto Sans", 18, "bold"),
                bg=self.glass_white, fg=self.accent_color,
            )
            val_lbl.pack(padx=10, pady=(0, 2))

            bar = ttk.Progressbar(card, length=120, mode="determinate", maximum=100)
            bar.pack(padx=10, pady=(0, 8), fill=tk.X)

            self._gauge_card_widgets[name] = {
                "card": card, "label": lbl, "value": val_lbl, "bar": bar,
            }

        # Keep canvas for backward compatibility but hide it
        self.gauge_canvas = tk.Canvas(
            gauge_frame, bg=self.glass_white, height=0,
            highlightthickness=0, bd=0,
        )
        # Don't pack the canvas — the grid cards replace it
        self.gauge_canvas.bind("<Configure>", lambda _e: self._draw_gauges())

        # Separator
        tk.Frame(main, bg=self.border_color, height=1).pack(fill=tk.X, padx=20, pady=5)

        # ── Title ──
        title_row = tk.Frame(main, bg=self.bg_color)
        title_row.pack(fill=tk.X, padx=20, pady=(5, 2))
        tk.Label(title_row, text="Diagnostic Log", font=("Noto Sans", 11, "bold"),
                 bg=self.bg_color, fg=self.text_dim).pack(side=tk.LEFT)

        self._create_collapsible_deck(
            main,
            "Dashboard Actions",
            [
                ("Run Diagnostics", lambda: self._run_threaded(self.scan_issues),
                 "Ctrl+D — Full system scan"),
                ("Refresh Status", self.check_initial_status, "F5 — Quick refresh"),
                ("Start Ollama", self._start_ollama_serve,
                 "Start the Ollama AI server if not already running"),
                ("Open AI Chat", lambda: self._select_tab(5),
                 "Jump to Fyxa AI Chat tab"),
            ],
            run_bg=self.accent_color,
            hint="Pick an action and press Run.",
            default="Run Diagnostics",
            collapsed=False,
        )

        # ── Text area ──
        txt_frame = self._create_glass_log_container(main, padx=20, pady=(0, 10))
        self.dashboard_text = self._create_modern_text(txt_frame)

        # Tag colours for diagnostic text
        self.dashboard_text.tag_config("heading", foreground=self.accent_color,   font=("Noto Sans Mono", 10, "bold"))
        self.dashboard_text.tag_config("ok",      foreground=self.success_color)
        self.dashboard_text.tag_config("warn",    foreground=self.warning_color)
        self.dashboard_text.tag_config("err",     foreground=self.danger_color)

    def _draw_gauges(self):
        """Update the grid-based gauge cards with live data."""
        # Update grid cards — these are the primary gauge display
        self._update_gauge_cards()

        # Legacy canvas is hidden (not packed) — skip drawing
        c = self.gauge_canvas
        if not c.winfo_ismapped():
            return
        c.delete("all")
        w = c.winfo_width()
        if w < 100:
            return

        bar_h      = 18
        gap        = 8
        label_w    = 60
        bar_x      = label_w + 10
        bar_w      = w - bar_x - 90
        if bar_w < 50:
            bar_w = 50

        if not self._gauge_targets:
            self._set_gauge_targets(self._get_gauge_data())
        order = ("CPU", "RAM", "Disk", "Temp", "GPU", "GPU T")
        names = [n for n in order if n in self._gauge_targets]
        names.extend([n for n in self._gauge_targets if n not in order])

        gauges = []
        for name in names:
            meta = self._gauge_targets[name]
            gauges.append(
                (
                    name,
                    self._gauge_display.get(name, meta["value"]),
                    meta["max"],
                    meta["color"],
                )
            )

        for i, (name, value, max_val, color) in enumerate(gauges):
            y = i * (bar_h + gap) + 8
            pct = min(value / max_val, 1.0) if max_val else 0

            # Label
            c.create_text(label_w, y + bar_h // 2, text=name, anchor="e",
                          fill=self.text_color, font=("Noto Sans", 10, "bold"))
            # Background bar (rounded rect via rectangle + arcs is too complex; use rect)
            c.create_rectangle(bar_x, y, bar_x + bar_w, y + bar_h,
                               fill=self.bg_secondary, outline="")
            # Fill bar
            fill_w = max(int(bar_w * pct), 0)
            if fill_w > 0:
                c.create_rectangle(bar_x, y, bar_x + fill_w, y + bar_h,
                                   fill=color, outline="")
            # Percentage text
            txt = f"{value:.0f}%" if max_val == 100 else f"{value:.0f}/{max_val:.0f}"
            c.create_text(bar_x + bar_w + 10, y + bar_h // 2, text=txt, anchor="w",
                          fill=self.text_color, font=("Noto Sans", 10))

    def _update_gauge_cards(self):
        """Populate the grid-based gauge cards with current values."""
        if not hasattr(self, "_gauge_card_widgets") or not self._gauge_card_widgets:
            return
        if not self._gauge_targets:
            return
        for name, meta in self._gauge_targets.items():
            card_w = self._gauge_card_widgets.get(name)
            if not card_w:
                continue
            value = self._gauge_display.get(name, meta["value"])
            max_val = meta["max"]
            pct = min(value / max_val, 1.0) if max_val else 0.0
            txt = f"{value:.0f}%" if max_val == 100 else f"{value:.0f}°"
            try:
                card_w["value"].config(text=txt, fg=meta["color"])
                card_w["bar"]["value"] = pct * 100
            except Exception:
                pass

    def _set_gauge_targets(self, gauges):
        targets = {}
        for name, value, max_val, color in gauges:
            targets[name] = {
                "value": float(value),
                "max": float(max_val),
                "color": color,
            }
            if name not in self._gauge_display:
                self._gauge_display[name] = float(value)
        for existing in list(self._gauge_display):
            if existing not in targets:
                self._gauge_display.pop(existing, None)
        self._gauge_targets = targets

    def _start_gauge_animation(self):
        if self._gauge_anim_after_id:
            try:
                self.root.after_cancel(self._gauge_anim_after_id)
            except Exception:
                pass
            self._gauge_anim_after_id = None
        self._animate_gauges()

    def _animate_gauges(self):
        if not self._gauge_targets:
            self._gauge_anim_after_id = self.root.after(60, self._animate_gauges)
            return
        changed = False
        for name, target in self._gauge_targets.items():
            cur = float(self._gauge_display.get(name, target["value"]))
            nxt = cur + (target["value"] - cur) * 0.26
            if abs(nxt - target["value"]) < 0.2:
                nxt = target["value"]
            if abs(nxt - cur) >= 0.01:
                self._gauge_display[name] = nxt
                changed = True
        if changed:
            try:
                self._draw_gauges()
            except Exception:
                pass
        self._gauge_anim_after_id = self.root.after(33, self._animate_gauges)

    def _get_gauge_data(self):
        """Return list of (name, value, max_value, colour) for dashboard gauges."""
        data = []
        if HAS_PSUTIL:
            try:
                cpu = psutil.cpu_percent(interval=0)
                data.append(("CPU", cpu, 100, self._usage_color(cpu)))
            except Exception:
                data.append(("CPU", 0, 100, self.text_dim))

            try:
                mem = psutil.virtual_memory()
                data.append(("RAM", mem.percent, 100, self._usage_color(mem.percent)))
            except Exception:
                data.append(("RAM", 0, 100, self.text_dim))

            try:
                import shutil
                disk = shutil.disk_usage("/")
                pct = 100 * disk.used / disk.total
                data.append(("Disk", pct, 100, self._usage_color(pct)))
            except Exception:
                data.append(("Disk", 0, 100, self.text_dim))

            try:
                temps = psutil.sensors_temperatures()
                max_temp = 0
                for _name, entries in temps.items():
                    for e in entries:
                        if e.current and e.current > max_temp:
                            max_temp = e.current
                color = self.danger_color if max_temp > 85 else (self.warning_color if max_temp > 70 else self.success_color)
                data.append(("Temp", max_temp, 110, color))
            except Exception:
                data.append(("Temp", 0, 110, self.text_dim))

            # GPU utilization (nvidia-smi)
            try:
                nv = subprocess.run(
                    ["nvidia-smi", "--query-gpu=utilization.gpu,temperature.gpu",
                     "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=3,
                    stdin=subprocess.DEVNULL,
                )
                if nv.returncode == 0 and nv.stdout.strip():
                    parts = [p.strip() for p in nv.stdout.strip().split(",")]
                    gpu_util = float(parts[0])
                    data.append(("GPU", gpu_util, 100, self._usage_color(gpu_util)))
                    if len(parts) > 1:
                        gpu_temp = float(parts[1])
                        color = self.danger_color if gpu_temp > 85 else (self.warning_color if gpu_temp > 70 else self.success_color)
                        data.append(("GPU T", gpu_temp, 110, color))
            except (FileNotFoundError, Exception):
                pass
        else:
            for label in ("CPU", "RAM", "Disk", "Temp"):
                data.append((label, 0, 100, self.text_dim))
        return data

    def _usage_color(self, pct):
        if pct > 90: return self.danger_color
        if pct > 70: return self.warning_color
        return self.success_color

    @classmethod
    def _preferred_gui_entrypoint(cls):
        """Return the best command to launch Sysfix GUI in a new process."""
        exe = shutil.which("sysfix")
        if exe:
            return [exe, "gui"]
        return [sys.executable, "-m", "sysfixai.launcher", "gui"]

    @classmethod
    def _manual_sudo_gui_command(cls):
        return "sudo " + " ".join(shlex.quote(part) for part in cls._preferred_gui_entrypoint())

    @staticmethod
    def _sudo_display_env():
        keys = (
            "DISPLAY",
            "XAUTHORITY",
            "WAYLAND_DISPLAY",
            "XDG_RUNTIME_DIR",
            "DBUS_SESSION_BUS_ADDRESS",
            "HOME",
            "PATH",
        )
        exports = []
        for key in keys:
            val = os.environ.get(key, "").strip()
            if val:
                exports.append(f"{key}={val}")
        return exports

    @classmethod
    def _build_elevated_gui_command(cls, takeover=False, parent_pid=None):
        """Build a reliable command for relaunching GUI with elevated privileges."""
        base_cmd = cls._preferred_gui_entrypoint()
        takeover_env = []
        if takeover:
            takeover_env.append("SYSFIX_TAKEOVER=1")
            takeover_pid = int(parent_pid) if parent_pid is not None else os.getpid()
            if takeover_pid > 1:
                takeover_env.append(f"SYSFIX_PARENT_PID={takeover_pid}")

        pkexec = shutil.which("pkexec")
        if pkexec:
            cmd = [pkexec]
            env_exports = cls._sudo_display_env()
            env_exports.extend(takeover_env)
            if env_exports:
                cmd.extend(["env", *env_exports])
            cmd.extend(base_cmd)
            return cmd, "pkexec"

        sudo_cmd = ["sudo", *takeover_env, *base_cmd]
        terminal_launchers = (
            ("konsole", lambda term: [term, "-e", *sudo_cmd]),
            ("gnome-terminal", lambda term: [term, "--", *sudo_cmd]),
            ("xfce4-terminal", lambda term: [term, "--command", " ".join(shlex.quote(p) for p in sudo_cmd)]),
            ("xterm", lambda term: [term, "-e", *sudo_cmd]),
            ("kitty", lambda term: [term, *sudo_cmd]),
        )

        for term_name, builder in terminal_launchers:
            term = shutil.which(term_name)
            if term:
                return builder(term), term_name
        return None, None

    def _graceful_exit(self):
        """Gracefully shut down the GUI for handoff to an elevated instance."""
        try:
            self.root.quit()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass

    def _enable_sudo_mode(self):
        """Restart Sysfix with root privileges via pkexec or terminal sudo.

        Always does a full restart so the entire session runs elevated.
        Uses pkexec (graphical password prompt) when available, otherwise
        opens a terminal emulator for sudo.
        """
        if self.is_sudo:
            messagebox.showinfo("Admin Mode", "Sysfix is already running with root privileges.")
            return

        if not messagebox.askyesno(
            "Restart as Admin",
            "This will restart Sysfix with root privileges.\n\n"
            "You will be prompted for your password.\n"
            "Your current session will close.\n\n"
            "Continue?",
        ):
            return

        try:
            cmd, launcher = self._build_elevated_gui_command(
                takeover=True,
                parent_pid=os.getpid(),
            )
            if not cmd:
                messagebox.showerror(
                    "Restart as Admin",
                    "Could not find pkexec or a terminal emulator.\n"
                    f"Run manually:\n{self._manual_sudo_gui_command()}",
                )
                return

            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self._set_status(
                f"Restarting as Admin via {launcher}\u2026", "working", timeout=15000,
            )

            def _await_elevated(attempt=0):
                rc = proc.poll()
                if rc is not None and rc != 0:
                    stderr_out = ""
                    try:
                        stderr_out = proc.stderr.read().decode(errors="replace").strip()
                    except Exception:
                        pass
                    detail = f"\n\n{stderr_out}" if stderr_out else ""
                    messagebox.showerror(
                        "Restart as Admin",
                        f"Elevated launch failed (exit code {rc}).{detail}\n\n"
                        f"Try manually:\n{self._manual_sudo_gui_command()}",
                    )
                    self._set_status("Admin restart failed", "err", timeout=4200)
                    return
                # Process exited cleanly or took too long — hand off
                if (rc is not None and rc == 0) or attempt >= 30:
                    self._set_status("Admin session started — closing\u2026", "ok", timeout=2000)
                    self.root.after(1200, self._graceful_exit)
                    return
                self.root.after(1000, lambda: _await_elevated(attempt + 1))

            self.root.after(1500, _await_elevated)
        except Exception as e:
            messagebox.showerror("Restart as Admin", f"Failed to restart:\n{e}")

    def _run_elevated_task(self, task_name, params=None, callback=None):
        """Run a single privileged task via Polkit worker subprocess.

        If the GUI is already root or Polkit on-demand is not enabled,
        runs the task directly in-process via the sandbox.
        """
        params = params or {}

        # Already root — run directly
        if self.is_sudo:
            self._run_task_direct(task_name, params, callback)
            return

        # Polkit on-demand available
        if getattr(self, "_polkit_on_demand", False) and check_polkit():
            def _worker():
                try:
                    self._safe(lambda: self._set_status(
                        f"Elevating: {task_name}…", "working", timeout=30000,
                    ))
                    result = pk_worker_run(task_name, params, timeout=120)
                    self._safe(lambda: self._set_status(
                        f"{task_name} completed ✓", "ok", timeout=3500,
                    ))
                    if callback:
                        self._safe(lambda: callback(result))
                except ElevationError as exc:
                    self._safe(lambda: self._show_toast(
                        f"Elevation denied: {exc}", "err",
                    ))
                except Exception as exc:
                    self._safe(lambda: self._show_toast(
                        f"Task failed: {exc}", "err",
                    ))
            threading.Thread(target=_worker, daemon=True).start()
            return

        # No elevation available — try direct (may fail for privileged ops)
        self._run_task_direct(task_name, params, callback)

    def _run_task_direct(self, task_name, params, callback=None):
        """Run task in-process (for root GUI or unprivileged tasks)."""
        def _work():
            try:
                from sysfixai.polkit import _dispatch_task
                result = _dispatch_task(task_name, params)
                if callback:
                    self._safe(lambda: callback(result))
            except Exception as exc:
                self._safe(lambda: self._show_toast(f"Task error: {exc}", "err"))
        threading.Thread(target=_work, daemon=True).start()

    def _start_ollama_serve(self):
        """Start the Ollama server if not already running."""
        if is_ollama_running():
            messagebox.showinfo("Ollama", "Ollama is already running.")
            return
        ollama_bin = shutil.which("ollama")
        if not ollama_bin:
            messagebox.showerror("Ollama Not Found",
                "The 'ollama' command was not found on your system.\n\n"
                "Install it from: https://ollama.com")
            return
        try:
            subprocess.Popen(
                [ollama_bin, "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            # Wait a moment then check if it came up
            def _check():
                import time
                time.sleep(2)
                if is_ollama_running():
                    self._safe(self._refresh_ai_status_label)
                    self._safe(lambda: messagebox.showinfo("Ollama", "Ollama server started successfully."))
                else:
                    self._safe(lambda: messagebox.showwarning("Ollama",
                        "Ollama was launched but hasn't come online yet.\n"
                        "It may take a moment — check again shortly."))
            threading.Thread(target=_check, daemon=True).start()
        except Exception as e:
            messagebox.showerror("Ollama", f"Failed to start Ollama:\n{e}")

    # ── Quick Fix ───────────────────────────────────────────────────────

    def create_quick_fix_tab(self):
        main, _canvas = self._create_scrollable_tab(self.quick_fix_frame)

        # Header
        title_row = tk.Frame(main, bg=self.bg_color)
        title_row.pack(fill=tk.X, padx=20, pady=(15, 2))
        tk.Frame(title_row, bg=self.success_color, width=4, height=20).pack(side=tk.LEFT, padx=(0, 10))
        tk.Label(title_row, text="Quick Actions", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(side=tk.LEFT)

        tk.Label(main, text="One-click system maintenance — scan, fix, optimise, and cleanup",
                 font=("Noto Sans", 9), bg=self.bg_color, fg=self.text_dim).pack(anchor="w", padx=20, pady=(0, 8))

        self._create_action_deck(
            main,
            "Maintenance Actions",
            [
                ("Fast Sweep", lambda: self._run_threaded(self.fast_sweep),
                 "Quick non-destructive scan"),
                ("Auto-Fix", lambda: self._run_threaded(self.apply_fixes),
                 "AI-powered automatic fixes (requires sudo)"),
                ("Memory Optimization", lambda: self._run_threaded(self.optimize_memory),
                 "Analyse RAM usage by process"),
                ("Disk Cleanup", lambda: self._run_threaded(self.cleanup_disk),
                 "Scan disk usage in your home directory"),
            ],
            run_bg=self.success_color,
            hint="Fewer controls, same power: choose maintenance action then Run.",
            default="Fast Sweep",
        )

        txt_frame = self._create_glass_log_container(main, padx=20, pady=(0, 10))
        self.fix_text = self._create_modern_text(txt_frame)

        # Tag config for coloured onboarding text
        self.fix_text.tag_config("heading", foreground=self.accent_color, font=("Noto Sans Mono", 10, "bold"))
        self.fix_text.tag_config("ok",   foreground=self.success_color)
        self.fix_text.tag_config("warn", foreground=self.warning_color)
        self.fix_text.tag_config("info", foreground=self.text_dim)
        self.fix_text.tag_config("err",  foreground=self.danger_color)

        # Show onboarding instructions by default
        self._show_quickfix_welcome()

    def _show_quickfix_welcome(self):
        """Show onboarding instructions on the Quick Fix tab."""
        def _do():
            w = self.fix_text
            w.config(state=tk.NORMAL)
            w.delete(1.0, tk.END)
            w.insert(tk.END, "QUICK ACTIONS\n", "heading")
            w.insert(tk.END, "=" * 55 + "\n\n")
            w.insert(tk.END, "  Welcome to Quick Actions. Use the action menu above to run\n")
            w.insert(tk.END, "  common maintenance tasks with one click.\n\n")
            w.insert(tk.END, "  Available actions:\n\n")
            w.insert(tk.END, "  ● Fast Sweep\n", "ok")
            w.insert(tk.END, "    Non-destructive scan of your system. Identifies issues\n", "info")
            w.insert(tk.END, "    without making any changes. Safe to run at any time.\n\n", "info")
            w.insert(tk.END, "  ● Auto-Fix\n", "ok")
            w.insert(tk.END, "    AI-powered automatic repair. Analyses your system and\n", "info")
            w.insert(tk.END, "    applies safe fixes. Requires sudo and an available AI provider.\n\n", "info")
            w.insert(tk.END, "  ● Memory Optimization\n", "warn")
            w.insert(tk.END, "    Lists the top 10 processes consuming the most RAM, with\n", "info")
            w.insert(tk.END, "    total/used/available breakdown.\n\n", "info")
            w.insert(tk.END, "  ● Disk Cleanup\n", "warn")
            w.insert(tk.END, "    Scans your home directory for large folders and shows\n", "info")
            w.insert(tk.END, "    total disk usage at a glance.\n\n", "info")
            w.insert(tk.END, "  " + "-" * 50 + "\n", "info")
            w.insert(tk.END, "  Tip: Run 'Fast Sweep' first to see what's going on,\n", "info")
            w.insert(tk.END, "  then use 'Auto-Fix' if issues are found.\n", "info")
            if not self.is_sudo:
                w.insert(tk.END, "\n  Note: Some actions need elevated privileges.\n", "warn")
                w.insert(tk.END, "  Run `sudo sysfix gui` for full access.\n", "warn")
            w.config(state=tk.DISABLED)
        self._safe(_do)

    # ── Security ────────────────────────────────────────────────────────

    def create_security_tab(self):
        main, _canvas = self._create_scrollable_tab(self.security_frame)

        title_row = tk.Frame(main, bg=self.bg_color)
        title_row.pack(fill=tk.X, padx=20, pady=(15, 2))
        tk.Frame(title_row, bg=self.danger_color, width=4, height=20).pack(side=tk.LEFT, padx=(0, 10))
        tk.Label(title_row, text="Security Scanner", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(side=tk.LEFT)

        tk.Label(main, text="Firewall, ports, SUID, rootkits, SSH, virus scanning, system updates",
                 font=("Noto Sans", 9), bg=self.bg_color, fg=self.text_dim).pack(anchor="w", padx=20, pady=(0, 8))

        self._create_action_deck(
            main,
            "Security Actions",
            [
                ("Security Scan", lambda: self._run_threaded(self._run_security_scan),
                 "Full security audit"),
                ("Check Updates", lambda: self._run_threaded(self._run_update_check),
                 "Check for Fedora/Debian package updates"),
                ("Apply Updates", lambda: self._run_threaded(self._run_apply_updates),
                 "Install all pending system updates (sudo)"),
                ("Sysfix Update", lambda: self._run_threaded(self._run_sysfix_update_check),
                 "Check & pull latest Sysfix from GitHub"),
                ("Scan File", self._scan_file_dialog,
                 "Hash-check a file against malware databases"),
                ("Scan Directory", self._scan_dir_dialog,
                 "Scan folder for known malware hashes"),
                ("Scan Downloads", lambda: self._run_threaded(self._scan_downloads),
                 "Scan ~/Downloads for known malware"),
            ],
            run_bg=self.danger_color,
            hint="All security operations are now in one compact action menu.",
            default="Security Scan",
        )

        txt_frame = self._create_glass_log_container(main, padx=20, pady=(0, 10))
        # Progress bar for security scans (hidden until a scan starts)
        self.security_progress = ttk.Progressbar(txt_frame, mode="determinate", maximum=100)
        self.security_progress.pack(fill=tk.X, padx=6, pady=(6, 4))
        self.security_progress.pack_forget()

        self.security_text = self._create_modern_text(txt_frame)
        self.security_text.tag_config("heading", foreground=self.accent_color,   font=("Noto Sans Mono", 10, "bold"))
        self.security_text.tag_config("ok",      foreground=self.success_color)
        self.security_text.tag_config("warn",    foreground=self.warning_color)
        self.security_text.tag_config("err",     foreground=self.danger_color)
        self.security_text.tag_config("info",    foreground=self.text_dim)

        # ── Advanced Security (collapsed sections) ─────────────────
        self._create_collapsible_deck(
            main,
            "Advanced Security & Acceleration",
            [
                ("eBPF Sentinel", lambda: self._run_threaded(self._run_sentinel_toggle),
                 "Real-time execve/connect monitoring (requires root + bcc)"),
                ("Sentinel Alerts", lambda: self._run_threaded(self._run_sentinel_report),
                 "View eBPF Sentinel alerts"),
                ("Micro-VM", lambda: self._open_microvm_dialog(),
                 "Run commands in Firecracker micro-VM"),
                ("VM Status", lambda: self._run_threaded(self._run_microvm_report),
                 "Micro-VM and sandbox backend status"),
                ("NPU Status", lambda: self._run_threaded(self._run_npu_report),
                 "Neural Processing Unit detection & offload status"),
            ],
            run_bg=self.danger_color,
            collapsed=True,
        )

        self._create_collapsible_deck(
            main,
            "Sentinel AV (Kernel Antivirus)",
            [
                ("Start/Stop AV", lambda: self._run_threaded(self._run_av_toggle),
                 "Start/stop the kernel-level eBPF antivirus engine"),
                ("AV Status", lambda: self._run_threaded(self._run_av_report),
                 "Full Sentinel AV capability and threat report"),
                ("Deep Scan", lambda: self._run_threaded(self._run_pipeline_scan),
                 "Multi-stage scan: ClamAV + YARA + VirusTotal"),
                ("Pipeline Status", lambda: self._run_threaded(self._run_pipeline_report),
                 "Malware pipeline capability report"),
                ("Threat Log", lambda: self._run_threaded(self._run_av_threat_log),
                 "View detected threats with dispositions"),
                ("Threat Map", lambda: self._run_threaded(self._run_av_threat_map),
                 "Visual map of what the latest threat touched"),
            ],
            run_bg=self.danger_color,
            collapsed=True,
        )

        self._create_collapsible_deck(
            main,
            "Sentinel Bridge (AI Security Scanner)",
            [
                ("Security Scan", lambda: self._run_threaded(self._run_bridge_scan),
                 "Full read-only security scan (free tier, no root needed)"),
                ("Process Scan", lambda: self._run_threaded(self._run_bridge_proc_scan),
                 "Check for malware, miners, reverse shells, fileless malware"),
                ("Network Scan", lambda: self._run_threaded(self._run_bridge_net_scan),
                 "Check for C2 ports, suspicious connections, listening services"),
                ("Bridge Status", lambda: self._run_threaded(self._run_bridge_status),
                 "Sentinel Bridge tier and capability report"),
            ],
            run_bg=self.accent_color,
            collapsed=True,
        )

        # Show onboarding text
        self._show_security_welcome()

    def _run_security_scan(self):
        self.update_text(self.security_text, "Running security scan... this may take a moment.\n")
        checks = [
            ("Listening ports", security_scan_full.__globals__.get("check_listening_ports")),
            ("Firewall status", security_scan_full.__globals__.get("check_firewall_status")),
            ("Failed logins", security_scan_full.__globals__.get("check_failed_logins")),
            ("SUID binaries", security_scan_full.__globals__.get("check_suid_binaries")),
            ("World-writable dirs", security_scan_full.__globals__.get("check_world_writable_dirs")),
            ("/tmp suspicious", security_scan_full.__globals__.get("check_tmp_suspicious")),
            ("SSH config", security_scan_full.__globals__.get("check_ssh_config")),
            ("Suspicious processes", security_scan_full.__globals__.get("check_suspicious_processes")),
            ("Rootkit tools", security_scan_full.__globals__.get("check_rootkit_tools")),
            ("User accounts", security_scan_full.__globals__.get("check_user_accounts")),
        ]

        total = len(checks)
        results = []
        try:
            # Show progress bar
            self._safe(self.security_progress.pack)
            for idx, (label, func) in enumerate(checks, start=1):
                pct = int((idx - 1) / total * 100)
                self._safe(self.security_progress.configure, value=pct)
                if not callable(func):
                    # fallback to running the full scan if a subcheck isn't available
                    chunk = []
                else:
                    try:
                        chunk = func() or []
                    except Exception as e:
                        chunk = [f"ERROR running {label}: {e}"]
                results.extend(chunk)
                # append incremental output to the text area
                if chunk:
                    self._safe(self.update_text, self.security_text, f"--- {label} ---\n")
                    for line in chunk:
                        self._safe(self.update_text, self.security_text, line + "\n")
                self._safe(self.security_progress.configure, value=int(idx / total * 100))
            # Finalize
            self._safe(self.security_progress.configure, value=100)
            self._safe(self._paint_report, self.security_text, "SECURITY SCAN", results)
            # Desktop notification with summary
            warns = sum(1 for r in results if "WARN" in str(r))
            self._safe(
                self._notify,
                "Security Scan Complete",
                f"{len(results)} checks done, {warns} warning(s) found." if warns
                else f"{len(results)} checks done — no issues found.",
                level="warn" if warns else "ok",
                timeout=5000,
            )
        except Exception as e:
            self._safe(self.update_text, self.security_text, f"Error during security scan: {e}")
        finally:
            # hide progress bar after brief pause
            def _hide():
                try:
                    self.security_progress.pack_forget()
                except Exception:
                    pass

            self._safe(lambda: self.root.after(450, _hide))

    def _show_security_welcome(self):
        """Onboarding instructions for the Security tab."""
        def _do():
            w = self.security_text
            w.config(state=tk.NORMAL)
            w.delete(1.0, tk.END)
            w.insert(tk.END, "SECURITY SCANNER\n", "heading")
            w.insert(tk.END, "=" * 55 + "\n\n")
            w.insert(tk.END, "  Comprehensive security auditing and malware scanning.\n")
            w.insert(tk.END, "  Use the action menu above to get started.\n\n")
            w.insert(tk.END, "  Security & Updates:\n\n", "heading")
            w.insert(tk.END, "  \u25cf Security Scan\n", "err")
            w.insert(tk.END, "    Full audit: firewall status, open ports, SUID binaries,\n", "info")
            w.insert(tk.END, "    rootkit indicators, SSH config, and suspicious processes.\n\n", "info")
            w.insert(tk.END, "  \u25cf Check Updates\n", "warn")
            w.insert(tk.END, "    Query your package manager for pending updates.\n\n", "info")
            w.insert(tk.END, "  \u25cf Apply Updates\n", "ok")
            w.insert(tk.END, "    Install all pending system updates (requires sudo).\n\n", "info")
            w.insert(tk.END, "  \u25cf Sysfix Update\n", "ok")
            w.insert(tk.END, "    Check for & pull new Sysfix commits from GitHub.\n\n", "info")
            w.insert(tk.END, "  Virus Scanning:\n\n", "heading")
            w.insert(tk.END, "  \u25cf Scan File / Scan Directory / Scan Downloads\n", "warn")
            w.insert(tk.END, "    Hash-check files against MalwareBazaar (free, no key)\n", "info")
            w.insert(tk.END, "    and VirusTotal (optional API key in Settings).\n\n", "info")
            w.insert(tk.END, "  " + "-" * 50 + "\n", "info")
            w.insert(tk.END, "  Tip: Start with 'Security Scan' for a full overview.\n", "info")
            if not self.is_sudo:
                w.insert(tk.END, "  Note: Some checks are more thorough with sudo.\n", "warn")
            w.config(state=tk.DISABLED)
        self._safe(_do)

    def _run_update_check(self):
        self.update_text(self.security_text, "Checking for system updates (this may take a moment)...\n")
        try:
            results = check_pending_updates_detailed()
            self._paint_report(self.security_text, "UPDATE CHECK", results)
        except Exception as e:
            self.update_text(self.security_text, f"Error: {e}")

    def _run_apply_updates(self):
        self.update_text(self.security_text, "Applying system updates (sudo dnf upgrade)...\nThis may take several minutes.\n")
        try:
            def _progress(msg):
                self._safe(lambda: self._append_text(self.security_text, msg + "\n"))
            results = apply_system_updates(progress_cb=_progress)
            self._paint_report(self.security_text, "SYSTEM UPDATE", results)
        except Exception as e:
            self._safe(lambda: self._append_text(self.security_text, f"\nError: {e}\n", "err"))

    def _run_sysfix_update_check(self):
        self.update_text(self.security_text, "Checking for Sysfix updates on GitHub...\n")
        try:
            results = check_sysfix_update()
            has_update = any("update available" in r.lower() for r in results)
            self._paint_report(self.security_text, "SYSFIX UPDATE CHECK", results)
            if has_update:
                self._safe(lambda: self._append_text(self.security_text,
                    "\nPulling updates...\n", "warn"))
                pull_results = apply_sysfix_update()
                for line in pull_results:
                    tag = "ok" if "success" in line.lower() else ("err" if "ERROR" in line else "info")
                    self._safe(lambda l=line, t=tag: self._append_text(self.security_text, l + "\n", t))
        except Exception as e:
            self._safe(lambda: self._append_text(self.security_text, f"Error: {e}\n", "err"))

    def _scan_file_dialog(self):
        path = filedialog.askopenfilename(title="Select file to scan")
        if path:
            self._run_threaded(self._run_file_scan, path)

    def _scan_dir_dialog(self):
        path = filedialog.askdirectory(title="Select directory to scan")
        if path:
            self._run_threaded(self._run_dir_scan, path)

    def _run_file_scan(self, path):
        vt_key = self.config.get("virustotal_api_key", "")
        self.update_text(self.security_text, f"Scanning: {path}\n")
        try:
            results = scan_file_hash(path, vt_api_key=vt_key or "")
            self._paint_report(self.security_text, "FILE SCAN", results)
        except Exception as e:
            self._safe(lambda: self._append_text(self.security_text, f"Error: {e}\n", "err"))

    def _run_dir_scan(self, path):
        vt_key = self.config.get("virustotal_api_key", "")
        self.update_text(self.security_text, f"Scanning directory: {path}\nThis may take a while...\n")
        try:
            def _progress(msg):
                self._safe(lambda: self._append_text(self.security_text, msg + "\n"))
            results = scan_directory_hashes(path, vt_api_key=vt_key or "", progress_cb=_progress)
            self._paint_report(self.security_text, "DIRECTORY SCAN", results)
        except Exception as e:
            self._safe(lambda: self._append_text(self.security_text, f"Error: {e}\n", "err"))

    def _scan_downloads(self):
        downloads = os.path.join(os.path.expanduser("~"), "Downloads")
        if not os.path.isdir(downloads):
            self.update_text(self.security_text, "~/Downloads not found.\n")
            return
        self._run_dir_scan(downloads)

    def _append_text(self, widget, text, tag=None):
        """Append text to a ScrolledText (must be called from main thread)."""
        widget.config(state=tk.NORMAL)
        if tag:
            widget.tag_config(tag, foreground={
                "ok": self.success_color, "err": self.danger_color,
                "warn": self.warning_color, "info": self.text_dim,
            }.get(tag, self.metallic_light))
            widget.insert(tk.END, text, tag)
        else:
            widget.insert(tk.END, text)
        widget.see(tk.END)
        widget.config(state=tk.DISABLED)

    # ── Network ─────────────────────────────────────────────────────────

    def create_network_tab(self):
        main, _canvas = self._create_scrollable_tab(self.network_frame)

        title_row = tk.Frame(main, bg=self.bg_color)
        title_row.pack(fill=tk.X, padx=20, pady=(15, 2))
        tk.Frame(title_row, bg=self.accent_secondary, width=4, height=20).pack(side=tk.LEFT, padx=(0, 10))
        tk.Label(title_row, text="Network & Connectivity", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(side=tk.LEFT)

        tk.Label(main, text="Interfaces, DNS, Wi-Fi, latency, firewall, bandwidth, traceroute",
                 font=("Noto Sans", 9), bg=self.bg_color, fg=self.text_dim).pack(anchor="w", padx=20, pady=(0, 8))

        self._create_action_deck(
            main,
            "Network Actions",
            [
                ("Full Network Check", lambda: self._run_threaded(self._run_network_diag),
                 "Interfaces, DNS, gateway, internet check"),
                ("Wi-Fi Info", lambda: self._run_threaded(self._run_wifi_info),
                 "SSID, signal strength, frequency"),
                ("Public IP", lambda: self._run_threaded(self._run_public_ip),
                 "Fetch your public IP address"),
                ("Firewall", lambda: self._run_threaded(self._run_firewall_brief),
                 "Quick firewall status check"),
                ("Ping Test", lambda: self._run_threaded(self._run_ping_test),
                 "Ping 8.8.8.8 and 1.1.1.1"),
                ("Traceroute", lambda: self._run_threaded(self._run_traceroute),
                 "Trace path to 8.8.8.8"),
                ("Connections", lambda: self._run_threaded(self._run_connections),
                 "Active TCP/UDP connections summary"),
                ("Bandwidth", lambda: self._run_threaded(self._run_bandwidth),
                 "Network I/O counters since boot"),
                ("Optimize Wi-Fi", lambda: self._run_threaded(self._run_wifi_optimize),
                 "Roam to the strongest BSSID for your current SSID"),
                ("Full Report", lambda: self._run_threaded(self._run_full_network_report),
                 "Run every diagnostic and produce a full report"),
            ],
            run_bg=self.accent_secondary,
            hint="Use one action picker instead of multiple button rows.",
            default="Full Network Check",
        )

        txt_frame = self._create_glass_log_container(main, padx=20, pady=(0, 10))
        self.network_text = self._create_modern_text(txt_frame)
        self.network_text.tag_config("heading", foreground=self.accent_color,   font=("Noto Sans Mono", 10, "bold"))
        self.network_text.tag_config("ok",      foreground=self.success_color)
        self.network_text.tag_config("warn",    foreground=self.warning_color)
        self.network_text.tag_config("err",     foreground=self.danger_color)
        self.network_text.tag_config("info",    foreground=self.text_dim)

        # Show onboarding text
        self._show_network_welcome()

    def _run_network_diag(self):
        self.update_text(self.network_text, "Running network diagnostics...\n")
        try:
            results = network_diagnostics()
            self._paint_report(self.network_text, "NETWORK DIAGNOSTICS", results)
            fails = sum(1 for r in results if "FAILED" in str(r) or "NOT" in str(r))
            self._safe(
                self._notify,
                "Network Diagnostics Complete",
                f"{len(results)} checks, {fails} issue(s)." if fails
                else f"{len(results)} checks — all good.",
                level="warn" if fails else "ok",
                timeout=4000,
            )
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_wifi_info(self):
        self.update_text(self.network_text, "Checking Wi-Fi info...\n")
        try:
            results = check_wifi_info()
            self._paint_report(self.network_text, "WI-FI INFO", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_wifi_optimize(self):
        self.update_text(self.network_text, "Optimizing Wi-Fi connection...\n")
        try:
            results = optimize_wifi_connection()
            self._paint_report(self.network_text, "WI-FI OPTIMIZATION", results)
            roamed = any("roam" in str(r).lower() or "switched" in str(r).lower() for r in results)
            self._safe(
                self._notify,
                "Wi-Fi Optimization",
                "Roamed to a stronger access point!" if roamed
                else "Already on the best available access point.",
                level="ok",
                timeout=4000,
            )
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_public_ip(self):
        self.update_text(self.network_text, "Fetching public IP...\n")
        try:
            results = check_public_ip()
            self._paint_report(self.network_text, "PUBLIC IP", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_firewall_brief(self):
        self.update_text(self.network_text, "Checking firewall status...\n")
        try:
            results = check_firewall_brief()
            self._paint_report(self.network_text, "FIREWALL STATUS", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_ping_test(self):
        self.update_text(self.network_text, "Running ping tests...\n")
        try:
            results: list = []
            results.extend(check_ping("8.8.8.8", 4))
            results.extend(check_ping("1.1.1.1", 4))
            results.extend(check_ping("google.com", 4))
            self._paint_report(self.network_text, "PING TEST", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_traceroute(self):
        self.update_text(self.network_text, "Running traceroute (this may take a moment)...\n")
        try:
            results = check_traceroute("8.8.8.8", 20)
            self._paint_report(self.network_text, "TRACEROUTE", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_connections(self):
        self.update_text(self.network_text, "Scanning active connections...\n")
        try:
            results = check_active_connections()
            self._paint_report(self.network_text, "ACTIVE CONNECTIONS", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_bandwidth(self):
        self.update_text(self.network_text, "Reading bandwidth counters...\n")
        try:
            results = check_bandwidth_usage()
            self._paint_report(self.network_text, "BANDWIDTH USAGE", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _run_full_network_report(self):
        self.update_text(self.network_text, "Generating full network & system report...\n")
        try:
            results: list = []
            results.append("── Network Interfaces ──")
            results.extend(check_network_interfaces())
            results.append("")
            results.append("── DNS Resolution ──")
            results.extend(check_dns_resolution())
            results.append("")
            results.append("── Gateway Latency ──")
            results.extend(check_gateway_latency())
            results.append("")
            results.append("── Internet Connectivity ──")
            results.extend(check_internet_connectivity())
            results.append("")
            results.append("── Wi-Fi ──")
            results.extend(check_wifi_info())
            results.append("")
            results.append("── Public IP ──")
            results.extend(check_public_ip())
            results.append("")
            results.append("── Firewall ──")
            results.extend(check_firewall_brief())
            results.append("")
            results.append("── Ping Tests ──")
            results.extend(check_ping("8.8.8.8", 3))
            results.extend(check_ping("1.1.1.1", 3))
            results.append("")
            results.append("── Bandwidth (since boot) ──")
            results.extend(check_bandwidth_usage())
            results.append("")
            results.append("── Active Connections ──")
            results.extend(check_active_connections())
            results.append("")
            results.append("── System Health ──")
            results.extend(check_boot_time())
            results.extend(check_systemd_failed())
            results.extend(check_journal_errors())
            results.extend(check_usb_devices())
            results.extend(check_smart_health())
            self._paint_report(self.network_text, "FULL NETWORK & SYSTEM REPORT", results)
        except Exception as e:
            self.update_text(self.network_text, f"Error: {e}")

    def _show_network_welcome(self):
        """Onboarding instructions for the Network tab."""
        def _do():
            w = self.network_text
            w.config(state=tk.NORMAL)
            w.delete(1.0, tk.END)
            w.insert(tk.END, "NETWORK & CONNECTIVITY\n", "heading")
            w.insert(tk.END, "=" * 55 + "\n\n")
            w.insert(tk.END, "  Complete network and system health diagnostics.\n")
            w.insert(tk.END, "  Use the action menu above to get started.\n\n")

            w.insert(tk.END, "  Core Checks:\n", "heading")
            w.insert(tk.END, "  ● Full Network Check\n", "ok")
            w.insert(tk.END, "    Interfaces, DNS, gateway latency, internet test.\n\n", "info")
            w.insert(tk.END, "  ● Wi-Fi Info\n", "ok")
            w.insert(tk.END, "    SSID, signal strength, frequency, security.\n\n", "info")
            w.insert(tk.END, "  ● Public IP\n", "ok")
            w.insert(tk.END, "    Fetch your external IP address.\n\n", "info")
            w.insert(tk.END, "  ● Firewall\n", "ok")
            w.insert(tk.END, "    Quick status of firewalld or ufw.\n\n", "info")

            w.insert(tk.END, "  Deep Diagnostics:\n", "heading")
            w.insert(tk.END, "  ● Ping Test\n", "ok")
            w.insert(tk.END, "    Ping 8.8.8.8, 1.1.1.1, and google.com.\n\n", "info")
            w.insert(tk.END, "  ● Traceroute\n", "ok")
            w.insert(tk.END, "    Trace the path to 8.8.8.8 hop by hop.\n\n", "info")
            w.insert(tk.END, "  ● Connections\n", "ok")
            w.insert(tk.END, "    Active TCP/UDP connections and remote hosts.\n\n", "info")
            w.insert(tk.END, "  ● Bandwidth\n", "ok")
            w.insert(tk.END, "    Network I/O counters since boot.\n\n", "info")

            w.insert(tk.END, "  System:\n", "heading")
            w.insert(tk.END, "  ● System Health\n", "ok")
            w.insert(tk.END, "    Boot time, systemd, journal, USB, SMART.\n\n", "info")
            w.insert(tk.END, "  ● Full Report\n", "err")
            w.insert(tk.END, "    Every diagnostic combined into one report.\n\n", "info")

            w.insert(tk.END, "  " + "-" * 50 + "\n", "info")
            w.insert(tk.END, "  Tip: Start with 'Full Network Check' for a quick\n", "info")
            w.insert(tk.END, "  overview, or 'Full Report' for everything at once.\n", "info")
            w.config(state=tk.DISABLED)
        self._safe(_do)

    def _run_system_health(self):
        self.update_text(self.health_text, "Checking system health...\n")
        try:
            results: list = []
            results.extend(check_boot_time())
            results.extend(check_systemd_failed())
            results.extend(check_journal_errors())
            results.extend(check_usb_devices())
            results.extend(check_smart_health())
            self._paint_report(self.health_text, "SYSTEM HEALTH", results)
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")

    # ── Health (Advanced Diagnostics) ───────────────────────────────────

    def create_health_tab(self):
        # ── Scrollable container wraps the entire Health tab ──
        scrollable, _canvas = self._create_scrollable_tab(self.health_frame)

        # Header (pinned at top of scrollable area)
        title_row = tk.Frame(scrollable, bg=self.bg_color)
        title_row.pack(fill=tk.X, padx=20, pady=(15, 2))
        tk.Frame(title_row, bg=self.accent_color, width=4, height=20).pack(side=tk.LEFT, padx=(0, 10))
        tk.Label(title_row, text="Health & Predictive Maintenance", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(side=tk.LEFT)

        tk.Label(scrollable, text="Hardware lifespan, zombie processes, kernel tuning, log analysis, energy & more",
                 font=("Noto Sans", 9), bg=self.bg_color, fg=self.text_dim).pack(anchor="w", padx=20, pady=(0, 8))

        # Health score bar at top
        self.health_score_frame = tk.Frame(scrollable, bg=self.bg_secondary)
        self.health_score_frame.pack(fill=tk.X, padx=20, pady=(0, 8))
        self.health_score_label = tk.Label(
            self.health_score_frame, text="Health Score: — / 100",
            font=("Noto Sans", 11, "bold"), bg=self.bg_secondary, fg=self.accent_color,
        )
        self.health_score_label.pack(side=tk.LEFT, padx=10, pady=6)
        self.health_score_bar = ttk.Progressbar(
            self.health_score_frame, length=200, mode="determinate", maximum=100,
        )
        self.health_score_bar.pack(side=tk.LEFT, padx=10, pady=6)

        # 1. Advanced Diagnostics — always open (primary deck)
        self._create_collapsible_deck(
            scrollable,
            "Advanced Diagnostics",
            [
                ("Health Score", lambda: self._run_threaded(self._run_health_score),
                 "Comprehensive hardware health rating"),
                ("Predictive Disk", lambda: self._run_threaded(self._run_predictive_disk),
                 "S.M.A.R.T. trend analysis & lifespan prediction"),
                ("Zombie Hunter", lambda: self._run_threaded(self._run_zombie_hunter),
                 "Find zombie & D-state processes"),
                ("Kernel Tuning", lambda: self._run_threaded(self._run_kernel_audit),
                 "Audit sysctl params & suggest optimisations"),
                ("Log Analysis", lambda: self._run_threaded(self._run_log_analysis),
                 "Scan logs for pre-failure patterns (24h)"),
                ("Repo Audit", lambda: self._run_threaded(self._run_repo_audit),
                 "Check package repos, orphans, conflicts"),
                ("Energy Profile", lambda: self._run_threaded(self._run_energy_profile),
                 "Power analysis & battery optimisation"),
                ("System Health", lambda: self._run_threaded(self._run_system_health),
                 "Boot time, services, journal, USB, SMART"),
                ("Network Heal", lambda: self._run_threaded(self._run_network_heal),
                 "MTU, BBR, DNS privacy, ghost interfaces"),
                ("Full Report", lambda: self._run_threaded(self._run_full_advanced),
                 "Run ALL advanced diagnostics"),
            ],
            run_bg=self.accent_color,
            hint="Deep system analysis — predictive maintenance, kernel tuning, and more.",
            default="Health Score",
            collapsed=False,
        )

        # 2. Sandbox & System Intelligence — collapsed by default
        self._create_collapsible_deck(
            scrollable,
            "Sandbox & System Intelligence",
            [
                ("Prescriptive", lambda: self._run_threaded(self._run_prescriptive),
                 "Predict problems before they happen"),
                ("Golden State", lambda: self._run_threaded(self._run_golden_drift),
                 "Check for drift from your baseline"),
                ("Capture State", lambda: self._run_threaded(self._run_capture_golden),
                 "Snapshot current system as Golden State"),
                ("Log Search", lambda: self._open_log_search_dialog(),
                 "Search logs with natural language"),
                ("Sandbox Test", lambda: self._open_sandbox_dialog(),
                 "Test commands in sandbox before applying"),
                ("Safety Pin", lambda: self._toggle_safety_pin(),
                 "Toggle safe mode vs autonomous"),
            ],
            run_bg=self.warning_color,
            collapsed=True,
        )

        # 3. Agentic Engine — collapsed by default
        self._create_collapsible_deck(
            scrollable,
            "Agentic Engine (Sysfix 1.1.0)",
            [
                ("System Pulse", lambda: self._run_threaded(self._run_pulse_toggle),
                 "Start/stop real-time System Pulse telemetry"),
                ("Pulse Report", lambda: self._run_threaded(self._run_pulse_report),
                 "View live telemetry, trends, and proactive alerts"),
                ("Agent Status", lambda: self._run_threaded(self._run_agent_report),
                 "Agentic loop capability status"),
                ("Safety Log", lambda: self._run_threaded(self._run_safety_log),
                 "View Safety Intercept audit log"),
                ("UI Status", lambda: self._run_threaded(self._run_ui_enhancements_report),
                 "Check CustomTkinter, pymunk, spring physics availability"),
            ],
            run_bg=self.accent_color,
            collapsed=True,
        )

        # Progress bar
        self.health_progress = ttk.Progressbar(scrollable, mode="indeterminate")

        txt_frame = self._create_glass_log_container(scrollable, padx=20, pady=(0, 10))
        self.health_text = self._create_modern_text(txt_frame, height=18)

        self.health_text.tag_config("heading", foreground=self.accent_color, font=("Noto Sans Mono", 10, "bold"))
        self.health_text.tag_config("ok",   foreground=self.success_color)
        self.health_text.tag_config("warn", foreground=self.warning_color)
        self.health_text.tag_config("info", foreground=self.text_dim)
        self.health_text.tag_config("err",  foreground=self.danger_color)

        self._show_health_welcome()

    def _show_health_welcome(self):
        def _do():
            w = self.health_text
            w.config(state=tk.NORMAL)
            w.delete(1.0, tk.END)
            w.insert(tk.END, "HEALTH & PREDICTIVE MAINTENANCE\n", "heading")
            w.insert(tk.END, "=" * 55 + "\n\n")
            w.insert(tk.END, "  Advanced diagnostics that go beyond simple pass/fail.\n\n")
            w.insert(tk.END, "  ● Health Score\n", "ok")
            w.insert(tk.END, "    Comprehensive 0-100 rating: thermal, RAM, CPU, disk, battery.\n\n", "info")
            w.insert(tk.END, "  ● Predictive Disk Analysis\n", "ok")
            w.insert(tk.END, "    S.M.A.R.T. trend analysis — estimates remaining SSD/HDD lifespan,\n", "info")
            w.insert(tk.END, "    tracks reallocated sectors, write rates, and temperature.\n\n", "info")
            w.insert(tk.END, "  ● Zombie Process Hunter\n", "warn")
            w.insert(tk.END, "    Finds zombie (Z) and D-state processes that waste resources.\n\n", "info")
            w.insert(tk.END, "  ● Kernel Tuning\n", "warn")
            w.insert(tk.END, "    Audits sysctl parameters: swappiness, TCP buffers, BBR, inotify.\n\n", "info")
            w.insert(tk.END, "  ● Log Analysis\n", "warn")
            w.insert(tk.END, "    Scans journalctl for pre-failure patterns: ECC errors, disk I/O,\n", "info")
            w.insert(tk.END, "    thermal throttling, OOM kills, GPU hangs, kernel panics.\n\n", "info")
            w.insert(tk.END, "  ● Repo Audit\n", "ok")
            w.insert(tk.END, "    Checks for orphaned packages, broken deps, stale repos.\n\n", "info")
            w.insert(tk.END, "  ● Energy Profile\n", "ok")
            w.insert(tk.END, "    Battery status, CPU governor, power consumers, brightness.\n\n", "info")
            w.insert(tk.END, "  ● Network Self-Healing\n", "ok")
            w.insert(tk.END, "    Congestion control (BBR), DNS privacy, ghost interfaces, MTU.\n\n", "info")
            w.config(state=tk.DISABLED)
        self._safe(_do)

    # ── Health tab runners ──────────────────────────────────────────────

    def _run_health_score(self):
        self.update_text(self.health_text, "Computing hardware health score...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = hardware_health_score()
            self._paint_report(self.health_text, "HARDWARE HEALTH SCORE", results)
            # Update the score bar
            for line in results:
                if "Health Score:" in line:
                    import re as _re
                    m = _re.search(r"(\d+)/100", line)
                    if m:
                        score = int(m.group(1))
                        self._safe(lambda s=score: self.health_score_bar.configure(value=s))
                        self._safe(lambda s=score, l=line: self.health_score_label.config(
                            text=f"Health Score: {s}/100",
                            fg=self.success_color if s >= 70 else (self.warning_color if s >= 40 else self.danger_color),
                        ))
            self._notify("Health Score", results[0] if results else "Done", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _run_predictive_disk(self):
        self.update_text(self.health_text, "Analysing S.M.A.R.T. data...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = smart_predictive_analysis()
            self._paint_report(self.health_text, "PREDICTIVE DISK ANALYSIS", results)
            self._notify("Disk Analysis", f"{len(results)} findings", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _run_zombie_hunter(self):
        self.update_text(self.health_text, "Hunting zombies...\n")
        try:
            results = zombie_process_hunter()
            self._paint_report(self.health_text, "ZOMBIE PROCESS HUNTER", results)
            zombie_count = sum(1 for r in results if "zombie" in r.lower() and "WARN" in r)
            if zombie_count:
                self._notify("Zombies Found", f"{zombie_count} zombie process(es) detected", "warn")
            else:
                self._notify("Zombie Hunter", "No zombies found", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")

    def _run_kernel_audit(self):
        self.update_text(self.health_text, "Auditing kernel parameters...\n")
        try:
            results = kernel_param_audit()
            self._paint_report(self.health_text, "KERNEL PARAMETER AUDIT", results)
            self._notify("Kernel Audit", f"{len(results)} items checked", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")

    def _run_log_analysis(self):
        self.update_text(self.health_text, "Scanning system logs (last 24h)...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = log_pattern_analysis()
            self._paint_report(self.health_text, "LOG PATTERN ANALYSIS", results)
            warns = sum(1 for r in results if r.startswith("WARN") or r.startswith("DANGER"))
            level = "warn" if warns else "ok"
            self._notify("Log Analysis", f"{warns} warning(s) found", level)
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _run_repo_audit(self):
        self.update_text(self.health_text, "Auditing package repositories...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = repo_audit()
            self._paint_report(self.health_text, "REPOSITORY AUDIT", results)
            self._notify("Repo Audit", "Complete", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _run_energy_profile(self):
        self.update_text(self.health_text, "Profiling energy usage...\n")
        try:
            results = energy_profile()
            self._paint_report(self.health_text, "ENERGY PROFILE", results)
            self._notify("Energy Profile", results[0] if results else "Done", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")

    def _run_network_heal(self):
        self.update_text(self.health_text, "Running network self-healing checks...\n")
        try:
            results = network_self_heal()
            self._paint_report(self.health_text, "NETWORK SELF-HEALING", results)
            self._notify("Network Heal", "Complete", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")

    def _run_full_advanced(self):
        self.update_text(self.health_text, "Running ALL advanced diagnostics...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = advanced_diagnostics_full()
            self._paint_report(self.health_text, "FULL ADVANCED DIAGNOSTICS", results)
            self._notify("Advanced Diagnostics", "Full report complete", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    # ── Sandbox / Golden State / Prescriptive runners ───────────────────

    def _run_prescriptive(self):
        self.update_text(self.health_text, "Running prescriptive analysis...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = prescriptive_analysis()
            self._paint_report(self.health_text, "PRESCRIPTIVE ANALYSIS", results)
            alerts = sum(1 for r in results if "🔴" in r or "🟡" in r)
            self._notify("Prescriptive", f"{alerts} alert(s) found", "warn" if alerts else "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _run_golden_drift(self):
        self.update_text(self.health_text, "Checking Golden State drift...\n")
        try:
            results = golden_state_drift_check()
            self._paint_report(self.health_text, "GOLDEN STATE DRIFT CHECK", results)
            drifts = sum(1 for r in results if "⚠" in r)
            self._notify("Golden State", f"{drifts} drift(s) found", "warn" if drifts else "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")

    def _run_capture_golden(self):
        self.update_text(self.health_text, "Capturing current system as Golden State...\n")
        try:
            results = capture_current_as_golden()
            self._paint_report(self.health_text, "GOLDEN STATE CAPTURED", results)
            self._notify("Golden State", "Baseline captured", "ok")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")

    def _open_log_search_dialog(self):
        """Open a dialog to search logs with natural language."""
        query = simpledialog.askstring(
            "Semantic Log Search",
            "Ask about your system logs:\n\n"
            "Examples:\n"
            "  • Why did my WiFi drop?\n"
            "  • Show me disk errors\n"
            "  • What crashed last night?\n",
            parent=self.root,
        )
        if not query:
            return
        self._run_threaded(lambda: self._run_log_search(query))

    def _run_log_search(self, query):
        self.update_text(self.health_text, f"Searching logs for: {query}\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = semantic_log_search(query, hours=24)
            self._paint_report(self.health_text, f"LOG SEARCH: {query}", results)
            matches = sum(1 for r in results if r.strip().startswith("["))
            self._notify("Log Search", f"{matches} entries found", "ok" if matches else "info")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _open_sandbox_dialog(self):
        """Open a dialog to test commands in a sandbox."""
        cmd_str = simpledialog.askstring(
            "Sandbox Dry-Run",
            "Enter command(s) to test in a sandbox:\n"
            "(separate multiple commands with newlines or ;)\n",
            parent=self.root,
        )
        if not cmd_str:
            return
        cmds = [c.strip() for c in cmd_str.replace(";", "\n").splitlines() if c.strip()]
        if not cmds:
            return
        self._run_threaded(lambda: self._run_sandbox(cmds))

    def _run_sandbox(self, commands):
        self.update_text(self.health_text, f"Testing {len(commands)} command(s) in sandbox...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = sandbox_dry_run(commands)
            self._paint_report(self.health_text, "SANDBOX DRY-RUN RESULTS", results)
            passed = sum(1 for r in results if "PASS" in r)
            failed = sum(1 for r in results if "FAIL" in r)
            self._notify("Sandbox", f"{passed} passed, {failed} failed",
                         "ok" if failed == 0 else "warn")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _toggle_safety_pin(self):
        """Toggle between Safe and Autonomous mode."""
        status = toggle_safety_pin()
        messagebox.showinfo(
            "Safety Pin",
            f"Mode: {status['label']}\n\n{status['description']}",
        )
        self._set_status(f"Safety: {status['label']}", "ok", timeout=3000)

    # ── eBPF Sentinel ─────────────────────────────────────────────────────

    def _run_sentinel_toggle(self):
        """Start or stop the eBPF sentinel."""
        sentinel = get_sentinel()
        if sentinel.running:
            msg = stop_sentinel()
            self.update_text(self.health_text, msg + "\n")
            self._notify("Sentinel", "eBPF Sentinel stopped", "info")
        else:
            msg = start_sentinel(on_alert=self._on_sentinel_alert)
            self.update_text(self.health_text, msg + "\n")
            if "✓" in msg:
                self._notify("Sentinel", "eBPF Sentinel started", "ok")
            else:
                self._notify("Sentinel", "Could not start sentinel", "warn")

    def _on_sentinel_alert(self, alert):
        """Callback when the eBPF sentinel detects suspicious activity."""
        sev_icon = {"low": "🟢", "medium": "🟡", "high": "🟠", "critical": "🔴"}
        icon = sev_icon.get(alert.severity, "⚪")
        msg = f"{icon} [{alert.severity.upper()}] {alert.kind}: {alert.comm} (pid {alert.pid}) — {alert.detail}"
        self._safe(lambda: self._append_health_alert(msg))
        if alert.severity in ("high", "critical"):
            self._notify("SENTINEL ALERT", f"{alert.comm}: {alert.detail[:80]}", "err")

    def _append_health_alert(self, text):
        """Append an alert to the health text widget."""
        try:
            w = self.health_text
            w.config(state=tk.NORMAL)
            w.insert(tk.END, text + "\n")
            w.see(tk.END)
            w.config(state=tk.DISABLED)
        except Exception:
            pass

    def _run_sentinel_report(self):
        """Show current sentinel status and alerts."""
        lines = sentinel_report()
        self._paint_report(self.health_text, "eBPF SENTINEL STATUS", lines)

    # ── Micro-VM ──────────────────────────────────────────────────────────

    def _open_microvm_dialog(self):
        """Open a dialog to run commands in a Firecracker micro-VM."""
        cmd_str = simpledialog.askstring(
            "Micro-VM Sandbox",
            "Enter command(s) to run inside a Firecracker micro-VM:\n"
            "(separate multiple commands with newlines or ;)\n\n"
            "Falls back to bwrap/podman if Firecracker is unavailable.",
            parent=self.root,
        )
        if not cmd_str:
            return
        cmds = [c.strip() for c in cmd_str.replace(";", "\n").splitlines() if c.strip()]
        if not cmds:
            return
        self._run_threaded(lambda: self._run_microvm(cmds))

    def _run_microvm(self, commands):
        self.update_text(self.health_text, f"Running {len(commands)} command(s) in micro-VM...\n")
        self._safe(lambda: self.health_progress.pack(fill=tk.X, padx=20, pady=(0, 5)))
        self._safe(lambda: self.health_progress.start(15))
        try:
            results = microvm_run(commands)
            self._paint_report(self.health_text, "MICRO-VM SANDBOX RESULTS", results)
            passed = sum(1 for r in results if "PASS" in r)
            failed = sum(1 for r in results if "FAIL" in r)
            self._notify("Micro-VM", f"{passed} passed, {failed} failed",
                         "ok" if failed == 0 else "warn")
        except Exception as e:
            self.update_text(self.health_text, f"Error: {e}")
        finally:
            self._safe(lambda: self.health_progress.stop())
            self._safe(lambda: self.health_progress.pack_forget())

    def _run_microvm_report(self):
        lines = microvm_report()
        self._paint_report(self.health_text, "MICRO-VM STATUS", lines)

    # ── NPU ───────────────────────────────────────────────────────────────

    def _run_npu_report(self):
        lines = npu_report()
        self._paint_report(self.health_text, "NPU STATUS", lines)

    # ── UI Enhancements ───────────────────────────────────────────────────

    def _run_ui_enhancements_report(self):
        lines = ui_enhancements_report()
        self._paint_report(self.health_text, "UI ENHANCEMENTS", lines)

    # ── System Pulse (Agentic 1.1.0) ─────────────────────────────────────

    def _run_pulse_toggle(self):
        """Start or stop the System Pulse telemetry daemon."""
        status = pulse_status()
        if status.get("running"):
            msg = stop_pulse()
            self.update_text(self.health_text, msg + "\n")
            self._notify("System Pulse", "Telemetry stopped", "info")
        else:
            msg = start_pulse(interval=5.0)
            self.update_text(self.health_text, msg + "\n")
            if "✓" in msg:
                self._notify("System Pulse", "Telemetry started", "ok")
            else:
                self._notify("System Pulse", "Could not start pulse", "warn")

    def _run_pulse_report(self):
        """Show the current System Pulse snapshot with trend analysis."""
        lines = pulse_report()
        self._paint_report(self.health_text, "SYSTEM PULSE TELEMETRY", lines)

    def _on_pulse_update(self, snapshot):
        """Callback for real-time pulse updates (registered with register_callback)."""
        try:
            trend = get_trend()
            if trend.alerts:
                for alert in trend.alerts:
                    self._safe(lambda a=alert: self._append_health_alert(f"🔄 PULSE: {a}"))
        except Exception:
            pass

    # ── Agentic Engine Status (1.1.0) ────────────────────────────────────

    def _run_agent_report(self):
        """Show the agentic reasoning engine capability report."""
        lines = agent_report()
        self._paint_report(self.health_text, "AGENTIC ENGINE (1.1.0)", lines)

    # ── Safety Intercept Log ─────────────────────────────────────────────

    def _run_safety_log(self):
        """Show the safety intercept audit log and pending approvals."""
        lines = intercept_report()
        self._paint_report(self.health_text, "SAFETY INTERCEPT LOG", lines)

    # ── Sentinel AV (Kernel Antivirus) ────────────────────────────────────

    def _run_av_toggle(self):
        """Start or stop the Sentinel AV engine."""
        status = av_status()
        if status.get("running"):
            msg = stop_av()
            self.update_text(self.health_text, msg + "\n")
            self._notify("Sentinel AV", "Kernel antivirus stopped", "info")
        else:
            msg = start_av(on_threat=self._on_av_threat)
            self.update_text(self.health_text, msg + "\n")
            if "✓" in msg:
                self._notify("Sentinel AV", "Kernel antivirus ACTIVE", "ok")
            else:
                self._notify("Sentinel AV", msg[:80], "warn")

    def _run_av_report(self):
        """Show full Sentinel AV capability and status report."""
        lines = av_report()
        self._paint_report(self.health_text, "SENTINEL AV — KERNEL ANTIVIRUS", lines)

    def _run_av_threat_log(self):
        """Show all detected threats with dispositions."""
        threats = av_threats()
        lines: list = []
        if not threats:
            lines.append("INFO: No threats detected. System is clean.")
        else:
            sev_icons = {"low": "🟢", "medium": "🟡", "high": "🟠", "critical": "🔴"}
            for t in threats:
                icon = sev_icons.get(t.get("severity", ""), "⚪")
                disp = t.get("disposition", "pending").upper()
                lines.append(
                    f"{icon} [{t.get('severity', '?').upper()}] "
                    f"{t.get('threat_type', '?')} — {t.get('comm', '?')} "
                    f"(PID {t.get('pid', '?')}) [{disp}]"
                )
                if t.get("description"):
                    lines.append(f"    {t['description'][:140]}")
                if t.get("clamav_result"):
                    lines.append(f"    ClamAV: {t['clamav_result']}")
                if t.get("ai_verdict"):
                    lines.append(f"    AI: {t['ai_verdict'][:100]} ({t.get('ai_confidence', 0)}%)")
                lines.append("")
        self._paint_report(self.health_text, "SENTINEL AV — THREAT LOG", lines)

    def _run_av_threat_map(self):
        """Show a visual threat map for the latest threat."""
        av = get_av()
        threats = av.threats
        if not threats:
            self.update_text(self.health_text, "No threats to map — system is clean.\n")
            return
        latest = threats[-1]
        tmap = av.get_threat_map(latest.threat_id)
        lines: list = []
        lines.append(f"Threat ID: {latest.threat_id}")
        lines.append(f"Process: {latest.comm} (PID {latest.pid})")
        lines.append(f"Type: {latest.threat_type}  |  Severity: {latest.severity.upper()}")
        lines.append(f"Frozen: {'YES' if latest.frozen else 'no'}  |  "
                      f"Disposition: {latest.disposition.upper()}")
        lines.append("")
        if tmap:
            lines.append(f"Risk Score: {tmap.risk_score}/100")
            lines.append("")
            if tmap.process_tree:
                lines.append("── Process Tree ──")
                lines.extend(tmap.process_tree[:15])
                lines.append("")
            if tmap.file_access_map:
                lines.append("── Files Touched ──")
                for fa in tmap.file_access_map[:20]:
                    cat = fa.get("category", "normal")
                    icon = {"boot_critical": "🥾", "sensitive_keys": "🔑",
                            "system_critical": "⚙"}.get(cat, "📄")
                    lines.append(f"  {icon} [{cat}] {fa.get('path', '?')}")
                lines.append("")
            if tmap.network_map:
                lines.append("── Network Connections ──")
                for nm in tmap.network_map[:10]:
                    lines.append(f"  {nm.get('label', '?')}")
                lines.append("")
        if latest.clamav_result:
            lines.append(f"ClamAV: {latest.clamav_result}")
        if latest.ai_verdict:
            lines.append(f"AI Verdict: {latest.ai_verdict[:200]}")
            lines.append(f"AI Confidence: {latest.ai_confidence}%")
        self._paint_report(self.health_text, "THREAT MAP", lines)

    def _run_pipeline_scan(self):
        """Run the multi-stage Malware Verification Pipeline on a user-selected file."""
        import tkinter.filedialog as fd
        file_path = fd.askopenfilename(
            title="Select file for deep scan",
            initialdir=os.path.expanduser("~/Downloads"),
        )
        if not file_path:
            return

        self.update_text(
            self.health_text,
            f"\n{'='*60}\n"
            f"🔬 MALWARE VERIFICATION PIPELINE\n"
            f"   Scanning: {file_path}\n"
            f"   Stages: ClamAV → YARA → VirusTotal → AI\n"
            f"{'='*60}\n",
        )

        def _on_stage(stage_name, result):
            icons = {"clamav": "🦠", "yara": "📐", "virustotal": "🌐"}
            icon = icons.get(stage_name, "✓")
            self._safe(lambda: self.update_text(
                self.health_text,
                f"  {icon} Stage complete: {stage_name}\n",
            ))

        profile = mvp_run_pipeline(file_path, on_stage_complete=_on_stage)

        # Show formatted results
        display_lines = mvp_format_profile(profile)
        self._paint_report(self.health_text, "THREAT PROFILE", display_lines)

        # Desktop notification based on risk
        risk = profile.overall_risk
        if risk in ("high", "critical"):
            self._notify(
                "🔴 THREAT DETECTED",
                f"{os.path.basename(file_path)}: {risk.upper()} risk "
                f"(score {profile.risk_score}/100)",
                "error",
            )
        elif risk == "medium":
            self._notify(
                "🟡 Suspicious File",
                f"{os.path.basename(file_path)}: medium risk "
                f"(score {profile.risk_score}/100)",
                "warn",
            )
        else:
            self._notify(
                "🟢 File Clean",
                f"{os.path.basename(file_path)}: {risk} "
                f"(score {profile.risk_score}/100)",
                "ok",
            )

    def _run_pipeline_report(self):
        """Show the Malware Verification Pipeline capability report."""
        lines = mvp_pipeline_report()
        self._paint_report(self.health_text, "MALWARE VERIFICATION PIPELINE", lines)

    # ── Sentinel Bridge runners ──────────────────────────────────

    def _run_bridge_scan(self):
        """Full read-only security scan via Sentinel Bridge."""
        self._clear_log(self.health_text)
        self._append_log(self.health_text, "🔍 Running Sentinel security scan...\n")
        try:
            result = sb_scan()
            self._append_log(self.health_text, result + "\n")
        except Exception as e:
            self._append_log(self.health_text, f"⚠ Scan error: {e}\n")

    def _run_bridge_proc_scan(self):
        """Process anomaly scan via Sentinel Bridge."""
        self._clear_log(self.health_text)
        self._append_log(self.health_text, "🔍 Scanning processes for anomalies...\n\n")
        try:
            result = sb_proc_scan()
            self._append_log(self.health_text, result + "\n")
        except Exception as e:
            self._append_log(self.health_text, f"⚠ Scan error: {e}\n")

    def _run_bridge_net_scan(self):
        """Network threat scan via Sentinel Bridge."""
        self._clear_log(self.health_text)
        self._append_log(self.health_text, "🔍 Scanning network for threats...\n\n")
        try:
            result = sb_net_scan()
            self._append_log(self.health_text, result + "\n")
        except Exception as e:
            self._append_log(self.health_text, f"⚠ Scan error: {e}\n")

    def _run_bridge_status(self):
        """Show Sentinel Bridge capability report."""
        lines = sb_report()
        self._paint_report(self.health_text, "SENTINEL BRIDGE STATUS", lines)

    # ── AV threat notification callback ──────────────────────────

    def _on_av_threat(self, threat: ThreatEvent, tmap: ThreatMap):
        """Callback when Sentinel AV detects a threat — show notification."""
        display = format_threat_for_display(threat)
        sev = threat.severity.upper()
        icon = display.get("severity_icon", "⚠")
        type_icon = display.get("type_icon", "⚠")

        # Desktop notification for high/critical threats
        if threat.severity in ("high", "critical"):
            self._notify(
                f"🛡 SENTINEL AV — {sev} THREAT",
                f"{type_icon} {threat.threat_type}: {threat.comm} (PID {threat.pid})\n"
                f"{threat.description[:100]}",
                level="danger",
            )

        # Append to health log
        self._safe(lambda: self._append_health_alert(
            f"{icon} SENTINEL AV [{sev}] {type_icon} {threat.threat_type}: "
            f"{threat.comm} (PID {threat.pid}) — {threat.description[:100]}"
        ))

        # Show spring-physics threat popup for critical threats
        if threat.severity == "critical":
            self._safe(lambda t=threat, d=display, tm=tmap: self._show_threat_popup(t, d, tm))

    def _show_threat_popup(self, threat: ThreatEvent, display: dict, tmap: ThreatMap):
        """High-priority spring-physics threat notification with one-click actions."""
        popup = tk.Toplevel(self.root)
        popup.title("🛡 THREAT DETECTED")
        popup.overrideredirect(True)
        popup.attributes("-topmost", True)

        # Size and position — center on screen
        pw, ph = 520, 420
        sx = self.root.winfo_screenwidth()
        sy = self.root.winfo_screenheight()
        px = (sx - pw) // 2
        py = (sy - ph) // 2

        # Spring-physics: start off-screen (above) and animate down
        popup.geometry(f"{pw}x{ph}+{px}+{py - 600}")
        popup.configure(bg="#0a0a0a")

        # Neon border frame
        sev_color = display.get("severity_color", "#ef4444")
        outer = tk.Frame(popup, bg=sev_color, bd=0)
        outer.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        inner = tk.Frame(outer, bg="#0f0f0f")
        inner.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        # Header
        hdr = tk.Frame(inner, bg="#1a0000")
        hdr.pack(fill=tk.X)
        sev_icon = display.get("severity_icon", "🔴")
        type_icon = display.get("type_icon", "⚠")
        tk.Label(hdr, text=f"{sev_icon} THREAT DETECTED {type_icon}",
                 font=("Noto Sans", 14, "bold"),
                 bg="#1a0000", fg=sev_color).pack(side=tk.LEFT, padx=12, pady=8)
        tk.Label(hdr, text=threat.severity.upper(),
                 font=("Noto Sans Mono", 10, "bold"),
                 bg=sev_color, fg="#000000", padx=8, pady=2).pack(
            side=tk.RIGHT, padx=12, pady=8)

        # Threat details
        details = tk.Frame(inner, bg="#0f0f0f")
        details.pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

        def _lbl(parent, text, fg="#e0e0e0", font_size=9, bold=False):
            f = ("Noto Sans Mono", font_size, "bold") if bold else ("Noto Sans Mono", font_size)
            tk.Label(parent, text=text, font=f, bg="#0f0f0f", fg=fg,
                     anchor="w", wraplength=480, justify=tk.LEFT).pack(
                anchor="w", pady=1)

        _lbl(details, f"Process: {threat.comm} (PID {threat.pid})", fg="#ffffff", bold=True)
        _lbl(details, f"Type: {display.get('type_label', threat.threat_type)}", fg=sev_color)
        _lbl(details, f"Status: {'🧊 FROZEN' if threat.frozen else '⚡ RUNNING'}", fg="#60a5fa")
        _lbl(details, f"")
        _lbl(details, threat.description[:200], fg="#d1d5db", font_size=8)

        # Mini threat map
        if tmap and tmap.file_access_map:
            _lbl(details, "", fg="#6b7280")
            _lbl(details, "Files Touched:", fg="#f59e0b", bold=True, font_size=8)
            for fa in tmap.file_access_map[:5]:
                _lbl(details, f"  {fa.get('path', '?')}", fg="#9ca3af", font_size=8)

        if tmap and tmap.network_map:
            _lbl(details, "Network:", fg="#f59e0b", bold=True, font_size=8)
            for nm in tmap.network_map[:3]:
                _lbl(details, f"  {nm.get('label', '?')}", fg="#9ca3af", font_size=8)

        # Action buttons
        btn_frame = tk.Frame(inner, bg="#0f0f0f")
        btn_frame.pack(fill=tk.X, padx=12, pady=(4, 12))

        def _delete():
            result = av_delete_threat(threat.threat_id)
            self._notify("Sentinel AV", result, "ok" if "✓" in result else "warn")
            popup.destroy()

        def _jail():
            result = av_jail_threat(threat.threat_id)
            self._notify("Sentinel AV", result, "ok" if "✓" in result else "warn")
            popup.destroy()

        def _dismiss():
            popup.destroy()

        tk.Button(btn_frame, text="🗑 DELETE VIRUS",
                  font=("Noto Sans", 10, "bold"),
                  bg="#dc2626", fg="#ffffff", activebackground="#b91c1c",
                  relief="flat", padx=16, pady=6,
                  command=_delete).pack(side=tk.LEFT, padx=(0, 8))
        tk.Button(btn_frame, text="⛓ JAIL FOREVER",
                  font=("Noto Sans", 10, "bold"),
                  bg="#7c3aed", fg="#ffffff", activebackground="#6d28d9",
                  relief="flat", padx=16, pady=6,
                  command=_jail).pack(side=tk.LEFT, padx=(0, 8))
        tk.Button(btn_frame, text="✕ Dismiss",
                  font=("Noto Sans", 9),
                  bg="#374151", fg="#e5e7eb", activebackground="#4b5563",
                  relief="flat", padx=12, pady=6,
                  command=_dismiss).pack(side=tk.RIGHT)

        # ── Spring-physics slide-in animation ────────────────────────────
        target_y = py
        current_y = [py - 600]
        velocity = [0.0]

        def _spring_step():
            if not popup.winfo_exists():
                return
            # Spring constants: stiffness, damping
            stiffness = 0.08
            damping = 0.72
            displacement = target_y - current_y[0]
            velocity[0] = velocity[0] * damping + displacement * stiffness
            current_y[0] += velocity[0]

            popup.geometry(f"{pw}x{ph}+{px}+{int(current_y[0])}")

            # Stop when settled (within 1px and low velocity)
            if abs(displacement) < 1 and abs(velocity[0]) < 0.5:
                popup.geometry(f"{pw}x{ph}+{px}+{target_y}")
                return
            popup.after(7, _spring_step)  # ~144Hz (1000/7 ≈ 143fps)

        popup.after(10, _spring_step)

        # Auto-dismiss after 30 seconds if not interacted with
        popup.after(30000, lambda: popup.destroy() if popup.winfo_exists() else None)

    # ── Command Palette (Ctrl+K) ──────────────────────────────────────────

    def _open_command_palette(self):
        """Open a command palette overlay — ask Fyxa anything or run actions.

        Enhanced with spring fade-in animation and AI-powered search.
        """
        palette = tk.Toplevel(self.root)
        palette.title("Command Palette")
        palette.overrideredirect(True)
        palette.configure(bg=self.bg_color)

        # Position at top-center of main window
        root_x = self.root.winfo_x()
        root_y = self.root.winfo_y()
        root_w = self.root.winfo_width()
        pw = 580
        px = root_x + (root_w - pw) // 2
        py = root_y + 80
        palette.geometry(f"{pw}x420+{px}+{py}")
        palette.attributes("-topmost", True)

        # Spring fade-in
        try:
            from sysfixai.ui_enhancements import UIPhysics
            UIPhysics.fade_in(palette, stiffness=340, damping=16)
        except Exception:
            pass

        # Dismiss on Escape or focus loss
        palette.bind("<Escape>", lambda _: palette.destroy())
        palette.bind("<FocusOut>", lambda _: palette.after(100, lambda: (
            palette.destroy() if palette.winfo_exists() and not palette.focus_get() else None
        )))

        # Glass effect
        frame = tk.Frame(palette, bg=self.bg_secondary, bd=1, relief="solid",
                         highlightbackground=self.accent_color, highlightthickness=1)
        frame.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        # Search bar
        tk.Label(frame, text="⌘ Command Palette", font=("Noto Sans", 10, "bold"),
                 bg=self.bg_secondary, fg=self.accent_color).pack(anchor="w", padx=12, pady=(8, 2))
        tk.Label(frame, text="Search actions, ask Fyxa, or jump to a tab",
                 font=("Noto Sans", 8), bg=self.bg_secondary, fg=self.text_dim).pack(anchor="w", padx=12)

        search_var = tk.StringVar()
        entry = tk.Entry(frame, textvariable=search_var, font=("Noto Sans", 12),
                         bg=self.bg_color, fg=self.text_color,
                         insertbackground=self.accent_color,
                         relief="flat", bd=0)
        entry.pack(fill=tk.X, padx=12, pady=(8, 4), ipady=6)
        entry.focus_set()

        # Results listbox
        listbox = tk.Listbox(
            frame, font=("Noto Sans", 10), bg=self.bg_color, fg=self.text_color,
            selectbackground=self.accent_color, selectforeground="#FFFFFF",
            relief="flat", bd=0, activestyle="none",
        )
        listbox.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 8))

        # Define all palette commands
        commands = [
            ("⏎  Ask Fyxa AI...",           "ask_fyxa"),
            ("🔍 Run Diagnostics",           "diagnostics"),
            ("⚡ Fast Sweep AI Fix",         "fast_sweep"),
            ("🔒 Security Audit",            "security"),
            ("🌐 Network Diagnostics",       "network"),
            ("💊 Health Score",              "health_score"),
            ("🔮 Predictive Disk Analysis",  "predict_disk"),
            ("🧟 Zombie Process Hunter",     "zombies"),
            ("⚙  Kernel Tuning",            "kernel"),
            ("📊 Log Analysis",             "log_analysis"),
            ("📦 Repo Audit",               "repo_audit"),
            ("🔋 Energy Profile",            "energy"),
            ("🩺 Prescriptive Analysis",     "prescriptive"),
            ("🏛  Golden State Drift Check",  "golden_drift"),
            ("📸 Capture Golden State",      "capture_golden"),
            ("🔎 Semantic Log Search",       "log_search"),
            ("🧪 Sandbox Dry-Run",           "sandbox"),
            ("�  eBPF Sentinel Start/Stop",  "sentinel"),
            ("🔔 Sentinel Alerts",           "sentinel_alerts"),
            ("📦 Micro-VM Sandbox",          "microvm"),
            ("🧮 NPU Status",               "npu_status"),
            ("🔄 System Pulse Start/Stop",   "pulse_toggle"),
            ("📈 Pulse Telemetry Report",    "pulse_report"),
            ("🧠 Agentic Engine Status",     "agent_report"),
            ("🛡  Safety Intercept Log",      "safety_log"),
            ("🦠 Sentinel AV Start/Stop",    "av_toggle"),
            ("🔬 Sentinel AV Status",        "av_status"),
            ("🗺  AV Threat Map",             "av_threat_map"),
            ("� Deep Scan (Pipeline)",      "pipeline_scan"),
            ("📊 Pipeline Status",           "pipeline_report"),
            ("🔍 Sentinel Security Scan",    "bridge_scan"),
            ("🧬 Process Anomaly Scan",      "bridge_proc_scan"),
            ("🌐 Network Threat Scan",       "bridge_net_scan"),
            ("📡 Sentinel Bridge Status",    "bridge_status"),
            ("�📤 Export Brain",              "export_brain"),
            ("📥 Import Brain",              "import_brain"),
            ("🧠 Brain Stats",              "brain_stats"),
            ("🔄 Check Updates",             "updates"),
            ("☀  Settings",                 "settings"),
        ]

        def _filter(_event=None):
            q = search_var.get().lower()
            listbox.delete(0, tk.END)
            for label, _cmd_id in commands:
                if not q or q in label.lower():
                    listbox.insert(tk.END, f"  {label}")
            if listbox.size() > 0:
                listbox.selection_set(0)

        search_var.trace_add("write", lambda *_: _filter())
        _filter()

        def _execute_selected(_event=None):
            sel = listbox.curselection()
            if not sel:
                # If no selection, treat as ask-Fyxa with the search text
                query = search_var.get().strip()
                if query:
                    palette.destroy()
                    self._palette_ask_fyxa(query)
                return

            idx = sel[0]
            visible = [(l, c) for l, c in commands if not search_var.get().lower() or search_var.get().lower() in l.lower()]
            if idx >= len(visible):
                palette.destroy()
                return
            _, cmd_id = visible[idx]
            palette.destroy()
            self._palette_dispatch(cmd_id)

        entry.bind("<Return>", _execute_selected)
        listbox.bind("<Double-1>", _execute_selected)
        listbox.bind("<Return>", _execute_selected)

        # Arrow keys navigation
        def _nav_down(_e=None):
            if listbox.size() == 0:
                return
            cur = listbox.curselection()
            nxt = (cur[0] + 1) % listbox.size() if cur else 0
            listbox.selection_clear(0, tk.END)
            listbox.selection_set(nxt)
            listbox.see(nxt)

        def _nav_up(_e=None):
            if listbox.size() == 0:
                return
            cur = listbox.curselection()
            nxt = (cur[0] - 1) % listbox.size() if cur else listbox.size() - 1
            listbox.selection_clear(0, tk.END)
            listbox.selection_set(nxt)
            listbox.see(nxt)

        entry.bind("<Down>", _nav_down)
        entry.bind("<Up>", _nav_up)

    def _palette_dispatch(self, cmd_id):
        """Execute a command palette action."""
        dispatch = {
            "diagnostics":    lambda: self._run_threaded(self.scan_issues),
            "fast_sweep":     lambda: self._run_threaded(self.fast_sweep),
            "security":       lambda: self.notebook.select(2),
            "network":        lambda: self.notebook.select(3),
            "health_score":   lambda: (self.notebook.select(4), self._run_threaded(self._run_health_score)),
            "predict_disk":   lambda: (self.notebook.select(4), self._run_threaded(self._run_predictive_disk)),
            "zombies":        lambda: (self.notebook.select(4), self._run_threaded(self._run_zombie_hunter)),
            "kernel":         lambda: (self.notebook.select(4), self._run_threaded(self._run_kernel_audit)),
            "log_analysis":   lambda: (self.notebook.select(4), self._run_threaded(self._run_log_analysis)),
            "repo_audit":     lambda: (self.notebook.select(4), self._run_threaded(self._run_repo_audit)),
            "energy":         lambda: (self.notebook.select(4), self._run_threaded(self._run_energy_profile)),
            "prescriptive":   lambda: (self.notebook.select(4), self._run_threaded(self._run_prescriptive)),
            "golden_drift":   lambda: (self.notebook.select(4), self._run_threaded(self._run_golden_drift)),
            "capture_golden": lambda: (self.notebook.select(4), self._run_threaded(self._run_capture_golden)),
            "log_search":     lambda: (self.notebook.select(4), self._open_log_search_dialog()),
            "sandbox":        lambda: (self.notebook.select(4), self._open_sandbox_dialog()),
            "sentinel":       lambda: (self.notebook.select(4), self._run_threaded(self._run_sentinel_toggle)),
            "sentinel_alerts": lambda: (self.notebook.select(4), self._run_threaded(self._run_sentinel_report)),
            "microvm":        lambda: (self.notebook.select(4), self._open_microvm_dialog()),
            "npu_status":     lambda: (self.notebook.select(4), self._run_threaded(self._run_npu_report)),
            "pulse_toggle":   lambda: (self.notebook.select(4), self._run_threaded(self._run_pulse_toggle)),
            "pulse_report":   lambda: (self.notebook.select(4), self._run_threaded(self._run_pulse_report)),
            "agent_report":   lambda: (self.notebook.select(4), self._run_threaded(self._run_agent_report)),
            "safety_log":     lambda: (self.notebook.select(4), self._run_threaded(self._run_safety_log)),
            "av_toggle":      lambda: (self.notebook.select(4), self._run_threaded(self._run_av_toggle)),
            "av_status":      lambda: (self.notebook.select(4), self._run_threaded(self._run_av_report)),
            "av_threat_map":  lambda: (self.notebook.select(4), self._run_threaded(self._run_av_threat_map)),
            "pipeline_scan":  lambda: (self.notebook.select(4), self._run_threaded(self._run_pipeline_scan)),
            "pipeline_report":lambda: (self.notebook.select(4), self._run_threaded(self._run_pipeline_report)),
            "bridge_scan":    lambda: (self.notebook.select(4), self._run_threaded(self._run_bridge_scan)),
            "bridge_proc_scan":lambda: (self.notebook.select(4), self._run_threaded(self._run_bridge_proc_scan)),
            "bridge_net_scan":lambda: (self.notebook.select(4), self._run_threaded(self._run_bridge_net_scan)),
            "bridge_status":  lambda: (self.notebook.select(4), self._run_threaded(self._run_bridge_status)),
            "export_brain":   lambda: self._export_brain_dialog(),
            "import_brain":   lambda: self._import_brain_dialog(),
            "brain_stats":    lambda: self.notebook.select(6),
            "updates":        lambda: self._run_threaded(self._check_updates_action),
            "settings":       lambda: self.notebook.select(7),
            "ask_fyxa":       lambda: self.notebook.select(5),
        }
        action = dispatch.get(cmd_id)
        if action:
            action()

    def _palette_ask_fyxa(self, query):
        """Send a query to Fyxa from the command palette."""
        self.notebook.select(5)  # Switch to AI Chat tab
        self._safe(lambda: self.chat_input.delete(0, tk.END))
        self._safe(lambda: self.chat_input.insert(0, query))
        self.root.after(200, self.send_message)

    # ── Shared report painter ───────────────────────────────────────────

    def _paint_report(self, widget, title, items):
        """Paint a list of report items to a ScrolledText with colour tags."""
        def _do():
            w = widget
            lines = list(items or ["INFO: No data to display."])
            w.config(state=tk.NORMAL)
            w.delete(1.0, tk.END)
            w.insert(tk.END, f"{title}\n", "heading")
            w.insert(tk.END, "=" * 55 + "\n\n")
            for raw_line in lines:
                line = str(raw_line)
                if line.startswith("WARN:"):
                    w.insert(tk.END, f"  {line}\n", "warn")
                elif line.startswith("INFO:"):
                    w.insert(tk.END, f"  {line}\n", "info")
                elif "PASSED" in line or "ACTIVE" in line or "working" in line.lower() or "connected" in line.lower():
                    w.insert(tk.END, f"  {line}\n", "ok")
                elif "FAILED" in line or "NOT" in line or "failed" in line.lower():
                    w.insert(tk.END, f"  {line}\n", "err")
                else:
                    w.insert(tk.END, f"  {line}\n")
            w.insert(tk.END, f"\n{'=' * 55}\n")
            w.insert(tk.END, f"  Completed at {datetime.now().strftime('%H:%M:%S')}\n", "info")
            w.config(state=tk.DISABLED)
        self._safe(_do)

    # ── AI Chat (Deep Analysis) ─────────────────────────────────────────

    def create_analysis_tab(self):
        main = tk.Frame(self.analysis_frame, bg=self.bg_color)
        main.pack(fill=tk.BOTH, expand=True)
        main.grid_rowconfigure(1, weight=1)
        main.grid_columnconfigure(0, weight=1)

        # ── Title row ──
        title = tk.Frame(main, bg=self.bg_color)
        title.grid(row=0, column=0, sticky="ew", padx=20, pady=(12, 4))

        tk.Frame(title, bg=self.accent_color, width=4, height=20).pack(side=tk.LEFT, padx=(0, 10))
        tk.Label(title, text="Fyxa AI Chat", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(side=tk.LEFT)

        # Web search badge
        self._web_badge = tk.Label(
            title, text="WEB", font=("Noto Sans", 8, "bold"),
            bg=self.accent_secondary, fg="#ffffff", padx=6, pady=2,
        )
        self._web_badge.pack(side=tk.LEFT, padx=10)
        ToolTip(self._web_badge, "Fyxa can search the internet for answers")
        tk.Label(
            title,
            text="ChatGPT-style threaded conversations + executable diagnostics",
            font=("Noto Sans", 9),
            bg=self.bg_color,
            fg=self.text_dim,
        ).pack(side=tk.RIGHT)

        # ── Body: sidebar + chat surface ──
        body = tk.Frame(main, bg=self.bg_color)
        body.grid(row=1, column=0, sticky="nsew", padx=20, pady=(6, 6))
        body.grid_rowconfigure(0, weight=1)
        body.grid_columnconfigure(1, weight=1)

        # Sidebar conversations
        sidebar_border = tk.Frame(body, bg=self.border_color, width=250)
        sidebar_border.grid(row=0, column=0, sticky="nsw", padx=(0, 10))
        sidebar_border.grid_propagate(False)

        sidebar = tk.Frame(sidebar_border, bg=self.glass_white)
        sidebar.place(relx=0.5, rely=0.5, relwidth=0.99, relheight=0.99, anchor="center")
        sidebar.grid_rowconfigure(1, weight=1)
        sidebar.grid_columnconfigure(0, weight=1)

        side_head = tk.Frame(sidebar, bg=self.glass_white)
        side_head.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 6))
        tk.Label(
            side_head,
            text="Conversations",
            font=("Noto Sans", 10, "bold"),
            bg=self.glass_white,
            fg=self.text_color,
        ).pack(side=tk.LEFT)

        list_border = tk.Frame(sidebar, bg=self.border_color)
        list_border.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 8))
        self._chat_listbox = tk.Listbox(
            list_border,
            bg=self.glass_white,
            fg=self.text_color,
            selectbackground=self.accent_color,
            selectforeground="#ffffff",
            activestyle="none",
            relief="flat",
            borderwidth=0,
            highlightthickness=0,
            font=("Noto Sans", 10),
        )
        self._chat_listbox.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)
        self._chat_listbox.bind("<<ListboxSelect>>", self._on_chat_listbox_changed)
        SmoothScroller.bind_smooth_scroll(self._chat_listbox)

        side_btns = tk.Frame(sidebar, bg=self.glass_white)
        side_btns.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
        side_btns.columnconfigure(0, weight=1)
        side_btns.columnconfigure(1, weight=1)
        self._make_button(
            side_btns, "New Chat", self.new_chat_thread,
            bg=self.success_color, tooltip="Create a new conversation thread",
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self._make_button(
            side_btns, "Delete", self.delete_chat_thread,
            bg=self.danger_color, tooltip="Delete selected conversation",
        ).grid(row=0, column=1, sticky="ew", padx=(4, 0))

        # Main chat panel
        chat_shell_border = tk.Frame(body, bg=self.border_color)
        chat_shell_border.grid(row=0, column=1, sticky="nsew")

        chat_shell = tk.Frame(chat_shell_border, bg=self.glass_white)
        chat_shell.place(relx=0.5, rely=0.5, relwidth=0.998, relheight=0.998, anchor="center")
        chat_shell.grid_rowconfigure(1, weight=1)
        chat_shell.grid_columnconfigure(0, weight=1)

        top_bar = tk.Frame(chat_shell, bg=self.glass_tint)
        top_bar.grid(row=0, column=0, sticky="ew", padx=1, pady=(1, 0))
        tk.Label(
            top_bar,
            text="Fyxa Assistant",
            font=("Noto Sans", 10, "bold"),
            bg=self.glass_tint,
            fg=self.text_color,
            padx=12,
            pady=8,
        ).pack(side=tk.LEFT)

        # ── Chat display ──
        chat_frame = tk.Frame(chat_shell, bg=self.border_color)
        chat_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)

        self.chat_display = self._create_modern_text(
            chat_frame, font=("Noto Sans", 12),
            padx_text=15, pady_text=15,
            spacing1=6, spacing2=3, spacing3=10,
        )

        # ── Chat tags ──
        self.chat_display.tag_config("user_header",      foreground=self.accent_color,   font=("Noto Sans", 11, "bold"))
        self.chat_display.tag_config("user_text",         foreground=self.text_color,     font=("Noto Sans", 12))
        self.chat_display.tag_config("fyxa_header",       foreground=self.success_color,  font=("Noto Sans", 11, "bold"))
        self.chat_display.tag_config("fyxa_text",         foreground=self.chat_fyxa_fg, font=("Noto Sans", 12))
        self.chat_display.tag_config("system_header",     foreground=self.warning_color,  font=("Noto Sans", 11, "bold"))
        self.chat_display.tag_config("system_text",       foreground=self.warning_color,  font=("Noto Sans", 11))
        self.chat_display.tag_config("code_block",        foreground=self.accent_secondary, font=("Noto Sans Mono", 11),
                                     background=self.glass_tint, lmargin1=20, lmargin2=20, rmargin=20)
        self.chat_display.tag_config("timestamp",         foreground=self.text_dim,       font=("Noto Sans", 8))
        self.chat_display.tag_config("web_tag",           foreground=self.accent_secondary,font=("Noto Sans", 9, "italic"))
        self.chat_display.tag_config("thinking",          foreground=self.text_dim,       font=("Noto Sans", 11, "italic"))
        self.chat_display.tag_config("md_h1",             foreground=self.accent_color,   font=("Noto Sans", 14, "bold"), spacing1=6, spacing3=4)
        self.chat_display.tag_config("md_h2",             foreground=self.accent_secondary,font=("Noto Sans", 13, "bold"), spacing1=5, spacing3=3)
        self.chat_display.tag_config("md_h3",             foreground=self.accent_secondary,font=("Noto Sans", 12, "bold"), spacing1=4, spacing3=2)
        self.chat_display.tag_config("md_bold",           foreground=self.text_color,     font=("Noto Sans", 12, "bold"))
        self.chat_display.tag_config("md_italic",         foreground=self.text_dim,       font=("Noto Sans", 12, "italic"))
        self.chat_display.tag_config("md_list_marker",    foreground=self.accent_color,   font=("Noto Sans", 12, "bold"))
        self.chat_display.tag_config("md_quote",          foreground=self.text_dim,       font=("Noto Sans", 11, "italic"))
        self.chat_display.tag_config("md_quote_bar",      foreground=self.accent_secondary,font=("Noto Sans", 12, "bold"))
        self.chat_display.tag_config("md_separator",      foreground=self.border_color,   font=("Noto Sans Mono", 10))
        self.chat_display.tag_config("md_link",           foreground=self.accent_color,   underline=1, font=("Noto Sans", 12, "underline"))
        self._init_chat_context_menu()
        self.chat_display.bind("<Button-3>", self._show_chat_context_menu, add=True)
        self.chat_display.bind("<Control-c>", lambda _e: self._copy_chat_selection(), add=True)
        self.root.bind("<Control-Shift-C>", lambda _e: self._copy_last_code_block())
        self.root.bind("<Control-Shift-V>", lambda _e: self._paste_clipboard_to_input())

        # ── Input row ──
        input_row = tk.Frame(main, bg=self.bg_color)
        input_row.grid(row=2, column=0, sticky="ew", padx=20, pady=(6, 12))

        inp_border = tk.Frame(input_row, bg=self.border_color)
        inp_border.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 8))

        self.chat_input = tk.Entry(
            inp_border, font=("Noto Sans", 12),
            bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="flat", bd=0,
            selectbackground=self._mix_hex(self.accent_color, self.glass_white, 0.35),
            selectforeground=self.text_color,
            highlightthickness=0,
        )
        self.chat_input.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)
        self.chat_input.bind("<Return>", lambda _e: self.send_message())
        self.chat_input.bind("<Control-a>", self._chat_input_select_all, add=True)
        self.chat_input.bind("<Control-A>", self._chat_input_select_all, add=True)
        self._install_entry_placeholder(self.chat_input, "Ask Fyxa anything about your system...")

        self._make_button(input_row, "Send", self.send_message, tooltip="Enter — Send message").pack(side=tk.LEFT, padx=(0, 6))

        self._refresh_chat_selector()
        self._render_active_conversation()

    # ── Brain (Fyxa's Memory) ──────────────────────────────────────────

    def create_brain_tab(self):
        main, _canvas = self._create_scrollable_tab(self.brain_frame)

        # Header
        title_row = tk.Frame(main, bg=self.bg_color)
        title_row.pack(fill=tk.X, padx=20, pady=(15, 2))
        tk.Frame(title_row, bg=self.accent_color, width=4, height=20).pack(side=tk.LEFT, padx=(0, 10))
        tk.Label(title_row, text="Fyxa's Brain", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(side=tk.LEFT)

        tk.Label(main, text="Persistent memory — Fyxa learns from your system, conversations, and past fixes",
                 font=("Noto Sans", 9), bg=self.bg_color, fg=self.text_dim).pack(anchor="w", padx=20, pady=(0, 4))

        # Permission hint
        tk.Label(main, text="Manage permissions in Settings → Brain & Learning",
                 font=("Noto Sans", 8, "italic"), bg=self.bg_color, fg=self.text_dim).pack(anchor="w", padx=20, pady=(0, 4))

        # Stats bar
        self._brain_stats_frame = tk.Frame(main, bg=self.glass_tint)
        self._brain_stats_frame.pack(fill=tk.X, padx=20, pady=(0, 8))
        self._brain_stats_label = tk.Label(
            self._brain_stats_frame, text="Loading brain stats...",
            font=("Noto Sans Mono", 9), bg=self.glass_tint,
            fg=self.text_dim, padx=10, pady=6,
        )
        self._brain_stats_label.pack(anchor="w")

        self._create_action_deck(
            main,
            "Brain Actions",
            [
                ("View Brain", lambda: self._run_threaded(self._show_brain),
                 "Show everything Fyxa has learned"),
                ("Learn System", lambda: self._run_threaded(self._run_brain_observe),
                 "Scan your system and learn facts"),
                ("Deep Learn", lambda: self._run_threaded(self._run_brain_deep_observe),
                 "Deep scan: dotfiles, projects, dev tools (requires permission)"),
                ("Export Brain", self._export_brain_dialog,
                 "Export brain to portable file (for new machines)"),
                ("Import Brain", self._import_brain_dialog,
                 "Import brain from another machine"),
                ("Clear Brain", self._clear_brain_confirm,
                 "Wipe all of Fyxa's memories"),
            ],
            run_bg=self.accent_color,
            hint="Memory tools are consolidated into one control row.",
            default="View Brain",
        )

        # Memory display
        txt_frame = self._create_glass_log_container(main, padx=20, pady=(0, 10))
        self.brain_text = self._create_modern_text(txt_frame)
        self.brain_text.tag_config("heading", foreground=self.accent_color, font=("Noto Sans Mono", 10, "bold"))
        self.brain_text.tag_config("ok",   foreground=self.success_color)
        self.brain_text.tag_config("warn", foreground=self.warning_color)
        self.brain_text.tag_config("err",  foreground=self.danger_color)
        self.brain_text.tag_config("info", foreground=self.text_dim)

        # Auto-observe on startup (non-blocking)
        if self.config.get("brain_auto_observe_on_startup", True) and self.config.get("enable_brain", True):
            threading.Thread(target=self._brain_startup_observe, daemon=True).start()

        # Refresh stats
        self._refresh_brain_stats()

        # Show onboarding text
        self._show_brain_welcome()

    def _refresh_brain_stats(self):
        try:
            stats = get_brain_stats()
            size = get_brain_size_kb()
            text = (
                f"Facts: {stats['total_facts']}  |  "
                f"System: {stats['system_facts']}  |  "
                f"Prefs: {stats['user_preferences']}  |  "
                f"Insights: {stats['insights']}  |  "
                f"Fixes: {stats['solutions']}  |  "
                f"Cache: {stats.get('cache_entries', 0)}  |  "
                f"Scans: {stats['system_scans']}  |  "
                f"Size: {size:.1f} KB"
            )
            self._safe(lambda: self._brain_stats_label.config(text=text))
        except Exception:
            pass

    def _show_brain(self):
        self.update_text(self.brain_text, "Loading brain...\n")
        try:
            lines = get_brain_dump()
            self._paint_report(self.brain_text, "FYXA'S BRAIN", lines)
            self._refresh_brain_stats()
        except Exception as e:
            self.update_text(self.brain_text, f"Error: {e}")

    def _run_brain_observe(self):
        self.update_text(self.brain_text, "Scanning system...\n")
        try:
            learned = observe_system(deep=False)
            lines = [f"Learned {len(learned)} fact(s):"] + [f"  - {f}" for f in learned]
            lines.append("")
            lines.append("INFO: Use 'Deep Learn' to also scan dotfiles, projects, and dev tools.")
            self._paint_report(self.brain_text, "SYSTEM OBSERVATION", lines)
            self._refresh_brain_stats()
        except Exception as e:
            self.update_text(self.brain_text, f"Error: {e}")

    def _run_brain_deep_observe(self):
        if not self.config.get("brain_observe_files", False):
            self.update_text(self.brain_text,
                "Deep observation requires 'Observe files & projects' permission.\n"
                "Enable it in Settings → Brain & Learning.\n")
            return
        self.update_text(self.brain_text, "Running deep system observation...\n")
        try:
            learned = observe_system(deep=True)
            lines = [f"Learned {len(learned)} fact(s):"] + [f"  - {f}" for f in learned]
            self._paint_report(self.brain_text, "DEEP OBSERVATION", lines)
            self._refresh_brain_stats()
        except Exception as e:
            self.update_text(self.brain_text, f"Error: {e}")

    def _clear_brain_confirm(self):
        if messagebox.askyesno("Clear Brain",
                "This will erase everything Fyxa has learned.\nAre you sure?"):
            clear_brain()
            self.update_text(self.brain_text, "Brain cleared. Fyxa is starting fresh.\n")
            self._refresh_brain_stats()

    def _export_brain_dialog(self):
        """Export brain to a portable JSON file."""
        path = filedialog.asksaveasfilename(
            title="Export Brain",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile=f"sysfix-brain-export-{datetime.now().strftime('%Y%m%d')}.json",
        )
        if path:
            def _do():
                results = export_brain(path)
                self._paint_report(self.brain_text, "BRAIN EXPORT", results)
                self._notify("Brain Export", results[0] if results else "Done", "ok")
            self._run_threaded(_do)

    def _import_brain_dialog(self):
        """Import brain from a portable JSON file."""
        path = filedialog.askopenfilename(
            title="Import Brain",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            merge = messagebox.askyesno("Import Brain",
                "Merge with existing brain?\n\n"
                "YES = combine knowledge (recommended)\n"
                "NO = replace entirely")
            def _do():
                results = import_brain(path, merge=merge)
                self._paint_report(self.brain_text, "BRAIN IMPORT", results)
                self._refresh_brain_stats()
                self._notify("Brain Import", results[0] if results else "Done", "ok")
            self._run_threaded(_do)

    def _brain_startup_observe(self):
        """Silent background observation on startup."""
        try:
            observe_system(deep=self.config.get("brain_observe_files", False))
            self._refresh_brain_stats()
        except Exception:
            pass

    def _show_brain_welcome(self):
        """Onboarding instructions for the Brain tab."""
        def _do():
            w = self.brain_text
            w.config(state=tk.NORMAL)
            w.delete(1.0, tk.END)
            w.insert(tk.END, "FYXA'S BRAIN\n", "heading")
            w.insert(tk.END, "=" * 55 + "\n\n")
            w.insert(tk.END, "  Fyxa's brain is a persistent learning database.\n")
            w.insert(tk.END, "  She learns from your system, your conversations, and\n")
            w.insert(tk.END, "  the fixes she applies \u2014 getting smarter over time.\n\n")
            w.insert(tk.END, "  Use the action menu above to run memory tools.\n\n", "info")
            w.insert(tk.END, "  How it works:\n\n", "heading")
            w.insert(tk.END, "  \u25cf View Brain\n", "ok")
            w.insert(tk.END, "    See everything Fyxa has learned: system profile,\n", "info")
            w.insert(tk.END, "    your preferences, discovered projects, past fixes,\n", "info")
            w.insert(tk.END, "    and insights extracted from conversations.\n\n", "info")
            w.insert(tk.END, "  \u25cf Learn System\n", "ok")
            w.insert(tk.END, "    Quick scan: hardware, OS, shell, package manager.\n", "info")
            w.insert(tk.END, "    Safe and non-intrusive. Runs automatically on startup.\n\n", "info")
            w.insert(tk.END, "  \u25cf Deep Learn\n", "ok")
            w.insert(tk.END, "    Extended scan: dotfiles, aliases, dev tools, git config,\n", "info")
            w.insert(tk.END, "    projects, and installed applications. Requires the\n", "info")
            w.insert(tk.END, "    'Observe files & projects' permission in Settings.\n\n", "info")
            w.insert(tk.END, "  \u25cf Clear Brain\n", "err")
            w.insert(tk.END, "    Wipe all of Fyxa's memories and start fresh.\n\n", "info")
            w.insert(tk.END, "  " + "-" * 50 + "\n", "info")
            w.insert(tk.END, "  All data stays local: ~/.config/sysfix/brain.json\n", "info")
            w.insert(tk.END, "  Nothing is ever sent to the internet.\n", "info")
            w.insert(tk.END, "  Manage permissions in Settings \u2192 Brain & Learning.\n", "info")
            w.config(state=tk.DISABLED)
        self._safe(_do)

    # ── Settings ────────────────────────────────────────────────────────

    def create_settings_tab(self):
        main = tk.Frame(self.settings_frame, bg=self.bg_color)
        main.pack(fill=tk.BOTH, expand=True)

        tk.Label(main, text="Settings & Preferences", font=("Noto Sans", 13, "bold"),
                 bg=self.bg_color, fg=self.metallic_light).pack(anchor="w", padx=20, pady=(15, 8))

        settings_container = tk.Frame(main, bg=self.border_color)
        settings_container.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 10))

        canvas = tk.Canvas(settings_container, bg=self.glass_white, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(settings_container, orient="vertical", command=canvas.yview)
        scrollable = tk.Frame(canvas, bg=self.glass_white)

        scrollable.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_window = canvas.create_window((0, 0), window=scrollable, anchor="nw")
        # Fix canvas width tracking
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(canvas_window, width=e.width))
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        SmoothScroller.bind_smooth_scroll(canvas)

        # ── About section ─────────────────────────────────────────
        from sysfixai import __version__
        about_hdr = tk.Frame(scrollable, bg=self.glass_white)
        about_hdr.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(about_hdr, text="About Sysfix AI", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(about_hdr, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        about_info = tk.Frame(scrollable, bg=self.glass_white)
        about_info.pack(fill=tk.X, padx=20, pady=(0, 5))
        tk.Label(about_info, text=f"Version: {__version__}",
                 font=("Noto Sans", 9), bg=self.glass_white, fg=self.text_color).pack(anchor="w")
        tk.Label(about_info, text=f"Config: {CONFIG_FILE}",
                 font=("Noto Sans", 8), bg=self.glass_white, fg=self.text_dim).pack(anchor="w", pady=(2, 0))
        sudo_note = " (sudo-aware: using real user's config)" if os.environ.get("SUDO_USER") else ""
        if sudo_note:
            tk.Label(about_info, text=sudo_note.strip(),
                     font=("Noto Sans", 8, "italic"), bg=self.glass_white, fg=self.warning_color).pack(anchor="w")
        tk.Label(about_info, text="© useofscript  •  Proprietary Licence  •  Free to use",
                 font=("Noto Sans", 8), bg=self.glass_white, fg=self.text_dim).pack(anchor="w", pady=(2, 0))
        tk.Label(about_info,
                 text="Sysfix utilises a proprietary local AI engine. No third-party API subscriptions required.",
                 font=("Noto Sans", 8, "italic"), bg=self.glass_white, fg=self.accent_color,
                 wraplength=440, justify=tk.LEFT).pack(anchor="w", pady=(4, 0))

        self._add_settings_section(scrollable, "System Scanning", [
            ("auto_scan_on_startup", "Auto-scan on startup", "Automatically run diagnostics when GUI opens"),
            ("auto_deep_dive", "Deep-dive on issues", "Automatically perform in-depth analysis of problems"),
        ])
        self._add_settings_section(scrollable, "Auto-Fix Settings", [
            ("auto_apply_safe_fixes", "Auto-apply safe fixes", "Automatically apply fixes that are safe to run"),
            ("memory_optimization", "Memory optimization", "Enable automatic memory cleanup"),
            ("disk_cleanup", "Disk cleanup", "Enable automatic disk space recovery"),
        ])
        self._add_settings_section(scrollable, "AI & Network", [
            ("enable_ai_features", "Enable AI features", "Use Fyxa's local AI engine for diagnostics"),
            ("enable_web_search", "Enable web search", "Let Fyxa search DuckDuckGo for real-time data"),
            ("ai_fallback_free", "Use local AI engine", "Always available — no API key required"),
            ("enable_notifications", "Enable notifications", "Show notification alerts"),
            ("eli5_mode", "ELI5 mode (simple explanations)", "Plain-language answers instead of technical details"),
        ])
        self._add_settings_section(scrollable, "Advanced Diagnostics", [
            ("enable_predictive_maintenance", "Predictive maintenance", "S.M.A.R.T. trend analysis and lifespan prediction"),
            ("enable_zombie_hunter", "Zombie process hunter", "Detect zombie and D-state processes on startup"),
            ("auto_snapshot_before_fix", "Auto-snapshot before fixes", "Create system snapshot before AI applies fixes"),
        ])

        # ── Theme selector ────────────────────────────────────────
        theme_hdr = tk.Frame(scrollable, bg=self.glass_white)
        theme_hdr.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(theme_hdr, text="Appearance", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(theme_hdr, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        theme_row = tk.Frame(scrollable, bg=self.glass_white)
        theme_row.pack(fill=tk.X, padx=20, pady=5)
        tk.Label(theme_row, text="Theme:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))

        theme_labels = [THEMES[k]["label"] for k in THEME_NAMES]
        current_label = THEMES.get(self._current_theme, THEMES["frutiger_aero"])["label"]
        self._theme_var = tk.StringVar(value=current_label)
        theme_menu = tk.OptionMenu(theme_row, self._theme_var, *theme_labels,
                                   command=self._on_theme_changed)
        theme_menu.config(font=("Noto Sans", 9), bg=self.glass_white,
                          fg=self.text_color, activebackground=self.glass_tint,
                          activeforeground=self.accent_color, highlightthickness=0,
                          relief="flat", bd=0)
        theme_menu["menu"].config(bg=self.glass_white, fg=self.text_color,
                                  activebackground=self.accent_color,
                                  activeforeground=self.button_fg,
                                  font=("Noto Sans", 9))
        theme_menu.pack(side=tk.LEFT, fill=tk.X, expand=True)

        theme_hint = tk.Frame(scrollable, bg=self.glass_white)
        theme_hint.pack(fill=tk.X, padx=35, pady=(0, 5))
        tk.Label(theme_hint,
                 text="Choose your look: Frutiger Aero, Light, Dark, or Cyberpunk.",
                 font=("Noto Sans", 8), bg=self.glass_white, fg=self.text_dim,
                 ).pack(anchor="w")

        # Model selector
        model_frame = tk.Frame(scrollable, bg=self.glass_white)
        model_frame.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(model_frame, text="AI Model", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(model_frame, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        # Row 0: provider selector
        provider_row = tk.Frame(scrollable, bg=self.glass_white)
        provider_row.pack(fill=tk.X, padx=20, pady=(6, 5))
        tk.Label(provider_row, text="Provider:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))

        provider_options = get_provider_options()
        self._provider_key_from_label = {label: key for key, label in provider_options.items()}
        self._provider_label_from_key = provider_options
        active_provider = get_active_provider()
        active_provider_label = provider_options.get(active_provider, provider_options["auto"])
        self._provider_var = tk.StringVar(value=active_provider_label)
        provider_menu = tk.OptionMenu(
            provider_row,
            self._provider_var,
            *[provider_options[k] for k in provider_options.keys()],
            command=self._on_provider_changed,
        )
        provider_menu.config(font=("Noto Sans", 9), bg=self.glass_white,
                             fg=self.text_color, activebackground=self.glass_tint,
                             activeforeground=self.accent_color, highlightthickness=0,
                             relief="flat", bd=0)
        provider_menu["menu"].config(bg=self.glass_white, fg=self.text_color,
                                      activebackground=self.accent_color,
                                      activeforeground=self.button_fg,
                                      font=("Noto Sans", 9))
        provider_menu.pack(side=tk.LEFT, fill=tk.X, expand=True)

        provider_hint = tk.Frame(scrollable, bg=self.glass_white)
        provider_hint.pack(fill=tk.X, padx=35, pady=(0, 3))
        tk.Label(
            provider_hint,
            text="Sysfix's core AI is fully local — no API subscriptions required. "
                 "Optionally connect Ollama for deeper local LLM reasoning.",
            font=("Noto Sans", 8),
            bg=self.glass_white,
            fg=self.text_dim,
        ).pack(anchor="w")

        # Row 1: dropdown for installed Ollama models
        selector_row = tk.Frame(scrollable, bg=self.glass_white)
        selector_row.pack(fill=tk.X, padx=20, pady=5)
        tk.Label(selector_row, text="Installed models:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))

        current = self._current_provider_model(active_provider)
        self._model_var = tk.StringVar(value=current)

        # Fetch models in background to avoid blocking the GUI
        self._model_menu_placeholder = tk.Label(
            selector_row, text="(loading…)", font=("Noto Sans", 9),
            bg=self.glass_white, fg=self.text_dim,
        )
        self._model_menu_placeholder.pack(side=tk.LEFT)
        self._model_selector_row = selector_row

        def _load_models():
            models = list_available_models()
            self.root.after(0, lambda: self._populate_model_menu(models))
        threading.Thread(target=_load_models, daemon=True).start()

        # Row 2: manual model entry (type any model name or API model)
        custom_row = tk.Frame(scrollable, bg=self.glass_white)
        custom_row.pack(fill=tk.X, padx=20, pady=(4, 5))
        tk.Label(custom_row, text="Or type a model:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))

        self._custom_model_var = tk.StringVar(value=current)
        custom_entry = tk.Entry(
            custom_row, textvariable=self._custom_model_var,
            font=("Noto Sans", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="solid", bd=1,
            highlightcolor=self.accent_color, highlightthickness=1,
        )
        custom_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))

        apply_btn = self._make_button(custom_row, "Apply", self._apply_custom_model,
                                       bg=self.accent_color, tooltip="Set this model as active")
        apply_btn.pack(side=tk.LEFT)

        # Row 3: Ollama API endpoint
        api_row = tk.Frame(scrollable, bg=self.glass_white)
        api_row.pack(fill=tk.X, padx=20, pady=(4, 5))
        tk.Label(api_row, text="Ollama endpoint:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))

        saved_endpoint = self.config.get("ollama_endpoint", "http://localhost:11434")
        self._endpoint_var = tk.StringVar(value=saved_endpoint)
        ep_entry = tk.Entry(
            api_row, textvariable=self._endpoint_var,
            font=("Noto Sans", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="solid", bd=1,
            highlightcolor=self.accent_color, highlightthickness=1,
        )
        ep_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))

        ep_btn = self._make_button(api_row, "Save", self._save_endpoint,
                                    bg=self.accent_color, tooltip="Save the API endpoint")
        ep_btn.pack(side=tk.LEFT)

        # Row 4: OpenAI API key
        openai_row = tk.Frame(scrollable, bg=self.glass_white)
        openai_row.pack(fill=tk.X, padx=20, pady=(4, 5))
        tk.Label(openai_row, text="OpenAI key:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))
        self._openai_key_var = tk.StringVar(value=self.config.get("openai_api_key", ""))
        openai_entry = tk.Entry(
            openai_row, textvariable=self._openai_key_var, show="*",
            font=("Noto Sans Mono", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="flat", bd=2, width=30,
        )
        openai_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self._make_button(
            openai_row, "Save", self._save_openai_key,
            bg=self.success_color, tooltip="Save OpenAI API key",
        ).pack(side=tk.LEFT)

        # Row 5: Anthropic API key
        anth_row = tk.Frame(scrollable, bg=self.glass_white)
        anth_row.pack(fill=tk.X, padx=20, pady=(4, 5))
        tk.Label(anth_row, text="Anthropic key:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))
        self._anthropic_key_var = tk.StringVar(value=self.config.get("anthropic_api_key", ""))
        anth_entry = tk.Entry(
            anth_row, textvariable=self._anthropic_key_var, show="*",
            font=("Noto Sans Mono", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="flat", bd=2, width=30,
        )
        anth_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self._make_button(
            anth_row, "Save", self._save_anthropic_key,
            bg=self.success_color, tooltip="Save Anthropic API key",
        ).pack(side=tk.LEFT)

        # Row 6: OpenRouter API key
        or_row = tk.Frame(scrollable, bg=self.glass_white)
        or_row.pack(fill=tk.X, padx=20, pady=(4, 5))
        tk.Label(or_row, text="OpenRouter key:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))
        self._openrouter_key_var = tk.StringVar(value=self.config.get("openrouter_api_key", ""))
        or_entry = tk.Entry(
            or_row, textvariable=self._openrouter_key_var, show="*",
            font=("Noto Sans Mono", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="flat", bd=2, width=30,
        )
        or_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self._make_button(
            or_row, "Save", self._save_openrouter_key,
            bg=self.success_color, tooltip="Save OpenRouter API key",
        ).pack(side=tk.LEFT)

        # Row 7: Generic OpenAI-compatible endpoint/key/model
        compat_row = tk.Frame(scrollable, bg=self.glass_white)
        compat_row.pack(fill=tk.X, padx=20, pady=(4, 5))
        tk.Label(compat_row, text="Compatible API:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))
        self._compat_base_var = tk.StringVar(value=self.config.get("ai_compatible_base_url", ""))
        compat_base = tk.Entry(
            compat_row, textvariable=self._compat_base_var,
            font=("Noto Sans", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="flat", bd=2, width=28,
        )
        compat_base.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        self._compat_key_var = tk.StringVar(value=self.config.get("ai_compatible_api_key", ""))
        compat_key = tk.Entry(
            compat_row, textvariable=self._compat_key_var, show="*",
            font=("Noto Sans Mono", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="flat", bd=2, width=18,
        )
        compat_key.pack(side=tk.LEFT, padx=(0, 6))
        self._compat_model_var = tk.StringVar(value=self.config.get("ai_compatible_model", ""))
        compat_model = tk.Entry(
            compat_row, textvariable=self._compat_model_var,
            font=("Noto Sans", 9), bg=self.glass_white, fg=self.text_color,
            insertbackground=self.accent_color, relief="flat", bd=2, width=18,
        )
        compat_model.pack(side=tk.LEFT, padx=(0, 6))
        self._make_button(
            compat_row, "Save", self._save_compatible_provider,
            bg=self.success_color, tooltip="Save OpenAI-compatible provider settings",
        ).pack(side=tk.LEFT)

        # Hint / status label
        model_hint = tk.Frame(scrollable, bg=self.glass_white)
        model_hint.pack(fill=tk.X, padx=35, pady=(0, 5))
        hint_text = f"Provider: {get_provider_label(active_provider)}  |  Model: {current or '(auto)'}"
        cloudish = active_provider in {"openai", "anthropic", "openrouter", "openai_compatible"} or is_cloud_model(current)
        self._model_hint_label = tk.Label(
            model_hint, text=hint_text,
            font=("Noto Sans", 8), bg=self.glass_white,
            fg=self.warning_color if cloudish else self.text_dim,
        )
        self._model_hint_label.pack(anchor="w")

        # Cloud warning label (shown/hidden dynamically)
        self._cloud_warn_frame = tk.Frame(scrollable, bg=self.glass_white)
        self._cloud_warn_frame.pack(fill=tk.X, padx=35, pady=(0, 8))
        self._cloud_warn_label = tk.Label(
            self._cloud_warn_frame,
            text="Optional: These advanced endpoints connect to external services. "
                 "Sysfix's core AI is fully local and requires no API subscriptions.",
            font=("Noto Sans", 8, "italic"), bg=self.glass_white,
            fg=self.warning_color, wraplength=400, justify=tk.LEFT,
        )
        if cloudish:
            self._cloud_warn_label.pack(anchor="w")

        # ── Brain & Learning section ──────────────────────────────
        self._add_settings_section(scrollable, "Brain & Learning", [
            ("enable_brain", "Enable Fyxa's brain",
             "Persistent memory — Fyxa learns and gets smarter over time"),
            ("brain_observe_system", "Observe system (hardware, tools)",
             "Learn installed software, hardware specs, package manager"),
            ("brain_observe_files", "Observe files & projects",
             "Read dotfiles, discover projects, learn aliases (needs permission)"),
            ("brain_learn_conversations", "Learn from conversations",
             "Extract insights from your chats with Fyxa"),
            ("brain_auto_observe_on_startup", "Auto-observe on startup",
             "Silently scan your system each time Sysfix opens"),
        ])

        # ── Startup & Updates section ─────────────────────────────
        startup_hdr = tk.Frame(scrollable, bg=self.glass_white)
        startup_hdr.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(startup_hdr, text="Startup & Updates", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(startup_hdr, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        # Autostart checkbox
        auto_f = tk.Frame(scrollable, bg=self.glass_white)
        auto_f.pack(fill=tk.X, padx=20, pady=5)
        self._autostart_var = tk.BooleanVar(value=is_autostart_enabled())
        tk.Checkbutton(
            auto_f, text="Start on login", variable=self._autostart_var,
            command=self._on_autostart_toggled,
            font=("Noto Sans", 9), bg=self.glass_white, fg=self.text_color,
            activebackground=self.glass_white, activeforeground=self.accent_color,
            selectcolor=self.glass_white, highlightthickness=0,
        ).pack(anchor="w", pady=(0, 1))
        tk.Label(auto_f, text="Launch Sysfix automatically when you log in (off by default)",
                 font=("Noto Sans", 8), bg=self.glass_white, fg=self.text_dim).pack(anchor="w", padx=(20, 0))

        self._add_setting_checkbox(
            scrollable,
            "auto_check_updates_on_startup",
            "Check for Sysfix updates on startup",
            "Run an update check during the loading screen. Disable for faster offline startup.",
        )

        # ── Privileges section ────────────────────────────────────
        priv_hdr = tk.Frame(scrollable, bg=self.glass_white)
        priv_hdr.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(priv_hdr, text="Privileges", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(priv_hdr, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        priv_info = tk.Frame(scrollable, bg=self.glass_white)
        priv_info.pack(fill=tk.X, padx=20, pady=(0, 5))
        mode_text = "Admin (root)" if self.is_sudo else "User (unprivileged)"
        mode_color = self.success_color if self.is_sudo else self.text_dim
        tk.Label(priv_info, text=f"Current mode:  {mode_text}",
                 font=("Noto Sans", 9), bg=self.glass_white, fg=mode_color).pack(anchor="w")
        if not self.is_sudo:
            tk.Label(priv_info,
                     text="Some operations (system updates, kernel tuning, etc.) require root privileges.",
                     font=("Noto Sans", 8), bg=self.glass_white, fg=self.text_dim,
                     wraplength=440, justify=tk.LEFT).pack(anchor="w", pady=(2, 0))

        priv_btn_row = tk.Frame(scrollable, bg=self.glass_white)
        priv_btn_row.pack(fill=tk.X, padx=20, pady=(2, 8))
        restart_btn = self._make_button(
            priv_btn_row,
            "Restart as Admin" if not self.is_sudo else "Already Admin ✓",
            self._enable_sudo_mode,
            bg=self.danger_color if not self.is_sudo else self.success_color,
            tooltip="Restart Sysfix with root privileges via pkexec",
        )
        restart_btn.pack(side=tk.LEFT)
        if self.is_sudo:
            restart_btn.config(state=tk.DISABLED)

        # ── Virus Scanning section ────────────────────────────────
        vt_hdr = tk.Frame(scrollable, bg=self.glass_white)
        vt_hdr.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(vt_hdr, text="Virus Scanning", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(vt_hdr, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        vt_row = tk.Frame(scrollable, bg=self.glass_white)
        vt_row.pack(fill=tk.X, padx=20, pady=5)
        tk.Label(vt_row, text="VirusTotal API key:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))
        self._vt_key_var = tk.StringVar(value=self.config.get("virustotal_api_key", ""))
        vt_entry = tk.Entry(vt_row, textvariable=self._vt_key_var, show="*",
                            font=("Noto Sans Mono", 9), bg=self.glass_white,
                            fg=self.text_color, insertbackground=self.accent_color,
                            relief="flat", bd=2, width=40)
        vt_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self._make_button(vt_row, "Save", self._save_vt_key,
                          bg=self.success_color, tooltip="Save VirusTotal API key").pack(side=tk.LEFT)

        vt_hint = tk.Frame(scrollable, bg=self.glass_white)
        vt_hint.pack(fill=tk.X, padx=35, pady=(0, 8))
        tk.Label(vt_hint, text="Optional — get a free key at virustotal.com (4 lookups/min). "
                 "MalwareBazaar scanning works without a key.",
                 font=("Noto Sans", 8), bg=self.glass_white, fg=self.text_dim,
                 wraplength=440, justify=tk.LEFT).pack(anchor="w")

        # ── GitHub / Updates section ──────────────────────────────
        gh_hdr = tk.Frame(scrollable, bg=self.glass_white)
        gh_hdr.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(gh_hdr, text="Updates & GitHub", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(gh_hdr, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        gh_row = tk.Frame(scrollable, bg=self.glass_white)
        gh_row.pack(fill=tk.X, padx=20, pady=5)
        tk.Label(gh_row, text="GitHub Token:", font=("Noto Sans", 9),
                 bg=self.glass_white, fg=self.text_color).pack(side=tk.LEFT, padx=(0, 8))
        self._gh_token_var = tk.StringVar(value=self.config.get("github_token", ""))
        gh_entry = tk.Entry(gh_row, textvariable=self._gh_token_var, show="*",
                            font=("Noto Sans Mono", 9), bg=self.glass_white,
                            fg=self.text_color, insertbackground=self.accent_color,
                            relief="flat", bd=2, width=40)
        gh_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self._make_button(gh_row, "Save", self._save_gh_token,
                          bg=self.success_color, tooltip="Save GitHub token").pack(side=tk.LEFT)

        gh_hint = tk.Frame(scrollable, bg=self.glass_white)
        gh_hint.pack(fill=tk.X, padx=35, pady=(0, 8))
        tk.Label(gh_hint, text="Required for updates from a private GitHub repo. "
                 "Create a fine-grained PAT at github.com/settings/tokens with read-only access to Contents and Releases.",
                 font=("Noto Sans", 8), bg=self.glass_white, fg=self.text_dim,
                 wraplength=440, justify=tk.LEFT).pack(anchor="w")

        # ── Sysfix Pro Upgrade section ────────────────────────────
        self._build_upgrade_section(scrollable)

        # ── Export / Import / Reset (inside scrollable) ───────────
        btn_row = tk.Frame(scrollable, bg=self.glass_white)
        btn_row.pack(fill=tk.X, padx=15, pady=(15, 15))
        settings_buttons = [
            ("Export Settings", self._export_settings,
             self.accent_color, "Export settings to a file"),
            ("Import Settings", self._import_settings,
             self.accent_secondary, "Import settings from a file"),
            ("Reset to Defaults", self.reset_settings,
             self.danger_color, "Restore all settings to defaults"),
        ]
        for i, (text, cmd, bg, tip) in enumerate(settings_buttons):
            btn_row.columnconfigure(i, weight=1, uniform="sett")
            self._make_button(btn_row, text, cmd, bg=bg, tooltip=tip).grid(
                row=0, column=i, sticky="ew", padx=(0 if i == 0 else 4, 0))

    def _export_settings(self):
        """Export current settings to a JSON file."""
        path = filedialog.asksaveasfilename(
            title="Export Settings",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="sysfix-settings.json",
        )
        if path:
            try:
                import json
                with open(path, "w") as f:
                    json.dump(self.config, f, indent=2)
                messagebox.showinfo("Export", f"Settings exported to:\n{path}")
            except Exception as e:
                messagebox.showerror("Export Error", str(e))

    def _import_settings(self):
        """Import settings from a JSON file."""
        path = filedialog.askopenfilename(
            title="Import Settings",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            try:
                import json
                with open(path, "r") as f:
                    imported = json.load(f)
                if not isinstance(imported, dict):
                    messagebox.showerror("Import Error", "Invalid settings file format.")
                    return
                self.config.update(imported)
                save_config(self.config)
                messagebox.showinfo("Import", "Settings imported successfully.\nRebuilding UI…")
                self._rebuild_ui()
            except Exception as e:
                messagebox.showerror("Import Error", str(e))

    def _on_theme_changed(self, label):
        """Handle theme selection from the dropdown."""
        # Reverse-lookup the theme key from its label
        for key, theme in THEMES.items():
            if theme["label"] == label:
                if key == self._current_theme:
                    return
                self._current_theme = key
                self.config["theme"] = key
                save_config(self.config)
                self._rebuild_ui()
                self._set_status(f"Theme set to {theme['label']}", "ok", timeout=1800)
                return

    def _rebuild_ui(self):
        """Destroy and rebuild the entire UI with the current theme."""
        # Preserve chat state
        if hasattr(self, "_conversations"):
            conversations = {}
            for cid, chat in self._conversations.items():
                conversations[cid] = {
                    "title": str(chat.get("title", "New Chat"))[:80],
                    "messages": self._sanitize_chat_messages(chat.get("messages", [])),
                    "last_response": str(chat.get("last_response", ""))[:5000],
                    "updated_at": str(chat.get("updated_at", "")),
                }
            conversation_order = [cid for cid in getattr(self, "_conversation_order", []) if cid in conversations]
            for cid in conversations.keys():
                if cid not in conversation_order:
                    conversation_order.append(cid)
            active_chat = self._active_chat_id if self._active_chat_id in conversations else None
        else:
            conversations = {}
            conversation_order = []
            active_chat = None
        pending_requests = dict(getattr(self, "_pending_command_requests", {}) or {})
        pending_order = list(getattr(self, "_pending_command_order", []) or [])
        exec_history = dict(getattr(self, "_last_exec_by_chat", {}) or {})
        auto_accept = bool(getattr(self, "_command_auto_accept", False))

        for timer_attr in ("_stats_after_id", "_gauge_anim_after_id", "_status_reset_after_id", "_bg_texture_job"):
            timer_id = getattr(self, timer_attr, None)
            if timer_id:
                try:
                    self.root.after_cancel(timer_id)
                except Exception:
                    pass
                setattr(self, timer_attr, None)

        # Destroy all children of root
        for w in self.root.winfo_children():
            w.destroy()

        # Re-init state that widget-creation methods depend on
        self.settings_vars = {}
        self._conversations = conversations
        self._conversation_order = conversation_order
        self._active_chat_id = active_chat
        self._chat_selector_labels = {}
        self._chat_selector_var = None
        self._chat_selector = None
        self._chat_listbox = None
        self._suspend_chat_select_events = False
        self._chat_context_menu = None
        self._link_tag_counter = 0
        self._ensure_chat_exists()
        if self._active_chat_id not in self._conversations:
            self._active_chat_id = self._conversation_order[0]
        self.chat_history = self._conversations[self._active_chat_id]["messages"]
        self._last_ai_response = self._conversations[self._active_chat_id].get("last_response", "")
        self._is_thinking = False
        self._thinking_frame = 0
        self._is_processing = False
        self._active_tasks = 0
        self._command_auto_accept = auto_accept
        self._pending_command_requests = pending_requests
        self._pending_command_order = pending_order
        self._command_request_widgets = {}
        self._last_exec_by_chat = exec_history
        self._revert_widgets = {}
        self._command_execution_active = False
        self._gauge_targets = {}
        self._gauge_display = {}
        self._quick_actions = {}

        # Rebuild
        self.configure_styles()
        self._apply_material_effects()
        self.create_header()
        self.create_update_banner()
        self.create_notebook()
        self.create_status_bar()
        self._setup_quick_actions()
        self.check_initial_status()
        self._start_live_stats()

    def _provider_model_key(self, provider):
        provider = (provider or "auto").strip().lower()
        mapping = {
            "ollama": "ai_model",
            "auto": "ai_model",
            "openai": "openai_model",
            "anthropic": "anthropic_model",
            "openrouter": "openrouter_model",
            "openai_compatible": "ai_compatible_model",
        }
        return mapping.get(provider, "ai_model")

    def _current_provider_model(self, provider=None):
        provider = (provider or self.config.get("ai_provider", "auto")).strip().lower()
        key = self._provider_model_key(provider)
        model = (self.config.get(key) or "").strip()
        if model:
            return model
        if provider in ("auto", "ollama"):
            return get_active_model()
        defaults = {
            "openai": "gpt-4o-mini",
            "anthropic": "claude-3-5-sonnet-latest",
            "openrouter": "meta-llama/llama-3.3-70b-instruct:free",
            "openai_compatible": "",
        }
        return defaults.get(provider, "")

    def _refresh_model_hint(self):
        provider = (self.config.get("ai_provider") or "auto").strip().lower()
        model = self._current_provider_model(provider) or "(auto)"
        cloudish = provider in {"openai", "anthropic", "openrouter", "openai_compatible"} or is_cloud_model(model)
        hint = f"Provider: {get_provider_label(provider)}  |  Model: {model}"
        if hasattr(self, "_model_hint_label"):
            self._model_hint_label.config(
                text=hint,
                fg=self.warning_color if cloudish else self.text_dim,
            )
        if hasattr(self, "_cloud_warn_label"):
            if cloudish:
                self._cloud_warn_label.pack(anchor="w")
            else:
                self._cloud_warn_label.pack_forget()
        if hasattr(self, "_custom_model_var"):
            self._custom_model_var.set("" if model == "(auto)" else model)
        self._refresh_ai_status_label()

    def _on_provider_changed(self, provider_label):
        provider_key = self._provider_key_from_label.get(provider_label, "auto")
        self.config["ai_provider"] = provider_key
        save_config(self.config)
        set_active_provider(provider_key)
        if hasattr(self, "_model_var"):
            self._model_var.set(self._current_provider_model(provider_key))
        self._refresh_model_hint()
        self._set_status(f"Provider set: {get_provider_label(provider_key)}", "ok", timeout=1800)

    def _on_model_changed(self, model_name):
        """Handle model selection change (from dropdown or custom entry)."""
        model_name = model_name.strip()
        if not model_name:
            return
        provider = (self.config.get("ai_provider") or "auto").strip().lower()
        key = self._provider_model_key(provider)
        self.config[key] = model_name
        if provider in ("auto", "ollama"):
            set_active_model(model_name)
            self.config["ai_model"] = model_name
        save_config(self.config)

        # Sync both the dropdown var and custom entry
        if hasattr(self, "_model_var"):
            self._model_var.set(model_name)
        if hasattr(self, "_custom_model_var"):
            self._custom_model_var.set(model_name)

        self._refresh_model_hint()
        self._set_status(f"Model set: {model_name}", "ok", timeout=1800)

    def _populate_model_menu(self, models):
        """Populate the model dropdown after background fetch completes."""
        try:
            self._model_menu_placeholder.destroy()
        except Exception:
            pass
        if models:
            model_menu = tk.OptionMenu(self._model_selector_row, self._model_var, *models,
                                        command=self._on_model_changed)
            model_menu.config(font=("Noto Sans", 9), bg=self.glass_white,
                              fg=self.text_color, activebackground=self.glass_tint,
                              activeforeground=self.accent_color, highlightthickness=0,
                              relief="flat", bd=0)
            model_menu["menu"].config(bg=self.glass_white, fg=self.text_color,
                                       activebackground=self.accent_color,
                                       activeforeground="#ffffff",
                                       font=("Noto Sans", 9))
            model_menu.pack(side=tk.LEFT, fill=tk.X, expand=True)
        else:
            tk.Label(self._model_selector_row, text="(no Ollama models found)",
                     font=("Noto Sans", 9), bg=self.glass_white,
                     fg=self.text_dim).pack(side=tk.LEFT)

    def _apply_custom_model(self):
        """Set a manually typed model name as active."""
        model = self._custom_model_var.get().strip()
        if model:
            self._on_model_changed(model)

    def _save_endpoint(self):
        """Save the Ollama API endpoint to config."""
        endpoint = self._endpoint_var.get().strip()
        if endpoint:
            self.config["ollama_endpoint"] = endpoint
            save_config(self.config)
            # Update the endpoint used by the AI module
            try:
                import sysfixai.ai as ai_mod
                ai_mod.OLLAMA_BASE = endpoint
            except Exception:
                pass
            self._refresh_ai_status_label()
            self._set_status("Ollama endpoint saved", "ok", timeout=1800)

    def _save_openai_key(self):
        self.config["openai_api_key"] = self._openai_key_var.get().strip()
        save_config(self.config)
        self._refresh_ai_status_label()
        self._set_status("OpenAI key saved", "ok", timeout=1800)

    def _save_anthropic_key(self):
        self.config["anthropic_api_key"] = self._anthropic_key_var.get().strip()
        save_config(self.config)
        self._refresh_ai_status_label()
        self._set_status("Anthropic key saved", "ok", timeout=1800)

    def _save_openrouter_key(self):
        self.config["openrouter_api_key"] = self._openrouter_key_var.get().strip()
        save_config(self.config)
        self._refresh_ai_status_label()
        self._set_status("OpenRouter key saved", "ok", timeout=1800)

    def _save_compatible_provider(self):
        self.config["ai_compatible_base_url"] = self._compat_base_var.get().strip()
        self.config["ai_compatible_api_key"] = self._compat_key_var.get().strip()
        self.config["ai_compatible_model"] = self._compat_model_var.get().strip()
        save_config(self.config)
        self._refresh_ai_status_label()
        self._set_status("OpenAI-compatible provider saved", "ok", timeout=1800)

    def _on_autostart_toggled(self):
        """Toggle XDG autostart .desktop entry."""
        if self._autostart_var.get():
            enable_autostart()
        else:
            disable_autostart()
        self.config["autostart_on_boot"] = self._autostart_var.get()
        save_config(self.config)
        state = "enabled" if self._autostart_var.get() else "disabled"
        self._set_status(f"Autostart {state}", "ok", timeout=1800)

    def _save_vt_key(self):
        key = self._vt_key_var.get().strip()
        self.config["virustotal_api_key"] = key
        save_config(self.config)
        self._set_status("VirusTotal key saved", "ok", timeout=1800)

    def _save_gh_token(self):
        token = self._gh_token_var.get().strip()
        self.config["github_token"] = token
        save_config(self.config)
        if token:
            messagebox.showinfo("GitHub Token", "Token saved. Sysfix can now check for updates from your private repo.")
            self._set_status("GitHub token saved", "ok", timeout=1800)
        else:
            messagebox.showinfo("GitHub Token", "Token cleared.")
            self._set_status("GitHub token cleared", "info", timeout=1800)

    # ── Sysfix Pro — Upgrade / Licence Management ─────────────────────

    def _build_upgrade_section(self, parent):
        """Build the 'Sysfix Pro' upgrade card inside the Settings scrollable."""
        pro_valid = is_licence_valid()

        hdr = tk.Frame(parent, bg=self.glass_white)
        hdr.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(hdr, text="Sysfix Pro", font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg="#00BFFF").pack(side=tk.LEFT)
        if pro_valid:
            tk.Label(hdr, text="  ACTIVE", font=("Noto Sans", 9, "bold"),
                     bg=self.glass_white, fg=self.success_color).pack(side=tk.LEFT)
        tk.Frame(hdr, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))

        card = tk.Frame(parent, bg=self._mix_hex(self.glass_white, "#00BFFF", 0.92),
                        highlightbackground="#00BFFF", highlightthickness=1)
        card.pack(fill=tk.X, padx=20, pady=(0, 5))

        if pro_valid:
            # ── Already activated ──
            info = get_licence_info() or {}
            tk.Label(card, text="✓  All Pro features are unlocked.",
                     font=("Noto Sans", 10, "bold"),
                     bg=card["bg"], fg=self.success_color).pack(anchor="w", padx=16, pady=(12, 4))
            details = (f"Licence: {info.get('licence_key', 'N/A')}\n"
                       f"Activated: {info.get('activated_at', 'N/A')}\n"
                       f"Order: {info.get('order_id', 'N/A')}")
            tk.Label(card, text=details, font=("Noto Sans Mono", 8),
                     bg=card["bg"], fg=self.text_dim,
                     justify=tk.LEFT).pack(anchor="w", padx=16, pady=(0, 4))

            deact_row = tk.Frame(card, bg=card["bg"])
            deact_row.pack(anchor="w", padx=16, pady=(0, 12))
            self._make_button(deact_row, "Deactivate Licence", self._on_deactivate_pro,
                              bg=self.danger_color,
                              tooltip="Remove Pro licence (e.g. to transfer to another machine)"
                              ).pack(side=tk.LEFT)
        else:
            # ── Not yet purchased ──
            tk.Label(card, text="Unlock every feature in Sysfix",
                     font=("Noto Sans", 11, "bold"),
                     bg=card["bg"], fg=self.text_color).pack(anchor="w", padx=16, pady=(14, 2))
            tk.Label(card, text="One-time purchase  •  $15  •  No subscription",
                     font=("Noto Sans", 9),
                     bg=card["bg"], fg=self.text_dim).pack(anchor="w", padx=16, pady=(0, 6))

            features = [
                "🔓  Auto-kill malicious processes",
                "🔓  Quarantine & jail threats",
                "🔓  Freeze suspicious processes",
                "🔓  Deep eBPF sentinel features",
                "🔓  Priority AI diagnostics pipeline",
            ]
            for feat in features:
                tk.Label(card, text=feat, font=("Noto Sans", 9),
                         bg=card["bg"], fg=self.text_color).pack(anchor="w", padx=24)

            btn_row = tk.Frame(card, bg=card["bg"])
            btn_row.pack(fill=tk.X, padx=16, pady=(10, 6))
            self._make_button(btn_row, "Buy Sysfix Pro — $15", self._on_buy_pro,
                              bg="#00BFFF",
                              tooltip="Open checkout in your browser").pack(side=tk.LEFT, padx=(0, 10))
            self._make_button(btn_row, "I already have a key", self._on_activate_key,
                              bg=self.accent_color,
                              tooltip="Enter a licence key manually").pack(side=tk.LEFT)

            # Manual licence key entry
            key_row = tk.Frame(card, bg=card["bg"])
            key_row.pack(fill=tk.X, padx=16, pady=(0, 12))
            self._pro_key_var = tk.StringVar()
            key_entry = tk.Entry(
                key_row, textvariable=self._pro_key_var,
                font=("Noto Sans Mono", 10), bg=self.glass_white,
                fg=self.text_color, insertbackground=self.accent_color,
                relief="solid", bd=1, width=30,
            )
            key_entry.pack(side=tk.LEFT, padx=(0, 8), ipady=4)
            self._pro_key_entry = key_entry

            # Placeholder text rendered via the entry itself
            def _show_placeholder():
                if not self._pro_key_var.get():
                    key_entry.config(fg=self.text_dim)
                    key_entry.delete(0, tk.END)
                    key_entry.insert(0, "XXXXX-XXXXX-XXXXX-XXXXX-XXXXX")

            def _on_key_focus_in(_e):
                if key_entry.get() == "XXXXX-XXXXX-XXXXX-XXXXX-XXXXX":
                    key_entry.delete(0, tk.END)
                key_entry.config(fg=self.text_color)

            def _on_key_focus_out(_e):
                if not key_entry.get().strip():
                    _show_placeholder()

            key_entry.bind("<FocusIn>", _on_key_focus_in)
            key_entry.bind("<FocusOut>", _on_key_focus_out)
            _show_placeholder()

            self._make_button(key_row, "Activate", self._on_submit_licence_key,
                              bg=self.success_color,
                              tooltip="Validate and activate this licence key").pack(side=tk.LEFT)

    def _on_buy_pro(self):
        """Create a Polar checkout session, open it in the browser, and poll for payment."""
        self._set_status("Creating checkout session…", "info")

        def _create_and_open():
            try:
                session = create_checkout_session()
            except Exception as exc:
                # Fallback to static link if API call fails
                log.warning("create_checkout_session failed: %s — falling back to static link", exc)
                url = get_checkout_url()
                if url:
                    webbrowser.open(url)
                self.root.after(0, lambda: self._set_status(
                    f"Checkout opened (fallback) — verify manually", "warn", timeout=5000))
                return

            checkout_id = session["id"]
            checkout_url = session["url"]

            # Open the Polar-hosted checkout page
            webbrowser.open(checkout_url)

            # Show waiting dialog and start polling
            self.root.after(0, lambda: self._show_checkout_waiting(checkout_id))

        threading.Thread(target=_create_and_open, daemon=True).start()

    def _show_checkout_waiting(self, checkout_id: str):
        """Show a modal dialog while waiting for the user to complete payment."""
        dialog = tk.Toplevel(self.root)
        dialog.title("Waiting for Payment")
        dialog.geometry("420x220")
        dialog.resizable(False, False)
        dialog.configure(bg="#0a0a1a")
        dialog.transient(self.root)
        dialog.grab_set()
        self._checkout_dialog = dialog

        tk.Label(
            dialog, text="Complete your purchase\nin the browser",
            font=("Noto Sans", 14, "bold"), bg="#0a0a1a", fg="#ffffff",
            justify=tk.CENTER,
        ).pack(pady=(28, 8))

        self._checkout_status_label = tk.Label(
            dialog, text="Waiting for payment confirmation…",
            font=("Noto Sans", 10), bg="#0a0a1a", fg="#999999",
            justify=tk.CENTER, wraplength=360,
        )
        self._checkout_status_label.pack(pady=(0, 18))

        # Spinner dots animation
        self._checkout_dots = 0

        cancel_lbl = tk.Label(
            dialog, text="Cancel", font=("Noto Sans", 9, "underline"),
            bg="#0a0a1a", fg="#666666", cursor="hand2",
        )
        cancel_lbl.pack(side=tk.BOTTOM, pady=(0, 16))
        cancel_lbl.bind("<Button-1>", lambda _e: self._cancel_checkout_wait())

        self._set_status("Checkout opened — waiting for payment…", "info")
        # Start polling the Polar API for payment confirmation
        self._poll_checkout(checkout_id, 0)

    def _cancel_checkout_wait(self):
        """User cancelled the waiting dialog."""
        if hasattr(self, "_checkout_dialog") and self._checkout_dialog:
            try:
                self._checkout_dialog.destroy()
            except Exception:
                pass
            self._checkout_dialog = None
        self._set_status("Checkout cancelled", "info", timeout=3000)

    def _poll_checkout(self, checkout_id, attempt):
        """Poll Polar API to see if the checkout was completed (max ~5 min)."""
        if attempt > 60:
            # Timed out — close dialog and inform user
            if hasattr(self, "_checkout_dialog") and self._checkout_dialog:
                try:
                    self._checkout_dialog.destroy()
                except Exception:
                    pass
                self._checkout_dialog = None
            self._set_status(
                "Payment verification timed out — use a licence key if you already paid",
                "warn", timeout=8000)
            return

        def _check():
            try:
                result = verify_order_by_id(checkout_id)
                if result.get("activated"):
                    # Payment confirmed! Close dialog and celebrate
                    def _on_success():
                        if hasattr(self, "_checkout_dialog") and self._checkout_dialog:
                            try:
                                self._checkout_dialog.destroy()
                            except Exception:
                                pass
                            self._checkout_dialog = None
                        self._on_pro_activated(result.get("licence", {}))
                    self.root.after(0, _on_success)
                    return
            except Exception:
                pass

            # Update waiting dialog dots animation
            def _update_dots():
                if hasattr(self, "_checkout_status_label") and self._checkout_status_label:
                    self._checkout_dots = (getattr(self, "_checkout_dots", 0) + 1) % 4
                    dots = "." * (self._checkout_dots + 1)
                    try:
                        self._checkout_status_label.config(
                            text=f"Waiting for payment confirmation{dots}")
                    except Exception:
                        pass
            self.root.after(0, _update_dots)

            # Not yet — retry in 5 seconds
            self.root.after(5000, lambda: self._poll_checkout(checkout_id, attempt + 1))

        threading.Thread(target=_check, daemon=True).start()

    def _on_activate_key(self):
        """Focus the licence key entry field."""
        if hasattr(self, "_pro_key_var"):
            # Scroll the settings tab so the key entry is visible
            self._set_status("Enter your licence key below and click Activate", "info", timeout=3000)

    def _on_submit_licence_key(self):
        """Validate and activate a manually entered licence key."""
        raw = self._pro_key_var.get().strip().upper() if hasattr(self, "_pro_key_var") else ""
        # Ignore placeholder text
        if not raw or raw == "XXXXX-XXXXX-XXXXX-XXXXX-XXXXX":
            self._set_status("Please enter a licence key", "error", timeout=2000)
            return

        self._set_status("Validating licence key…", "info")

        def _verify():
            try:
                activated = verify_order_by_key(raw)
                if activated:
                    licence = get_licence_info() or {}
                    self.root.after(0, lambda: self._on_pro_activated(licence))
                else:
                    self.root.after(0, lambda: self._set_status(
                        "Activation failed: invalid key format (expected XXXXX-XXXXX-XXXXX-XXXXX-XXXXX)",
                        "error", timeout=4000))
            except Exception as exc:
                self.root.after(0, lambda: self._set_status(
                    f"Activation error: {exc}", "error", timeout=4000))

        threading.Thread(target=_verify, daemon=True).start()

    def _on_deactivate_pro(self):
        """Deactivate the local Pro licence after confirmation."""
        if not messagebox.askyesno(
            "Deactivate Sysfix Pro",
            "This will remove your Pro licence from this machine.\n\n"
            "You can re-activate later with your licence key or\n"
            "transfer it to another machine.\n\nContinue?",
        ):
            return
        deactivate_premium()
        self.config = load_config()
        self._update_pro_badge()
        self._rebuild_ui()
        self._set_status("Pro licence deactivated", "info", timeout=3000)

    def _on_pro_activated(self, licence_info):
        """Called when Pro is successfully activated — show badge + confetti."""
        # Clear any pending checkout
        self.config.pop("_pending_checkout_id", None)
        self.config = load_config()

        # Show the PRO badge
        self._update_pro_badge()

        # Show confetti celebration
        self._show_pro_confetti(licence_info)

        self._set_status("🎉 Sysfix Pro activated!", "ok", timeout=5000)

    def _update_pro_badge(self):
        """Show or hide the PRO badge next to the title and update window title."""
        if not hasattr(self, "_pro_badge"):
            return
        if is_licence_valid():
            self._pro_badge.pack(side=tk.LEFT, padx=(8, 0), pady=(4, 0))
            self.root.title("Sysfix Pro — Diagnostics \u2022 Security \u2022 AI Repair")
        else:
            self._pro_badge.pack_forget()
            self.root.title("Sysfix — Diagnostics \u2022 Security \u2022 AI Repair")

    def _show_pro_confetti(self, licence_info=None):
        """Show a celebratory thank-you dialog with confetti animation."""
        dialog = tk.Toplevel(self.root)
        dialog.title("Sysfix Pro — Activated!")
        dialog.geometry("520x420")
        dialog.resizable(False, False)
        dialog.configure(bg="#0a0a1a")
        dialog.transient(self.root)
        dialog.grab_set()

        # Centre on parent
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - 520) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 420) // 2
        dialog.geometry(f"+{x}+{y}")

        # Canvas for confetti
        canvas = tk.Canvas(dialog, width=520, height=420, bg="#0a0a1a",
                           highlightthickness=0, bd=0)
        canvas.pack(fill=tk.BOTH, expand=True)

        # Draw text content on top of canvas
        canvas.create_text(260, 80, text="🎉", font=("Noto Sans", 40), fill="#ffffff")
        canvas.create_text(260, 140, text="Thank You!",
                           font=("Noto Sans", 22, "bold"), fill="#ffffff")
        canvas.create_text(260, 175, text="Sysfix Pro is now active",
                           font=("Noto Sans", 12), fill="#00BFFF")
        canvas.create_text(260, 210, text="All features have been unlocked.",
                           font=("Noto Sans", 10), fill="#aaaaaa")

        if licence_info:
            key = licence_info.get("licence_key", "")
            if key:
                canvas.create_text(260, 260, text="Your licence key:",
                                   font=("Noto Sans", 9), fill="#666666")
                canvas.create_text(260, 282, text=key,
                                   font=("Noto Sans Mono", 11, "bold"), fill="#00BFFF")

                def _copy_key():
                    dialog.clipboard_clear()
                    dialog.clipboard_append(key)
                    copy_btn.config(text="Copied!", bg="#2ecc71")
                    dialog.after(2000, lambda: copy_btn.config(text="Copy Key", bg="#333333")
                                 if dialog.winfo_exists() else None)

                copy_btn = tk.Button(
                    dialog, text="Copy Key", font=("Noto Sans", 9, "bold"),
                    bg="#333333", fg="#ffffff", relief="flat", bd=0,
                    padx=12, pady=4, cursor="hand2",
                    command=_copy_key,
                )
                canvas.create_window(260, 315, window=copy_btn)

        # Close button
        close_btn = tk.Button(
            dialog, text="Let's Go!", font=("Noto Sans", 11, "bold"),
            bg="#00BFFF", fg="#ffffff", relief="flat", bd=0,
            padx=20, pady=8, cursor="hand2",
            command=dialog.destroy,
        )
        canvas.create_window(260, 370, window=close_btn)

        # ── Confetti particles ──
        confetti_colors = [
            "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7",
            "#DDA0DD", "#98FB98", "#FF69B4", "#00BFFF", "#FFD700",
            "#FF4500", "#7B68EE", "#00FA9A", "#FF1493", "#1E90FF",
        ]
        particles = []
        for _ in range(80):
            px = random.randint(0, 520)
            py = random.randint(-420, -10)
            size = random.randint(4, 10)
            color = random.choice(confetti_colors)
            speed_y = random.uniform(1.5, 4.0)
            speed_x = random.uniform(-1.5, 1.5)
            wobble = random.uniform(0.02, 0.08)
            shape = random.choice(["rect", "oval"])
            if shape == "rect":
                cid = canvas.create_rectangle(px, py, px + size, py + size * 0.5,
                                              fill=color, outline="")
            else:
                cid = canvas.create_oval(px, py, px + size, py + size,
                                         fill=color, outline="")
            particles.append({
                "id": cid, "x": float(px), "y": float(py),
                "vx": speed_x, "vy": speed_y, "wobble": wobble, "tick": 0,
            })

        def _animate_confetti():
            if not dialog.winfo_exists():
                return
            for p in particles:
                p["tick"] += 1
                p["x"] += p["vx"] + math.sin(p["tick"] * p["wobble"]) * 0.8
                p["y"] += p["vy"]
                if p["y"] > 440:
                    p["y"] = random.randint(-50, -10)
                    p["x"] = random.randint(0, 520)
                canvas.coords(p["id"], p["x"], p["y"],
                              p["x"] + 6, p["y"] + 4)
            dialog.after(30, _animate_confetti)

        _animate_confetti()

    def _check_pro_on_startup(self):
        """Check for pending checkout or existing licence on startup."""
        # If there's a pending checkout ID from a previous session, try verifying it
        pending_id = self.config.get("_pending_checkout_id", "")
        if pending_id:
            def _verify():
                try:
                    result = verify_order_by_id(pending_id)
                    if result.get("activated"):
                        self.root.after(0, lambda: self._on_pro_activated(result.get("licence", {})))
                except Exception:
                    pass  # Silently fail — user can always activate manually
            threading.Thread(target=_verify, daemon=True).start()
        elif is_licence_valid():
            # Already pro — just make sure badge is visible
            self.root.after(100, self._update_pro_badge)

    def _add_settings_section(self, parent, section_title, settings_list):
        frame = tk.Frame(parent, bg=self.glass_white)
        frame.pack(fill=tk.X, padx=15, pady=(15, 8))
        tk.Label(frame, text=section_title, font=("Noto Sans", 10, "bold"),
                 bg=self.glass_white, fg=self.accent_color).pack(anchor="w")
        tk.Frame(frame, bg=self.border_color, height=1).pack(fill=tk.X, pady=(6, 0))
        for key, label, desc in settings_list:
            self._add_setting_checkbox(parent, key, label, desc)

    def _add_setting_checkbox(self, parent, key, label, description):
        f = tk.Frame(parent, bg=self.glass_white)
        f.pack(fill=tk.X, padx=20, pady=5)
        var = tk.BooleanVar(value=self.config.get(key, False))
        self.settings_vars[key] = var
        tk.Checkbutton(
            f, text=label, variable=var,
            command=lambda: self._on_setting_changed(key, var),
            font=("Noto Sans", 9), bg=self.glass_white, fg=self.text_color,
            activebackground=self.glass_white, activeforeground=self.accent_color,
            selectcolor=self.glass_white, highlightthickness=0,
        ).pack(anchor="w", pady=(0, 1))
        tk.Label(f, text=description, font=("Noto Sans", 8),
                 bg=self.glass_white, fg=self.text_dim).pack(anchor="w", padx=(20, 0))

    def _on_setting_changed(self, key, var):
        self.config[key] = var.get()
        save_config(self.config)
        if key in ("enable_brain", "brain_learn_conversations"):
            if self._chat_memory_enabled():
                self._persist_conversations()
            else:
                try:
                    delete_cache(self._CHAT_CACHE_KEY)
                except Exception:
                    pass
            # keep in-memory threads usable, only persistence changes
        if key in ("ai_fallback_free", "enable_ai_features", "enable_web_search"):
            self._refresh_ai_status_label()
        if key == "auto_check_updates_on_startup" and not var.get():
            self._hide_update_banner()
        self._set_status(f"Saved: {key}", "ok", timeout=1300)

    def reset_settings(self):
        if messagebox.askyesno("Reset Settings", "Reset all settings to defaults?"):
            from sysfixai.config import DEFAULT_CONFIG
            self.config = DEFAULT_CONFIG.copy()
            save_config(self.config)
            for key, var in self.settings_vars.items():
                var.set(self.config.get(key, False))
            messagebox.showinfo("Done", "Settings reset to defaults.")

    # ── Status bar ──────────────────────────────────────────────────────

    def create_status_bar(self):
        bar = tk.Frame(self.root, bg=self.glass_white, height=30)
        bar.pack(side=tk.BOTTOM, fill=tk.X)
        bar.pack_propagate(False)

        # Thin top border
        tk.Frame(bar, bg=self.border_color, height=1).pack(side=tk.TOP, fill=tk.X)

        inner = tk.Frame(bar, bg=self.glass_white)
        inner.pack(fill=tk.BOTH, expand=True, padx=12)

        lbl_style = dict(font=("Noto Sans", 9), bg=self.glass_white, padx=8)

        self._sb_cpu  = tk.Label(inner, text="CPU: --", fg=self.text_dim, **lbl_style)
        self._sb_cpu.pack(side=tk.LEFT)
        self._sb_ram  = tk.Label(inner, text="RAM: --", fg=self.text_dim, **lbl_style)
        self._sb_ram.pack(side=tk.LEFT)
        self._sb_temp = tk.Label(inner, text="Temp: --", fg=self.text_dim, **lbl_style)
        self._sb_temp.pack(side=tk.LEFT)
        self._sb_disk = tk.Label(inner, text="Disk: --", fg=self.text_dim, **lbl_style)
        self._sb_disk.pack(side=tk.LEFT)
        self._sb_gpu = tk.Label(inner, text="GPU: --", fg=self.text_dim, **lbl_style)
        self._sb_gpu.pack(side=tk.LEFT)

        # Right side: copyright watermark
        tk.Label(inner, text="\u00a9 2026 useofscript",
                 font=("Noto Sans", 8), bg=self.glass_white,
                 fg=self.text_dim).pack(side=tk.RIGHT, padx=(8, 0))
        # Shortcuts hint
        tk.Label(inner, text="Ctrl+1..7 Tabs  |  Ctrl+D Scan  |  Ctrl+L Clear",
                 font=("Noto Sans", 8), bg=self.glass_white,
                 fg=self.text_dim).pack(side=tk.RIGHT)
        self._sb_status = tk.Label(
            inner, text="Ready", font=("Noto Sans", 8),
            bg=self.glass_white, fg=self.text_dim, padx=8,
        )
        self._sb_status.pack(side=tk.RIGHT)
        self._sb_busy = ttk.Progressbar(inner, mode="indeterminate", length=80)
        self._sb_busy.pack(side=tk.RIGHT, padx=(0, 6))

    def _start_live_stats(self):
        if self._stats_after_id:
            try:
                self.root.after_cancel(self._stats_after_id)
            except Exception:
                pass
            self._stats_after_id = None
        self._start_gauge_animation()
        self._update_live_stats()

    def _update_live_stats(self):
        """Periodically update status bar and dashboard gauges."""
        gauges = self._get_gauge_data() if HAS_PSUTIL else []
        if gauges:
            self._set_gauge_targets(gauges)
            gmap = {name: (value, max_val, color) for name, value, max_val, color in gauges}
            if "CPU" in gmap:
                cpu, _m, clr = gmap["CPU"]
                self._sb_cpu.config(text=f"CPU: {cpu:.0f}%", fg=clr)
            if "RAM" in gmap:
                ram, _m, clr = gmap["RAM"]
                self._sb_ram.config(text=f"RAM: {ram:.0f}%", fg=clr)
            if "Disk" in gmap:
                disk, _m, clr = gmap["Disk"]
                self._sb_disk.config(text=f"Disk: {disk:.0f}%", fg=clr)
            if "Temp" in gmap:
                temp, _m, clr = gmap["Temp"]
                self._sb_temp.config(text=f"Temp: {temp:.0f}C", fg=clr)
            if "GPU" in gmap:
                gpu, _m, clr = gmap["GPU"]
                gpu_temp = gmap.get("GPU T", (0, 110, clr))[0]
                self._sb_gpu.config(text=f"GPU: {gpu:.0f}% {gpu_temp:.0f}C", fg=clr)
            else:
                self._sb_gpu.config(text="GPU: --", fg=self.text_dim)

        # Refresh AI status
        try:
            self._refresh_ai_status_label()
        except Exception:
            pass

        self._stats_after_id = self.root.after(3000, self._update_live_stats)

    # ── Text widget helpers ─────────────────────────────────────────────

    def update_text(self, widget, message):
        def _do():
            widget.config(state=tk.NORMAL)
            widget.delete(1.0, tk.END)
            widget.insert(tk.END, message)
            widget.config(state=tk.DISABLED)
        self._safe(_do)

    def check_initial_status(self):
        self.update_text(self.dashboard_text, "Checking system status...")
        self._set_status("Running diagnostics", "working")
        self._run_threaded(self.scan_issues)

    # ── Diagnostics ─────────────────────────────────────────────────────

    def scan_issues(self):
        try:
            issues = diagnose()
            categorized = categorize_issues(issues)

            problems = categorized.get("problems", [])
            warnings = categorized.get("warnings", [])
            info_items = categorized.get("info", [])

            def _paint():
                w = self.dashboard_text
                w.config(state=tk.NORMAL)
                w.delete(1.0, tk.END)

                w.insert(tk.END, "SYSTEM DIAGNOSTICS\n", "heading")
                w.insert(tk.END, "=" * 50 + "\n\n")

                total = len(issues)
                w.insert(tk.END, f"Total items: {total}   ")
                w.insert(tk.END, f"Problems: {len(problems)}   ", "err" if problems else "ok")
                w.insert(tk.END, f"Warnings: {len(warnings)}  ", "warn" if warnings else "ok")
                w.insert(tk.END, f"Info: {len(info_items)}\n\n")

                if problems:
                    w.insert(tk.END, f"PROBLEMS ({len(problems)})\n", "err")
                    w.insert(tk.END, "-" * 50 + "\n")
                    for i, p in enumerate(problems, 1):
                        w.insert(tk.END, f"  {i}. {p}\n", "err")
                    w.insert(tk.END, "\n")

                if warnings:
                    w.insert(tk.END, f"WARNINGS ({len(warnings)})\n", "warn")
                    w.insert(tk.END, "-" * 50 + "\n")
                    for i, wr in enumerate(warnings, 1):
                        w.insert(tk.END, f"  {i}. {wr}\n", "warn")
                    w.insert(tk.END, "\n")

                if info_items:
                    w.insert(tk.END, f"INFO ({len(info_items)})\n", "heading")
                    w.insert(tk.END, "-" * 50 + "\n")
                    for i, inf in enumerate(info_items, 1):
                        w.insert(tk.END, f"  {i}. {inf}\n")
                    w.insert(tk.END, "\n")

                if not problems and not warnings:
                    w.insert(tk.END, "System is healthy!\n", "ok")

                w.config(state=tk.DISABLED)

            self._safe(_paint)
        except Exception as e:
            self.update_text(self.dashboard_text, f"Error: {e}")

    # ── Quick-fix actions ───────────────────────────────────────────────

    def fast_sweep(self):
        out = "FAST SWEEP — Quick System Optimization\n" + "=" * 50 + "\n\n"
        out += "1. Scanning system...\n"
        try:
            issues = diagnose()
            if not issues or issues == ["No issues detected."]:
                out += "\nSystem is already optimized!\n"
            else:
                out += f"\n   Found {len(issues)} items\n"
                out += "2. Applying quick fixes...\n\n"
                if not self.is_sudo:
                    out += "   Limited to non-destructive fixes (no sudo)\n"
                    out += "   Run 'sudo sysfix gui' for full capability\n"
                else:
                    out += "   Using all available fixes\n"
                out += "\n3. Complete.\n"
            self.update_text(self.fix_text, out)
        except Exception as e:
            self.update_text(self.fix_text, f"Error: {e}")

    def apply_fixes(self):
        if not self.is_sudo:
            self._safe(lambda: messagebox.showwarning("Permission Denied",
                       "Auto-Fix requires elevated privileges.\nRun: sudo sysfix gui"))
            return
        if not self.config.get("enable_ai_features", True):
            self._safe(lambda: messagebox.showwarning("AI Disabled",
                       "Enable AI features in Settings first."))
            return
        ai_state = get_ai_runtime_status()
        if not ai_state.get("online"):
            detail = ai_state.get("detail", "No AI provider available.")
            self._safe(lambda: messagebox.showwarning("AI Offline", detail))
            return
        self.update_text(self.fix_text, "Running AI Auto-Fix...\nPlease wait...")
        try:
            issues = diagnose()
            if not issues or issues == ["No issues detected."]:
                self._safe(lambda: messagebox.showinfo("Healthy", "System is already healthy!"))
                self.update_text(self.fix_text, "System is already healthy — no fixes needed.")
                return
            # Use AI to analyse issues and suggest fixes (GUI-safe — no input() calls)
            ctx = get_system_snapshot()
            summary = "\n".join(f"  {i+1}. {iss}" for i, iss in enumerate(issues))
            prompt = (
                f"I found {len(issues)} issue(s) on this system:\n{summary}\n\n"
                "For each issue, give me a concise fix with the exact command(s) to run. "
                "Use numbered steps. Only suggest safe, non-destructive fixes."
            )
            response = get_deep_dive(prompt, gui_mode=True, system_context=ctx)
            out = f"AI AUTO-FIX ANALYSIS\n{'=' * 50}\n\n"
            out += f"Found {len(issues)} issue(s):\n{summary}\n\n"
            out += f"{'=' * 50}\nAI RECOMMENDATIONS:\n{'=' * 50}\n\n"
            out += response
            out += "\n\nTip: Fyxa now shows an in-chat approval card (Accept / Deny / Auto-Accept) before running commands."
            self.update_text(self.fix_text, out)
        except Exception as e:
            self.update_text(self.fix_text, f"Error: {e}")

    def optimize_memory(self):
        out = "MEMORY OPTIMIZATION\n" + "=" * 50 + "\n\n"
        try:
            if HAS_PSUTIL:
                mem = psutil.virtual_memory()
                out += f"Total : {mem.total / (1024**3):.1f} GB\n"
                out += f"Used  : {mem.used / (1024**3):.1f} GB ({mem.percent}%)\n"
                out += f"Avail : {mem.available / (1024**3):.1f} GB\n\n"
                out += "Top memory consumers:\n"
                top = sorted(psutil.process_iter(["name", "memory_percent"]),
                             key=lambda p: p.info.get("memory_percent", 0) or 0,
                             reverse=True)[:10]
                for i, p in enumerate(top, 1):
                    name = p.info.get("name", "?")
                    pct = p.info.get("memory_percent", 0) or 0
                    out += f"  {i:2d}. {name:<25s}  {pct:.1f}%\n"
            else:
                out += "psutil not available\n"
            self.update_text(self.fix_text, out)
        except Exception as e:
            self.update_text(self.fix_text, f"Error: {e}")

    def cleanup_disk(self):
        out = "DISK USAGE\n" + "=" * 50 + "\n\n"
        try:
            import shutil
            disk = shutil.disk_usage("/")
            out += f"Total : {disk.total / (1024**3):.1f} GB\n"
            out += f"Used  : {disk.used / (1024**3):.1f} GB\n"
            out += f"Free  : {disk.free / (1024**3):.1f} GB\n\n"

            # Check common large directories
            home = Path.home()
            out += "Large directories in home:\n"
            for d in sorted(home.iterdir()):
                if d.is_dir() and not d.name.startswith("."):
                    try:
                        size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) / (1024 ** 3)
                        if size > 0.5:
                            out += f"  {d.name:<30s}  {size:.1f} GB\n"
                    except (PermissionError, OSError):
                        pass

            self.update_text(self.fix_text, out)
        except Exception as e:
            self.update_text(self.fix_text, f"Error: {e}")

    # ── Conversation threads ────────────────────────────────────────────

    def _chat_memory_enabled(self):
        return bool(
            self.config.get("enable_brain", True)
            and self.config.get("brain_learn_conversations", True)
        )

    def _default_chat_welcome(self):
        return (
            "Hey! I'm Fyxa, your system engineer with web search.\n\n"
            "I can see your live system stats, diagnose issues, search for solutions online, "
            "and run commands for you. Ask me anything about your setup.\n\n"
            "Try: \"what are my specs?\" or \"how's my system doing?\""
        )

    def _sanitize_chat_messages(self, messages):
        clean = []
        for msg in (messages or []):
            if not isinstance(msg, dict):
                continue
            role = msg.get("role")
            content = str(msg.get("content", "")).strip()
            if role in ("user", "assistant") and content:
                clean.append({"role": role, "content": content[:5000]})
        return clean[-self._MAX_CHAT_MESSAGES:]

    def _make_chat_title(self, text):
        base = re.sub(r"\s+", " ", text or "").strip()
        if not base:
            return "New Chat"
        return (base[:42] + "...") if len(base) > 42 else base

    def _touch_chat(self, chat_id):
        if chat_id in self._conversation_order:
            self._conversation_order.remove(chat_id)
        self._conversation_order.insert(0, chat_id)

    def _ensure_chat_exists(self):
        if self._conversations:
            return
        chat_id = uuid4().hex[:10]
        self._conversations[chat_id] = {
            "title": "New Chat",
            "messages": [],
            "last_response": "",
            "updated_at": datetime.now().isoformat(timespec="seconds"),
        }
        self._conversation_order = [chat_id]
        self._active_chat_id = chat_id
        self.chat_history = self._conversations[chat_id]["messages"]
        self._last_ai_response = ""

    def _init_conversations(self):
        self._conversations = {}
        self._conversation_order = []
        self._active_chat_id = None
        loaded = {}

        if self._chat_memory_enabled():
            try:
                entry = get_cache(self._CHAT_CACHE_KEY) or {}
                if isinstance(entry, dict):
                    loaded = entry.get("value") or {}
            except Exception:
                loaded = {}

        if isinstance(loaded, dict):
            raw_threads = loaded.get("threads", {})
            raw_order = loaded.get("order", [])
            if isinstance(raw_threads, dict):
                for chat_id, raw in raw_threads.items():
                    if not isinstance(chat_id, str) or not isinstance(raw, dict):
                        continue
                    title = str(raw.get("title", "New Chat")).strip() or "New Chat"
                    msgs = self._sanitize_chat_messages(raw.get("messages", []))
                    last = str(raw.get("last_response", ""))[:5000]
                    self._conversations[chat_id] = {
                        "title": title[:80],
                        "messages": msgs,
                        "last_response": last,
                        "updated_at": str(raw.get("updated_at", "")),
                    }

            if isinstance(raw_order, list):
                self._conversation_order = [
                    cid for cid in raw_order if isinstance(cid, str) and cid in self._conversations
                ]
            for cid in self._conversations.keys():
                if cid not in self._conversation_order:
                    self._conversation_order.append(cid)

            if len(self._conversation_order) > self._MAX_CHAT_THREADS:
                keep = set(self._conversation_order[:self._MAX_CHAT_THREADS])
                self._conversation_order = self._conversation_order[:self._MAX_CHAT_THREADS]
                self._conversations = {
                    cid: data for cid, data in self._conversations.items() if cid in keep
                }

            active = loaded.get("active")
            if isinstance(active, str) and active in self._conversations:
                self._active_chat_id = active

        self._ensure_chat_exists()
        if self._active_chat_id not in self._conversations:
            self._active_chat_id = self._conversation_order[0]
        self.chat_history = self._conversations[self._active_chat_id]["messages"]
        self._last_ai_response = self._conversations[self._active_chat_id].get("last_response", "")

    def _persist_conversations(self):
        if not self._chat_memory_enabled():
            try:
                delete_cache(self._CHAT_CACHE_KEY)
            except Exception:
                pass
            return

        payload_threads = {}
        for chat_id in self._conversation_order[:self._MAX_CHAT_THREADS]:
            chat = self._conversations.get(chat_id)
            if not chat:
                continue
            payload_threads[chat_id] = {
                "title": str(chat.get("title", "New Chat"))[:80],
                "messages": self._sanitize_chat_messages(chat.get("messages", [])),
                "last_response": str(chat.get("last_response", ""))[:5000],
                "updated_at": str(chat.get("updated_at", "")),
            }
        payload = {
            "active": self._active_chat_id,
            "order": [cid for cid in self._conversation_order if cid in payload_threads],
            "threads": payload_threads,
        }
        try:
            set_cache(self._CHAT_CACHE_KEY, payload, metadata={"kind": "gui_threads", "v": 1})
        except Exception:
            pass

    def _refresh_chat_selector(self):
        labels = []
        label_map = {}
        for i, cid in enumerate(self._conversation_order, 1):
            chat = self._conversations.get(cid, {})
            title = str(chat.get("title", "New Chat")).strip() or "New Chat"
            label = f"{i}. {title}"
            labels.append(label)
            label_map[label] = cid
        self._chat_selector_labels = label_map
        active_label = ""
        active_index = 0
        for idx, (label, cid) in enumerate(label_map.items()):
            if cid == self._active_chat_id:
                active_label = label
                active_index = idx
                break

        if self._chat_selector and self._chat_selector_var:
            self._chat_selector["values"] = labels
            self._chat_selector_var.set(active_label if active_label else (labels[0] if labels else ""))

        if self._chat_listbox:
            self._suspend_chat_select_events = True
            self._chat_listbox.delete(0, tk.END)
            for label in labels:
                self._chat_listbox.insert(tk.END, label)
            if labels:
                self._chat_listbox.selection_clear(0, tk.END)
                self._chat_listbox.selection_set(active_index)
                self._chat_listbox.activate(active_index)
                self._chat_listbox.see(active_index)
            self._suspend_chat_select_events = False

    def _set_active_chat(self, chat_id, render=True):
        if chat_id not in self._conversations:
            return
        self._active_chat_id = chat_id
        chat = self._conversations[chat_id]
        self.chat_history = chat.get("messages", [])
        self._last_ai_response = chat.get("last_response", "")
        self._refresh_chat_selector()
        if render:
            self._render_active_conversation()

    def _render_active_conversation(self):
        if not hasattr(self, "chat_display"):
            return

        def _clear():
            self.chat_display.config(state=tk.NORMAL)
            self.chat_display.delete(1.0, tk.END)
            self.chat_display.config(state=tk.DISABLED)

        self._safe(_clear)
        self._command_request_widgets = {}
        self._revert_widgets = {}
        messages = list(self.chat_history)
        if not messages:
            self.add_chat_message("Fyxa", self._default_chat_welcome(), is_user=False)
            self._safe(lambda cid=self._active_chat_id: self._render_pending_command_cards(cid))
            self._safe(lambda cid=self._active_chat_id: self._render_revert_card_for_chat(cid))
            return
        for msg in messages:
            if msg.get("role") == "user":
                self.add_chat_message("You", msg.get("content", ""), is_user=True)
            else:
                self.add_chat_message("Fyxa", msg.get("content", ""), is_user=False)
        self._safe(lambda cid=self._active_chat_id: self._render_pending_command_cards(cid))
        self._safe(lambda cid=self._active_chat_id: self._render_revert_card_for_chat(cid))

    def _append_chat_message(self, chat_id, role, content, track_last_response=True):
        if chat_id not in self._conversations:
            return
        chat = self._conversations[chat_id]
        msgs = chat.setdefault("messages", [])
        msgs.append({"role": role, "content": content})
        if len(msgs) > self._MAX_CHAT_MESSAGES:
            chat["messages"] = msgs[-self._MAX_CHAT_MESSAGES:]
            msgs = chat["messages"]
        if role == "assistant" and track_last_response:
            chat["last_response"] = content[:5000]
        chat["updated_at"] = datetime.now().isoformat(timespec="seconds")
        self._touch_chat(chat_id)

        if chat_id == self._active_chat_id:
            self.chat_history = msgs
            if role == "assistant" and track_last_response:
                self._last_ai_response = content[:5000]

    def _post_assistant_message(self, message, chat_id=None, track_last_response=False):
        target_chat = chat_id or self._active_chat_id
        if not target_chat:
            return
        is_active = (target_chat == self._active_chat_id)
        if is_active:
            self.add_chat_message("Fyxa", message, is_user=False)
        with self._conversation_lock:
            self._append_chat_message(
                target_chat, "assistant", message, track_last_response=track_last_response
            )
            self._persist_conversations()

    def _latest_pending_request_id(self, chat_id=None):
        target_chat = chat_id or self._active_chat_id
        for rid in reversed(self._pending_command_order):
            req = self._pending_command_requests.get(rid)
            if not req:
                continue
            if req.get("status") != "pending":
                continue
            if req.get("chat_id") == target_chat:
                return rid
        return None

    def _drop_command_request(self, request_id):
        self._pending_command_requests.pop(request_id, None)
        self._pending_command_order = [r for r in self._pending_command_order if r != request_id]
        w = self._command_request_widgets.pop(request_id, None)
        try:
            if w and w.winfo_exists():
                w.destroy()
        except Exception:
            pass

    def _queue_command_request(self, commands, chat_id=None, source="fyxa"):
        target_chat = chat_id or self._active_chat_id
        if not target_chat:
            return None

        valid, invalid = self._validate_commands(commands)
        if invalid:
            bad = "\n".join(f"  - {c}" for c in invalid[:12])
            msg = f"Filtered out {len(invalid)} command(s) not available on this system:\n{bad}"
            if len(invalid) > 12:
                msg += f"\n  ... and {len(invalid) - 12} more"
            self._post_assistant_message(msg, target_chat, track_last_response=False)

        if not valid:
            self._post_assistant_message(
                "I couldn't find runnable commands for this step on your system.",
                target_chat,
                track_last_response=False,
            )
            return None

        # ── Safety Intercept gate ─────────────────────────────────────────
        try:
            overall, confidence, risk_level, notes = classify_commands(valid)
        except Exception:
            overall, confidence, risk_level, notes = "needs_confirm", 50, "medium", []

        if overall == "blocked":
            blocked_msg = (
                "🛡 **Safety Intercept — BLOCKED**\n"
                f"Confidence: {confidence}%  |  Risk: {risk_level}\n"
            )
            if notes:
                blocked_msg += "\n".join(f"  ⚠ {n}" for n in notes[:8])
            blocked_msg += "\n\nThese commands were blocked by the Safety Intercept for your protection."
            self._post_assistant_message(blocked_msg, target_chat, track_last_response=False)
            return None

        req_id = uuid4().hex[:10]
        request = {
            "id": req_id,
            "chat_id": target_chat,
            "commands": list(valid),
            "status": "pending",
            "source": source,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "safety_classification": overall,
            "safety_confidence": confidence,
            "safety_risk": risk_level,
            "safety_notes": notes,
        }
        self._pending_command_requests[req_id] = request
        self._pending_command_order.append(req_id)

        # Build safety-aware message
        risk_icons = {"low": "🟢", "medium": "🟡", "high": "🟠", "critical": "🔴"}
        risk_icon = risk_icons.get(risk_level, "⚪")
        safety_msg = (
            f"Fyxa wants to execute {len(valid)} command(s). "
            f"{risk_icon} Safety: {overall.upper()} ({confidence}% confidence, {risk_level} risk)\n"
            "Review and choose: Accept, Deny, or Auto-Accept."
        )
        if notes and overall == "needs_confirm":
            safety_msg += "\n" + "\n".join(f"  ⚠ {n}" for n in notes[:4])
        self._post_assistant_message(safety_msg, target_chat, track_last_response=False)

        if target_chat == self._active_chat_id:
            self._safe(lambda rid=req_id: self._insert_command_approval_card(rid))

        if self._command_auto_accept:
            self._safe(lambda rid=req_id: self._approve_command_request(rid, auto_trigger=True))
        return req_id

    def _render_pending_command_cards(self, chat_id):
        for rid in self._pending_command_order:
            req = self._pending_command_requests.get(rid)
            if not req:
                continue
            if req.get("status") != "pending":
                continue
            if req.get("chat_id") != chat_id:
                continue
            self._insert_command_approval_card(rid)

    def _insert_command_approval_card(self, request_id):
        req = self._pending_command_requests.get(request_id)
        if not req or req.get("status") != "pending":
            return
        if req.get("chat_id") != self._active_chat_id:
            return
        if request_id in self._command_request_widgets:
            w = self._command_request_widgets.get(request_id)
            try:
                if w and w.winfo_exists():
                    return
            except Exception:
                pass

        d = self.chat_display
        d.config(state=tk.NORMAL)

        outer = tk.Frame(
            d,
            bg=self.border_color,
            highlightthickness=1,
            highlightbackground=self.accent_secondary,
        )
        inner = tk.Frame(outer, bg=self.glass_white)
        inner.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        head = tk.Frame(inner, bg=self.glass_tint)
        head.pack(fill=tk.X)
        tk.Label(
            head,
            text="Execution Request",
            font=("Noto Sans", 9, "bold"),
            bg=self.glass_tint,
            fg=self.accent_secondary,
            padx=8,
            pady=5,
        ).pack(side=tk.LEFT)
        tk.Label(
            head,
            text=f"{len(req.get('commands', []))} command(s)",
            font=("Noto Sans", 8),
            bg=self.glass_tint,
            fg=self.text_dim,
            padx=8,
        ).pack(side=tk.RIGHT)

        body = tk.Text(
            inner,
            height=min(max(len(req.get("commands", [])), 2), 8),
            wrap=tk.WORD,
            font=("Noto Sans Mono", 9),
            bg=self.glass_white,
            fg=self.text_color,
            relief="flat",
            borderwidth=0,
            padx=10,
            pady=8,
            highlightthickness=0,
        )
        body.pack(fill=tk.BOTH, expand=True)
        for cmd in req.get("commands", []):
            body.insert(tk.END, f"$ {cmd}\n")
        body.config(state=tk.DISABLED)
        SmoothScroller.bind_smooth_scroll(body)

        btn_row = tk.Frame(inner, bg=self.glass_white)
        btn_row.pack(fill=tk.X, padx=8, pady=(0, 8))

        self._make_button(
            btn_row,
            "Accept",
            lambda rid=request_id: self._approve_command_request(rid),
            bg=self.success_color,
            tooltip="Approve and execute these commands",
            font=("Noto Sans", 8, "bold"),
            padx=10,
            pady=5,
        ).pack(side=tk.LEFT, padx=(0, 6))
        self._make_button(
            btn_row,
            "Deny",
            lambda rid=request_id: self._deny_command_request(rid),
            bg=self.danger_color,
            tooltip="Reject this execution request",
            font=("Noto Sans", 8, "bold"),
            padx=10,
            pady=5,
        ).pack(side=tk.LEFT, padx=(0, 6))

        auto_label = "Auto-Accept: ON" if self._command_auto_accept else "Auto-Accept"
        self._make_button(
            btn_row,
            auto_label,
            lambda rid=request_id: self._toggle_command_auto_accept(rid),
            bg=self.accent_color if self._command_auto_accept else self.border_color,
            fg="#ffffff" if self._command_auto_accept else self.text_color,
            tooltip="Toggle automatic acceptance for future command requests",
            font=("Noto Sans", 7, "bold"),
            padx=8,
            pady=4,
        ).pack(side=tk.RIGHT)

        d.window_create(tk.END, window=outer, padx=6, pady=5)
        d.insert(tk.END, "\n")
        d.config(state=tk.DISABLED)
        d.see(tk.END)
        self._command_request_widgets[request_id] = outer

    def _toggle_command_auto_accept(self, request_id=None):
        self._command_auto_accept = not self._command_auto_accept
        state = "enabled" if self._command_auto_accept else "disabled"
        self._set_status(f"Auto-accept {state}", "ok" if self._command_auto_accept else "info", timeout=1600)
        if self._active_chat_id:
            self._render_active_conversation()
        if self._command_auto_accept and request_id:
            self._approve_command_request(request_id, auto_trigger=True)

    def _approve_command_request(self, request_id, auto_trigger=False):
        req = self._pending_command_requests.get(request_id)
        if not req or req.get("status") != "pending":
            return
        chat_id = req.get("chat_id") or self._active_chat_id
        commands = list(req.get("commands", []))
        req["status"] = "approved"
        self._drop_command_request(request_id)

        self._last_ai_response = ""
        with self._conversation_lock:
            if chat_id in self._conversations:
                self._conversations[chat_id]["last_response"] = ""
                self._persist_conversations()

        if auto_trigger:
            self._post_assistant_message("Auto-accept enabled: executing requested commands now.", chat_id)
        else:
            self._post_assistant_message("Approved. Executing now.", chat_id)

        self._is_processing = True
        self._command_execution_active = True
        self._run_threaded(self._run_commands, commands, chat_id)

    def _deny_command_request(self, request_id):
        req = self._pending_command_requests.get(request_id)
        if not req:
            return
        chat_id = req.get("chat_id") or self._active_chat_id
        req["status"] = "denied"
        self._drop_command_request(request_id)
        self._post_assistant_message("Denied. No commands were executed.", chat_id)
        self._set_status("Execution request denied", "warn", timeout=1800)
        self._is_processing = False

    @staticmethod
    def _build_revert_plan(commands):
        revert = []
        for cmd in commands:
            try:
                parts = shlex.split(cmd)
            except Exception:
                continue
            if not parts:
                continue
            if parts[0] == "sudo":
                parts = parts[1:]
            if not parts:
                continue

            tool = parts[0]
            args = parts[1:]

            if tool == "dnf" and args and args[0] == "install":
                pkgs = [a for a in args[1:] if not a.startswith("-")]
                if pkgs:
                    revert.append("sudo dnf remove -y " + " ".join(pkgs))
            elif tool in ("apt", "apt-get") and args and args[0] == "install":
                pkgs = [a for a in args[1:] if not a.startswith("-")]
                if pkgs:
                    revert.append("sudo apt remove -y " + " ".join(pkgs))
            elif tool == "pacman" and args and any(a.startswith("-S") for a in args):
                pkgs = [a for a in args[1:] if not a.startswith("-")]
                if pkgs:
                    revert.append("sudo pacman -Rns --noconfirm " + " ".join(pkgs))
            elif tool == "flatpak" and args and args[0] == "install":
                refs = [a for a in args[1:] if not a.startswith("-")]
                if refs:
                    revert.append("flatpak uninstall -y " + " ".join(refs))
            elif tool == "systemctl" and len(args) >= 2:
                action = args[0]
                unit = args[1]
                opposites = {
                    "start": "stop",
                    "stop": "start",
                    "enable": "disable",
                    "disable": "enable",
                    "restart": "restart",
                }
                if action in opposites:
                    revert.append(f"sudo systemctl {opposites[action]} {unit}")

        # Deduplicate while preserving order
        uniq = []
        seen = set()
        for cmd in revert:
            key = cmd.strip().lower()
            if key and key not in seen:
                uniq.append(cmd)
                seen.add(key)
        return uniq

    def _remember_execution_batch(self, chat_id, commands, revert_cmds):
        self._last_exec_by_chat[chat_id] = {
            "commands": list(commands),
            "revert": list(revert_cmds),
            "executed_at": datetime.now().isoformat(timespec="seconds"),
        }

    def _render_revert_card_for_chat(self, chat_id):
        batch = self._last_exec_by_chat.get(chat_id)
        if not batch:
            return
        if self._revert_widgets.get(chat_id):
            w = self._revert_widgets.get(chat_id)
            try:
                if w and w.winfo_exists():
                    return
            except Exception:
                pass

        d = self.chat_display
        d.config(state=tk.NORMAL)
        outer = tk.Frame(
            d,
            bg=self.border_color,
            highlightthickness=1,
            highlightbackground=self.border_color,
        )
        inner = tk.Frame(outer, bg=self.glass_tint)
        inner.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)
        tk.Label(
            inner,
            text="Post-run safety",
            font=("Noto Sans", 8, "bold"),
            bg=self.glass_tint,
            fg=self.text_dim,
            padx=10,
            pady=6,
        ).pack(side=tk.LEFT)
        self._make_button(
            inner,
            "Revert Changes",
            lambda cid=chat_id: self._queue_revert_for_chat(cid),
            bg=self.warning_color,
            tooltip="Prepare undo commands for the last execution",
            font=("Noto Sans", 8, "bold"),
            padx=10,
            pady=4,
        ).pack(side=tk.RIGHT, padx=8, pady=6)
        d.window_create(tk.END, window=outer, padx=6, pady=5)
        d.insert(tk.END, "\n")
        d.config(state=tk.DISABLED)
        d.see(tk.END)
        self._revert_widgets[chat_id] = outer

    def _queue_revert_for_chat(self, chat_id):
        batch = self._last_exec_by_chat.get(chat_id)
        if not batch:
            self._post_assistant_message("No recent command execution found to revert.", chat_id)
            return
        revert_cmds = list(batch.get("revert", []))
        if not revert_cmds:
            self._post_assistant_message(
                "I can't safely auto-revert that change set. I'll need a manual rollback plan.",
                chat_id,
            )
            return
        self._queue_command_request(revert_cmds, chat_id=chat_id, source="revert")

    def _purge_chat_execution_state(self, chat_id):
        if not chat_id:
            return
        doomed = [
            rid for rid, req in self._pending_command_requests.items()
            if req.get("chat_id") == chat_id
        ]
        for rid in doomed:
            self._drop_command_request(rid)
        self._last_exec_by_chat.pop(chat_id, None)
        w = self._revert_widgets.pop(chat_id, None)
        try:
            if w and w.winfo_exists():
                w.destroy()
        except Exception:
            pass

    def _on_chat_selector_changed(self, _event=None):
        if self._is_processing:
            self._set_status("Wait for Fyxa to finish before switching chats.", "warn", timeout=2200)
            self._refresh_chat_selector()
            return
        label = self._chat_selector_var.get().strip() if self._chat_selector_var else ""
        chat_id = self._chat_selector_labels.get(label)
        if not chat_id or chat_id == self._active_chat_id:
            return
        self._set_active_chat(chat_id, render=True)
        self._persist_conversations()

    def _on_chat_listbox_changed(self, _event=None):
        if self._suspend_chat_select_events:
            return
        if self._is_processing:
            self._set_status("Wait for Fyxa to finish before switching chats.", "warn", timeout=2200)
            self._refresh_chat_selector()
            return
        if not self._chat_listbox:
            return
        sel = self._chat_listbox.curselection()
        if not sel:
            return
        label = self._chat_listbox.get(sel[0]).strip()
        chat_id = self._chat_selector_labels.get(label)
        if not chat_id or chat_id == self._active_chat_id:
            return
        self._set_active_chat(chat_id, render=True)
        self._persist_conversations()

    def new_chat_thread(self):
        if self._is_processing:
            self._set_status("Wait for Fyxa to finish before creating a new chat.", "warn", timeout=2200)
            return
        with self._conversation_lock:
            chat_id = uuid4().hex[:10]
            self._conversations[chat_id] = {
                "title": "New Chat",
                "messages": [],
                "last_response": "",
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            }
            self._touch_chat(chat_id)

            while len(self._conversation_order) > self._MAX_CHAT_THREADS:
                stale_id = self._conversation_order.pop()
                if stale_id == chat_id:
                    continue
                self._conversations.pop(stale_id, None)
            self._set_active_chat(chat_id, render=True)
            self._persist_conversations()
        self._set_status("New conversation created", "ok", timeout=1500)
        if hasattr(self, "chat_input"):
            self.chat_input.focus_set()

    def delete_chat_thread(self):
        if self._is_processing:
            self._set_status("Wait for Fyxa to finish before deleting chats.", "warn", timeout=2200)
            return
        if not self._active_chat_id or self._active_chat_id not in self._conversations:
            return
        if len(self._conversation_order) <= 1:
            self.clear_chat()
            return

        title = self._conversations[self._active_chat_id].get("title", "this chat")
        ok = messagebox.askyesno("Delete Conversation", f"Delete conversation:\n\n{title}\n")
        if not ok:
            return

        with self._conversation_lock:
            doomed = self._active_chat_id
            if doomed in self._conversation_order:
                self._conversation_order.remove(doomed)
            self._conversations.pop(doomed, None)
            self._purge_chat_execution_state(doomed)
            self._ensure_chat_exists()
            self._set_active_chat(self._conversation_order[0], render=True)
            self._persist_conversations()
        self._set_status("Conversation deleted", "ok", timeout=1500)

    def _init_chat_context_menu(self):
        if self._chat_context_menu is not None:
            return
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Copy Selection", command=self._copy_chat_selection)
        menu.add_command(label="Copy Last Code Block", command=self._copy_last_code_block)
        menu.add_separator()
        menu.add_command(label="Paste Into Prompt", command=self._paste_clipboard_to_input)
        menu.add_command(label="Paste and Send", command=self._paste_and_send_prompt)
        self._chat_context_menu = menu

    def _show_chat_context_menu(self, event):
        if self._chat_context_menu is None:
            return
        try:
            self._chat_context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self._chat_context_menu.grab_release()

    def _copy_chat_selection(self):
        try:
            if self.chat_display.tag_ranges("sel"):
                text = self.chat_display.get("sel.first", "sel.last")
                self._copy_text_to_clipboard(text, "Copied selected text")
                return "break"
        except Exception:
            pass
        self._set_status("No selected text to copy", "warn", timeout=1200)
        return "break"

    def _extract_last_code_block(self):
        src = self._last_ai_response or ""
        if not src:
            return ""
        fenced = re.findall(r"```(?:[\w.+-]+)?\n([\s\S]*?)```", src, flags=re.IGNORECASE)
        if fenced:
            return fenced[-1].strip()
        inline = re.findall(r"`([^`]+)`", src)
        return inline[-1].strip() if inline else ""

    def _copy_last_code_block(self):
        block = self._extract_last_code_block()
        if not block:
            self._set_status("No code block found in the latest Fyxa reply", "warn", timeout=1800)
            return
        self._copy_text_to_clipboard(block, "Latest code block copied")

    def _copy_text_to_clipboard(self, text, status_msg="Copied"):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self._set_status(status_msg, "ok", timeout=1300)
            return True
        except Exception:
            self._set_status("Copy failed", "err", timeout=1600)
            return False

    def _chat_input_select_all(self, _event=None):
        if not hasattr(self, "chat_input"):
            return "break"
        if getattr(self.chat_input, "_placeholder_active", False):
            return "break"
        self.chat_input.selection_range(0, tk.END)
        self.chat_input.icursor(tk.END)
        return "break"

    def _open_chat_link(self, url):
        link = (url or "").strip()
        if not link:
            return
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", link):
            link = f"https://{link}"
        try:
            webbrowser.open(link)
            self._set_status("Opened link", "ok", timeout=1200)
        except Exception:
            self._set_status("Failed to open link", "warn", timeout=1500)

    def _insert_text_with_links(self, widget, text, base_tag):
        url_re = re.compile(r"(?i)\b((?:https?://|www\.)[^\s<>()]+)")
        cursor = 0
        for match in url_re.finditer(text):
            if match.start() > cursor:
                widget.insert(tk.END, text[cursor:match.start()], base_tag)

            raw = match.group(1)
            trailing = ""
            while raw and raw[-1] in ".,;:!?)]":
                trailing = raw[-1] + trailing
                raw = raw[:-1]

            start_idx = widget.index(tk.END)
            widget.insert(tk.END, raw, ("md_link", base_tag))
            end_idx = widget.index(tk.END)

            self._link_tag_counter += 1
            tag = f"md_link_{self._link_tag_counter}"
            widget.tag_add(tag, start_idx, end_idx)
            widget.tag_bind(tag, "<Button-1>", lambda _e, u=raw: self._open_chat_link(u))
            widget.tag_bind(tag, "<Enter>", lambda _e: widget.config(cursor="hand2"))
            widget.tag_bind(tag, "<Leave>", lambda _e: widget.config(cursor="xterm"))

            if trailing:
                widget.insert(tk.END, trailing, base_tag)
            cursor = match.end()

        if cursor < len(text):
            widget.insert(tk.END, text[cursor:], base_tag)

    def _paste_clipboard_to_input(self):
        if not hasattr(self, "chat_input"):
            return
        try:
            clip = self.root.clipboard_get()
        except Exception:
            self._set_status("Clipboard is empty", "warn", timeout=1200)
            return
        if getattr(self.chat_input, "_placeholder_active", False):
            self.chat_input.delete(0, tk.END)
            self.chat_input._placeholder_active = False  # type: ignore[attr-defined]
            self.chat_input.config(fg=self.text_color)
        self.chat_input.insert(tk.END, clip)
        self.chat_input.focus_set()
        self._set_status("Pasted into prompt", "ok", timeout=1200)

    def _paste_and_send_prompt(self):
        self._paste_clipboard_to_input()
        self.send_message()

    # ── Chat system ─────────────────────────────────────────────────────

    def add_chat_message(self, sender, message, is_user=True):
        """Add a styled message to the chat display (thread-safe)."""
        def _do():
            d = self.chat_display
            d.config(state=tk.NORMAL)
            ts = datetime.now().strftime("%H:%M")
            d.insert(tk.END, "\n")

            if is_user:
                d.insert(tk.END, f"You  ", "user_header")
                d.insert(tk.END, f"{ts}\n", "timestamp")
                d.insert(tk.END, f"{message}\n", "user_text")
            elif sender == "System Output":
                d.insert(tk.END, f"System  ", "system_header")
                d.insert(tk.END, f"{ts}\n", "timestamp")
                # Render code blocks for system output
                self._insert_rich_text(d, message, "system_text")
                d.insert(tk.END, "\n")
            else:  # Fyxa
                d.insert(tk.END, f"Fyxa  ", "fyxa_header")
                d.insert(tk.END, f"{ts}\n", "timestamp")
                self._insert_rich_text(d, message, "fyxa_text")
                d.insert(tk.END, "\n")

            d.config(state=tk.DISABLED)
            d.see(tk.END)

        self._safe(_do)

    def _insert_rich_text(self, widget, text, default_tag):
        """Insert text with markdown-like formatting and fenced code cards."""
        cursor = 0
        fence_re = re.compile(r"```([a-zA-Z0-9_.+-]*)\n([\s\S]*?)```")
        for match in fence_re.finditer(text):
            before = text[cursor:match.start()]
            self._insert_markdown_block(widget, before, default_tag)

            language = match.group(1).strip() or "code"
            code = match.group(2).rstrip("\n")
            self._insert_code_card(widget, code, language)
            widget.insert(tk.END, "\n", default_tag)
            cursor = match.end()

        tail = text[cursor:]
        self._insert_markdown_block(widget, tail, default_tag)

    def _insert_markdown_block(self, widget, text, default_tag):
        lines = text.splitlines()
        i = 0
        total = len(lines)

        while i < total:
            line = lines[i]
            stripped = line.strip()

            if not stripped:
                widget.insert(tk.END, "\n", default_tag)
                i += 1
                continue

            # Markdown tables
            if i + 1 < total and "|" in lines[i] and self._is_md_table_separator(lines[i + 1]):
                j = i + 2
                while j < total:
                    candidate = lines[j].strip()
                    if not candidate or "|" not in lines[j]:
                        break
                    j += 1
                rows = self._parse_md_table(lines[i:j])
                if rows:
                    self._insert_table_card(widget, rows)
                    widget.insert(tk.END, "\n", default_tag)
                    i = j
                    continue

            # Headers
            head_match = re.match(r"^(#{1,3})\s+(.*)$", stripped)
            if head_match:
                level = len(head_match.group(1))
                content = head_match.group(2).strip()
                tag = {1: "md_h1", 2: "md_h2", 3: "md_h3"}[level]
                self._insert_markdown_inline(widget, content, tag)
                widget.insert(tk.END, "\n", tag)
                i += 1
                continue

            # Horizontal rule
            if re.match(r"^\s*([-*_]\s*){3,}$", stripped):
                widget.insert(tk.END, "─" * 56 + "\n", "md_separator")
                i += 1
                continue

            # Quote block
            if stripped.startswith(">"):
                quote_text = stripped[1:].lstrip()
                widget.insert(tk.END, "▍ ", "md_quote_bar")
                self._insert_markdown_inline(widget, quote_text, "md_quote")
                widget.insert(tk.END, "\n", "md_quote")
                i += 1
                continue

            # Numbered list
            number_match = re.match(r"^(\d+)\.\s+(.*)$", stripped)
            if number_match:
                widget.insert(tk.END, f"{number_match.group(1)}. ", "md_list_marker")
                self._insert_markdown_inline(widget, number_match.group(2), default_tag)
                widget.insert(tk.END, "\n", default_tag)
                i += 1
                continue

            # Bulleted list
            bullet_match = re.match(r"^[-*+]\s+(.*)$", stripped)
            if bullet_match:
                widget.insert(tk.END, "• ", "md_list_marker")
                self._insert_markdown_inline(widget, bullet_match.group(1), default_tag)
                widget.insert(tk.END, "\n", default_tag)
                i += 1
                continue

            self._insert_markdown_inline(widget, line, default_tag)
            widget.insert(tk.END, "\n", default_tag)
            i += 1

    def _insert_markdown_inline(self, widget, text, default_tag):
        token_re = re.compile(
            r"(`[^`\n]+`|\*\*[^*\n][\s\S]*?\*\*|__[^_\n][\s\S]*?__|\*[^*\n]+\*|_[^_\n]+_)"
        )
        parts = token_re.split(text)
        for part in parts:
            if not part:
                continue
            if part.startswith("`") and part.endswith("`") and len(part) > 2:
                widget.insert(tk.END, part[1:-1], "code_block")
            elif (part.startswith("**") and part.endswith("**") and len(part) > 4) or (
                part.startswith("__") and part.endswith("__") and len(part) > 4
            ):
                self._insert_text_with_links(widget, part[2:-2], "md_bold")
            elif (part.startswith("*") and part.endswith("*") and len(part) > 2) or (
                part.startswith("_") and part.endswith("_") and len(part) > 2
            ):
                self._insert_text_with_links(widget, part[1:-1], "md_italic")
            else:
                self._insert_text_with_links(widget, part, default_tag)

    def _is_md_table_separator(self, line):
        return bool(re.match(r"^\s*\|?(?:\s*:?-{2,}:?\s*\|)+\s*:?-{2,}:?\s*\|?\s*$", line))

    def _parse_md_table(self, lines):
        if len(lines) < 2 or not self._is_md_table_separator(lines[1]):
            return []

        def _split(row_text):
            return [c.strip() for c in row_text.strip().strip("|").split("|")]

        rows = [_split(lines[0])]
        for raw in lines[2:]:
            cells = _split(raw)
            if cells and any(c for c in cells):
                rows.append(cells)
        if not rows:
            return []

        cols = max(len(r) for r in rows)
        for row in rows:
            if len(row) < cols:
                row.extend([""] * (cols - len(row)))
        return rows

    def _insert_table_card(self, widget, rows):
        if not rows:
            return
        outer = tk.Frame(
            widget,
            bg=self.border_color,
            highlightthickness=1,
            highlightbackground=self.border_color,
        )
        cols = len(rows[0])
        for c in range(cols):
            outer.grid_columnconfigure(c, weight=1, uniform="mdtbl")

        for r, row in enumerate(rows):
            for c, cell in enumerate(row):
                is_header = (r == 0)
                lbl = tk.Label(
                    outer,
                    text=cell,
                    font=("Noto Sans", 9, "bold" if is_header else "normal"),
                    bg=self.glass_tint if is_header else self.glass_white,
                    fg=self.accent_color if is_header else self.text_color,
                    anchor="w",
                    justify=tk.LEFT,
                    relief="solid",
                    bd=1,
                    padx=8,
                    pady=5,
                    wraplength=260,
                )
                lbl.grid(row=r, column=c, sticky="nsew")
                if isinstance(cell, str) and re.match(r"(?i)^(https?://|www\.)\S+$", cell.strip()):
                    link_val = cell.strip()
                    lbl.config(
                        fg=self.accent_color,
                        cursor="hand2",
                        font=("Noto Sans", 9, "underline"),
                    )
                    lbl.bind("<Button-1>", lambda _e, u=link_val: self._open_chat_link(u))

        widget.window_create(tk.END, window=outer, padx=6, pady=5)

    def _insert_code_card(self, widget, code, language="code"):
        code = (code or "").rstrip()
        if not code:
            return

        outer = tk.Frame(
            widget,
            bg=self.border_color,
            highlightthickness=1,
            highlightbackground=self.border_color,
        )

        header = tk.Frame(outer, bg=self.glass_tint)
        header.pack(fill=tk.X, padx=1, pady=(1, 0))
        tk.Label(
            header,
            text=language.upper(),
            font=("Noto Sans", 8, "bold"),
            bg=self.glass_tint,
            fg=self.text_dim,
            padx=8,
            pady=5,
        ).pack(side=tk.LEFT)
        tk.Button(
            header,
            text="Copy",
            command=lambda value=code: self._copy_text_to_clipboard(value, "Code block copied"),
            font=("Noto Sans", 8, "bold"),
            bg=self.accent_color,
            fg="#ffffff",
            activebackground=self.button_hover,
            activeforeground="#ffffff",
            relief="flat",
            bd=0,
            padx=8,
            pady=2,
            cursor="hand2",
        ).pack(side=tk.RIGHT, padx=6, pady=4)

        body = tk.Text(
            outer,
            height=min(max(code.count("\n") + 1, 2), 16),
            wrap=tk.NONE,
            font=("Noto Sans Mono", 10),
            bg=self.glass_white,
            fg=self.text_color,
            relief="flat",
            borderwidth=0,
            padx=10,
            pady=8,
            highlightthickness=0,
        )
        body.insert("1.0", code)
        body.config(state=tk.DISABLED)
        body.pack(fill=tk.BOTH, expand=True, padx=1, pady=(0, 1))
        SmoothScroller.bind_smooth_scroll(body)

        widget.window_create(tk.END, window=outer, padx=6, pady=5)

    def _install_entry_placeholder(self, entry, text):
        entry._placeholder_text = text  # type: ignore[attr-defined]
        if getattr(entry, "_placeholder_installed", False):
            if not entry.get().strip():
                entry.delete(0, tk.END)
                entry.insert(0, text)
                entry.config(fg=self.text_dim)
                entry._placeholder_active = True  # type: ignore[attr-defined]
            return

        placeholder_color = self.text_dim
        normal_color = self.text_color

        def _show_placeholder():
            current_text = getattr(entry, "_placeholder_text", text)
            if entry.get():
                return
            entry.delete(0, tk.END)
            entry.insert(0, current_text)
            entry.config(fg=placeholder_color)
            entry._placeholder_active = True  # type: ignore[attr-defined]

        def _hide_placeholder(_event=None):
            if getattr(entry, "_placeholder_active", False):
                entry.delete(0, tk.END)
                entry.config(fg=normal_color)
                entry._placeholder_active = False  # type: ignore[attr-defined]

        def _restore_placeholder(_event=None):
            if not entry.get().strip():
                _show_placeholder()

        entry.bind("<FocusIn>", _hide_placeholder, add=True)
        entry.bind("<FocusOut>", _restore_placeholder, add=True)
        entry._placeholder_installed = True  # type: ignore[attr-defined]
        _show_placeholder()

    # ── Execute-request keywords ─────────────────────────────────────

    _EXEC_KEYWORDS = (
        "run that", "run those", "execute", "do that", "do it",
        "apply that", "perform", "run them", "run the command",
        "can you run", "go ahead",
    )

    def send_message(self):
        if getattr(self.chat_input, "_placeholder_active", False):
            return
        msg = self.chat_input.get().strip()
        if not msg or self._is_processing:
            return
        if not self._active_chat_id:
            self._ensure_chat_exists()

        if not self.config.get("enable_ai_features", True):
            messagebox.showwarning(
                "AI Disabled",
                "AI features are disabled in Settings. Enable them to chat with Fyxa.",
            )
            return

        ai_state = get_ai_runtime_status()
        if not ai_state.get("online"):
            messagebox.showwarning(
                "AI Offline",
                ai_state.get("detail", "No AI provider available."),
            )
            return

        self._is_processing = True
        self.add_chat_message("You", msg, is_user=True)
        self.chat_input.delete(0, tk.END)
        self._install_entry_placeholder(self.chat_input, "Ask Fyxa anything about your system...")

        with self._conversation_lock:
            chat_id = self._active_chat_id
            self._append_chat_message(chat_id, "user", msg)
            chat = self._conversations.get(chat_id, {})
            user_msgs = [m for m in chat.get("messages", []) if m.get("role") == "user"]
            if chat.get("title", "New Chat") == "New Chat" and len(user_msgs) <= 1:
                chat["title"] = self._make_chat_title(msg)
            history_snapshot = list(chat.get("messages", []))
            self._persist_conversations()

        self._refresh_chat_selector()

        # --- handle execution approvals on the main thread ---
        user_lower = msg.lower()
        wants_exec = any(kw in user_lower for kw in self._EXEC_KEYWORDS)

        if wants_exec:
            pending_id = self._latest_pending_request_id(self._active_chat_id)
            if pending_id:
                self._approve_command_request(pending_id)
                return

            commands = self._extract_commands_from_history()
            if commands:
                self._queue_command_request(commands, chat_id=self._active_chat_id, source="history")
                self._is_processing = False
                return

            self._post_assistant_message(
                "I don't have a pending command set yet. Ask me to diagnose first, then I'll prepare commands.",
                self._active_chat_id,
            )
            self._is_processing = False
            return

        # --- normal AI query (in thread) ---
        self._is_thinking = True
        self._thinking_frame = 0
        self._show_thinking()
        self._animate_thinking()

        self._run_threaded(self._get_ai_response, msg, self._active_chat_id, history_snapshot)

    def _show_thinking(self):
        def _do():
            self.chat_display.config(state=tk.NORMAL)
            self.chat_display.insert(tk.END, "\n")
            self._thinking_mark = self.chat_display.index(tk.END)
            self.chat_display.insert(tk.END, "Fyxa is thinking...", "thinking")
            self.chat_display.config(state=tk.DISABLED)
            self.chat_display.see(tk.END)
        self._safe(_do)

    def _animate_thinking(self):
        """Animate the thinking indicator with a spinner."""
        if not self._is_thinking:
            return
        dots = ["", ".", "..", "..."]
        frame = self._thinking_frame % len(dots)
        self._thinking_frame += 1

        def _do():
            try:
                d = self.chat_display
                d.config(state=tk.NORMAL)
                # Find and replace thinking text
                start = d.search("Fyxa is thinking", "1.0", tk.END)
                if start:
                    line_end = d.index(f"{start} lineend")
                    d.delete(start, line_end)
                    d.insert(start, f"Fyxa is thinking{dots[frame]}", "thinking")
                d.config(state=tk.DISABLED)
            except Exception:
                pass

        self._safe(_do)
        self.root.after(400, self._animate_thinking)

    def _remove_thinking(self):
        """Remove the animated thinking indicator."""
        self._is_thinking = False
        def _do():
            d = self.chat_display
            d.config(state=tk.NORMAL)
            start = d.search("Fyxa is thinking", "1.0", tk.END)
            if start:
                # Delete the line and its preceding newline
                line_start = d.index(f"{start} linestart")
                line_end = d.index(f"{start} lineend + 1 char")
                d.delete(line_start, line_end)
            d.config(state=tk.DISABLED)
        self._safe(_do)

    # ── Actionable step detection ───────────────────────────────────────

    def _contains_actionable_steps(self, response):
        rl = response.lower()
        if '`' in response:
            cmds = re.findall(r'`([^`]+)`', rl)
            for cmd in cmds:
                if any(s in cmd for s in ('sudo', 'apt', 'dnf', 'yum', 'rm ', 'cp ', 'mv ',
                                           'systemctl', 'service', 'chmod', 'chown', 'sed',
                                           'awk', 'pip', 'npm', 'pacman', 'flatpak')):
                    return True
        if re.search(r'\b(install|uninstall|remove)\s+\w+|apt-get|yum install|dnf install', rl):
            return True
        if re.search(r'\b(restart|reboot|shutdown)\s+(your\s+)?(computer|system|pc|machine)', rl):
            return True
        if re.search(r'\b(start|stop|restart|disable|enable)\s+(the\s+)?(network|audio|service|process|daemon)', rl):
            return True
        return False

    # Interactive commands that hang when run headless via subprocess
    _INTERACTIVE_CMDS = frozenset({
        "htop", "top", "btop", "bashtop", "nmon", "glances",
        "vim", "vi", "nvim", "nano", "emacs", "pico",
        "less", "more", "man", "pager",
        "watch", "ncdu", "mc", "nmtui", "iotop",
        "python", "python3", "ipython", "node", "irb",
        "bash", "zsh", "sh", "fish",
    })

    # Package names people mention but aren't runnable commands
    _PACKAGE_NAMES = frozenset({
        "lm-sensors", "lm_sensors", "mesa-utils", "vulkan-tools",
        "xorg-x11-drv-nvidia", "nvidia-driver", "nvidia-utils",
        "linux-headers", "build-essential", "kernel-devel",
        "python3-pip", "python-pip", "pipewire-pulse",
    })

    def _extract_commands(self, text):
        """Extract shell commands from backticks — deduplicated, filtered."""
        raw = re.findall(r'`([^`]+)`', text)

        # Prefixes / substrings that indicate a real executable command
        cmd_hints = (
            'sudo ', 'apt ', 'apt-get ', 'dnf ', 'yum ', 'pacman ',
            'pip ', 'pip3 ', 'npm ', 'npx ',
            'systemctl ', 'service ', 'journalctl ',
            'cat ', 'echo ', 'grep ', 'sed ', 'awk ', 'xargs ',
            'rm ', 'cp ', 'mv ', 'mkdir ', 'chmod ', 'chown ', 'chgrp ',
            'ls ', 'cd ', 'find ', 'kill ', 'pkill ', 'xkill',
            'nvidia-smi', 'nvidia-settings', 'nvidia-xconfig',
            'lspci', 'lsblk', 'lscpu', 'lsusb', 'lsmod',
            'sensors', 'free ', 'ps ', 'df ', 'du ', 'mount ',
            'curl ', 'wget ', 'git ', 'docker ', 'podman ',
            'flatpak ', 'snap ', 'rpm ', 'dpkg ',
            'modprobe ', 'modinfo ', 'dmesg', 'uname ',
            'ip ', 'ss ', 'ping ', 'traceroute ', 'nmcli ',
            'timedatectl', 'hostnamectl', 'localectl',
            'xrandr', 'wlr-randr', 'kscreen-doctor',
        )
        # Operators that indicate a pipeline / compound command
        operator_hints = ('|', '>', '&&', ';', '$(')

        seen = set()
        cmds = []
        for c in raw:
            c = c.strip()
            if not c or len(c) < 2:
                continue
            cl = c.lower()

            # --- deduplication ---
            if cl in seen:
                continue

            # --- blocklists ---
            base = cl.split()[0]
            if base in self._INTERACTIVE_CMDS:
                continue
            if cl in self._PACKAGE_NAMES:
                continue

            # --- positive match ---
            is_cmd = (
                any(h in cl for h in cmd_hints)
                or any(op in c for op in operator_hints)
                or c.startswith('/')
                or c.startswith('./')
            )
            if is_cmd:
                seen.add(cl)
                cmds.append(c)

        return cmds

    def _extract_commands_from_history(self):
        """Extract commands from the last Fyxa response in chat history."""
        if self._last_ai_response:
            return self._extract_commands(self._last_ai_response)
        # Fall back to scanning chat history
        for msg in reversed(self.chat_history):
            if msg.get("role") == "assistant":
                cmds = self._extract_commands(msg.get("content", ""))
                if cmds:
                    return cmds
        return []

    def _validate_commands(self, commands):
        """Split commands into (valid, invalid) based on whether the base binary exists."""
        valid, invalid = [], []
        for cmd in commands:
            # Extract the actual binary (handle sudo, env vars, etc.)
            parts = cmd.strip().split()
            base = parts[0]
            if base == "sudo" and len(parts) > 1:
                base = parts[1]
            # Check if binary exists on PATH
            if shutil.which(base):
                valid.append(cmd)
            else:
                invalid.append(cmd)
        return valid, invalid

    def _execute_command(self, command):
        try:
            result = subprocess.run(
                command, shell=True, capture_output=True,
                text=True, timeout=30,
            )
            out = result.stdout if result.stdout else result.stderr
            ok = result.returncode == 0
            if not out:
                out = "Command executed successfully" if ok else f"Command failed (exit {result.returncode})"
            return ok, out.strip()
        except subprocess.TimeoutExpired:
            return False, "Command timed out (30s limit)"
        except Exception as e:
            return False, f"Error: {e}"

    def _run_commands(self, commands, chat_id=None):
        """Execute a list of commands in a background thread and post results."""
        target_chat = chat_id or self._active_chat_id
        try:
            intro = "Running approved commands now."
            self._post_assistant_message(intro, target_chat, track_last_response=False)
            ok_count = 0

            with self._conversation_lock:
                self._touch_chat(target_chat)
                self._persist_conversations()
            for cmd in commands:
                ok, output = self._execute_command(cmd)
                if ok:
                    ok_count += 1
                self.add_chat_message(
                    "System Output",
                    f"`{cmd}`\n\n{output}",
                    is_user=False,
                )
                with self._conversation_lock:
                    self._append_chat_message(
                        target_chat, "assistant", f"`{cmd}`\n\n{output}", track_last_response=False
                    )

                if self._chat_memory_enabled():
                    try:
                        summary = re.sub(r"\s+", " ", output).strip()[:260]
                        add_solution(cmd, summary or ("Command succeeded" if ok else "Command failed"), worked=ok)
                    except Exception:
                        pass

            revert_cmds = self._build_revert_plan(commands)
            self._remember_execution_batch(target_chat, commands, revert_cmds)

            done = (
                f"Execution finished: {ok_count}/{len(commands)} command(s) succeeded."
                "\nUse the Revert Changes button below if you want to roll back."
            )
            self._post_assistant_message(done, target_chat, track_last_response=False)
            if target_chat == self._active_chat_id:
                self._safe(lambda cid=target_chat: self._render_revert_card_for_chat(cid))
        except Exception as e:
            self._post_assistant_message(
                f"Error running commands: {e}",
                target_chat,
                track_last_response=False,
            )
        finally:
            self._command_execution_active = False
            self._is_processing = False

    # ── AI response handler ─────────────────────────────────────────────

    def _get_ai_response(self, user_message, chat_id=None, history_snapshot=None):
        """Worker thread: query AI and display response."""
        target_chat = chat_id or self._active_chat_id
        chat_memory = list(history_snapshot or self.chat_history)
        try:
            # Capture live system state
            sys_ctx = get_system_snapshot()

            # ── Inject Heartbeat real-time telemetry into AI context ──
            try:
                hb_awareness = get_heartbeat().awareness_dict()
                if hb_awareness and isinstance(sys_ctx, dict):
                    sys_ctx["_heartbeat"] = hb_awareness
                    # Surface active alerts prominently
                    hb_alerts = heartbeat_alerts()
                    if hb_alerts:
                        sys_ctx["_heartbeat_alerts"] = [
                            {"type": a.alert_type, "severity": a.severity,
                             "message": a.message}
                            for a in hb_alerts[:8]
                        ]
            except Exception:
                pass  # Heartbeat not started or unavailable

            # Auto-detect topic keywords and enrich context
            topic_ctx = self._detect_topic_keywords(user_message)
            if topic_ctx:
                if isinstance(sys_ctx, dict):
                    sys_ctx["_extra_context"] = topic_ctx
                else:
                    sys_ctx = {"_extra_context": topic_ctx}

            # ELI5 mode: instruct AI to use simple language
            if self.config.get("eli5_mode", False):
                eli5_instruction = (
                    "[INSTRUCTION] The user has ELI5 mode enabled. "
                    "Explain everything in plain, simple language that a non-technical "
                    "person can understand. Avoid jargon. Use analogies and everyday "
                    "terms. Keep explanations short and friendly. If you must mention "
                    "a command, explain what it does in simple words first."
                )
                if isinstance(sys_ctx, dict):
                    sys_ctx["_eli5"] = eli5_instruction
                else:
                    sys_ctx = {"_eli5": eli5_instruction}

            # Scrub PII from string values inside the context dict
            if sys_ctx and isinstance(sys_ctx, dict):
                for k, v in sys_ctx.items():
                    if isinstance(v, str):
                        sys_ctx[k] = scrub_pii(v)

            # Normal AI query — pass history + context
            response = get_deep_dive(
                user_message,
                gui_mode=True,
                chat_history=chat_memory,
                system_context=sys_ctx,
            )

            self._remove_thinking()

            with self._conversation_lock:
                self._append_chat_message(target_chat, "assistant", response)
                self._persist_conversations()
                is_active_chat = (target_chat == self._active_chat_id)

            # Show response
            if is_active_chat:
                self.add_chat_message("Fyxa", response, is_user=False)

            # Offer command execution if response has validated commands
            commands = self._extract_commands(response)
            if commands:
                self._queue_command_request(commands, chat_id=target_chat, source="assistant")

        except Exception as e:
            self._remove_thinking()
            self.add_chat_message(
                "Fyxa",
                f"Something went wrong: {e}\n\nTry again.",
                is_user=False,
            )
            with self._conversation_lock:
                self._append_chat_message(
                    target_chat, "assistant", f"Something went wrong: {e}", track_last_response=False
                )
                self._persist_conversations()
        finally:
            if not self._command_execution_active:
                self._is_processing = False

    def clear_chat(self):
        if self._is_processing:
            self._set_status("Wait for Fyxa to finish before clearing chat.", "warn", timeout=1800)
            return
        if not self._active_chat_id or self._active_chat_id not in self._conversations:
            return
        with self._conversation_lock:
            chat = self._conversations[self._active_chat_id]
            chat["messages"] = []
            chat["last_response"] = ""
            chat["updated_at"] = datetime.now().isoformat(timespec="seconds")
            self.chat_history = chat["messages"]
            self._last_ai_response = ""
            self._purge_chat_execution_state(self._active_chat_id)
            self._persist_conversations()
        self._render_active_conversation()
        self._set_status("Conversation cleared", "ok", timeout=1400)


# ---------------------------------------------------------------------------
# Single-instance guard
# ---------------------------------------------------------------------------

class GuiInstanceGuard:
    """Prevent multiple Sysfix GUI processes from running simultaneously."""

    LOCK_PATH = Path("/tmp/sysfix-gui.lock")

    def __init__(self, lock_path=None):
        self.lock_path = Path(lock_path) if lock_path else self.LOCK_PATH
        self._fd = None

    def _open_lock_file(self):
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(self.lock_path), os.O_CREAT | os.O_RDWR, 0o666)
        try:
            os.fchmod(fd, 0o666)
        except Exception:
            pass
        self._fd = fd
        return fd

    def _read_holder_pid(self):
        if self._fd is None:
            return None
        try:
            os.lseek(self._fd, 0, os.SEEK_SET)
            raw = os.read(self._fd, 128).decode("utf-8", errors="ignore").strip()
            if not raw:
                return None
            first = raw.splitlines()[0].strip()
            return int(first) if first.isdigit() else None
        except Exception:
            return None

    def _write_holder_state(self):
        if self._fd is None:
            return
        payload = f"{os.getpid()}\n{int(time.time())}\n"
        data = payload.encode("utf-8")
        try:
            os.ftruncate(self._fd, 0)
            os.lseek(self._fd, 0, os.SEEK_SET)
            os.write(self._fd, data)
            os.fsync(self._fd)
        except Exception:
            pass

    def release(self):
        if self._fd is None:
            return
        try:
            if fcntl is not None:
                fcntl.flock(self._fd, fcntl.LOCK_UN)
        except Exception:
            pass
        try:
            os.close(self._fd)
        except Exception:
            pass
        self._fd = None

    def acquire(self, takeover=False, parent_pid=None, timeout_seconds=6.0):
        """Acquire the singleton lock.

        Returns:
            (ok: bool, holder_pid: Optional[int])
        """
        if fcntl is None:
            # Best effort fallback on platforms without fcntl.
            return True, None

        fd = self._open_lock_file()
        deadline = time.monotonic() + max(0.6, float(timeout_seconds))
        takeover_signal_sent = False
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._write_holder_state()
                return True, None
            except BlockingIOError:
                holder_pid = self._read_holder_pid()
                if takeover and not takeover_signal_sent:
                    target_pid = None
                    if parent_pid and isinstance(parent_pid, int) and parent_pid > 1:
                        target_pid = parent_pid
                    elif holder_pid and holder_pid != os.getpid():
                        target_pid = holder_pid
                    if target_pid and target_pid != os.getpid():
                        try:
                            os.kill(target_pid, signal.SIGTERM)
                        except ProcessLookupError:
                            pass
                        except PermissionError:
                            pass
                        except Exception:
                            pass
                    takeover_signal_sent = True
                if time.monotonic() >= deadline:
                    self.release()
                    return False, holder_pid
                time.sleep(0.12)
            except Exception:
                self.release()
                return False, None


def _show_single_instance_notice(message):
    try:
        tmp = tk.Tk()
        tmp.withdraw()
        messagebox.showinfo("Sysfix", message, parent=tmp)
        tmp.destroy()
    except Exception:
        print(message, file=sys.stderr)


def _read_env_int(name, default=0):
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except Exception:
        return default


def _acquire_single_instance_guard():
    guard = GuiInstanceGuard()
    takeover = os.environ.get("SYSFIX_TAKEOVER", "").strip() == "1"
    parent_pid = _read_env_int("SYSFIX_PARENT_PID", 0)
    ok, holder_pid = guard.acquire(takeover=takeover, parent_pid=parent_pid)
    if ok:
        return guard
    if takeover:
        msg = "Could not hand off to elevated Sysfix. Close other Sysfix windows and try again."
    else:
        msg = "Sysfix is already running. Close the existing window first."
    if holder_pid:
        msg += f"\n\nRunning process PID: {holder_pid}"
    _show_single_instance_notice(msg)
    return None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    guard = _acquire_single_instance_guard()
    if guard is None:
        return

    try:
        root = tk.Tk()
    except Exception as e:
        # Common when running in headless environments (no $DISPLAY).
        # Provide a friendly fallback message and avoid a hard crash.
        msg = str(e)
        if "no display name" in msg or "DISPLAY" in msg:
            print("GUI launch failed: no display name and no $DISPLAY environment variable", file=sys.stderr)
            print("Tip: run 'sysfix interactive' for terminal mode.", file=sys.stderr)
            guard.release()
            return
        raise

    # Gracefully handle SIGTERM (sent by the elevated takeover instance).
    def _sigterm_handler(*_args):
        try:
            root.quit()
        except Exception:
            pass
    signal.signal(signal.SIGTERM, _sigterm_handler)

    root.withdraw()
    splash = StartupSplash(root)
    startup_data = {
        "integrity_results": [],
        "update_results": [],
    }
    try:
        splash.set_message("Loading startup profile...")
        cfg = load_config()

        try:
            startup_data["integrity_results"] = splash.run_task(
                "Checking Sysfix file integrity...",
                check_sysfix_integrity,
            ) or []
        except Exception as e:
            startup_data["integrity_results"] = [f"WARN: Integrity check failed: {e}"]

        if cfg.get("auto_check_updates_on_startup", True):
            try:
                startup_data["update_results"] = splash.run_task(
                    "Checking for Sysfix updates...",
                    check_sysfix_update,
                ) or []
            except Exception as e:
                startup_data["update_results"] = [f"INFO: Startup update check failed: {e}"]

        splash.set_message("Launching interface...")
        SysfixApp(
            root,
            startup_feedback=splash.set_message,
            startup_data=startup_data,
        )
    except Exception:
        try:
            splash.close()
        finally:
            try:
                root.destroy()
            except Exception:
                pass
        raise
    try:
        splash.close(min_visible_ms=850)
        root.deiconify()
        root.mainloop()
    finally:
        guard.release()


if __name__ == "__main__":
    main()
