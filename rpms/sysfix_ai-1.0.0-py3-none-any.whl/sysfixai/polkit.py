"""
Polkit (PolicyKit) integration for Sysfix — hardened privilege elevation.

Design goals:
  - The main GUI process NEVER runs as root.
  - Only specific, auditable backend "worker" scripts run as root via pkexec.
  - Wayland session handling: forward $DISPLAY, $XAUTHORITY, $XDG_RUNTIME_DIR,
    $WAYLAND_DISPLAY, and $DBUS_SESSION_BUS_ADDRESS through pkexec env.
  - Fallback: if pkexec is unavailable, try pkexec → sudo in terminal.
  - Every elevation request is logged to the audit journal.

Public API:
  - check_polkit()        → bool — is pkexec available?
  - elevate(argv, ...)    → CompletedProcess — run argv as root via pkexec
  - worker_run(task, ...) → str — run a named worker task as root
  - install_policy()      → bool — install our .policy XML so pkexec shows
                                    a branded dialog instead of generic
  - ElevationError        — raised when elevation fails
  - AuditLog              — append-only elevation audit trail

Architecture:
  ┌──────────────────────┐
  │   GUI (unprivileged) │
  │   calls polkit.      │
  │   elevate(worker_cmd)│
  └─────────┬────────────┘
            │  pkexec env DISPLAY=... WAYLAND_DISPLAY=...
            ▼
  ┌──────────────────────┐
  │  pkexec → worker.py  │  (runs as root)
  │  stdin:  JSON task    │
  │  stdout: JSON result  │
  └──────────────────────┘
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("sysfix.polkit")

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ElevationError(Exception):
    """Raised when privilege elevation fails."""

    def __init__(self, message: str, returncode: int = -1, stderr: str = ""):
        super().__init__(message)
        self.returncode = returncode
        self.stderr = stderr


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------

@dataclass
class AuditEntry:
    """Single elevation audit record."""
    timestamp: float
    task: str
    argv: List[str]
    user: str
    success: bool
    returncode: int
    duration_ms: float
    error: str = ""


class AuditLog:
    """Append-only audit trail for elevation requests."""

    _entries: List[AuditEntry] = []
    _max_entries: int = 500

    @classmethod
    def record(cls, entry: AuditEntry) -> None:
        cls._entries.append(entry)
        if len(cls._entries) > cls._max_entries:
            cls._entries = cls._entries[-cls._max_entries:]

    @classmethod
    def entries(cls) -> List[AuditEntry]:
        return list(cls._entries)

    @classmethod
    def last(cls, n: int = 20) -> List[AuditEntry]:
        return cls._entries[-n:]

    @classmethod
    def format_report(cls) -> List[str]:
        """Human-readable audit report."""
        if not cls._entries:
            return ["INFO: No elevation requests recorded this session."]
        lines: List[str] = []
        for e in cls._entries[-30:]:
            ts = time.strftime("%H:%M:%S", time.localtime(e.timestamp))
            status = "✓" if e.success else "✗"
            lines.append(
                f"{status} [{ts}] {e.task} (rc={e.returncode}, "
                f"{e.duration_ms:.0f}ms) user={e.user}"
            )
            if e.error:
                lines.append(f"    Error: {e.error[:200]}")
        return lines


# ---------------------------------------------------------------------------
# Wayland / X11 session environment
# ---------------------------------------------------------------------------

_SESSION_ENV_KEYS = (
    "DISPLAY",
    "XAUTHORITY",
    "WAYLAND_DISPLAY",
    "XDG_RUNTIME_DIR",
    "XDG_SESSION_TYPE",
    "DBUS_SESSION_BUS_ADDRESS",
    "HOME",
    "PATH",
    "LANG",
    "LC_ALL",
)


def _session_env() -> Dict[str, str]:
    """Capture the current desktop session environment variables.

    On Wayland sessions, ``XAUTHORITY`` may not be set if XWayland hasn't
    started yet—but ``WAYLAND_DISPLAY`` and ``XDG_RUNTIME_DIR`` must be
    forwarded so GUI apps launched via pkexec can reach the compositor.
    """
    env: Dict[str, str] = {}
    for key in _SESSION_ENV_KEYS:
        val = os.environ.get(key, "").strip()
        if val:
            env[key] = val

    # Wayland: ensure XDG_RUNTIME_DIR points to a valid path
    xdg_rt = env.get("XDG_RUNTIME_DIR", "")
    if xdg_rt and not os.path.isdir(xdg_rt):
        # Fallback to /run/user/<uid>
        fallback = f"/run/user/{os.getuid()}"
        if os.path.isdir(fallback):
            env["XDG_RUNTIME_DIR"] = fallback

    # X11: ensure XAUTHORITY is set (some DMs don't export it)
    if "DISPLAY" in env and "XAUTHORITY" not in env:
        xauth_path = os.path.expanduser("~/.Xauthority")
        if os.path.exists(xauth_path):
            env["XAUTHORITY"] = xauth_path

    return env


def is_wayland() -> bool:
    """Detect if running on a Wayland session."""
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def session_type() -> str:
    """Return 'wayland', 'x11', or 'unknown'."""
    if os.environ.get("WAYLAND_DISPLAY"):
        return "wayland"
    if os.environ.get("DISPLAY"):
        return "x11"
    xdg = os.environ.get("XDG_SESSION_TYPE", "").lower()
    if xdg in ("wayland", "x11"):
        return xdg
    return "unknown"


# ---------------------------------------------------------------------------
# Polkit availability
# ---------------------------------------------------------------------------

def check_polkit() -> bool:
    """Return True if pkexec is available on this system."""
    return shutil.which("pkexec") is not None


def polkit_status() -> Dict[str, Any]:
    """Detailed Polkit integration status."""
    pkexec_path = shutil.which("pkexec")
    return {
        "available": pkexec_path is not None,
        "pkexec_path": pkexec_path or "",
        "session_type": session_type(),
        "is_wayland": is_wayland(),
        "policy_installed": _policy_installed(),
        "audit_entries": len(AuditLog._entries),
        "euid": os.geteuid() if hasattr(os, "geteuid") else -1,
        "is_root": (os.geteuid() == 0) if hasattr(os, "geteuid") else False,
    }


# ---------------------------------------------------------------------------
# PolicyKit .policy file
# ---------------------------------------------------------------------------

_POLICY_ID = "com.sysfix.worker"
_POLICY_DIR = Path("/usr/share/polkit-1/actions")

_POLICY_XML = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE policyconfig PUBLIC
 "-//freedesktop//DTD PolicyKit Policy Configuration 1.0//EN"
 "http://www.freedesktop.org/standards/PolicyKit/1/policyconfig.dtd">
<policyconfig>
  <vendor>Sysfix AI</vendor>
  <vendor_url>https://github.com/useofscript/sysfix-ai</vendor_url>

  <action id="{_POLICY_ID}">
    <description>Sysfix — run a privileged diagnostic/repair task</description>
    <message>Sysfix needs elevated privileges to perform system maintenance.</message>
    <defaults>
      <allow_any>auth_admin</allow_any>
      <allow_inactive>auth_admin</allow_inactive>
      <allow_active>auth_admin_keep</allow_active>
    </defaults>
    <annotate key="org.freedesktop.policykit.exec.path">{sys.executable}</annotate>
    <annotate key="org.freedesktop.policykit.exec.allow_gui">true</annotate>
  </action>
</policyconfig>
"""


def _policy_installed() -> bool:
    """Check if our Polkit policy file exists."""
    policy_file = _POLICY_DIR / f"{_POLICY_ID}.policy"
    return policy_file.exists()


def install_policy() -> bool:
    """Install the Sysfix Polkit policy file.

    Must be run as root (typically via pkexec itself or during package install).
    Returns True on success.
    """
    policy_file = _POLICY_DIR / f"{_POLICY_ID}.policy"
    try:
        _POLICY_DIR.mkdir(parents=True, exist_ok=True)
        policy_file.write_text(_POLICY_XML, encoding="utf-8")
        log.info("Installed Polkit policy: %s", policy_file)
        return True
    except PermissionError:
        log.warning("Cannot install Polkit policy (not root)")
        return False
    except Exception as e:
        log.error("Failed to install Polkit policy: %s", e)
        return False


# ---------------------------------------------------------------------------
# Worker protocol
# ---------------------------------------------------------------------------

# Allowed worker tasks — only these can be executed as root.
# Each maps to a function in the worker dispatch table.
ALLOWED_TASKS = frozenset({
    "apply_kernel_optimisation",
    "apply_bbr",
    "kill_zombie_parents",
    "apply_system_updates",
    "golden_state_reconcile",
    "rollback_config",
    "install_policy",
    "sentinel_start",
    "sentinel_stop",
    "av_start",
    "av_stop",
    "network_heal",
    "firecracker_setup",
})


def _worker_entrypoint() -> List[str]:
    """Build the command to invoke the worker script."""
    # Use the same Python interpreter that's running the GUI
    python = sys.executable
    return [python, "-m", "sysfixai.polkit", "--worker"]


# ---------------------------------------------------------------------------
# Core elevation API
# ---------------------------------------------------------------------------

def elevate(
    argv: List[str],
    *,
    task_name: str = "custom",
    timeout: int = 120,
    stdin_data: Optional[str] = None,
) -> subprocess.CompletedProcess:
    """Run *argv* as root via pkexec with session environment forwarding.

    On Wayland, ``WAYLAND_DISPLAY``, ``XDG_RUNTIME_DIR``, and
    ``DBUS_SESSION_BUS_ADDRESS`` are forwarded so the elevated process
    can reach the compositor and session bus.

    On X11, ``DISPLAY`` and ``XAUTHORITY`` are forwarded.

    Raises :class:`ElevationError` if pkexec is missing or the command fails.
    """
    pkexec = shutil.which("pkexec")
    if not pkexec:
        raise ElevationError("pkexec not found — install polkit")

    # Build env-forwarding prefix
    session = _session_env()
    env_args = [f"{k}={v}" for k, v in session.items()]

    cmd = [pkexec, "env", *env_args, *argv]

    user = os.environ.get("USER", os.environ.get("LOGNAME", "unknown"))
    t0 = time.monotonic()

    try:
        result = subprocess.run(
            cmd,
            input=stdin_data,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        elapsed = (time.monotonic() - t0) * 1000

        AuditLog.record(AuditEntry(
            timestamp=time.time(),
            task=task_name,
            argv=argv,
            user=user,
            success=(result.returncode == 0),
            returncode=result.returncode,
            duration_ms=elapsed,
            error=result.stderr[:500] if result.returncode != 0 else "",
        ))

        if result.returncode == 126:
            raise ElevationError(
                "Authentication dismissed — user cancelled the password prompt.",
                returncode=126,
                stderr=result.stderr,
            )
        if result.returncode == 127:
            raise ElevationError(
                "pkexec: command not found or not authorized.",
                returncode=127,
                stderr=result.stderr,
            )

        return result

    except subprocess.TimeoutExpired:
        elapsed = (time.monotonic() - t0) * 1000
        AuditLog.record(AuditEntry(
            timestamp=time.time(),
            task=task_name,
            argv=argv,
            user=user,
            success=False,
            returncode=-1,
            duration_ms=elapsed,
            error="Timed out",
        ))
        raise ElevationError(f"Elevated command timed out after {timeout}s")


def worker_run(
    task: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    timeout: int = 120,
) -> Dict[str, Any]:
    """Run a named worker task as root via pkexec.

    This is the primary API for the GUI.  It:
      1. Validates the task name against the allowlist
      2. Launches the worker process via pkexec
      3. Passes the task + params as JSON on stdin
      4. Reads the JSON result from stdout
      5. Records the request in the audit log

    Returns a dict with ``{"ok": bool, "result": ..., "error": ...}``.
    """
    if task not in ALLOWED_TASKS:
        raise ElevationError(
            f"Task '{task}' is not in the allowed worker task list. "
            f"Allowed: {', '.join(sorted(ALLOWED_TASKS))}"
        )

    payload = json.dumps({"task": task, "params": params or {}})
    worker_cmd = _worker_entrypoint()

    try:
        result = elevate(
            worker_cmd,
            task_name=task,
            timeout=timeout,
            stdin_data=payload,
        )

        # Parse worker JSON output
        stdout = result.stdout.strip()
        if not stdout:
            return {"ok": result.returncode == 0, "result": None, "error": result.stderr}

        try:
            return json.loads(stdout)
        except json.JSONDecodeError:
            return {"ok": False, "result": stdout, "error": "Invalid JSON from worker"}

    except ElevationError:
        raise
    except Exception as e:
        raise ElevationError(f"Worker invocation failed: {e}")


# ---------------------------------------------------------------------------
# Worker entry point (runs as root when invoked via pkexec)
# ---------------------------------------------------------------------------

def _worker_main() -> None:
    """Worker entry point — reads JSON task from stdin, dispatches, writes result.

    This function is called when the module is run as ``python -m sysfixai.polkit --worker``.
    It runs as root (launched via pkexec). Only tasks in ALLOWED_TASKS are dispatched.
    """
    import json
    import sys

    try:
        raw = sys.stdin.read()
        if not raw.strip():
            _worker_respond(False, error="No input received")
            return

        try:
            request = json.loads(raw)
        except json.JSONDecodeError as e:
            _worker_respond(False, error=f"Invalid JSON: {e}")
            return

        task = request.get("task", "")
        params = request.get("params", {})

        if task not in ALLOWED_TASKS:
            _worker_respond(False, error=f"Disallowed task: {task}")
            return

        # Dispatch
        result = _dispatch_task(task, params)
        _worker_respond(True, result=result)

    except Exception as e:
        _worker_respond(False, error=str(e))


def _worker_respond(ok: bool, result: Any = None, error: str = "") -> None:
    """Write JSON response to stdout."""
    response = {"ok": ok, "result": result, "error": error}
    sys.stdout.write(json.dumps(response))
    sys.stdout.flush()


def _dispatch_task(task: str, params: Dict[str, Any]) -> Any:
    """Dispatch a worker task. Each task is a thin wrapper around existing functions."""
    if task == "apply_kernel_optimisation":
        from sysfixai.advanced_diagnostics import apply_kernel_optimisation
        param = params.get("param", "")
        value = params.get("value", "")
        return apply_kernel_optimisation(param, value)

    elif task == "apply_bbr":
        from sysfixai.advanced_diagnostics import apply_bbr
        return apply_bbr()

    elif task == "kill_zombie_parents":
        from sysfixai.advanced_diagnostics import kill_zombie_parents
        pids = params.get("pids", [])
        return kill_zombie_parents(pids)

    elif task == "apply_system_updates":
        from sysfixai.diagnostics import apply_system_updates
        return apply_system_updates()

    elif task == "golden_state_reconcile":
        from sysfixai.sandbox import golden_state_reconcile_services
        return golden_state_reconcile_services()

    elif task == "rollback_config":
        from sysfixai.advanced_diagnostics import rollback_config
        snapshot_id = params.get("snapshot_id", "")
        return rollback_config(snapshot_id)

    elif task == "install_policy":
        return install_policy()

    elif task == "sentinel_start":
        from sysfixai.ebpf_sentinel import start_sentinel
        return start_sentinel()

    elif task == "sentinel_stop":
        from sysfixai.ebpf_sentinel import stop_sentinel
        return stop_sentinel()

    elif task == "av_start":
        from sysfixai.sentinel_av import start_av
        return start_av()

    elif task == "av_stop":
        from sysfixai.sentinel_av import stop_av
        return stop_av()

    elif task == "network_heal":
        from sysfixai.advanced_diagnostics import network_self_heal
        return network_self_heal()

    elif task == "firecracker_setup":
        from sysfixai.microvm import setup_vm_environment
        return setup_vm_environment()

    else:
        raise ValueError(f"Unknown task: {task}")


# ---------------------------------------------------------------------------
# Human-readable status report
# ---------------------------------------------------------------------------

def polkit_report() -> List[str]:
    """Generate a human-readable Polkit status report."""
    status = polkit_status()
    lines: List[str] = []

    if status["available"]:
        lines.append(f"✓ pkexec available at: {status['pkexec_path']}")
    else:
        lines.append("✗ pkexec not found — install polkit for graphical elevation")

    lines.append(f"  Session type: {status['session_type']}")
    if status["is_wayland"]:
        lines.append("  Wayland detected — env forwarding enabled")

    if status["policy_installed"]:
        lines.append("  ✓ Sysfix Polkit policy installed")
    else:
        lines.append("  ⚠ Sysfix Polkit policy not installed (generic dialog will show)")

    if status["is_root"]:
        lines.append("  ⚠ Currently running as root — elevation not needed")
    else:
        lines.append(f"  Running as UID {status['euid']}")

    # Audit summary
    audit = AuditLog.last(10)
    if audit:
        lines.append("")
        lines.append("  Recent elevation log:")
        for entry in audit:
            ts = time.strftime("%H:%M:%S", time.localtime(entry.timestamp))
            mark = "✓" if entry.success else "✗"
            lines.append(f"    {mark} [{ts}] {entry.task} ({entry.duration_ms:.0f}ms)")
            if entry.error:
                lines.append(f"      {entry.error[:120]}")
    else:
        lines.append("  No elevation requests this session")

    return lines


# ---------------------------------------------------------------------------
# Module entry point (worker mode)
# ---------------------------------------------------------------------------

if __name__ == "__main__" or (
    len(sys.argv) > 1 and sys.argv[-1] == "--worker"
):
    # Only run worker code when explicitly invoked
    if "--worker" in sys.argv:
        _worker_main()
