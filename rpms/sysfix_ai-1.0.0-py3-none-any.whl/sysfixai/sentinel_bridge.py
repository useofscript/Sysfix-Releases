"""
SentinelBridge — Pure-Python security bridge for AI tool-calling.

Maps AI intents ("scan processes", "check network", "identify threats")
to Python functions that gather security telemetry.  Works in three
capability tiers:

  Tier 1 — ebpfcat + root:  real eBPF map/program interface for
           kernel-level visibility (pure Python — no C compilation)
  Tier 2 — /proc + /sys:    read-only procfs scanning (works WITHOUT
           root; the primary path for free-tier users)
  Tier 3 — subprocess:      fallback to ps/ss/netstat CLI tools

Free-tier AI (Qwen2.5-Coder via Ollama) can always call:
  • read_only_ebpf_scan()      — live snapshot of processes, network,
                                  open files, with threat heuristics
  • check_network_threats()    — suspicious connections, open ports,
                                  DNS anomalies
  • scan_process_anomalies()   — unusual process trees, /tmp exec,
                                  privilege patterns
  • get_sentinel_status()      — engine health and capability report

Paid-tier only (raises PermissionError for free users):
  • auto_kill_threat(pid)      — freeze/kill detected malicious process
  • quarantine_file(path)      — move suspicious file to quarantine

The bridge auto-registers its functions as AI tools (via tool_calling)
so the local Ollama model sees them in its context window and can
invoke them natively through the Agentic Reasoning Loop.

Dependencies:
  • ebpfcat (optional) — pure-Python eBPF interface
  • No hard dependencies — /proc scraping always works
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import signal
import subprocess
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Tier detection — ebpfcat, /proc, subprocess
# ---------------------------------------------------------------------------

_HAS_EBPFCAT = False
_ebpfcat_mod = None


def _check_ebpfcat() -> bool:
    """Attempt to import ebpfcat for pure-Python eBPF support."""
    global _HAS_EBPFCAT, _ebpfcat_mod
    if _HAS_EBPFCAT:
        return True
    try:
        import ebpfcat  # type: ignore[import-untyped]
        _ebpfcat_mod = ebpfcat
        _HAS_EBPFCAT = True
        return True
    except ImportError:
        return False


def _is_root() -> bool:
    return hasattr(os, "geteuid") and os.geteuid() == 0


# ---------------------------------------------------------------------------
# Paid-tier check — integrates with config
# ---------------------------------------------------------------------------

_PAID_FEATURES = {"auto_kill", "quarantine_file", "freeze_process"}


def _is_paid_tier() -> bool:
    """Check if the user has a paid/premium licence.

    Reads ``premium`` or ``paid_tier`` from the Sysfix config.
    Returns False unless explicitly enabled — free tier is default.
    """
    try:
        from sysfixai.config import load_config
        cfg = load_config()
        return bool(cfg.get("premium") or cfg.get("paid_tier"))
    except Exception:
        return False


def _require_paid(feature: str) -> None:
    """Raise if *feature* is gated behind the paid tier."""
    if feature in _PAID_FEATURES and not _is_paid_tier():
        raise PermissionError(
            f"🔒 '{feature}' requires the Sysfix Pro upgrade. "
            f"Advanced unlocks Sentinel Auto-Fix (auto-kill, process "
            f"quarantine, live eBPF enforcement) and higher-tier local "
            f"reasoning. No third-party API subscriptions required — "
            f"everything runs locally. Free-tier users can still run "
            f"read_only_ebpf_scan() to identify threats."
        )


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ProcessSnapshot:
    """One scanned process."""
    pid: int = 0
    ppid: int = 0
    uid: int = 0
    user: str = ""
    comm: str = ""
    cmdline: str = ""
    exe: str = ""
    state: str = ""
    cpu_pct: float = 0.0
    mem_pct: float = 0.0
    open_fds: int = 0
    threads: int = 1
    started_from_tmp: bool = False
    has_network: bool = False
    suspicious: bool = False
    risk_factors: List[str] = field(default_factory=list)
    risk_score: int = 0  # 0-100


@dataclass
class NetworkConnection:
    """One observed network connection."""
    proto: str = "tcp"
    local_addr: str = ""
    local_port: int = 0
    remote_addr: str = ""
    remote_port: int = 0
    state: str = ""
    pid: int = 0
    comm: str = ""
    suspicious: bool = False
    risk_factors: List[str] = field(default_factory=list)


@dataclass
class ScanResult:
    """Aggregated result of a read-only security scan."""
    scan_time: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    scan_duration_ms: int = 0
    tier: str = "procfs"  # ebpfcat | procfs | subprocess
    is_root: bool = False

    # Processes
    total_processes: int = 0
    suspicious_processes: List[Dict[str, Any]] = field(default_factory=list)

    # Network
    total_connections: int = 0
    suspicious_connections: List[Dict[str, Any]] = field(default_factory=list)
    listening_services: List[Dict[str, Any]] = field(default_factory=list)

    # File system anomalies
    tmp_executables: List[str] = field(default_factory=list)
    suid_binaries: List[str] = field(default_factory=list)
    world_writable_dirs: List[str] = field(default_factory=list)

    # Overall
    threat_count: int = 0
    risk_level: str = "clean"  # clean | low | medium | high | critical
    risk_score: int = 0  # 0-100
    summary: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, default=str)


# ---------------------------------------------------------------------------
# Suspicious-pattern databases
# ---------------------------------------------------------------------------

_SUSPICIOUS_PORTS: Set[int] = {
    4444, 5555, 6666, 6667, 31337, 12345, 1234, 9999,
    4443, 8443, 1337, 7777, 8888, 9090,
}

_C2_PORTS: Set[int] = {4444, 5555, 31337, 1337, 6667}

_NOISY_COMMS: Set[str] = {
    "systemd", "kworker", "ksoftirqd", "rcu_sched", "rcu_preempt",
    "migration", "idle", "kcompactd", "khugepaged", "kdevtmpfs",
    "watchdog", "thermald", "irqbalance", "dbus-daemon", "dbus-broker",
    "gdbus", "gnome-shell", "Xwayland", "pipewire", "wireplumber",
    "pulseaudio", "at-spi-bus-laun", "at-spi2-regist", "gsd-",
    "ibus-daemon", "ibus-engine", "ibus-portal", "gvfs-",
    "tracker-miner", "evolution-data", "gnome-keyring",
    "ssh-agent", "polkitd", "rtkit-daemon", "upowerd",
    "packagekitd", "fwupd", "abrt-dbus", "chronyd", "NetworkManager",
    "wpa_supplicant", "systemd-journal", "systemd-logind",
    "systemd-oomd", "systemd-resolve", "systemd-timesyn",
    "systemd-udevd", "auditd", "firewalld", "accounts-daemon",
    "colord", "cups", "avahi-daemon", "bluetoothd",
    "sysfix", "python", "python3", "ollama",
}

_NO_NETWORK_APPS: Set[str] = {
    "gnome-calculator", "kcalc", "galculator", "xcalc",
    "eog", "loupe", "feh", "shotwell",
    "evince", "okular", "mupdf",
    "gedit", "nano", "mousepad",
    "file-roller", "ark",
}

_CRYPTO_MINERS_PATTERNS = re.compile(
    r"(xmrig|minerd|cpuminer|cgminer|bfgminer|ethminer|nbminer|"
    r"t-rex|phoenixminer|lolminer|stratum\+tcp)",
    re.I,
)

_REVERSE_SHELL_PATTERNS = re.compile(
    r"(nc\s+-[^z]*e\s+/bin|bash\s+-i\s+>&|/dev/tcp/|"
    r"python.*socket.*connect|perl.*socket.*INET|"
    r"ruby.*TCPSocket|socat\s+exec|mkfifo.*nc\s)",
    re.I,
)


def _is_noisy(comm: str) -> bool:
    base = comm.strip().split("/")[-1]
    for n in _NOISY_COMMS:
        if base.startswith(n):
            return True
    return False


# ---------------------------------------------------------------------------
# ebpfcat eBPF programs — pure-Python probe definitions
# ---------------------------------------------------------------------------

class _EbpfcatProbes:
    """Thin wrapper around ebpfcat to load read-only eBPF programs.

    ebpfcat provides a Python-native interface to eBPF maps and programs
    without requiring the BCC C-compilation toolchain.  We use it for
    kernel-level inspection of:
      • process launches (tracepoint/syscalls/sys_enter_execve)
      • TCP connect attempts (kprobe/tcp_v4_connect)
      • file opens on sensitive paths (tracepoint/syscalls/sys_enter_openat)

    All programs are read-only — they observe and record events in
    ring-buffer maps but never modify kernel state.
    """

    def __init__(self):
        self._programs: Dict[str, Any] = {}
        self._maps: Dict[str, Any] = {}
        self._events: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    @property
    def available(self) -> bool:
        return _HAS_EBPFCAT and _is_root()

    def attach(self) -> bool:
        """Load and attach eBPF programs via ebpfcat.

        Returns True on success.  Falls through silently if ebpfcat
        is not installed or we lack privileges.
        """
        if not self.available:
            return False

        try:
            import ebpfcat  # type: ignore[import-untyped]

            # --- execve tracepoint (read-only observer) ---
            # ebpfcat uses a declarative approach to define BPF
            # programs.  We create a minimal program that populates
            # a perf-event ring buffer with exec metadata.
            #
            # NOTE: The exact ebpfcat API may vary across versions.
            # We wrap each probe in its own try/except so a failure
            # in one probe doesn't block the others.

            # Process-launch observer
            try:
                prog = ebpfcat.Program(
                    prog_type="tracepoint",
                    attach_point="syscalls/sys_enter_execve",
                    name="sentinel_execve",
                )
                prog.load()
                prog.attach()
                self._programs["execve"] = prog
            except Exception:
                pass

            # TCP-connect observer
            try:
                prog = ebpfcat.Program(
                    prog_type="kprobe",
                    attach_point="tcp_v4_connect",
                    name="sentinel_connect",
                )
                prog.load()
                prog.attach()
                self._programs["connect"] = prog
            except Exception:
                pass

            # openat observer (sensitive-path watcher)
            try:
                prog = ebpfcat.Program(
                    prog_type="tracepoint",
                    attach_point="syscalls/sys_enter_openat",
                    name="sentinel_openat",
                )
                prog.load()
                prog.attach()
                self._programs["openat"] = prog
            except Exception:
                pass

            if self._programs:
                self._running = True
                self._thread = threading.Thread(
                    target=self._poll_loop, daemon=True,
                    name="sentinel-ebpfcat",
                )
                self._thread.start()
                return True
        except Exception:
            pass

        return False

    def detach(self) -> None:
        """Detach all eBPF programs."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)
        for prog in self._programs.values():
            try:
                prog.detach()
            except Exception:
                pass
        self._programs.clear()

    def _poll_loop(self) -> None:
        """Background poll for eBPF ring-buffer events."""
        while self._running:
            for name, prog in list(self._programs.items()):
                try:
                    events = prog.poll(timeout_ms=50)
                    if events:
                        with self._lock:
                            for ev in events:
                                self._events.append({
                                    "probe": name,
                                    "data": ev,
                                    "ts": time.time(),
                                })
                            # Cap at 1000 events
                            if len(self._events) > 1000:
                                self._events = self._events[-500:]
                except Exception:
                    pass
            time.sleep(0.05)

    def drain_events(self) -> List[Dict[str, Any]]:
        """Return and clear buffered events."""
        with self._lock:
            events = list(self._events)
            self._events.clear()
            return events

    @property
    def active_probes(self) -> List[str]:
        return list(self._programs.keys())


# Module-level probe instance
_probes = _EbpfcatProbes()


# ---------------------------------------------------------------------------
# /proc-based scanning (Tier 2 — works without root)
# ---------------------------------------------------------------------------

def _scan_proc_processes() -> List[ProcessSnapshot]:
    """Scan /proc for all running processes and apply threat heuristics."""
    procs: List[ProcessSnapshot] = []

    try:
        proc_path = Path("/proc")
        pid_dirs = [
            d for d in proc_path.iterdir()
            if d.name.isdigit()
        ]
    except Exception:
        return procs

    for pid_dir in pid_dirs:
        try:
            pid = int(pid_dir.name)
            snap = ProcessSnapshot(pid=pid)

            # Read /proc/PID/status
            try:
                status_text = (pid_dir / "status").read_text()
                for line in status_text.splitlines():
                    if line.startswith("Name:"):
                        snap.comm = line.split(":", 1)[1].strip()
                    elif line.startswith("PPid:"):
                        snap.ppid = int(line.split(":", 1)[1].strip())
                    elif line.startswith("Uid:"):
                        parts = line.split(":", 1)[1].strip().split()
                        snap.uid = int(parts[0]) if parts else 0
                    elif line.startswith("State:"):
                        snap.state = line.split(":", 1)[1].strip()[:1]
                    elif line.startswith("Threads:"):
                        snap.threads = int(line.split(":", 1)[1].strip())
            except (PermissionError, FileNotFoundError):
                continue

            if _is_noisy(snap.comm):
                continue

            # Read exe path
            try:
                snap.exe = os.readlink(str(pid_dir / "exe"))
            except (PermissionError, FileNotFoundError, OSError):
                snap.exe = ""

            # Read cmdline
            try:
                raw = (pid_dir / "cmdline").read_text()
                snap.cmdline = raw.replace("\x00", " ").strip()[:500]
            except (PermissionError, FileNotFoundError):
                pass

            # Count open file descriptors
            try:
                fd_dir = pid_dir / "fd"
                snap.open_fds = len(list(fd_dir.iterdir()))
            except (PermissionError, FileNotFoundError):
                pass

            # Check for network sockets (via /proc/PID/net/tcp)
            try:
                tcp_path = pid_dir / "net" / "tcp"
                if tcp_path.exists():
                    tcp_lines = tcp_path.read_text().strip().splitlines()[1:]
                    if tcp_lines:
                        snap.has_network = True
            except (PermissionError, FileNotFoundError):
                pass

            # --- Threat heuristics ---
            risk = 0
            factors: List[str] = []

            # Executed from /tmp or /dev/shm
            if snap.exe and (
                snap.exe.startswith("/tmp/")
                or snap.exe.startswith("/dev/shm/")
                or snap.exe.startswith("/var/tmp/")
            ):
                snap.started_from_tmp = True
                risk += 30
                factors.append(f"Binary in volatile path: {snap.exe}")

            # Crypto miner detection
            if _CRYPTO_MINERS_PATTERNS.search(snap.cmdline):
                risk += 40
                factors.append("Crypto-miner process pattern detected")

            # Reverse shell detection
            if _REVERSE_SHELL_PATTERNS.search(snap.cmdline):
                risk += 50
                factors.append("Reverse shell pattern in command line")

            # Deleted binary (process running from unlinked file)
            if snap.exe and "(deleted)" in snap.exe:
                risk += 35
                factors.append("Running from deleted binary (fileless malware?)")

            # Excessive file descriptors (possible C2 beacon)
            if snap.open_fds > 500:
                risk += 10
                factors.append(f"Excessive open FDs: {snap.open_fds}")

            # Non-root process with many threads (possible brute-force)
            if snap.uid != 0 and snap.threads > 100:
                risk += 10
                factors.append(f"Unusual thread count: {snap.threads}")

            # No-network app with network activity
            if snap.has_network and snap.comm.lower() in _NO_NETWORK_APPS:
                risk += 40
                factors.append(
                    f"{snap.comm} has network activity "
                    f"(should be offline-only)"
                )

            # UID 0 running non-system binary from user paths
            if snap.uid == 0 and snap.exe and snap.exe.startswith("/home/"):
                risk += 20
                factors.append("Root process running from /home directory")

            snap.risk_score = min(risk, 100)
            snap.risk_factors = factors
            snap.suspicious = risk >= 20

            if snap.suspicious:
                procs.append(snap)

        except (ValueError, FileNotFoundError, PermissionError):
            continue

    return procs


def _scan_proc_network() -> Tuple[
    List[NetworkConnection], List[NetworkConnection]
]:
    """Scan /proc/net/tcp{,6} for suspicious network connections.

    Returns (all_connections, suspicious_only).
    """
    connections: List[NetworkConnection] = []
    suspicious: List[NetworkConnection] = []

    # Build PID→comm lookup from /proc
    pid_comm: Dict[int, str] = {}
    try:
        for p in Path("/proc").iterdir():
            if p.name.isdigit():
                try:
                    comm = (p / "comm").read_text().strip()
                    pid_comm[int(p.name)] = comm
                except Exception:
                    pass
    except Exception:
        pass

    # Build inode→PID lookup
    inode_pid: Dict[int, int] = {}
    try:
        for p in Path("/proc").iterdir():
            if p.name.isdigit():
                pid = int(p.name)
                try:
                    fd_dir = p / "fd"
                    for fd in fd_dir.iterdir():
                        try:
                            link = os.readlink(str(fd))
                            if link.startswith("socket:["):
                                inode = int(link[8:-1])
                                inode_pid[inode] = pid
                        except (OSError, ValueError):
                            pass
                except (PermissionError, FileNotFoundError):
                    pass
    except Exception:
        pass

    for proto_file, proto_name in [
        ("/proc/net/tcp", "tcp"),
        ("/proc/net/tcp6", "tcp6"),
    ]:
        try:
            lines = Path(proto_file).read_text().strip().splitlines()[1:]
        except (FileNotFoundError, PermissionError):
            continue

        for line in lines:
            parts = line.split()
            if len(parts) < 10:
                continue

            try:
                # Parse local address
                local_hex = parts[1]
                local_ip_hex, local_port_hex = local_hex.split(":")
                local_port = int(local_port_hex, 16)

                # Parse remote address
                remote_hex = parts[2]
                remote_ip_hex, remote_port_hex = remote_hex.split(":")
                remote_port = int(remote_port_hex, 16)

                # Parse state
                state_num = int(parts[3], 16)
                state_map = {
                    1: "ESTABLISHED", 2: "SYN_SENT", 3: "SYN_RECV",
                    4: "FIN_WAIT1", 5: "FIN_WAIT2", 6: "TIME_WAIT",
                    7: "CLOSE", 8: "CLOSE_WAIT", 9: "LAST_ACK",
                    10: "LISTEN",
                }
                state = state_map.get(state_num, f"UNKNOWN({state_num})")

                # Convert hex IP to dotted quad (IPv4)
                if proto_name == "tcp" and len(local_ip_hex) == 8:
                    local_ip = ".".join(
                        str(int(local_ip_hex[i:i+2], 16))
                        for i in (6, 4, 2, 0)
                    )
                    remote_ip = ".".join(
                        str(int(remote_ip_hex[i:i+2], 16))
                        for i in (6, 4, 2, 0)
                    )
                else:
                    local_ip = local_ip_hex
                    remote_ip = remote_ip_hex

                # Find owning PID via inode
                inode = int(parts[9])
                pid = inode_pid.get(inode, 0)
                comm = pid_comm.get(pid, "")

                conn = NetworkConnection(
                    proto=proto_name,
                    local_addr=local_ip,
                    local_port=local_port,
                    remote_addr=remote_ip,
                    remote_port=remote_port,
                    state=state,
                    pid=pid,
                    comm=comm,
                )

                connections.append(conn)

                # --- Threat heuristics ---
                factors: List[str] = []

                if remote_port in _C2_PORTS:
                    factors.append(
                        f"Connection to C2/backdoor port {remote_port}"
                    )
                elif remote_port in _SUSPICIOUS_PORTS:
                    factors.append(
                        f"Connection to suspicious port {remote_port}"
                    )

                if comm and comm.lower() in _NO_NETWORK_APPS:
                    factors.append(
                        f"{comm} should not be making network connections"
                    )

                if state == "ESTABLISHED" and remote_port in _C2_PORTS:
                    factors.append("Active established connection to C2 port")

                if factors:
                    conn.suspicious = True
                    conn.risk_factors = factors
                    suspicious.append(conn)

            except (ValueError, IndexError):
                continue

    return connections, suspicious


def _scan_tmp_executables() -> List[str]:
    """Find executable files in /tmp, /dev/shm, /var/tmp."""
    executables: List[str] = []
    for base in ("/tmp", "/dev/shm", "/var/tmp"):
        try:
            for root, _dirs, files in os.walk(base):
                for f in files:
                    fp = os.path.join(root, f)
                    try:
                        if os.access(fp, os.X_OK):
                            executables.append(fp)
                        elif fp.endswith((".sh", ".py", ".pl", ".rb", ".elf")):
                            executables.append(fp)
                    except (OSError, PermissionError):
                        pass
                # Don't recurse too deep
                if root.count(os.sep) - base.count(os.sep) > 3:
                    _dirs.clear()
        except (PermissionError, FileNotFoundError):
            pass

    return executables[:50]  # cap


def _scan_suid_binaries() -> List[str]:
    """Quick check for SUID binaries in common paths."""
    suid: List[str] = []
    # Only scan a few fast directories (avoid full-disk scan)
    for base in ("/usr/bin", "/usr/sbin", "/usr/local/bin"):
        try:
            for entry in Path(base).iterdir():
                try:
                    st = entry.stat()
                    if st.st_mode & 0o4000:  # SUID bit
                        suid.append(str(entry))
                except (PermissionError, FileNotFoundError):
                    pass
        except (PermissionError, FileNotFoundError):
            pass

    return suid[:100]


def _scan_listening_services() -> List[Dict[str, Any]]:
    """Find all listening TCP/UDP services."""
    services: List[Dict[str, Any]] = []

    # Try ss first (faster, more info)
    try:
        r = subprocess.run(
            ["ss", "-tulnp"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            for line in r.stdout.strip().splitlines()[1:]:
                parts = line.split()
                if len(parts) >= 5:
                    proto = parts[0]
                    listen_addr = parts[4]
                    # Extract process name if available
                    proc_info = ""
                    for p in parts[5:]:
                        if "users:" in p:
                            proc_info = p
                            break
                    services.append({
                        "proto": proto,
                        "address": listen_addr,
                        "process": proc_info[:100],
                    })
            return services[:50]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Fallback: parse /proc/net/tcp for LISTEN state
    try:
        for line in Path("/proc/net/tcp").read_text().splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 4 and int(parts[3], 16) == 10:  # LISTEN
                local = parts[1]
                ip_hex, port_hex = local.split(":")
                port = int(port_hex, 16)
                ip = ".".join(
                    str(int(ip_hex[i:i+2], 16))
                    for i in (6, 4, 2, 0)
                )
                services.append({
                    "proto": "tcp",
                    "address": f"{ip}:{port}",
                    "process": "",
                })
    except Exception:
        pass

    return services[:50]


# ---------------------------------------------------------------------------
# SentinelBridge — the main class the AI calls
# ---------------------------------------------------------------------------

class SentinelBridge:
    """Maps AI intents to security scanning functions.

    The bridge is the primary interface between the AI reasoning loop
    and the Sentinel security engine.  It provides:

    1. **Intent mapping** — AI says "scan processes" and the bridge
       invokes the right combination of /proc, eBPF, and subprocess
       tools to gather security telemetry.

    2. **Tier-aware execution** — automatically uses the best available
       backend (ebpfcat → /proc → subprocess).

    3. **Free/Advanced gating** — read-only scans are always available;
       active response actions (kill, quarantine) require Advanced.

    4. **Tool registration** — exposes its capabilities as AI tools
       so the model sees them in its context window.
    """

    # Maps natural-language AI intents to method names
    INTENT_MAP: Dict[str, str] = {
        "scan processes":       "read_only_ebpf_scan",
        "scan_processes":       "read_only_ebpf_scan",
        "check processes":      "scan_process_anomalies",
        "check network":        "check_network_threats",
        "scan network":         "check_network_threats",
        "network threats":      "check_network_threats",
        "identify threats":     "read_only_ebpf_scan",
        "security scan":        "read_only_ebpf_scan",
        "threat scan":          "read_only_ebpf_scan",
        "kill process":         "auto_kill_threat",
        "kill threat":          "auto_kill_threat",
        "quarantine":           "quarantine_file",
        "sentinel status":      "get_sentinel_status",
        "health check":         "read_only_ebpf_scan",
    }

    def __init__(self):
        self._probes = _probes
        self._scan_cache: Optional[ScanResult] = None
        self._cache_age: float = 0.0
        self._lock = threading.Lock()

    # ── Tier detection ────────────────────────────────────────────

    @property
    def tier(self) -> str:
        """Current capability tier."""
        if _HAS_EBPFCAT and _is_root():
            return "ebpfcat"
        if Path("/proc").exists():
            return "procfs"
        return "subprocess"

    @property
    def capabilities(self) -> Dict[str, Any]:
        """Return capability map for the AI context window."""
        return {
            "tier": self.tier,
            "ebpfcat_available": _HAS_EBPFCAT,
            "is_root": _is_root(),
            "probes_active": self._probes.active_probes,
            "free_tier_tools": [
                "read_only_ebpf_scan",
                "scan_process_anomalies",
                "check_network_threats",
                "get_sentinel_status",
            ],
            "paid_tier_tools": [
                "auto_kill_threat",
                "quarantine_file",
            ],
            "intent_map": self.INTENT_MAP,
        }

    # ── Intent dispatcher ─────────────────────────────────────────

    def dispatch_intent(self, intent: str, **kwargs) -> str:
        """Dispatch a natural-language AI intent to the correct method.

        This is called by the AI reasoning loop when the model emits
        a Sentinel-related intent.
        """
        intent_lower = intent.strip().lower()

        # Exact match
        method_name = self.INTENT_MAP.get(intent_lower)

        # Fuzzy match — check if any intent key is a substring
        if not method_name:
            for key, mname in self.INTENT_MAP.items():
                if key in intent_lower or intent_lower in key:
                    method_name = mname
                    break

        if not method_name:
            return (
                f"Unknown Sentinel intent: '{intent}'. "
                f"Available: {', '.join(sorted(set(self.INTENT_MAP.values())))}"
            )

        method = getattr(self, method_name, None)
        if not method:
            return f"Internal error: method {method_name} not found."

        try:
            result = method(**kwargs)
            if isinstance(result, str):
                return result
            return json.dumps(result, indent=2, default=str)
        except PermissionError as e:
            return str(e)
        except Exception as e:
            return f"Sentinel error: {e}"

    # ── FREE-TIER: read_only_ebpf_scan ────────────────────────────

    def read_only_ebpf_scan(self, **kwargs) -> str:
        """Full read-only security scan — ALWAYS available (free tier).

        Scans processes, network connections, temp executables, and
        listening services for threat indicators.  Returns a structured
        report the AI can interpret.

        Uses eBPF (via ebpfcat) when available for kernel-level events,
        falls back to /proc scraping which works without root.
        """
        start = time.time()
        result = ScanResult(
            tier=self.tier,
            is_root=_is_root(),
        )

        # ── 1. Process scan ──────────────────────────────────────
        suspicious_procs = _scan_proc_processes()
        result.total_processes = len(list(Path("/proc").iterdir()))
        result.suspicious_processes = [
            asdict(p) for p in suspicious_procs
        ]

        # ── 2. Network scan ──────────────────────────────────────
        all_conns, suspicious_conns = _scan_proc_network()
        result.total_connections = len(all_conns)
        result.suspicious_connections = [
            asdict(c) for c in suspicious_conns
        ]

        # ── 3. Listening services ────────────────────────────────
        result.listening_services = _scan_listening_services()

        # ── 4. Temp executables ──────────────────────────────────
        result.tmp_executables = _scan_tmp_executables()

        # ── 5. SUID binaries (quick check) ───────────────────────
        if _is_root():
            result.suid_binaries = _scan_suid_binaries()

        # ── 6. ebpfcat kernel events (if available) ──────────────
        if self._probes.available:
            if not self._probes.active_probes:
                self._probes.attach()
            ebpf_events = self._probes.drain_events()
            # Incorporate kernel-level events
            for ev in ebpf_events:
                probe = ev.get("probe", "")
                if probe == "execve":
                    result.suspicious_processes.append({
                        "source": "ebpf_kernel",
                        "probe": probe,
                        "data": str(ev.get("data", "")),
                        "risk_score": 30,
                    })

        # ── 7. Compute overall risk ──────────────────────────────
        threat_count = (
            len(result.suspicious_processes)
            + len(result.suspicious_connections)
            + len(result.tmp_executables)
        )
        result.threat_count = threat_count

        max_proc_risk = max(
            (p.get("risk_score", 0) for p in result.suspicious_processes),
            default=0,
        )
        max_conn_risk = 40 if result.suspicious_connections else 0
        tmp_risk = min(len(result.tmp_executables) * 10, 30)

        result.risk_score = min(max_proc_risk + max_conn_risk + tmp_risk, 100)

        if result.risk_score >= 70:
            result.risk_level = "critical"
        elif result.risk_score >= 50:
            result.risk_level = "high"
        elif result.risk_score >= 30:
            result.risk_level = "medium"
        elif result.risk_score >= 10:
            result.risk_level = "low"
        else:
            result.risk_level = "clean"

        # Build summary
        result.scan_duration_ms = int((time.time() - start) * 1000)
        result.summary = (
            f"Scanned {result.total_processes} processes and "
            f"{result.total_connections} network connections. "
            f"Found {threat_count} potential threat(s). "
            f"Risk level: {result.risk_level.upper()} "
            f"(score {result.risk_score}/100). "
            f"Tier: {result.tier}. "
            f"Scan took {result.scan_duration_ms}ms."
        )

        # Cache the result
        with self._lock:
            self._scan_cache = result
            self._cache_age = time.time()

        return self._format_scan_result(result)

    # ── FREE-TIER: scan_process_anomalies ─────────────────────────

    def scan_process_anomalies(self, **kwargs) -> str:
        """Focused process-anomaly scan — ALWAYS available (free tier).

        Checks for: crypto miners, reverse shells, fileless malware,
        /tmp execution, offline-app network access, excessive FDs.
        """
        procs = _scan_proc_processes()

        if not procs:
            return (
                "✓ No suspicious processes detected. "
                "All running processes appear normal."
            )

        lines: List[str] = [
            f"⚠ Found {len(procs)} suspicious process(es):",
            "",
        ]

        for p in sorted(procs, key=lambda x: x.risk_score, reverse=True):
            severity = "🔴" if p.risk_score >= 50 else (
                "🟠" if p.risk_score >= 30 else "🟡"
            )
            lines.append(
                f"{severity} PID {p.pid} — {p.comm} "
                f"(risk: {p.risk_score}/100)"
            )
            lines.append(f"    exe: {p.exe or '(unknown)'}")
            lines.append(f"    cmdline: {p.cmdline[:120] or '(empty)'}")
            for factor in p.risk_factors:
                lines.append(f"    ⚠ {factor}")
            lines.append("")

        lines.append(
            "NOTE: This is a read-only scan. Use Auto-Kill (Sysfix Pro) "
            "to neutralise threats."
        )

        return "\n".join(lines)

    # ── FREE-TIER: check_network_threats ──────────────────────────

    def check_network_threats(self, **kwargs) -> str:
        """Network threat scan — ALWAYS available (free tier).

        Checks connections for C2 ports, suspicious endpoints,
        offline-app violations, and reports listening services.
        """
        all_conns, suspicious = _scan_proc_network()
        listening = _scan_listening_services()

        lines: List[str] = [
            f"Network scan: {len(all_conns)} connection(s), "
            f"{len(listening)} listening service(s)",
            "",
        ]

        if suspicious:
            lines.append(
                f"⚠ {len(suspicious)} suspicious connection(s):"
            )
            lines.append("")
            for c in suspicious:
                lines.append(
                    f"  🔴 {c.proto} {c.remote_addr}:{c.remote_port} "
                    f"← PID {c.pid} ({c.comm or '?'}) "
                    f"[{c.state}]"
                )
                for f in c.risk_factors:
                    lines.append(f"     ⚠ {f}")
            lines.append("")
        else:
            lines.append("✓ No suspicious connections found.")
            lines.append("")

        if listening:
            lines.append("Listening services:")
            for svc in listening[:15]:
                lines.append(
                    f"  • {svc['proto']} {svc['address']} "
                    f"{svc.get('process', '')}"
                )

        return "\n".join(lines)

    # ── FREE-TIER: get_sentinel_status ────────────────────────────

    def get_sentinel_status(self, **kwargs) -> str:
        """Return Sentinel engine health and capabilities — free tier."""
        caps = self.capabilities
        lines: List[str] = [
            "═══ SENTINEL BRIDGE STATUS ═══",
            "",
            f"Capability tier:  {caps['tier']}",
            f"Running as root:  {'yes' if caps['is_root'] else 'no'}",
            f"ebpfcat library:  {'✓ installed' if caps['ebpfcat_available'] else '✗ not installed (pip install ebpfcat)'}",
            "",
        ]

        # Active eBPF probes
        probes = caps.get("probes_active", [])
        if probes:
            lines.append(f"Active eBPF probes: {', '.join(probes)}")
        else:
            lines.append(
                "eBPF probes: not active "
                "(using /proc fallback — still fully functional)"
            )

        lines.append("")
        lines.append("Free-tier tools (always available):")
        for tool in caps["free_tier_tools"]:
            lines.append(f"  ✓ {tool}")

        lines.append("")
        paid = _is_paid_tier()
        lines.append(
            f"Advanced tools ({'✓ unlocked' if paid else '🔒 locked'}):"
        )
        for tool in caps["paid_tier_tools"]:
            icon = "✓" if paid else "🔒"
            lines.append(f"  {icon} {tool}")

        # Last scan cache
        with self._lock:
            if self._scan_cache:
                age = int(time.time() - self._cache_age)
                lines.append("")
                lines.append(
                    f"Last scan: {self._scan_cache.risk_level.upper()} "
                    f"(score {self._scan_cache.risk_score}/100, "
                    f"{age}s ago)"
                )

        # Sentinel AV integration
        lines.append("")
        try:
            from sysfixai.sentinel_av import av_status
            avs = av_status()
            if avs.get("running"):
                lines.append("✓ Sentinel AV engine: ACTIVE")
                lines.append(
                    f"  Threats: {avs.get('threat_count', 0)} detected, "
                    f"{avs.get('neutralised', 0)} neutralised"
                )
            else:
                lines.append(
                    "● Sentinel AV engine: stopped "
                    "(requires root + python3-bcc)"
                )
        except ImportError:
            lines.append("● Sentinel AV module not available.")

        return "\n".join(lines)

    # ── PAID-TIER: auto_kill_threat ───────────────────────────────

    def auto_kill_threat(self, pid: int = 0, **kwargs) -> str:
        """Kill/freeze a malicious process — ADVANCED TIER.

        Freezes the process using cgroups v2, then terminates it.
        Free-tier users receive an upgrade prompt.

        Args:
            pid: Process ID to neutralise.
        """
        _require_paid("auto_kill")

        if pid <= 0:
            return "Error: valid PID required."

        if not _is_root():
            return (
                "⚠ Auto-Kill requires root privileges. "
                "Relaunch Sysfix with sudo."
            )

        # Verify the process exists
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return f"PID {pid} no longer exists."
        except PermissionError:
            return f"Permission denied for PID {pid}."

        # Try to freeze first (graceful)
        frozen = False
        try:
            from sysfixai.sentinel_av import freeze_process
            ok, msg = freeze_process(pid)
            frozen = ok
        except ImportError:
            pass

        if not frozen:
            try:
                os.kill(pid, signal.SIGSTOP)
                frozen = True
            except (ProcessLookupError, PermissionError) as e:
                return f"Failed to stop PID {pid}: {e}"

        # Now kill
        try:
            os.kill(pid, signal.SIGKILL)
            return (
                f"✓ PID {pid} has been neutralised "
                f"({'frozen + killed' if frozen else 'killed'})."
            )
        except ProcessLookupError:
            return f"PID {pid} exited during neutralisation."
        except PermissionError:
            return f"Permission denied killing PID {pid}."

    # ── PAID-TIER: quarantine_file ────────────────────────────────

    def quarantine_file(self, path: str = "", **kwargs) -> str:
        """Move a suspicious file to quarantine — ADVANCED TIER.

        Moves the file to ~/.config/sysfix/quarantine/ with a
        .quarantine extension, recording metadata for forensics.

        Args:
            path: File path to quarantine.
        """
        _require_paid("quarantine_file")

        if not path:
            return "Error: file path required."

        src = Path(os.path.expanduser(path))
        if not src.exists():
            return f"File not found: {path}"

        try:
            from sysfixai.config import CONFIG_DIR
            qdir = CONFIG_DIR / "quarantine"
        except ImportError:
            qdir = Path.home() / ".config" / "sysfix" / "quarantine"

        qdir.mkdir(parents=True, exist_ok=True)

        # Hash the file
        sha256 = hashlib.sha256()
        try:
            with open(src, "rb") as f:
                while chunk := f.read(65536):
                    sha256.update(chunk)
        except Exception as e:
            return f"Cannot read file: {e}"

        file_hash = sha256.hexdigest()
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        dest = qdir / f"{src.name}_{ts}_{file_hash[:12]}.quarantine"

        # Move
        try:
            shutil.move(str(src), str(dest))
        except Exception as e:
            return f"Quarantine failed: {e}"

        # Write metadata
        meta = {
            "original_path": str(src),
            "quarantine_path": str(dest),
            "sha256": file_hash,
            "timestamp": ts,
            "size_bytes": dest.stat().st_size,
        }
        meta_path = dest.with_suffix(".meta.json")
        meta_path.write_text(json.dumps(meta, indent=2))

        return (
            f"✓ File quarantined:\n"
            f"  From: {src}\n"
            f"  To:   {dest}\n"
            f"  SHA-256: {file_hash}"
        )

    # ── Formatting helpers ────────────────────────────────────────

    @staticmethod
    def _format_scan_result(result: ScanResult) -> str:
        """Format a ScanResult into human-readable text for the AI."""
        lines: List[str] = [
            "═══ SENTINEL SECURITY SCAN ═══",
            "",
            result.summary,
            "",
        ]

        risk_icons = {
            "clean": "✅", "low": "🟢", "medium": "🟡",
            "high": "🟠", "critical": "🔴",
        }
        lines.append(
            f"Overall: {risk_icons.get(result.risk_level, '⚪')} "
            f"{result.risk_level.upper()} (score {result.risk_score}/100)"
        )
        lines.append(f"Tier:    {result.tier}")
        lines.append(f"Root:    {'yes' if result.is_root else 'no'}")
        lines.append("")

        # Suspicious processes
        if result.suspicious_processes:
            lines.append(
                f"⚠ Suspicious processes ({len(result.suspicious_processes)}):"
            )
            for p in result.suspicious_processes[:10]:
                risk = p.get("risk_score", 0)
                sev = "🔴" if risk >= 50 else (
                    "🟠" if risk >= 30 else "🟡"
                )
                comm = p.get("comm", "?")
                pid = p.get("pid", "?")
                lines.append(f"  {sev} PID {pid} — {comm} (risk {risk})")
                for f in p.get("risk_factors", [])[:3]:
                    lines.append(f"      ⚠ {f}")
            if len(result.suspicious_processes) > 10:
                lines.append(
                    f"  ... and {len(result.suspicious_processes) - 10} more"
                )
            lines.append("")

        # Suspicious connections
        if result.suspicious_connections:
            lines.append(
                f"⚠ Suspicious connections ({len(result.suspicious_connections)}):"
            )
            for c in result.suspicious_connections[:10]:
                comm = c.get("comm", "?")
                lines.append(
                    f"  🔴 {c.get('proto','?')} "
                    f"{c.get('remote_addr','?')}:{c.get('remote_port','?')} "
                    f"← PID {c.get('pid','?')} ({comm})"
                )
                for f in c.get("risk_factors", [])[:2]:
                    lines.append(f"      ⚠ {f}")
            lines.append("")

        # Temp executables
        if result.tmp_executables:
            lines.append(
                f"⚠ Executables in volatile paths ({len(result.tmp_executables)}):"
            )
            for f in result.tmp_executables[:10]:
                lines.append(f"  📁 {f}")
            lines.append("")

        # Listening services
        if result.listening_services:
            lines.append(
                f"Listening services ({len(result.listening_services)}):"
            )
            for svc in result.listening_services[:10]:
                lines.append(
                    f"  • {svc['proto']} {svc['address']} "
                    f"{svc.get('process', '')}"
                )
            lines.append("")

        # Clean report
        if result.risk_level == "clean":
            lines.append("✅ System appears clean — no threats detected.")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_bridge_instance: Optional[SentinelBridge] = None
_bridge_lock = threading.Lock()


def get_bridge() -> SentinelBridge:
    """Return the singleton SentinelBridge instance."""
    global _bridge_instance
    with _bridge_lock:
        if _bridge_instance is None:
            _bridge_instance = SentinelBridge()
        return _bridge_instance


# ---------------------------------------------------------------------------
# Tool registration — makes the Sentinel visible to the AI
# ---------------------------------------------------------------------------

def register_sentinel_tools() -> int:
    """Register SentinelBridge methods as AI-callable tools.

    Called at module import and also on-demand by the reasoning loop.
    Returns the number of tools registered.
    """
    try:
        from sysfixai.tool_calling import register_tool
    except ImportError:
        return 0

    bridge = get_bridge()
    count = 0

    # ── Free-tier tools ──────────────────────────────────────────

    register_tool(
        "read_only_ebpf_scan",
        (
            "Run a comprehensive read-only security scan of the system. "
            "Scans all running processes for malware patterns (crypto miners, "
            "reverse shells, fileless malware, /tmp execution), checks "
            "network connections for C2/backdoor ports, finds executables "
            "in volatile paths, and reports listening services. "
            "Returns a threat report with risk score (0-100). "
            "ALWAYS AVAILABLE — works in free tier without root."
        ),
        {"type": "object", "properties": {}, "required": []},
        lambda **kw: bridge.read_only_ebpf_scan(**kw),
    )
    count += 1

    register_tool(
        "scan_process_anomalies",
        (
            "Focused scan for suspicious processes: crypto miners, "
            "reverse shells, deleted-binary execution, excessive file "
            "descriptors, offline-app network violations. "
            "ALWAYS AVAILABLE — works in free tier."
        ),
        {"type": "object", "properties": {}, "required": []},
        lambda **kw: bridge.scan_process_anomalies(**kw),
    )
    count += 1

    register_tool(
        "check_network_threats",
        (
            "Scan network connections for threats: C2/backdoor ports, "
            "offline-app violations, suspicious endpoints. Also reports "
            "all listening services. "
            "ALWAYS AVAILABLE — works in free tier."
        ),
        {"type": "object", "properties": {}, "required": []},
        lambda **kw: bridge.check_network_threats(**kw),
    )
    count += 1

    register_tool(
        "get_sentinel_status",
        (
            "Get the Sentinel security engine status: capability tier, "
            "active eBPF probes, available tools (free vs advanced), "
            "last scan results, and Sentinel AV integration state."
        ),
        {"type": "object", "properties": {}, "required": []},
        lambda **kw: bridge.get_sentinel_status(**kw),
    )
    count += 1

    # ── Paid-tier tools (registered so AI knows they exist) ──────

    register_tool(
        "auto_kill_threat",
        (
            "ADVANCED TIER — Freeze and kill a malicious process by PID. "
            "Uses cgroups v2 freezer then SIGKILL. Requires root. "
            "Free-tier users should use read_only_ebpf_scan() to "
            "identify threats and report them to the user instead."
        ),
        {
            "type": "object",
            "properties": {
                "pid": {
                    "type": "integer",
                    "description": "PID of the malicious process to kill",
                },
            },
            "required": ["pid"],
        },
        lambda pid=0, **kw: bridge.auto_kill_threat(pid=pid, **kw),
    )
    count += 1

    register_tool(
        "quarantine_file",
        (
            "ADVANCED TIER — Move a suspicious file to quarantine. "
            "Hashes the file (SHA-256), moves it to a safe directory, "
            "and records forensic metadata. "
            "Free-tier users should report suspicious files to the user."
        ),
        {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path of the suspicious file to quarantine",
                },
            },
            "required": ["path"],
        },
        lambda path="", **kw: bridge.quarantine_file(path=path, **kw),
    )
    count += 1

    return count


# ---------------------------------------------------------------------------
# Convenience API
# ---------------------------------------------------------------------------

def sentinel_bridge_status() -> Dict[str, Any]:
    """Return bridge capabilities as a dict."""
    return get_bridge().capabilities


def sentinel_bridge_report() -> List[str]:
    """Human-readable capability report lines."""
    return get_bridge().get_sentinel_status().splitlines()


def read_only_ebpf_scan() -> str:
    """Run a read-only security scan (convenience wrapper)."""
    return get_bridge().read_only_ebpf_scan()


def scan_process_anomalies() -> str:
    """Run a process anomaly scan (convenience wrapper)."""
    return get_bridge().scan_process_anomalies()


def check_network_threats() -> str:
    """Run a network threat scan (convenience wrapper)."""
    return get_bridge().check_network_threats()


# ---------------------------------------------------------------------------
# AI prompt injection — tells the model about the Sentinel
# ---------------------------------------------------------------------------

def get_sentinel_prompt_block() -> str:
    """Generate a prompt block telling the AI about Sentinel capabilities.

    This is injected into the system prompt so the local Ollama model
    (Qwen2.5-Coder) knows the Sentinel exists and can be used.
    """
    bridge = get_bridge()
    caps = bridge.capabilities
    paid = _is_paid_tier()

    block = (
        "\n--- SENTINEL SECURITY ENGINE ---\n"
        "You have access to the Sysfix Sentinel — a real-time security scanner.\n"
        "You CAN and SHOULD use these tools when the user asks about security,\n"
        "threats, suspicious processes, or network safety:\n\n"
        "FREE tools (always available, call them anytime):\n"
        "  • read_only_ebpf_scan — full system security scan (processes + network + files)\n"
        "  • scan_process_anomalies — check for malware, miners, reverse shells\n"
        "  • check_network_threats — check for C2 connections, suspicious ports\n"
        "  • get_sentinel_status — engine health and capability report\n\n"
    )

    if paid:
        block += (
            "ADVANCED tools (unlocked — Sysfix Pro tier):\n"
            "  • auto_kill_threat(pid) — freeze/kill malicious process\n"
            "  • quarantine_file(path) — quarantine suspicious file\n\n"
        )
    else:
        block += (
            "ADVANCED tools (locked — requires Sysfix Pro upgrade):\n"
            "  • auto_kill_threat(pid) — 🔒 requires Sysfix Pro\n"
            "  • quarantine_file(path) — 🔒 requires Sysfix Pro\n"
            "  If the user asks you to kill a threat, explain that Sentinel Auto-Fix\n"
            "  is an Advanced feature, but you CAN scan and identify threats for free.\n"
            "  Note: Sysfix Pro unlocks higher-tier local reasoning and\n"
            "  Sentinel Auto-Fix capabilities. No third-party API subscriptions required.\n\n"
        )

    block += (
        f"Current tier: {caps['tier']} | "
        f"Root: {'yes' if caps['is_root'] else 'no'} | "
        f"ebpfcat: {'yes' if caps['ebpfcat_available'] else 'no (using /proc fallback)'}\n"
        "The Sentinel is AVAILABLE and FUNCTIONAL. Use it.\n"
        "---\n"
    )

    return block


# ---------------------------------------------------------------------------
# Auto-register tools on import
# ---------------------------------------------------------------------------

_check_ebpfcat()  # probe for library at import time
register_sentinel_tools()
