"""
Smart launcher for Sysfix - routes to GUI or CLI based on command.
"""

import sys
import os


def can_launch_gui():
    """Check if GUI can be launched (X server available)."""
    # Try to import tkinter - if it fails, GUI can't work
    try:
        import tkinter
        # Try to create a test window to verify X server is available
        # This is done in a try-except to catch display-related errors
        root = tkinter.Tk()
        root.destroy()
        return True
    except Exception as e:
        # Any error (import, display, etc.) means GUI won't work
        return False


def launch_gui():
    """Launch the GUI directly in this process."""
    try:
        from sysfixai.gui import main
        main()
    except Exception as e:
        print(f"GUI launch failed: {e}", file=sys.stderr)
        print("Tip: run 'sysfix interactive' for terminal mode.", file=sys.stderr)
        sys.exit(1)


def launch_cli(args):
    """Launch the CLI with given arguments."""
    # Inject command name as first arg for Click
    sys.argv = ['sysfix'] + args
    try:
        from sysfixai.cli import cli
        cli()
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        sys.exit(0)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def show_help():
    """Show usage help."""
    print("\n" + "="*60)
    print("  SYSFIX-AI v1.0.0 — Powered by Fyxa AI")
    print("="*60 + "\n")
    print("USAGE:\n")
    print("  sysfix [MODE] [COMMAND]\n")
    print("MODES:\n")
    print("  (none)       Launch GUI (if DISPLAY available)")
    print("  gui          Explicitly launch GUI")
    print("  terminal     Launch terminal/CLI interface")
    print("  cli          Alias for terminal\n")
    print("COMMANDS:\n")
    print("  check        Run system diagnostics")
    print("  run          Quick scan and fix with AI")
    print("  status       Quick health summary")
    print("  security     Full security audit")
    print("  network      Network diagnostics")
    print("  health       System health (boot, systemd, SMART)")
    print("  scan <path>  Virus/malware hash scan")
    print("  update       Check & apply updates")
    print("  chat         Interactive Fyxa AI conversation")
    print("  brain        Brain/memory management")
    print("  interactive  Full interactive menu")
    print("  version      Version info")
    print("  --help       Show all help\n")
    print("EXAMPLES:\n")
    print("  sysfix              # Launch GUI")
    print("  sysfix gui          # Force GUI")
    print("  sysfix terminal     # Force terminal mode")
    print("  sysfix check        # Run diagnostics")
    print("  sysfix chat         # Talk to Fyxa")
    print("  sysfix security     # Security audit")
    print("  sysfix scan --downloads   # Scan Downloads for malware")
    print("  sysfix brain stats  # Brain statistics")
    print("  sudo sysfix check   # Elevated diagnostics\n")
    print("="*60 + "\n")


def main():
    """Main entry point - routes to GUI or CLI."""
    # Check if running under sudo
    is_sudo = os.environ.get('SUDO_USER') is not None
    
    # No arguments - default behavior
    if len(sys.argv) == 1:
        if can_launch_gui():
            # Launch GUI if display is available (works under sudo too)
            launch_gui()
        elif is_sudo:
            launch_cli(['status'])
        else:
            # Default to running diagnostics if no GUI available
            launch_cli(['check'])
        return
    
    # Get first argument
    first_arg = sys.argv[1].lower()
    
    # Explicit GUI launch
    if first_arg == 'gui':
        launch_gui()
        return
    
    # Explicit CLI/terminal launch
    if first_arg in ('terminal', 'cli'):
        # Remove 'terminal'/'cli' from args, pass rest to CLI
        remaining_args = sys.argv[2:] if len(sys.argv) > 2 else []
        launch_cli(remaining_args)
        return
    
    # Everything else goes to CLI (backward compatibility)
    # This allows: sysfix check, sysfix interactive, etc.
    launch_cli(sys.argv[1:])


if __name__ == "__main__":
    main()
