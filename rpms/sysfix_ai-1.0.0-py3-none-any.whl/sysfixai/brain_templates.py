"""
Hardcoded brain templates — deterministic command sequences for common tasks.

This provides safe, tested command templates for tasks where automation must
be precise (e.g., installing Wine). plan_and_execute will consult these
templates before asking the LLM, improving reliability.
"""
from typing import List, Dict, Any
import shutil


def _detect_package_manager() -> str:
    if shutil.which("dnf"):
        return "dnf"
    if shutil.which("apt"):
        return "apt"
    if shutil.which("pacman"):
        return "pacman"
    if shutil.which("zypper"):
        return "zypper"
    return "unknown"


def get_template(key: str, context: Dict[str, Any] = None) -> List[str]:
    """Return a list of shell commands for the given template key.

    Returns empty list if no template matches.
    """
    ctx = context or {}
    pm = ctx.get("package_manager") or _detect_package_manager()

    if key == "install_wine":
        # Safe, idempotent template: prefer distro package, otherwise build from tarball
        cmds: List[str] = []
        if pm == "dnf":
            cmds = [
                "sudo dnf -y install wine",
            ]
        elif pm == "apt":
            cmds = [
                "sudo dpkg --add-architecture i386 || true",
                "sudo apt update",
                "sudo apt -y install wine64 wine32",
            ]
        elif pm == "pacman":
            cmds = [
                "sudo pacman -Syu --noconfirm wine",
            ]
        elif pm == "zypper":
            cmds = [
                "sudo zypper refresh",
                "sudo zypper -n install wine",
            ]
        else:
            # Fallback to building from Downloads if package manager unknown
            cmds = [
                "if [ -f ~/Downloads/wine-11.2.tar.xz ]; then",
                "  tar xf ~/Downloads/wine-11.2.tar.xz -C ~/Downloads",
                "fi",
                "cd ~/Downloads/wine-11.2 || exit 1",
                "./configure --prefix=/usr/local || exit 1",
                "make -j$(nproc) || exit 1",
                "sudo make install || exit 1",
            ]

        # If user provided path in context, prefer it
        if ctx.get("download_path"):
            path = ctx["download_path"].rstrip("/")
            # Use local install if it's an rpm or deb
            if path.endswith(".rpm") and pm in ("dnf", "zypper"):
                return [f"sudo {pm} -y install {path}"]
            if path.endswith(".deb") and pm == "apt":
                return [f"sudo dpkg -i {path} || sudo apt -f install -y"]
            if path.endswith(".tar.xz") or path.endswith(".tar.gz"):
                return [
                    f"tar xf {path} -C /tmp",
                    f"cd /tmp/$(basename {path} .tar.xz) || true",
                    "./configure --prefix=/usr/local || exit 1",
                    "make -j$(nproc) || exit 1",
                    "sudo make install || exit 1",
                ]

        return cmds

    if key == "update_system":
        if pm == "dnf":
            return ["sudo dnf -y upgrade --refresh"]
        if pm == "apt":
            return ["sudo apt update", "sudo apt -y upgrade"]
        if pm == "pacman":
            return ["sudo pacman -Syu --noconfirm"]
        if pm == "zypper":
            return ["sudo zypper refresh", "sudo zypper -n update"]
        return ["echo 'Unknown package manager; please update manually.'"]

    if key == "restart_service":
        svc = ctx.get("service") or ""
        if svc:
            return [f"sudo systemctl restart {svc}", f"sudo systemctl status {svc} --no-pager"]
        return []

    if key == "install_python_packages":
        pkgs = ctx.get("packages") or []
        if not pkgs:
            return []
        return [f"python3 -m pip install {' '.join(pkgs)}"]
    return []
