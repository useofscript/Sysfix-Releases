"""
UI Enhancements — CustomTkinter compatibility + spring physics animations.

CustomTkinter
~~~~~~~~~~~~~
If ``customtkinter`` is installed, Sysfix can use CTk widgets for a
modern look (rounded corners, built-in dark mode, smooth scaling).
This module provides a thin compatibility layer: if CTk is available
the enhanced widgets are used; otherwise standard tkinter widgets are
returned so gui.py keeps working either way.

Install:  pip install customtkinter

Spring Physics
~~~~~~~~~~~~~~
Adds physics-based spring animations to any tkinter widget property.
Uses a simple Hooke's law spring simulation (no external dependency
required, but can optionally use ``pymunk`` for richer physics).

Usage::

    from sysfixai.ui_enhancements import SpringAnimator, UIPhysics

    anim = SpringAnimator(widget, "x", target=300, stiffness=180, damping=12)
    anim.start()

    # Or simpler:
    UIPhysics.spring_move(widget, target_x=300, target_y=100)
"""

from __future__ import annotations

import math
import time
import tkinter as tk
from tkinter import ttk
from typing import Any, Callable, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# CustomTkinter detection & compatibility
# ---------------------------------------------------------------------------

_HAS_CTK = False
_ctk = None

def _ensure_ctk() -> bool:
    """Try to import customtkinter."""
    global _HAS_CTK, _ctk
    if _HAS_CTK:
        return True
    try:
        import customtkinter as ctk  # type: ignore[import-untyped]
        _ctk = ctk
        _HAS_CTK = True
        return True
    except ImportError:
        return False

# Try on module load
_ensure_ctk()


def has_customtkinter() -> bool:
    """Return True if CustomTkinter is available."""
    return _HAS_CTK


def get_ctk_module():
    """Return the customtkinter module (or None)."""
    _ensure_ctk()
    return _ctk


# ---------------------------------------------------------------------------
# Widget factory — returns CTk widgets when available, tk otherwise
# ---------------------------------------------------------------------------

class WidgetFactory:
    """
    Factory that returns the best available widget class.

    Example::

        wf = WidgetFactory()
        root = wf.Window()
        btn  = wf.Button(root, text="Hello", command=cb)
        lbl  = wf.Label(root, text="Status")
    """

    def __init__(self, prefer_ctk: bool = True):
        self._use_ctk = prefer_ctk and _HAS_CTK

    @property
    def using_ctk(self) -> bool:
        return self._use_ctk

    # -- Main window -------------------------------------------------------

    def Window(self, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTk(**kw)
        return tk.Tk(**kw)

    def Toplevel(self, parent=None, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTkToplevel(parent, **kw)
        return tk.Toplevel(parent, **kw)

    # -- Containers --------------------------------------------------------

    def Frame(self, parent, **kw) -> Any:
        if self._use_ctk:
            kw = _remap_ctk_frame(kw)
            return _ctk.CTkFrame(parent, **kw)
        return tk.Frame(parent, **kw)

    def ScrollableFrame(self, parent, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTkScrollableFrame(parent, **kw)
        # Fallback: plain frame (caller manages scrolling)
        return tk.Frame(parent, **kw)

    # -- Widgets -----------------------------------------------------------

    def Button(self, parent, **kw) -> Any:
        if self._use_ctk:
            kw = _remap_ctk_button(kw)
            return _ctk.CTkButton(parent, **kw)
        return tk.Button(parent, **kw)

    def Label(self, parent, **kw) -> Any:
        if self._use_ctk:
            kw = _remap_ctk_label(kw)
            return _ctk.CTkLabel(parent, **kw)
        return tk.Label(parent, **kw)

    def Entry(self, parent, **kw) -> Any:
        if self._use_ctk:
            kw = _remap_ctk_entry(kw)
            return _ctk.CTkEntry(parent, **kw)
        return tk.Entry(parent, **kw)

    def Textbox(self, parent, **kw) -> Any:
        if self._use_ctk:
            kw = _remap_ctk_textbox(kw)
            return _ctk.CTkTextbox(parent, **kw)
        from tkinter import scrolledtext
        return scrolledtext.ScrolledText(parent, **kw)

    def ProgressBar(self, parent, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTkProgressBar(parent, **kw)
        return ttk.Progressbar(parent, **kw)

    def Switch(self, parent, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTkSwitch(parent, **kw)
        # Fallback: Checkbutton
        return ttk.Checkbutton(parent, **kw)

    def Slider(self, parent, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTkSlider(parent, **kw)
        return ttk.Scale(parent, **kw)

    def TabView(self, parent, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTkTabview(parent, **kw)
        return ttk.Notebook(parent, **kw)

    def OptionMenu(self, parent, variable, values, **kw) -> Any:
        if self._use_ctk:
            return _ctk.CTkOptionMenu(parent, variable=variable, values=values, **kw)
        return ttk.Combobox(parent, textvariable=variable, values=values, **kw)


# ---------------------------------------------------------------------------
# Keyword remapping helpers (tk kwargs → CTk kwargs)
# ---------------------------------------------------------------------------

def _remap_ctk_frame(kw: dict) -> dict:
    """Translate tk.Frame kwargs to CTkFrame kwargs."""
    out: dict = {}
    for k, v in kw.items():
        if k == "bg" or k == "background":
            out["fg_color"] = v
        elif k == "highlightthickness" or k == "bd" or k == "borderwidth":
            out["border_width"] = int(v)
        elif k == "relief":
            continue  # CTk doesn't use relief
        elif k == "padx":
            continue  # handled by pack/grid
        elif k == "pady":
            continue
        else:
            out[k] = v
    return out


def _remap_ctk_button(kw: dict) -> dict:
    """Translate tk.Button kwargs to CTkButton kwargs."""
    out: dict = {}
    for k, v in kw.items():
        if k == "bg" or k == "background":
            out["fg_color"] = v
        elif k == "fg" or k == "foreground":
            out["text_color"] = v
        elif k == "font":
            out["font"] = v
        elif k == "text":
            out["text"] = v
        elif k == "command":
            out["command"] = v
        elif k in ("relief", "bd", "borderwidth", "highlightthickness",
                    "overrelief", "cursor"):
            continue
        elif k == "activebackground":
            out["hover_color"] = v
        elif k == "activeforeground":
            continue
        elif k in ("padx", "pady"):
            continue
        elif k == "state":
            if v == "disabled":
                out["state"] = "disabled"
        else:
            out[k] = v
    return out


def _remap_ctk_label(kw: dict) -> dict:
    """Translate tk.Label kwargs to CTkLabel kwargs."""
    out: dict = {}
    for k, v in kw.items():
        if k == "bg" or k == "background":
            out["fg_color"] = v
        elif k == "fg" or k == "foreground":
            out["text_color"] = v
        elif k == "font":
            out["font"] = v
        elif k == "text":
            out["text"] = v
        elif k in ("relief", "bd", "borderwidth", "highlightthickness",
                    "anchor", "justify", "wraplength"):
            out[k] = v if k in ("anchor", "justify", "wraplength") else None
            if out.get(k) is None:
                del out[k]
        elif k in ("padx", "pady"):
            continue
        else:
            out[k] = v
    return out


def _remap_ctk_entry(kw: dict) -> dict:
    """Translate tk.Entry kwargs to CTkEntry kwargs."""
    out: dict = {}
    for k, v in kw.items():
        if k == "bg" or k == "background":
            out["fg_color"] = v
        elif k == "fg" or k == "foreground":
            out["text_color"] = v
        elif k == "font":
            out["font"] = v
        elif k == "insertbackground":
            continue
        elif k in ("relief", "bd", "borderwidth", "highlightthickness"):
            continue
        elif k == "show":
            out["show"] = v
        else:
            out[k] = v
    return out


def _remap_ctk_textbox(kw: dict) -> dict:
    """Translate ScrolledText kwargs to CTkTextbox kwargs."""
    out: dict = {}
    for k, v in kw.items():
        if k == "bg" or k == "background":
            out["fg_color"] = v
        elif k == "fg" or k == "foreground":
            out["text_color"] = v
        elif k == "font":
            out["font"] = v
        elif k in ("relief", "bd", "borderwidth", "highlightthickness",
                    "insertbackground", "wrap"):
            if k == "wrap":
                out["wrap"] = v
        else:
            out[k] = v
    return out


# ---------------------------------------------------------------------------
# Spring Physics Animation Engine
# ---------------------------------------------------------------------------

class Spring:
    """
    Hooke's law spring simulation for smooth UI animations.

    Simulates a damped spring: F = -kx - cv
    where k=stiffness, c=damping, x=displacement, v=velocity.
    """

    def __init__(self, stiffness: float = 180.0, damping: float = 12.0,
                 mass: float = 1.0, precision: float = 0.5):
        """
        Args:
            stiffness: Spring constant k (higher = snappier).
            damping:   Damping coefficient c (higher = less oscillation).
            mass:      Mass of the animated object.
            precision: Stop threshold — animation ends when displacement
                       is below this value.
        """
        self.stiffness = stiffness
        self.damping = damping
        self.mass = mass
        self.precision = precision

    def simulate(self, current: float, target: float, velocity: float,
                 dt: float) -> Tuple[float, float, bool]:
        """
        Advance the spring simulation by dt seconds.

        Returns:
            (new_position, new_velocity, is_settled)
        """
        displacement = current - target
        # Hooke's law + damping
        force = -self.stiffness * displacement - self.damping * velocity
        acceleration = force / self.mass
        velocity += acceleration * dt
        position = current + velocity * dt

        # Check if settled
        settled = (abs(displacement) < self.precision and
                   abs(velocity) < self.precision)
        if settled:
            position = target
            velocity = 0.0

        return position, velocity, settled


class SpringAnimator:
    """
    Animates a numeric widget property using spring physics.

    Usage::

        anim = SpringAnimator(widget, "winfo_x", target=300)
        anim.start()  # runs via tkinter after() loop
    """

    _FPS = 60
    _DT = 1.0 / _FPS

    def __init__(self, widget: tk.Widget, prop: str, target: float,
                 spring: Optional[Spring] = None,
                 on_update: Optional[Callable[[float], None]] = None,
                 on_complete: Optional[Callable[[], None]] = None):
        self.widget = widget
        self.prop = prop
        self.target = target
        self.spring = spring or Spring()
        self._on_update = on_update
        self._on_complete = on_complete
        self._velocity = 0.0
        self._current: Optional[float] = None
        self._running = False
        self._after_id: Optional[str] = None

    def start(self, from_value: Optional[float] = None) -> None:
        """Start the spring animation."""
        if self._running:
            self.stop()
        self._current = from_value if from_value is not None else self._get_current()
        self._velocity = 0.0
        self._running = True
        self._tick()

    def stop(self) -> None:
        """Stop the animation."""
        self._running = False
        if self._after_id:
            try:
                self.widget.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None

    def _get_current(self) -> float:
        """Read the current value of the property."""
        try:
            if self.prop == "x":
                return float(self.widget.winfo_x())
            elif self.prop == "y":
                return float(self.widget.winfo_y())
            elif self.prop == "width":
                return float(self.widget.winfo_width())
            elif self.prop == "height":
                return float(self.widget.winfo_height())
            elif self.prop == "alpha":
                return float(self.widget.attributes("-alpha"))
            else:
                return 0.0
        except Exception:
            return 0.0

    def _apply(self, value: float) -> None:
        """Apply the value to the widget."""
        if self._on_update:
            self._on_update(value)
            return

        try:
            if self.prop in ("x", "y"):
                x = value if self.prop == "x" else self.widget.winfo_x()
                y = value if self.prop == "y" else self.widget.winfo_y()
                self.widget.place(x=int(x), y=int(y))
            elif self.prop == "width":
                self.widget.configure(width=int(value))
            elif self.prop == "height":
                self.widget.configure(height=int(value))
            elif self.prop == "alpha":
                self.widget.attributes("-alpha", max(0.0, min(1.0, value)))
        except Exception:
            self.stop()

    def _tick(self) -> None:
        if not self._running:
            return
        if self._current is None:
            self._current = self._get_current()

        self._current, self._velocity, settled = self.spring.simulate(
            self._current, self.target, self._velocity, self._DT,
        )
        self._apply(self._current)

        if settled:
            self._running = False
            if self._on_complete:
                self._on_complete()
        else:
            try:
                self._after_id = self.widget.after(
                    int(1000 / self._FPS), self._tick
                )
            except Exception:
                self._running = False


# ---------------------------------------------------------------------------
# High-level UI physics helpers
# ---------------------------------------------------------------------------

class UIPhysics:
    """Convenience methods for common UI animations."""

    @staticmethod
    def spring_move(widget: tk.Widget, target_x: Optional[float] = None,
                    target_y: Optional[float] = None,
                    stiffness: float = 180, damping: float = 14,
                    on_complete: Optional[Callable] = None) -> List[SpringAnimator]:
        """Animate a widget to a new position with spring physics."""
        anims: List[SpringAnimator] = []
        spring = Spring(stiffness=stiffness, damping=damping)

        if target_x is not None:
            a = SpringAnimator(widget, "x", target_x, spring=spring,
                               on_complete=on_complete)
            a.start()
            anims.append(a)

        if target_y is not None:
            a = SpringAnimator(widget, "y", target_y, spring=spring)
            a.start()
            anims.append(a)

        return anims

    @staticmethod
    def spring_scale(widget: tk.Widget, target_scale: float = 1.02,
                     duration_ms: int = 150, stiffness: float = 300,
                     damping: float = 15) -> Optional[SpringAnimator]:
        """Scale a widget up/down with spring bounce (hover effect)."""
        try:
            current_w = widget.winfo_width()
            current_h = widget.winfo_height()
            target_w = int(current_w * target_scale)

            def on_update(val):
                try:
                    widget.configure(width=int(val))
                except Exception:
                    pass

            spring = Spring(stiffness=stiffness, damping=damping)
            anim = SpringAnimator(widget, "width", target_w, spring=spring,
                                  on_update=on_update)
            anim.start(from_value=current_w)
            return anim
        except Exception:
            return None

    @staticmethod
    def hover_bounce(widget: tk.Widget, scale: float = 1.02) -> None:
        """Add spring-bounce hover effect to a widget."""
        original_font = None
        try:
            original_font = widget.cget("font")
        except Exception:
            pass

        def on_enter(e):
            UIPhysics.spring_scale(widget, target_scale=scale)

        def on_leave(e):
            UIPhysics.spring_scale(widget, target_scale=1.0)

        widget.bind("<Enter>", on_enter, add=True)
        widget.bind("<Leave>", on_leave, add=True)

    @staticmethod
    def fade_in(widget: tk.Widget, duration_ms: int = 300,
                stiffness: float = 120, damping: float = 15) -> Optional[SpringAnimator]:
        """Fade a Toplevel widget in with spring physics."""
        try:
            widget.attributes("-alpha", 0.0)
            spring = Spring(stiffness=stiffness, damping=damping)
            anim = SpringAnimator(widget, "alpha", 1.0, spring=spring)
            anim.start(from_value=0.0)
            return anim
        except Exception:
            return None

    @staticmethod
    def fade_out(widget: tk.Widget, on_complete: Optional[Callable] = None,
                 stiffness: float = 120, damping: float = 15) -> Optional[SpringAnimator]:
        """Fade a Toplevel widget out with spring physics."""
        try:
            spring = Spring(stiffness=stiffness, damping=damping)
            anim = SpringAnimator(widget, "alpha", 0.0, spring=spring,
                                  on_complete=on_complete)
            anim.start(from_value=float(widget.attributes("-alpha")))
            return anim
        except Exception:
            return None

    @staticmethod
    def slide_in(widget: tk.Widget, direction: str = "right",
                 distance: int = 50, stiffness: float = 180,
                 damping: float = 14) -> Optional[SpringAnimator]:
        """Slide a widget in from a direction with spring bounce."""
        try:
            target_x = widget.winfo_x()
            target_y = widget.winfo_y()

            if direction == "right":
                start_x = target_x + distance
                anim = SpringAnimator(
                    widget, "x", target_x,
                    spring=Spring(stiffness=stiffness, damping=damping),
                )
                anim.start(from_value=start_x)
                return anim
            elif direction == "left":
                start_x = target_x - distance
                anim = SpringAnimator(
                    widget, "x", target_x,
                    spring=Spring(stiffness=stiffness, damping=damping),
                )
                anim.start(from_value=start_x)
                return anim
            elif direction == "down":
                start_y = target_y + distance
                anim = SpringAnimator(
                    widget, "y", target_y,
                    spring=Spring(stiffness=stiffness, damping=damping),
                )
                anim.start(from_value=start_y)
                return anim
            elif direction == "up":
                start_y = target_y - distance
                anim = SpringAnimator(
                    widget, "y", target_y,
                    spring=Spring(stiffness=stiffness, damping=damping),
                )
                anim.start(from_value=start_y)
                return anim
        except Exception:
            return None
        return None


# ---------------------------------------------------------------------------
# Pymunk integration (optional)
# ---------------------------------------------------------------------------

_HAS_PYMUNK = False
_pymunk = None

def _ensure_pymunk() -> bool:
    """Try to import pymunk."""
    global _HAS_PYMUNK, _pymunk
    if _HAS_PYMUNK:
        return True
    try:
        import pymunk  # type: ignore[import-untyped]
        _pymunk = pymunk
        _HAS_PYMUNK = True
        return True
    except ImportError:
        return False


def has_pymunk() -> bool:
    """Return True if pymunk is available."""
    _ensure_pymunk()
    return _HAS_PYMUNK


class PymunkSpring:
    """
    Uses pymunk's 2D physics for richer spring simulations.

    Only used when pymunk is installed — otherwise the pure-Python
    Spring class is used automatically.
    """

    def __init__(self):
        if not _ensure_pymunk():
            raise ImportError("pymunk is not installed. pip install pymunk")
        self._space = _pymunk.Space()
        self._space.gravity = (0, 0)  # No gravity — we're doing UI springs

    def create_spring_body(self, x: float, y: float,
                           target_x: float, target_y: float,
                           stiffness: float = 200, damping: float = 10):
        """
        Create a pymunk body attached to a spring anchor.

        Returns (body, spring_constraint) that can be stepped.
        """
        body = _pymunk.Body(1, _pymunk.moment_for_circle(1, 0, 5))
        body.position = (x, y)
        self._space.add(body)

        anchor = _pymunk.Body(body_type=_pymunk.Body.STATIC)
        anchor.position = (target_x, target_y)
        self._space.add(anchor)

        spring = _pymunk.DampedSpring(
            body, anchor, (0, 0), (0, 0),
            rest_length=0,
            stiffness=stiffness,
            damping=damping,
        )
        self._space.add(spring)

        return body, spring

    def step(self, dt: float = 1 / 60):
        """Advance the physics simulation."""
        self._space.step(dt)


# ---------------------------------------------------------------------------
# Status / report
# ---------------------------------------------------------------------------

def ui_enhancements_status() -> Dict[str, Any]:
    """Return status of UI enhancement features."""
    return {
        "customtkinter": _HAS_CTK,
        "customtkinter_version": getattr(_ctk, "__version__", "unknown") if _ctk else None,
        "pymunk": has_pymunk(),
        "pymunk_version": getattr(_pymunk, "version", "unknown") if _pymunk else None,
        "spring_physics": True,  # Always available (pure Python)
    }


def ui_enhancements_report() -> List[str]:
    """Human-readable UI enhancements status."""
    lines: List[str] = []
    status = ui_enhancements_status()

    lines.append("=== UI Enhancements ===")
    lines.append("")

    if status["customtkinter"]:
        lines.append(f"✓ CustomTkinter {status['customtkinter_version']} — modern rounded widgets active")
    else:
        lines.append("● CustomTkinter not installed (optional)")
        lines.append("  Install: pip install customtkinter")
        lines.append("  Gives modern rounded corners, built-in dark mode, smooth scaling")

    lines.append("")

    lines.append("✓ Spring Physics — pure Python spring animation engine active")
    lines.append("  Hooke's law: F = -kx - cv (stiffness, damping, mass)")
    lines.append("  Used for: hover effects, panel transitions, fade-ins")

    if status["pymunk"]:
        lines.append(f"✓ pymunk {status['pymunk_version']} — advanced 2D physics available")
    else:
        lines.append("● pymunk not installed (optional, for richer physics)")
        lines.append("  Install: pip install pymunk")

    return lines
