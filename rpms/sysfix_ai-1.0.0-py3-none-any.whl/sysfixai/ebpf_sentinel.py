"""
eBPF Sentinel — zero-day behavioural security for Sysfix.

Uses the BCC (BPF Compiler Collection) Python bindings to attach tiny
eBPF probes to the Linux kernel.  The sentinel monitors:

  • execve() — every new process launch
  • connect() — every outbound network connection
  • open()   — sensitive file access (SSH keys, /etc/shadow, …)

When suspicious activity is detected Fyxa is alerted immediately.

Requirements:
  • python3-bcc (Fedora: dnf install python3-bcc)
  • Root privileges (BPF programs require CAP_BPF / CAP_SYS_ADMIN)

If bcc is not installed or the user is not root, all public functions
degrade gracefully — they return status strings instead of crashing.
"""

from __future__ import annotations

import os
import re
import time
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Optional, Callable

# ---------------------------------------------------------------------------
# Lazy BCC import — the sentinel works in "stub" mode without it.
# ---------------------------------------------------------------------------
_BPF = None
_HAS_BCC = False

def _ensure_bcc() -> bool:
    global _BPF, _HAS_BCC
    if _HAS_BCC:
        return True
    try:
        from bcc import BPF  # type: ignore[import-untyped]
        _BPF = BPF
        _HAS_BCC = True
        return True
    except ImportError:
        return False


# ---------------------------------------------------------------------------
# BPF C source — intentionally minimal to avoid external .c files.
# ---------------------------------------------------------------------------

_BPF_EXECVE_SRC = r"""
#include <uapi/linux/ptrace.h>
#include <linux/sched.h>
#include <linux/fs.h>

struct exec_event_t {
    u32 pid;
    u32 ppid;
    u32 uid;
    char comm[64];
    char filename[256];
};

BPF_PERF_OUTPUT(exec_events);

TRACEPOINT_PROBE(syscalls, sys_enter_execve) {
    struct exec_event_t evt = {};
    u64 pid_tgid = bpf_get_current_pid_tgid();
    evt.pid  = pid_tgid >> 32;
    struct task_struct *task = (struct task_struct *)bpf_get_current_task();
    evt.ppid = task->real_parent->tgid;
    evt.uid  = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    bpf_get_current_comm(&evt.comm, sizeof(evt.comm));
    bpf_probe_read_user_str(&evt.filename, sizeof(evt.filename),
                            (void *)args->filename);
    exec_events.perf_submit(args, &evt, sizeof(evt));
    return 0;
}
"""

_BPF_CONNECT_SRC = r"""
#include <uapi/linux/ptrace.h>
#include <net/sock.h>

struct conn_event_t {
    u32 pid;
    u32 uid;
    u16 dport;
    u32 daddr;
    char comm[64];
};

BPF_PERF_OUTPUT(conn_events);

int trace_connect(struct pt_regs *ctx, struct sock *sk) {
    struct conn_event_t evt = {};
    u64 pid_tgid = bpf_get_current_pid_tgid();
    evt.pid  = pid_tgid >> 32;
    evt.uid  = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    evt.dport = sk->__sk_common.skc_dport;
    evt.daddr = sk->__sk_common.skc_daddr;
    bpf_get_current_comm(&evt.comm, sizeof(evt.comm));
    conn_events.perf_submit(ctx, &evt, sizeof(evt));
    return 0;
}
"""

# ---------------------------------------------------------------------------
# Suspicious-pattern heuristics
# ---------------------------------------------------------------------------

_NOISY_COMMS: set[str] = {
    "systemd", "kworker", "ksoftirqd", "rcu_sched", "rcu_preempt",
    "migration", "idle", "kcompactd", "khugepaged", "kdevtmpfs",
    "watchdog", "thermald", "irqbalance", "dbus-daemon", "dbus-broker",
    "gdbus", "gnome-shell", "Xwayland", "pipewire", "wireplumber",
    "pulseaudio", "at-spi-bus-laun", "at-spi2-regist", "gsd-",
    "ibus-daemon", "ibus-engine", "ibus-portal", "gvfs-",
    "tracker-miner", "evolution-data", "gnome-keyring",
    "ssh-agent", "polkitd", "rtkit-daemon", "upowerd",
    "packagekitd", "fwupd", "abrt-dbus", "chronyd", "NetworkManager",
    "wpa_supplicant", "systemd-journal", "systemd-logind",
    "systemd-oomd", "systemd-resolve", "systemd-timesyn",
    "systemd-udevd", "auditd", "firewalld", "accounts-daemon",
    "colord", "cups", "avahi-daemon", "bluetoothd",
    "sysfix", "python", "python3", "ollama",
}

_SENSITIVE_PATHS: list[re.Pattern[str]] = [
    re.compile(r"/etc/shadow"),
    re.compile(r"/etc/passwd"),
    re.compile(r"/etc/sudoers"),
    re.compile(r"\.ssh/id_"),
    re.compile(r"\.ssh/authorized_keys"),
    re.compile(r"\.gnupg/"),
    re.compile(r"/proc/\d+/mem"),
    re.compile(r"\.bash_history"),
    re.compile(r"\.config/sysfix/brain\.json"),
]

_SUSPICIOUS_FILENAMES: list[re.Pattern[str]] = [
    re.compile(r"\.(sh|py|pl|rb|php)$", re.I),  # interpreters launching scripts
    re.compile(r"/tmp/"),                          # anything from /tmp
    re.compile(r"/dev/shm/"),                      # shared-memory execution
    re.compile(r"\.exe$", re.I),                   # Windows binaries on Linux
]


def _is_noisy(comm: str) -> bool:
    """Return True if this process name is benign OS noise."""
    base = comm.strip().split("/")[-1]
    for n in _NOISY_COMMS:
        if base.startswith(n):
            return True
    return False


# ---------------------------------------------------------------------------
# Alert data structures
# ---------------------------------------------------------------------------

class SentinelAlert:
    """One suspicious event detected by the eBPF sentinel."""

    __slots__ = ("timestamp", "kind", "pid", "ppid", "uid", "comm",
                 "detail", "severity")

    def __init__(self, kind: str, pid: int, comm: str, detail: str,
                 severity: str = "medium", ppid: int = 0, uid: int = 0):
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.kind = kind          # "exec" | "connect" | "file_access"
        self.pid = pid
        self.ppid = ppid
        self.uid = uid
        self.comm = comm
        self.detail = detail
        self.severity = severity  # "low" | "medium" | "high" | "critical"

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__slots__}

    def __repr__(self) -> str:
        return (f"[{self.severity.upper()}] {self.kind}: "
                f"pid={self.pid} comm={self.comm} — {self.detail}")


# ---------------------------------------------------------------------------
# Sentinel engine
# ---------------------------------------------------------------------------

class EBPFSentinel:
    """
    Real-time eBPF-based process / network / file sentinel.

    Usage::

        sentinel = EBPFSentinel()
        sentinel.start()          # runs in a daemon thread
        …
        alerts = sentinel.alerts  # list[SentinelAlert]
        sentinel.stop()

    If BCC is not available **or** we are not root, ``start()`` does nothing
    and ``status()`` returns an explanatory message.
    """

    def __init__(self, on_alert: Optional[Callable[[SentinelAlert], None]] = None):
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._on_alert = on_alert
        self._alerts: list[SentinelAlert] = []
        self._lock = threading.Lock()
        self._bpf_exec = None
        self._bpf_conn = None
        self._known_pids: set[int] = set()
        self._baseline_taken = False

    # -- public API --------------------------------------------------------

    @property
    def alerts(self) -> list[SentinelAlert]:
        with self._lock:
            return list(self._alerts)

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> str:
        """Start the sentinel daemon thread.  Returns a status string."""
        if self.running:
            return "eBPF Sentinel is already running."

        if os.geteuid() != 0:
            return ("⚠ eBPF Sentinel requires root privileges.  "
                    "Relaunch Sysfix with sudo or enable Sudo Mode.")

        if not _ensure_bcc():
            return ("⚠ python3-bcc is not installed.  "
                    "Install it with: sudo dnf install python3-bcc  "
                    "(or apt install python3-bpfcc on Debian/Ubuntu)")

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="ebpf-sentinel"
        )
        self._thread.start()
        return "✓ eBPF Sentinel started — monitoring execve() and connect()."

    def stop(self) -> str:
        """Stop the sentinel."""
        if not self.running:
            return "eBPF Sentinel is not running."
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3)
        self._cleanup()
        return "✓ eBPF Sentinel stopped."

    def status(self) -> dict[str, Any]:
        """Return current sentinel state."""
        return {
            "running": self.running,
            "has_bcc": _HAS_BCC,
            "is_root": os.geteuid() == 0 if hasattr(os, "geteuid") else False,
            "alert_count": len(self._alerts),
            "latest_alerts": [a.to_dict() for a in self._alerts[-10:]],
        }

    def clear_alerts(self) -> None:
        with self._lock:
            self._alerts.clear()

    # -- internal ----------------------------------------------------------

    def _emit(self, alert: SentinelAlert) -> None:
        with self._lock:
            self._alerts.append(alert)
            # Cap history at 500 alerts
            if len(self._alerts) > 500:
                self._alerts = self._alerts[-300:]
        if self._on_alert:
            try:
                self._on_alert(alert)
            except Exception:
                pass

    def _run(self) -> None:
        """Main sentinel loop — runs in a daemon thread."""
        try:
            self._attach_probes()
            self._take_baseline()
            while not self._stop_event.is_set():
                try:
                    if self._bpf_exec:
                        self._bpf_exec.perf_buffer_poll(timeout=100)
                    if self._bpf_conn:
                        self._bpf_conn.perf_buffer_poll(timeout=100)
                except Exception:
                    pass
        except Exception as exc:
            self._emit(SentinelAlert(
                "error", 0, "sentinel",
                f"eBPF Sentinel crashed: {exc}", severity="high",
            ))
        finally:
            self._cleanup()

    def _attach_probes(self) -> None:
        """Load BPF programs and attach to tracepoints / kprobes."""
        if not _BPF:
            return

        # execve tracepoint
        try:
            self._bpf_exec = _BPF(text=_BPF_EXECVE_SRC)
            self._bpf_exec["exec_events"].open_perf_buffer(self._on_exec_event)
        except Exception as exc:
            self._emit(SentinelAlert(
                "error", 0, "sentinel",
                f"Failed to attach execve probe: {exc}", severity="low",
            ))
            self._bpf_exec = None

        # connect kprobe
        try:
            self._bpf_conn = _BPF(text=_BPF_CONNECT_SRC)
            self._bpf_conn.attach_kprobe(
                event="tcp_v4_connect", fn_name="trace_connect"
            )
            self._bpf_conn["conn_events"].open_perf_buffer(self._on_conn_event)
        except Exception as exc:
            self._emit(SentinelAlert(
                "error", 0, "sentinel",
                f"Failed to attach connect probe: {exc}", severity="low",
            ))
            self._bpf_conn = None

    def _take_baseline(self) -> None:
        """Snapshot all currently-running PIDs so we don't alert on them."""
        try:
            for entry in Path("/proc").iterdir():
                if entry.name.isdigit():
                    self._known_pids.add(int(entry.name))
        except Exception:
            pass
        self._baseline_taken = True

    def _cleanup(self) -> None:
        for bpf in (self._bpf_exec, self._bpf_conn):
            if bpf:
                try:
                    bpf.cleanup()
                except Exception:
                    pass
        self._bpf_exec = None
        self._bpf_conn = None
        self._thread = None

    # -- event callbacks ---------------------------------------------------

    def _on_exec_event(self, cpu, data, size) -> None:
        """Called for every execve() syscall."""
        if not self._bpf_exec:
            return
        try:
            event = self._bpf_exec["exec_events"].event(data)
            pid = event.pid
            ppid = event.ppid
            uid = event.uid
            comm = event.comm.decode("utf-8", errors="replace")
            filename = event.filename.decode("utf-8", errors="replace")
        except Exception:
            return

        # Skip known OS noise
        if _is_noisy(comm):
            return

        # If this is a truly new PID (not in our baseline), flag it
        is_new = pid not in self._known_pids
        self._known_pids.add(pid)

        severity = "low"
        reasons: list[str] = []

        # Check for sensitive file access in the filename
        for pat in _SENSITIVE_PATHS:
            if pat.search(filename):
                severity = "critical"
                reasons.append(f"accesses sensitive path: {filename}")

        # Check for suspicious launch locations
        for pat in _SUSPICIOUS_FILENAMES:
            if pat.search(filename):
                if severity != "critical":
                    severity = "medium"
                reasons.append(f"launched from suspicious location: {filename}")

        # Execution from /tmp or /dev/shm is always suspicious
        if filename.startswith("/tmp/") or filename.startswith("/dev/shm/"):
            severity = "high"
            reasons.append(f"binary executed from volatile path: {filename}")

        # Root UID running something unexpected
        if uid == 0 and is_new and not _is_noisy(comm):
            if severity == "low":
                severity = "medium"
            reasons.append("new root process")

        if not reasons and not is_new:
            return  # nothing interesting

        if not reasons:
            reasons.append(f"new process: {filename}")

        detail = f"{filename} — {'; '.join(reasons)}"
        self._emit(SentinelAlert(
            "exec", pid, comm, detail,
            severity=severity, ppid=ppid, uid=uid,
        ))

    def _on_conn_event(self, cpu, data, size) -> None:
        """Called for every outbound TCP connect()."""
        if not self._bpf_conn:
            return
        try:
            event = self._bpf_conn["conn_events"].event(data)
            pid = event.pid
            uid = event.uid
            comm = event.comm.decode("utf-8", errors="replace")
            dport = ((event.dport & 0xFF) << 8) | ((event.dport >> 8) & 0xFF)  # ntohs
            # Convert u32 to dotted-quad
            daddr = event.daddr
            ip = f"{daddr & 0xFF}.{(daddr >> 8) & 0xFF}.{(daddr >> 16) & 0xFF}.{(daddr >> 24) & 0xFF}"
        except Exception:
            return

        if _is_noisy(comm):
            return

        severity = "low"
        reasons: list[str] = []

        # Known-suspicious ports
        if dport in (4444, 5555, 6666, 6667, 31337, 12345, 1234):
            severity = "high"
            reasons.append(f"connection to known-suspicious port {dport}")
        elif dport in (22, 23, 3389):
            severity = "medium"
            reasons.append(f"outbound connection to remote-access port {dport}")

        # Connections to local-network scanners
        if ip.startswith("0.") or ip == "0.0.0.0":
            return  # ignore

        if not reasons:
            return  # benign

        detail = f"{ip}:{dport} — {'; '.join(reasons)}"
        self._emit(SentinelAlert(
            "connect", pid, comm, detail,
            severity=severity, uid=uid,
        ))


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

_sentinel_instance: Optional[EBPFSentinel] = None
_sentinel_lock = threading.Lock()


def get_sentinel() -> EBPFSentinel:
    """Return the singleton sentinel instance (lazily created)."""
    global _sentinel_instance
    with _sentinel_lock:
        if _sentinel_instance is None:
            _sentinel_instance = EBPFSentinel()
        return _sentinel_instance


def start_sentinel(on_alert: Optional[Callable[[SentinelAlert], None]] = None) -> str:
    """Start the global eBPF sentinel."""
    s = get_sentinel()
    if on_alert:
        s._on_alert = on_alert
    return s.start()


def stop_sentinel() -> str:
    """Stop the global eBPF sentinel."""
    return get_sentinel().stop()


def sentinel_status() -> dict[str, Any]:
    """Get current sentinel status."""
    return get_sentinel().status()


def sentinel_alerts() -> list[dict]:
    """Get recent alerts as dicts."""
    return [a.to_dict() for a in get_sentinel().alerts]


def sentinel_report() -> list[str]:
    """Human-readable sentinel report lines."""
    s = get_sentinel()
    lines: list[str] = []

    if not _HAS_BCC:
        lines.append("⚠ python3-bcc is not installed.")
        lines.append("  Install: sudo dnf install python3-bcc")
        lines.append("  (or: sudo apt install python3-bpfcc)")
        return lines

    if not (os.geteuid() == 0 if hasattr(os, "geteuid") else False):
        lines.append("⚠ eBPF Sentinel requires root privileges.")
        lines.append("  Relaunch Sysfix with sudo or enable Sudo Mode.")
        return lines

    st = s.status()
    if st["running"]:
        lines.append(f"✓ eBPF Sentinel is running — {st['alert_count']} alert(s) total.")
    else:
        lines.append("● eBPF Sentinel is stopped.")
        lines.append("  Use 'Start Sentinel' to begin monitoring.")

    if st["latest_alerts"]:
        lines.append("")
        lines.append("Recent alerts:")
        for a in st["latest_alerts"]:
            sev = a["severity"].upper()
            icon = {"LOW": "🟢", "MEDIUM": "🟡", "HIGH": "🟠", "CRITICAL": "🔴"}.get(sev, "⚪")
            lines.append(f"  {icon} [{sev}] {a['kind']} pid={a['pid']} {a['comm']}: {a['detail']}")
    elif st["running"]:
        lines.append("  No suspicious activity detected yet.")

    return lines


def check_bcc_available() -> dict[str, Any]:
    """Check if BCC is available and return install instructions if not."""
    available = _ensure_bcc()
    result: dict[str, Any] = {
        "available": available,
        "is_root": os.geteuid() == 0 if hasattr(os, "geteuid") else False,
    }
    if not available:
        # Detect distro for install instructions
        if os.path.exists("/etc/fedora-release") or os.path.exists("/etc/redhat-release"):
            result["install_cmd"] = "sudo dnf install python3-bcc"
        elif os.path.exists("/etc/debian_version"):
            result["install_cmd"] = "sudo apt install python3-bpfcc"
        elif os.path.exists("/etc/arch-release"):
            result["install_cmd"] = "sudo pacman -S python-bcc"
        else:
            result["install_cmd"] = "Install python3-bcc for your distribution"
    return result
