"""
Heartbeat — real-time system awareness bridge for AI context injection.

Wraps the existing System Pulse telemetry into a structured JSON feed that
gets injected into every AI prompt.  Also provides proactive alert detection
and GUI notification callbacks so the sidebar can pulse icons when issues
are detected.

Design:
  - Heartbeat is a singleton background thread (daemon)
  - Samples System Pulse snapshots every 3 seconds
  - Maintains a compact JSON "awareness" blob for AI injection
  - Detects anomalies: CPU spike, RAM pressure, thermal throttle,
    disk near-full, zombie processes, eBPF alerts
  - Fires registered callbacks with (alert_type, severity, message)
  - Thread-safe: all reads go through a lock

Public API:
  - Heartbeat.start()                 → start the heartbeat loop
  - Heartbeat.stop()                  → stop it
  - Heartbeat.awareness_json()        → compact JSON str for AI context
  - Heartbeat.active_alerts()         → list of current alerts
  - Heartbeat.register_alert_cb(fn)   → register (alert_type, sev, msg) callback
  - Heartbeat.status()                → dict with running state
  - heartbeat_report()                → human-readable report lines
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("sysfix.heartbeat")

# ---------------------------------------------------------------------------
# Alert types — map to sidebar tab indices for proactive highlighting
# ---------------------------------------------------------------------------

# alert_type → (sidebar_tab_index, icon, category)
ALERT_TAB_MAP: Dict[str, Tuple[int, str, str]] = {
    "cpu_spike":       (0, "📊", "Dashboard"),
    "ram_pressure":    (0, "📊", "Dashboard"),
    "thermal":         (4, "💊", "Health"),
    "disk_full":       (4, "💊", "Health"),
    "zombies":         (4, "💊", "Health"),
    "ebpf_alert":      (2, "🔒", "Security"),
    "av_threat":       (2, "🔒", "Security"),
    "network_issue":   (3, "🌐", "Network"),
    "gpu_thermal":     (0, "📊", "Dashboard"),
    "swap_pressure":   (4, "💊", "Health"),
    "kernel_warning":  (4, "💊", "Health"),
}


@dataclass
class Alert:
    """A single proactive alert."""
    alert_type: str
    severity: str  # "info", "warn", "critical"
    message: str
    tab_index: int
    icon: str
    timestamp: float = 0.0
    dismissed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.alert_type,
            "severity": self.severity,
            "message": self.message,
            "tab": self.tab_index,
            "icon": self.icon,
            "time": self.timestamp,
        }


# ---------------------------------------------------------------------------
# Heartbeat singleton
# ---------------------------------------------------------------------------

class Heartbeat:
    """Singleton system-awareness daemon for AI context and proactive alerts."""

    _instance: Optional[Heartbeat] = None
    _lock = threading.Lock()

    def __new__(cls) -> Heartbeat:
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    inst = super().__new__(cls)
                    inst._initialized = False
                    cls._instance = inst
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._interval = 3.0
        self._data_lock = threading.Lock()
        self._awareness: Dict[str, Any] = {}
        self._alerts: List[Alert] = []
        self._alert_callbacks: List[Callable] = []
        self._last_snapshot_time = 0.0
        self._tick_count = 0

        # Thresholds for anomaly detection
        self._thresholds = {
            "cpu_spike": 90.0,       # CPU % sustained
            "ram_pressure": 88.0,    # RAM %
            "thermal_warn": 80.0,    # °C
            "thermal_crit": 95.0,    # °C
            "disk_full": 92.0,       # disk %
            "gpu_thermal": 85.0,     # GPU °C
            "swap_pressure": 50.0,   # swap %
            "zombie_threshold": 3,   # zombie process count
        }

    def start(self, interval: float = 3.0) -> str:
        """Start the heartbeat daemon thread."""
        if self._running:
            return "Heartbeat already running"
        self._interval = max(1.0, interval)
        self._running = True
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="sysfix-heartbeat"
        )
        self._thread.start()
        log.info("Heartbeat started (interval=%.1fs)", self._interval)
        return f"✓ Heartbeat started (interval={self._interval}s)"

    def stop(self) -> str:
        """Stop the heartbeat daemon."""
        if not self._running:
            return "Heartbeat not running"
        self._running = False
        if self._thread:
            self._thread.join(timeout=5.0)
        log.info("Heartbeat stopped")
        return "✓ Heartbeat stopped"

    def register_alert_cb(self, callback: Callable) -> None:
        """Register a callback: fn(alert: Alert) called when anomaly detected."""
        self._alert_callbacks.append(callback)

    # -- Data access (thread-safe) --

    def awareness_json(self) -> str:
        """Return compact JSON blob for AI context injection.

        This is the 'system awareness' payload that gets injected into every
        AI prompt so Fyxa can see what's happening right now.
        """
        with self._data_lock:
            if not self._awareness:
                return ""
            return json.dumps(self._awareness, separators=(",", ":"))

    def awareness_dict(self) -> Dict[str, Any]:
        """Return awareness data as a dict."""
        with self._data_lock:
            return dict(self._awareness)

    def active_alerts(self) -> List[Alert]:
        """Return list of undismissed alerts."""
        with self._data_lock:
            return [a for a in self._alerts if not a.dismissed]

    def dismiss_alert(self, alert_type: str) -> None:
        """Dismiss all alerts of a given type."""
        with self._data_lock:
            for a in self._alerts:
                if a.alert_type == alert_type:
                    a.dismissed = True

    def status(self) -> Dict[str, Any]:
        """Heartbeat status dict."""
        return {
            "running": self._running,
            "interval": self._interval,
            "ticks": self._tick_count,
            "active_alerts": len(self.active_alerts()),
            "last_sample": self._last_snapshot_time,
            "callbacks": len(self._alert_callbacks),
        }

    # -- Internal loop --

    def _loop(self) -> None:
        """Background polling loop."""
        while self._running:
            try:
                self._tick()
            except Exception as e:
                log.debug("Heartbeat tick error: %s", e)
            time.sleep(self._interval)

    def _tick(self) -> None:
        """Single heartbeat tick: sample, detect anomalies, notify."""
        self._tick_count += 1

        # Get latest pulse snapshot
        try:
            from sysfixai.system_pulse import get_pulse, get_trend
            snap = get_pulse()
            trend = get_trend()
        except Exception:
            return

        if not snap:
            return

        now = time.time()
        self._last_snapshot_time = now

        # Build compact awareness blob
        awareness: Dict[str, Any] = {
            "ts": int(now),
            "cpu": round(snap.cpu_percent, 1),
            "ram": round(snap.ram_percent, 1),
            "disk": round(snap.disk_percent, 1),
            "temp": round(snap.max_temp_c, 1),
            "gpu": round(snap.gpu_util_percent, 1),
            "gpu_t": round(snap.gpu_temp_c, 1),
            "swap": round(snap.swap_percent, 1),
            "zombies": snap.zombie_count,
            "procs": snap.process_count,
            "load": [
                round(snap.load_avg_1, 2),
                round(snap.load_avg_5, 2),
                round(snap.load_avg_15, 2),
            ],
        }

        # Trend arrows
        if trend:
            awareness["trends"] = {
                "cpu": getattr(trend, "cpu_trend", "stable"),
                "ram": getattr(trend, "ram_trend", "stable"),
                "temp": getattr(trend, "temp_trend", "stable"),
            }
            if trend.alerts:
                awareness["pulse_alerts"] = trend.alerts[:5]

        # Top processes
        if snap.top_cpu_processes:
            awareness["top_cpu"] = snap.top_cpu_processes[:3]
        if snap.top_ram_processes:
            awareness["top_ram"] = snap.top_ram_processes[:3]

        # eBPF sentinel alerts
        try:
            from sysfixai.ebpf_sentinel import sentinel_status
            sst = sentinel_status()
            if sst.get("running"):
                awareness["ebpf"] = True
                blocked = sst.get("blocked_count", 0)
                if blocked > 0:
                    awareness["ebpf_blocked"] = blocked
        except Exception:
            pass

        # AV threat count
        try:
            from sysfixai.sentinel_av import av_status
            avs = av_status()
            if avs.get("running"):
                awareness["av"] = True
                threats = avs.get("threat_count", 0)
                if threats > 0:
                    awareness["av_threats"] = threats
        except Exception:
            pass

        with self._data_lock:
            self._awareness = awareness

        # Detect anomalies and fire alerts
        self._detect_anomalies(snap, trend)

    def _detect_anomalies(self, snap: Any, trend: Any) -> None:
        """Check for anomalies and create/update alerts."""
        new_alerts: List[Alert] = []
        now = time.time()
        th = self._thresholds

        # CPU spike
        if snap.cpu_percent >= th["cpu_spike"]:
            top = snap.top_cpu_processes[0] if snap.top_cpu_processes else "unknown"
            new_alerts.append(Alert(
                alert_type="cpu_spike",
                severity="warn",
                message=f"CPU at {snap.cpu_percent}% — top: {top}",
                tab_index=ALERT_TAB_MAP["cpu_spike"][0],
                icon=ALERT_TAB_MAP["cpu_spike"][1],
                timestamp=now,
            ))

        # RAM pressure
        if snap.ram_percent >= th["ram_pressure"]:
            new_alerts.append(Alert(
                alert_type="ram_pressure",
                severity="warn",
                message=f"RAM at {snap.ram_percent}% — {snap.ram_used_gb:.1f}/{snap.ram_total_gb:.1f} GB",
                tab_index=ALERT_TAB_MAP["ram_pressure"][0],
                icon=ALERT_TAB_MAP["ram_pressure"][1],
                timestamp=now,
            ))

        # Thermal
        if snap.max_temp_c >= th["thermal_crit"]:
            new_alerts.append(Alert(
                alert_type="thermal",
                severity="critical",
                message=f"CRITICAL thermal: {snap.max_temp_c}°C!",
                tab_index=ALERT_TAB_MAP["thermal"][0],
                icon=ALERT_TAB_MAP["thermal"][1],
                timestamp=now,
            ))
        elif snap.max_temp_c >= th["thermal_warn"]:
            new_alerts.append(Alert(
                alert_type="thermal",
                severity="warn",
                message=f"High temperature: {snap.max_temp_c}°C",
                tab_index=ALERT_TAB_MAP["thermal"][0],
                icon=ALERT_TAB_MAP["thermal"][1],
                timestamp=now,
            ))

        # GPU thermal
        if snap.gpu_temp_c >= th["gpu_thermal"]:
            new_alerts.append(Alert(
                alert_type="gpu_thermal",
                severity="warn",
                message=f"GPU temperature: {snap.gpu_temp_c}°C",
                tab_index=ALERT_TAB_MAP["gpu_thermal"][0],
                icon=ALERT_TAB_MAP["gpu_thermal"][1],
                timestamp=now,
            ))

        # Disk full
        if snap.disk_percent >= th["disk_full"]:
            new_alerts.append(Alert(
                alert_type="disk_full",
                severity="warn",
                message=f"Disk {snap.disk_percent}% full — {snap.disk_free_gb:.1f} GB free",
                tab_index=ALERT_TAB_MAP["disk_full"][0],
                icon=ALERT_TAB_MAP["disk_full"][1],
                timestamp=now,
            ))

        # Zombie processes
        if snap.zombie_count >= th["zombie_threshold"]:
            new_alerts.append(Alert(
                alert_type="zombies",
                severity="info",
                message=f"{snap.zombie_count} zombie processes detected",
                tab_index=ALERT_TAB_MAP["zombies"][0],
                icon=ALERT_TAB_MAP["zombies"][1],
                timestamp=now,
            ))

        # Swap pressure
        if snap.swap_percent >= th["swap_pressure"]:
            new_alerts.append(Alert(
                alert_type="swap_pressure",
                severity="warn",
                message=f"Swap usage at {snap.swap_percent}%",
                tab_index=ALERT_TAB_MAP["swap_pressure"][0],
                icon=ALERT_TAB_MAP["swap_pressure"][1],
                timestamp=now,
            ))

        if not new_alerts:
            # Clear old alerts if system is healthy
            with self._data_lock:
                self._alerts = [a for a in self._alerts if not a.dismissed and
                                (now - a.timestamp) < 30]
            return

        # Merge: replace existing alerts of the same type
        with self._data_lock:
            existing_types = {a.alert_type for a in self._alerts if not a.dismissed}
            for alert in new_alerts:
                # Replace existing alert of this type
                self._alerts = [a for a in self._alerts if a.alert_type != alert.alert_type]
                self._alerts.append(alert)
                # Only fire callback for genuinely new alerts
                if alert.alert_type not in existing_types:
                    self._fire_alert(alert)

            # Cap alert list
            if len(self._alerts) > 50:
                self._alerts = self._alerts[-50:]

    def _fire_alert(self, alert: Alert) -> None:
        """Fire registered callbacks for a new alert."""
        for cb in self._alert_callbacks:
            try:
                cb(alert)
            except Exception as e:
                log.debug("Alert callback error: %s", e)


# ---------------------------------------------------------------------------
# Module-level convenience API
# ---------------------------------------------------------------------------

_heartbeat: Optional[Heartbeat] = None


def get_heartbeat() -> Heartbeat:
    """Get (or create) the singleton Heartbeat instance."""
    global _heartbeat
    if _heartbeat is None:
        _heartbeat = Heartbeat()
    return _heartbeat


def start_heartbeat(interval: float = 3.0) -> str:
    """Start the heartbeat daemon."""
    return get_heartbeat().start(interval)


def stop_heartbeat() -> str:
    """Stop the heartbeat daemon."""
    return get_heartbeat().stop()


def heartbeat_awareness() -> str:
    """Get the JSON awareness blob for AI injection."""
    return get_heartbeat().awareness_json()


def heartbeat_alerts() -> List[Alert]:
    """Get active alerts."""
    return get_heartbeat().active_alerts()


def heartbeat_status() -> Dict[str, Any]:
    """Get heartbeat status."""
    return get_heartbeat().status()


def heartbeat_report() -> List[str]:
    """Human-readable heartbeat status report."""
    hb = get_heartbeat()
    st = hb.status()
    lines: List[str] = []

    if st["running"]:
        lines.append(f"✓ Heartbeat running (interval={st['interval']}s, ticks={st['ticks']})")
    else:
        lines.append("⚠ Heartbeat not running")
        return lines

    awareness = hb.awareness_dict()
    if awareness:
        lines.append(f"  CPU: {awareness.get('cpu', '?')}% | "
                     f"RAM: {awareness.get('ram', '?')}% | "
                     f"Disk: {awareness.get('disk', '?')}%")
        temp = awareness.get("temp", 0)
        if temp > 0:
            lines.append(f"  Temp: {temp}°C")
        trends = awareness.get("trends", {})
        if trends:
            parts = [f"{k}: {v}" for k, v in trends.items() if v != "stable"]
            if parts:
                lines.append(f"  Trends: {', '.join(parts)}")
        if awareness.get("ebpf"):
            blocked = awareness.get("ebpf_blocked", 0)
            lines.append(f"  eBPF Sentinel: active ({blocked} blocked)")
        if awareness.get("av"):
            threats = awareness.get("av_threats", 0)
            lines.append(f"  Sentinel AV: active ({threats} threats)")

    alerts = hb.active_alerts()
    if alerts:
        lines.append("")
        lines.append("  Active alerts:")
        for a in alerts:
            sev_icon = {"critical": "🔴", "warn": "🟡", "info": "🔵"}.get(a.severity, "⚪")
            lines.append(f"    {sev_icon} {a.message}")
    else:
        lines.append("  No active alerts")

    return lines
