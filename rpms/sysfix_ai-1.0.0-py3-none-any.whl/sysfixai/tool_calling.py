"""
Tool Calling — structured function-calling infrastructure for Fyxa AI.

Defines a registry of internal Python functions that the AI can invoke
during its Think-Act-Observe cycle. Each tool has a name, description,
parameter schema, and a Python callable. The registry is serialized into
the Ollama/OpenAI tool-calling format so models like qwen2.5-coder can
call tools natively.

Supported tool-call protocols:
1. Native Ollama tool-calling (model.tools parameter)
2. OpenAI-compatible function-calling (tools array in chat completions)
3. Regex extraction fallback for models that emit <tool_call> XML or
   ```json blocks instead of using native tool protocol

Public API:
- register_tool(name, description, parameters, fn)
- get_tool_definitions()        → list of tool schemas for API
- execute_tool_call(name, args) → result string
- parse_tool_calls(response)    → list of (name, args) tuples
- get_tool_registry()           → dict of all registered tools
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import traceback
from typing import Any, Callable, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

_tools: Dict[str, Dict[str, Any]] = {}


def register_tool(
    name: str,
    description: str,
    parameters: Dict[str, Any],
    fn: Callable[..., str],
) -> None:
    """Register a tool that the AI can call."""
    _tools[name] = {
        "name": name,
        "description": description,
        "parameters": parameters,
        "fn": fn,
    }


def get_tool_registry() -> Dict[str, Dict[str, Any]]:
    """Return the full tool registry."""
    return dict(_tools)


def get_tool_definitions() -> List[Dict[str, Any]]:
    """Return tool definitions in OpenAI/Ollama function-calling format."""
    defs = []
    for name, tool in _tools.items():
        defs.append({
            "type": "function",
            "function": {
                "name": tool["name"],
                "description": tool["description"],
                "parameters": tool["parameters"],
            },
        })
    return defs


def get_tool_descriptions_text() -> str:
    """Return a plain-text description of all tools for prompt injection.

    Used as a fallback when the model doesn't support native tool-calling
    but can still be instructed to emit tool calls in a structured format.
    """
    lines = ["Available tools you can call:"]
    for name, tool in _tools.items():
        params = tool["parameters"].get("properties", {})
        param_desc = ", ".join(
            f"{k}: {v.get('description', v.get('type', 'any'))}"
            for k, v in params.items()
        )
        lines.append(f"  - {name}({param_desc}): {tool['description']}")
    lines.append("")
    lines.append(
        "To call a tool, output exactly:\n"
        '<tool_call>{"name": "tool_name", "arguments": {"arg1": "value1"}}</tool_call>\n'
        "Wait for the result before continuing your response."
    )
    return "\n".join(lines)


def execute_tool_call(name: str, arguments: Dict[str, Any]) -> str:
    """Execute a registered tool and return its result as a string.

    Returns an error message (not an exception) if the tool doesn't exist
    or execution fails, so the AI can see what went wrong.
    """
    tool = _tools.get(name)
    if not tool:
        return f"Error: unknown tool '{name}'. Available: {', '.join(_tools.keys())}"

    fn = tool["fn"]
    try:
        result = fn(**arguments)
        if isinstance(result, str):
            return result
        return json.dumps(result, indent=2, default=str)
    except Exception as e:
        return f"Error executing {name}: {e}\n{traceback.format_exc()[-500:]}"


def parse_tool_calls(response: str) -> List[Tuple[str, Dict[str, Any]]]:
    """Extract tool calls from an AI response string.

    Supports multiple formats:
    1. <tool_call>{"name": "...", "arguments": {...}}</tool_call>
    2. ```json\n{"name": "...", "arguments": {...}}\n```
    3. Ollama-style function_call blocks
    """
    calls: List[Tuple[str, Dict[str, Any]]] = []

    # Pattern 1: <tool_call> XML tags
    for match in re.finditer(
        r'<tool_call>\s*(\{.*?\})\s*</tool_call>',
        response, re.DOTALL,
    ):
        try:
            obj = json.loads(match.group(1))
            name = obj.get("name", "")
            args = obj.get("arguments", {})
            if name:
                calls.append((name, args))
        except json.JSONDecodeError:
            pass

    if calls:
        return calls

    # Pattern 2: ```json blocks that look like tool calls
    for match in re.finditer(
        r'```(?:json)?\s*(\{[^`]*?"name"[^`]*?\})\s*```',
        response, re.DOTALL,
    ):
        try:
            obj = json.loads(match.group(1))
            name = obj.get("name", "")
            args = obj.get("arguments", {})
            if name and name in _tools:
                calls.append((name, args))
        except json.JSONDecodeError:
            pass

    if calls:
        return calls

    # Pattern 3: plain JSON objects with name+arguments keys
    for match in re.finditer(
        r'\{[^{}]*"name"\s*:\s*"([^"]+)"[^{}]*"arguments"\s*:\s*(\{[^{}]*\})[^{}]*\}',
        response,
    ):
        try:
            name = match.group(1)
            args = json.loads(match.group(2))
            if name in _tools:
                calls.append((name, args))
        except (json.JSONDecodeError, IndexError):
            pass

    return calls


# ---------------------------------------------------------------------------
# Built-in tools — Sysfix internal functions exposed to the AI
# ---------------------------------------------------------------------------

def _tool_get_kernel_diagnostics(**kwargs) -> str:
    """Get kernel version, loaded modules, sysctl parameters, and recent dmesg."""
    sections: List[str] = []

    # Kernel version
    try:
        import platform
        sections.append(f"Kernel: {platform.release()}")
    except Exception:
        sections.append("Kernel: unknown")

    # Loaded modules (top 20 by size)
    try:
        result = subprocess.run(
            ["lsmod"], capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            lines = result.stdout.strip().splitlines()
            sections.append(f"Loaded modules: {len(lines) - 1}")
            # Sort by size (column 2)
            data_lines = lines[1:]
            parsed = []
            for l in data_lines:
                parts = l.split()
                if len(parts) >= 2:
                    try:
                        parsed.append((parts[0], int(parts[1])))
                    except ValueError:
                        pass
            parsed.sort(key=lambda x: x[1], reverse=True)
            top = parsed[:20]
            sections.append("Top modules by size:")
            for name, size in top:
                sections.append(f"  {name}: {size} bytes")
    except Exception:
        pass

    # Key sysctl values
    try:
        sysctl_keys = [
            "vm.swappiness", "vm.vfs_cache_pressure",
            "net.core.default_qdisc", "net.ipv4.tcp_congestion_control",
            "net.ipv4.tcp_fastopen", "fs.inotify.max_user_watches",
            "kernel.pid_max", "vm.dirty_ratio", "vm.dirty_background_ratio",
        ]
        for key in sysctl_keys:
            try:
                r = subprocess.run(
                    ["sysctl", "-n", key],
                    capture_output=True, text=True, timeout=2,
                    stdin=subprocess.DEVNULL,
                )
                if r.returncode == 0:
                    sections.append(f"  {key} = {r.stdout.strip()}")
            except Exception:
                pass
    except Exception:
        pass

    # Recent dmesg warnings/errors
    try:
        r = subprocess.run(
            ["dmesg", "-l", "err,warn", "--time-format=reltime"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            tail = r.stdout.strip().splitlines()[-15:]
            sections.append("Recent dmesg (warn/err):")
            for line in tail:
                sections.append(f"  {line.strip()[:150]}")
    except Exception:
        pass

    return "\n".join(sections) if sections else "Could not collect kernel diagnostics."


def _tool_monitor_process_tree(pid: int = 0, **kwargs) -> str:
    """Get process tree information. If pid=0, show top resource consumers."""
    sections: List[str] = []

    if pid > 0:
        # Show tree for specific PID
        try:
            r = subprocess.run(
                ["ps", "--forest", "-o", "pid,ppid,user,%cpu,%mem,stat,start,cmd",
                 "-g", str(pid)],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                sections.append(f"Process tree for PID {pid}:")
                for line in r.stdout.strip().splitlines()[:30]:
                    sections.append(f"  {line}")
        except Exception:
            sections.append(f"Could not get process tree for PID {pid}")

        # Also show open files
        try:
            r = subprocess.run(
                ["ls", "-la", f"/proc/{pid}/fd"],
                capture_output=True, text=True, timeout=3,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                fds = r.stdout.strip().splitlines()
                sections.append(f"Open file descriptors: {len(fds) - 1}")
        except Exception:
            pass

    else:
        # General overview
        try:
            r = subprocess.run(
                ["ps", "aux", "--sort=-%cpu"],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                lines = r.stdout.strip().splitlines()
                sections.append("Top CPU consumers:")
                for line in lines[:11]:
                    sections.append(f"  {line[:120]}")
        except Exception:
            pass

        try:
            r = subprocess.run(
                ["ps", "aux", "--sort=-%mem"],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                lines = r.stdout.strip().splitlines()
                sections.append("Top RAM consumers:")
                for line in lines[:11]:
                    sections.append(f"  {line[:120]}")
        except Exception:
            pass

    return "\n".join(sections) if sections else "Could not collect process info."


def _tool_analyze_ebpf_events(**kwargs) -> str:
    """Get recent eBPF sentinel events and security alerts."""
    try:
        from sysfixai.ebpf_sentinel import sentinel_status, sentinel_alerts, check_bcc_available
    except ImportError:
        return "eBPF sentinel module not available."

    sections: List[str] = []
    avail = check_bcc_available()
    sections.append(f"bcc available: {avail.get('available', False)}")

    status = sentinel_status()
    sections.append(f"Sentinel running: {status.get('running', False)}")
    sections.append(f"Total alerts: {status.get('alert_count', 0)}")

    alerts = sentinel_alerts()
    if alerts:
        sections.append(f"\nRecent alerts ({len(alerts)}):")
        for a in alerts[-10:]:
            severity = getattr(a, 'severity', 'info')
            kind = getattr(a, 'kind', '?')
            comm = getattr(a, 'comm', '?')
            detail = getattr(a, 'detail', '')
            sections.append(f"  [{severity}] {kind}: {comm} — {detail[:100]}")
    else:
        sections.append("No alerts recorded.")

    return "\n".join(sections)


def _tool_check_service_status(service: str = "", **kwargs) -> str:
    """Check systemd service status. If service is empty, show failed services."""
    sections: List[str] = []

    if service:
        try:
            r = subprocess.run(
                ["systemctl", "status", service, "--no-pager", "-l"],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            sections.append(f"Service: {service}")
            sections.append(r.stdout.strip()[:1000] if r.stdout else "")
            if r.stderr.strip():
                sections.append(r.stderr.strip()[:500])
        except Exception:
            sections.append(f"Could not check service {service}")
    else:
        try:
            r = subprocess.run(
                ["systemctl", "--failed", "--no-pager", "-l"],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                sections.append("Failed systemd services:")
                sections.append(r.stdout.strip()[:1000])
        except Exception:
            sections.append("Could not list failed services")

    return "\n".join(sections) if sections else "No service info available."


def _tool_check_network_status(**kwargs) -> str:
    """Get network interface status, DNS resolution, and connectivity."""
    sections: List[str] = []

    # Interfaces
    try:
        r = subprocess.run(
            ["ip", "-brief", "addr"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            sections.append("Network interfaces:")
            for line in r.stdout.strip().splitlines():
                sections.append(f"  {line}")
    except Exception:
        pass

    # DNS
    try:
        r = subprocess.run(
            ["dig", "+short", "google.com"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            sections.append(f"DNS OK: google.com → {r.stdout.strip().splitlines()[0]}")
        else:
            sections.append("DNS: resolution failed")
    except FileNotFoundError:
        # Try nslookup
        try:
            r = subprocess.run(
                ["nslookup", "google.com"],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if r.returncode == 0:
                sections.append("DNS OK (nslookup)")
        except Exception:
            sections.append("DNS: could not test")
    except Exception:
        pass

    # Gateway ping
    try:
        r = subprocess.run(
            ["ip", "route", "show", "default"],
            capture_output=True, text=True, timeout=3,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            gw = r.stdout.strip().split()[2]
            ping = subprocess.run(
                ["ping", "-c", "1", "-W", "2", gw],
                capture_output=True, text=True, timeout=5,
                stdin=subprocess.DEVNULL,
            )
            if ping.returncode == 0:
                sections.append(f"Gateway {gw}: reachable")
            else:
                sections.append(f"Gateway {gw}: unreachable")
    except Exception:
        pass

    return "\n".join(sections) if sections else "Could not collect network info."


def _tool_run_sandbox_test(command: str = "", **kwargs) -> str:
    """Test a command in a sandboxed environment without touching the host."""
    if not command:
        return "Error: 'command' argument is required."

    try:
        from sysfixai.sandbox import sandbox_dry_run
        results = sandbox_dry_run([command])
        return "\n".join(results)
    except ImportError:
        return "Sandbox module not available."
    except Exception as e:
        return f"Sandbox error: {e}"


def _tool_read_file(path: str = "", max_lines: int = 100, **kwargs) -> str:
    """Read a file from the filesystem (read-only, safe)."""
    if not path:
        return "Error: 'path' argument is required."

    # Security: block access to sensitive paths
    blocked = ["/etc/shadow", "/etc/gshadow", ".ssh/id_", ".gnupg/"]
    for b in blocked:
        if b in path:
            return f"Access denied: {path} is a sensitive file."

    try:
        expanded = os.path.expanduser(path)
        if not os.path.isfile(expanded):
            return f"File not found: {path}"
        with open(expanded, "r", errors="ignore") as f:
            lines = f.readlines()
        if len(lines) > max_lines:
            return f"(showing first {max_lines} of {len(lines)} lines)\n" + "".join(lines[:max_lines])
        return "".join(lines)
    except Exception as e:
        return f"Error reading {path}: {e}"


def _tool_search_logs(query: str = "", lines: int = 50, **kwargs) -> str:
    """Search system logs (journalctl) for a pattern."""
    if not query:
        return "Error: 'query' argument is required."

    try:
        r = subprocess.run(
            ["journalctl", "--no-pager", "-q", "-n", "5000",
             "--grep", query],
            capture_output=True, text=True, timeout=10,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0 and r.stdout.strip():
            result_lines = r.stdout.strip().splitlines()
            if len(result_lines) > lines:
                return f"Found {len(result_lines)} matches (showing last {lines}):\n" + \
                       "\n".join(result_lines[-lines:])
            return f"Found {len(result_lines)} matches:\n" + r.stdout.strip()
        return f"No log entries matching '{query}'"
    except Exception as e:
        return f"Error searching logs: {e}"


def _tool_get_disk_health(**kwargs) -> str:
    """Get S.M.A.R.T. disk health data."""
    sections: List[str] = []

    # Find block devices
    try:
        r = subprocess.run(
            ["lsblk", "-d", "-o", "NAME,SIZE,TYPE,MODEL,ROTA"],
            capture_output=True, text=True, timeout=5,
            stdin=subprocess.DEVNULL,
        )
        if r.returncode == 0:
            sections.append("Block devices:")
            for line in r.stdout.strip().splitlines():
                sections.append(f"  {line}")
    except Exception:
        pass

    # Try smartctl on first NVMe/SDA
    for dev in ["/dev/nvme0n1", "/dev/sda"]:
        if os.path.exists(dev):
            try:
                r = subprocess.run(
                    ["smartctl", "-a", dev],
                    capture_output=True, text=True, timeout=10,
                    stdin=subprocess.DEVNULL,
                )
                if r.stdout:
                    # Extract key health lines
                    for line in r.stdout.splitlines():
                        if any(kw in line.lower() for kw in
                               ("health", "temperature", "power_on", "reallocated",
                                "pending", "percentage used", "data units")):
                            sections.append(f"  {line.strip()}")
            except (FileNotFoundError, Exception):
                pass
            break

    return "\n".join(sections) if sections else "Could not collect disk health data."


def _tool_get_system_pulse(**kwargs) -> str:
    """Get the current System Pulse data (live telemetry)."""
    try:
        from sysfixai.system_pulse import get_pulse_prompt_header, pulse_status
        status = pulse_status()
        if not status.get("running"):
            return "System Pulse is not running. Use 'sysfix pulse --start' to begin monitoring."
        header = get_pulse_prompt_header()
        return header if header else "Pulse running but no data collected yet."
    except ImportError:
        return "System Pulse module not available."


# ---------------------------------------------------------------------------
# Register all built-in tools
# ---------------------------------------------------------------------------

def _register_defaults():
    """Register all default tools. Called once at module load."""
    register_tool(
        "get_kernel_diagnostics",
        "Get kernel version, loaded modules, sysctl parameters, and recent dmesg warnings/errors.",
        {"type": "object", "properties": {}, "required": []},
        _tool_get_kernel_diagnostics,
    )

    register_tool(
        "monitor_process_tree",
        "Get process tree and resource usage. Set pid=0 for overview, or a specific PID for details.",
        {
            "type": "object",
            "properties": {
                "pid": {"type": "integer", "description": "Process ID to inspect (0 for overview)"},
            },
            "required": [],
        },
        _tool_monitor_process_tree,
    )

    register_tool(
        "analyze_ebpf_events",
        "Get recent eBPF sentinel security events and alerts.",
        {"type": "object", "properties": {}, "required": []},
        _tool_analyze_ebpf_events,
    )

    register_tool(
        "check_service_status",
        "Check systemd service status. Leave service empty to list all failed services.",
        {
            "type": "object",
            "properties": {
                "service": {"type": "string", "description": "Service name (e.g. 'NetworkManager')"},
            },
            "required": [],
        },
        _tool_check_service_status,
    )

    register_tool(
        "check_network_status",
        "Get network interface status, DNS resolution, and gateway connectivity.",
        {"type": "object", "properties": {}, "required": []},
        _tool_check_network_status,
    )

    register_tool(
        "run_sandbox_test",
        "Test a shell command in a sandboxed environment without affecting the host system.",
        {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Shell command to test in sandbox"},
            },
            "required": ["command"],
        },
        _tool_run_sandbox_test,
    )

    register_tool(
        "read_file",
        "Read a file from the filesystem (read-only, blocks sensitive paths).",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
                "max_lines": {"type": "integer", "description": "Max lines to return (default 100)"},
            },
            "required": ["path"],
        },
        _tool_read_file,
    )

    register_tool(
        "search_logs",
        "Search system logs (journalctl) for a grep pattern.",
        {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search pattern (grep-compatible)"},
                "lines": {"type": "integer", "description": "Max result lines (default 50)"},
            },
            "required": ["query"],
        },
        _tool_search_logs,
    )

    register_tool(
        "get_disk_health",
        "Get S.M.A.R.T. disk health data and block device info.",
        {"type": "object", "properties": {}, "required": []},
        _tool_get_disk_health,
    )

    register_tool(
        "get_system_pulse",
        "Get current live system telemetry (CPU, RAM, temps, disk, processes, trends).",
        {"type": "object", "properties": {}, "required": []},
        _tool_get_system_pulse,
    )


# Auto-register on import
_register_defaults()

# Register Sentinel Bridge tools (security scanning for the AI)
try:
    from sysfixai.sentinel_bridge import register_sentinel_tools
    register_sentinel_tools()
except ImportError:
    pass
