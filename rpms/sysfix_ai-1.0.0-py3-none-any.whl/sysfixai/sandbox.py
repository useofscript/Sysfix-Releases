"""
Sandbox, Golden State Engine, Prescriptive Intelligence, and Semantic Logs.

Features:
- Sandboxed dry-run via bwrap / podman / systemd-nspawn
- Golden State declarative service/config monitor with drift detection
- Prescriptive notifications (disk-space projection, log-growth, journal pruning)
- Semantic log search (natural-language queries over journalctl via AI)
- Safety Pin toggle integration (safe-mode vs autonomous)

Every public function returns ``List[str]`` and never raises.
"""

import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    from sysfixai.config import load_config, save_config, CONFIG_DIR
except ImportError:
    CONFIG_DIR = Path.home() / ".config" / "sysfix"

    def load_config():
        return {}

    def save_config(c):
        pass


# ──────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────

def _run(cmd: List[str], timeout: int = 15) -> str:
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def _run_full(cmd: List[str], timeout: int = 30) -> Tuple[int, str, str]:
    """Run command returning (returncode, stdout, stderr)."""
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception as exc:
        return -1, "", str(exc)


# ══════════════════════════════════════════════════════════════════════════
#  1.  Sandboxed Dry-Run  ("Shadow Fix" Pipeline)
# ══════════════════════════════════════════════════════════════════════════

def detect_sandbox_backend() -> Dict[str, Any]:
    """Detect available sandbox backends."""
    backends: Dict[str, Any] = {}
    bwrap = shutil.which("bwrap")
    if bwrap:
        backends["bwrap"] = {"path": bwrap, "label": "bubblewrap"}
    podman = shutil.which("podman")
    if podman:
        backends["podman"] = {"path": podman, "label": "Podman container"}
    nspawn = shutil.which("systemd-nspawn")
    if nspawn:
        backends["nspawn"] = {"path": nspawn, "label": "systemd-nspawn"}
    distrobox = shutil.which("distrobox")
    if distrobox:
        backends["distrobox"] = {"path": distrobox, "label": "Distrobox"}
    return backends


def sandbox_dry_run(
    commands: List[str],
    backend: str = "auto",
    label: str = "sysfix-dryrun",
) -> List[str]:
    """Execute commands in a sandboxed environment to test before applying.

    Returns a list of result lines showing pass/fail status for each command.
    """
    results: List[str] = []
    results.append("═══ SANDBOXED DRY-RUN ═══\n")

    available = detect_sandbox_backend()
    if not available:
        results.append("⚠  No sandbox backend found.")
        results.append("   Install one of: bubblewrap, podman, distrobox")
        results.append("   e.g.: sudo dnf install bubblewrap")
        results.append("")
        results.append("Falling back to shell syntax-check only...")
        results.append("")
        return results + _syntax_check_fallback(commands)

    # Pick backend
    if backend == "auto":
        # Prefer bwrap (lightest), then podman, then distrobox
        for pref in ("bwrap", "podman", "distrobox", "nspawn"):
            if pref in available:
                backend = pref
                break
    if backend not in available:
        backend = list(available.keys())[0]

    info = available[backend]
    results.append(f"Backend: {info['label']} ({info['path']})")
    results.append(f"Commands to test: {len(commands)}")
    results.append("")

    if backend == "bwrap":
        return results + _dry_run_bwrap(commands, info["path"])
    elif backend == "podman":
        return results + _dry_run_podman(commands, info["path"], label)
    else:
        return results + _dry_run_generic(commands, backend, info["path"])


def _syntax_check_fallback(commands: List[str]) -> List[str]:
    """When no sandbox is available, do basic shell syntax checking."""
    results: List[str] = []
    for i, cmd in enumerate(commands, 1):
        # Use bash -n for syntax check
        rc, out, err = _run_full(["bash", "-n", "-c", cmd], timeout=5)
        if rc == 0:
            results.append(f"  [{i}] ✓ Syntax OK: {cmd[:80]}")
        else:
            results.append(f"  [{i}] ✗ Syntax error: {cmd[:80]}")
            if err:
                results.append(f"      {err[:120]}")
    results.append("")
    results.append("Note: Syntax-only check (no execution). Install bubblewrap for full sandbox.")
    return results


def _dry_run_bwrap(commands: List[str], bwrap_path: str) -> List[str]:
    """Run commands in a bubblewrap sandbox with read-only root."""
    results: List[str] = []
    passed = 0
    failed = 0

    for i, cmd in enumerate(commands, 1):
        # Build bwrap command: read-only bind of /, writable tmpfs for /tmp
        bwrap_cmd = [
            bwrap_path,
            "--ro-bind", "/", "/",
            "--tmpfs", "/tmp",
            "--tmpfs", "/var/tmp",
            "--dev", "/dev",
            "--proc", "/proc",
            "--unshare-net",   # no network access in sandbox
            "--die-with-parent",
            "--", "bash", "-c", cmd,
        ]
        rc, out, err = _run_full(bwrap_cmd, timeout=30)
        if rc == 0:
            results.append(f"  [{i}] ✓ PASS: {cmd[:80]}")
            if out:
                for line in out.splitlines()[:3]:
                    results.append(f"      {line[:100]}")
            passed += 1
        else:
            results.append(f"  [{i}] ✗ FAIL (exit {rc}): {cmd[:80]}")
            if err:
                for line in err.splitlines()[:3]:
                    results.append(f"      {line[:100]}")
            failed += 1

    results.append("")
    results.append(f"Results: {passed} passed, {failed} failed out of {len(commands)} commands")
    if failed == 0:
        results.append("✓ All commands passed sandbox test — safe to apply.")
    else:
        results.append("⚠  Some commands failed in sandbox. Review before applying.")
    return results


def _dry_run_podman(
    commands: List[str], podman_path: str, label: str
) -> List[str]:
    """Run commands inside a Podman container matching the host OS."""
    results: List[str] = []

    # Detect host OS for container image
    os_id = "fedora"
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith("ID="):
                    os_id = line.split("=", 1)[1].strip().strip('"')
                    break
    except Exception:
        pass

    image_map = {
        "fedora": "registry.fedoraproject.org/fedora:latest",
        "ubuntu": "docker.io/library/ubuntu:latest",
        "debian": "docker.io/library/debian:latest",
        "arch": "docker.io/library/archlinux:latest",
        "opensuse": "registry.opensuse.org/opensuse/tumbleweed:latest",
    }
    image = image_map.get(os_id, f"docker.io/library/{os_id}:latest")
    results.append(f"Container image: {image}")
    results.append("")

    # Run each command  
    passed = 0
    failed = 0
    for i, cmd in enumerate(commands, 1):
        podman_cmd = [
            podman_path, "run", "--rm",
            "--network=none",
            "--name", f"{label}-{i}",
            image,
            "bash", "-c", cmd,
        ]
        rc, out, err = _run_full(podman_cmd, timeout=60)
        if rc == 0:
            results.append(f"  [{i}] ✓ PASS: {cmd[:80]}")
            passed += 1
        else:
            results.append(f"  [{i}] ✗ FAIL (exit {rc}): {cmd[:80]}")
            if err:
                for line in err.splitlines()[:3]:
                    results.append(f"      {line[:100]}")
            failed += 1

    results.append("")
    results.append(f"Results: {passed} passed, {failed} failed out of {len(commands)} commands")
    return results


def _dry_run_generic(
    commands: List[str], backend: str, path: str
) -> List[str]:
    """Fallback for other backends."""
    return _syntax_check_fallback(commands)


# ══════════════════════════════════════════════════════════════════════════
#  2.  Golden State Engine  (Declarative System State + Drift Detection)
# ══════════════════════════════════════════════════════════════════════════

GOLDEN_STATE_FILE = CONFIG_DIR / "golden_state.json"

_DEFAULT_GOLDEN_STATE: Dict[str, Any] = {
    "version": 1,
    "services": {},       # {"sshd": "active", "nginx": "active"}
    "ports_closed": [],   # [22, 3389]
    "sysctl": {},         # {"vm.swappiness": "10"}
    "files": {},          # {"/etc/hostname": "<sha256>"}
    "packages": [],       # ["nginx", "htop"] — ensure installed
}


def load_golden_state() -> Dict[str, Any]:
    """Load or create golden state definition."""
    try:
        if GOLDEN_STATE_FILE.exists():
            with open(GOLDEN_STATE_FILE) as f:
                state = json.load(f)
            return {**_DEFAULT_GOLDEN_STATE, **state}
    except Exception:
        pass
    return _DEFAULT_GOLDEN_STATE.copy()


def save_golden_state(state: Dict[str, Any]) -> bool:
    """Persist golden state to disk."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(GOLDEN_STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)
        return True
    except Exception:
        return False


def capture_current_as_golden() -> List[str]:
    """Snapshot current system state as the Golden State baseline."""
    results: List[str] = []
    results.append("═══ CAPTURING GOLDEN STATE ═══\n")

    state = _DEFAULT_GOLDEN_STATE.copy()

    # Capture running services
    try:
        out = _run(["systemctl", "list-units", "--type=service", "--state=active",
                     "--no-pager", "--no-legend", "--plain"], timeout=10)
        if out:
            for line in out.splitlines():
                parts = line.split()
                if parts:
                    svc = parts[0].replace(".service", "")
                    state["services"][svc] = "active"
            results.append(f"  Services captured: {len(state['services'])}")
    except Exception:
        pass

    # Capture listening ports (mark which are open)
    try:
        out = _run(["ss", "-tlnp"], timeout=5)
        if out:
            ports_open = set()
            for line in out.splitlines()[1:]:
                m = re.search(r":(\d+)\s", line)
                if m:
                    ports_open.add(int(m.group(1)))
            results.append(f"  Open ports detected: {sorted(ports_open)}")
    except Exception:
        pass

    # Capture key sysctl values
    sysctl_keys = [
        "vm.swappiness", "net.ipv4.tcp_congestion_control",
        "net.core.default_qdisc", "fs.inotify.max_user_watches",
    ]
    for key in sysctl_keys:
        val = _run(["sysctl", "-n", key], timeout=3)
        if val:
            state["sysctl"][key] = val

    results.append(f"  Sysctl params captured: {len(state['sysctl'])}")

    # Capture checksums of key config files
    config_files = [
        "/etc/hostname", "/etc/hosts", "/etc/fstab",
        "/etc/resolv.conf", "/etc/sysctl.conf",
    ]
    import hashlib
    for fp in config_files:
        try:
            with open(fp, "rb") as f:
                h = hashlib.sha256(f.read()).hexdigest()
            state["files"][fp] = h
        except Exception:
            pass

    results.append(f"  Config files checksummed: {len(state['files'])}")

    if save_golden_state(state):
        results.append(f"\n✓ Golden State saved to {GOLDEN_STATE_FILE}")
    else:
        results.append("\n✗ Failed to save Golden State")

    return results


def golden_state_add_service(service_name: str) -> str:
    """Add a service to the Golden State."""
    state = load_golden_state()
    state["services"][service_name] = "active"
    save_golden_state(state)
    return f"Added '{service_name}' to Golden State (expected: active)"


def golden_state_add_port_closed(port: int) -> str:
    """Mark a port as 'should be closed' in the Golden State."""
    state = load_golden_state()
    if port not in state["ports_closed"]:
        state["ports_closed"].append(port)
        save_golden_state(state)
    return f"Port {port} marked as 'must be closed' in Golden State"


def golden_state_drift_check() -> List[str]:
    """Compare current system against the Golden State. Returns drift report."""
    results: List[str] = []
    results.append("═══ GOLDEN STATE — DRIFT DETECTION ═══\n")

    state = load_golden_state()
    if not state.get("services") and not state.get("sysctl") and not state.get("files"):
        results.append("No Golden State defined yet.")
        results.append("Run 'Capture Golden State' first to establish a baseline.")
        return results

    drifts: List[str] = []
    ok_count = 0

    # Check services
    for svc, expected in state.get("services", {}).items():
        actual = _run(["systemctl", "is-active", f"{svc}.service"], timeout=3)
        if actual != expected:
            drifts.append(f"  ⚠  Service '{svc}': expected={expected}, actual={actual or 'unknown'}")
        else:
            ok_count += 1

    # Check closed ports
    for port in state.get("ports_closed", []):
        out = _run(["ss", "-tlnp", f"sport = :{port}"], timeout=3)
        if out and str(port) in out:
            drifts.append(f"  ⚠  Port {port}: should be CLOSED but is LISTENING")
        else:
            ok_count += 1

    # Check sysctl
    for key, expected in state.get("sysctl", {}).items():
        actual = _run(["sysctl", "-n", key], timeout=3)
        if actual != expected:
            drifts.append(f"  ⚠  sysctl {key}: expected={expected}, actual={actual}")
        else:
            ok_count += 1

    # Check file checksums
    import hashlib
    for fp, expected_hash in state.get("files", {}).items():
        try:
            with open(fp, "rb") as f:
                actual_hash = hashlib.sha256(f.read()).hexdigest()
            if actual_hash != expected_hash:
                drifts.append(f"  ⚠  File '{fp}': checksum CHANGED since Golden State capture")
            else:
                ok_count += 1
        except FileNotFoundError:
            drifts.append(f"  ⚠  File '{fp}': MISSING (was present in Golden State)")
        except Exception:
            pass

    results.append(f"Checks passed: {ok_count}")
    results.append(f"Drifts found: {len(drifts)}\n")

    if drifts:
        results.append("DRIFT DETECTED:\n")
        results.extend(drifts)
        results.append("")
        results.append("Consider reconciling or re-capturing Golden State.")
    else:
        results.append("✓ System matches Golden State — no drift detected.")

    return results


def golden_state_reconcile_services() -> List[str]:
    """Attempt to restart stopped services that should be active per Golden State."""
    results: List[str] = []
    state = load_golden_state()
    fixed = 0

    for svc, expected in state.get("services", {}).items():
        if expected != "active":
            continue
        actual = _run(["systemctl", "is-active", f"{svc}.service"], timeout=3)
        if actual == "active":
            continue
        results.append(f"  Restarting {svc}...")
        rc, out, err = _run_full(
            ["sudo", "systemctl", "start", f"{svc}.service"], timeout=15
        )
        if rc == 0:
            results.append(f"    ✓ {svc} started successfully")
            fixed += 1
        else:
            results.append(f"    ✗ Failed to start {svc}: {err[:80]}")

    if not results:
        results.append("All Golden State services are already running.")
    else:
        results.insert(0, f"Reconciled {fixed} service(s).\n")

    return results


# ══════════════════════════════════════════════════════════════════════════
#  3.  Prescriptive Notifications  (Proactive Predictions)
# ══════════════════════════════════════════════════════════════════════════

def prescriptive_analysis() -> List[str]:
    """Run all prescriptive analyses — predict problems before they occur."""
    results: List[str] = []
    results.append("═══ PRESCRIPTIVE ANALYSIS ═══\n")
    alerts: List[str] = []

    # ── Disk space projection ──
    disk = _disk_space_projection()
    if disk:
        alerts.extend(disk)

    # ── Journal/log growth ──
    journal = _journal_growth_analysis()
    if journal:
        alerts.extend(journal)

    # ── Memory pressure trend ──
    mem = _memory_pressure_check()
    if mem:
        alerts.extend(mem)

    # ── Systemd service health ──
    svc = _failing_services_prediction()
    if svc:
        alerts.extend(svc)

    # ── Package update staleness ──
    pkg = _update_staleness_check()
    if pkg:
        alerts.extend(pkg)

    if alerts:
        results.extend(alerts)
    else:
        results.append("✓ No prescriptive alerts — system looks healthy for the foreseeable future.")

    return results


def _disk_space_projection() -> List[str]:
    """Predict when disk will run out based on recent usage trends."""
    alerts: List[str] = []
    if not HAS_PSUTIL:
        return alerts

    for part in psutil.disk_partitions():
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except Exception:
            continue
        if usage.total < 1e9:  # skip tiny mounts
            continue

        pct = usage.percent
        free_gb = usage.free / (1024 ** 3)

        if pct >= 95:
            alerts.append(
                f"🔴 CRITICAL: {part.mountpoint} is {pct:.0f}% full "
                f"({free_gb:.1f} GB free). Immediate action needed!"
            )
        elif pct >= 85:
            # Estimate days remaining at ~1 GB/day growth (conservative)
            days_left = free_gb / 1.0
            alerts.append(
                f"🟡 WARNING: {part.mountpoint} is {pct:.0f}% full "
                f"({free_gb:.1f} GB free). At typical usage, "
                f"~{days_left:.0f} days until full."
            )
            # Check if journal is large
            journal_size = _get_journal_size_gb()
            if journal_size and journal_size > 1.0:
                alerts.append(
                    f"   Tip: systemd journal is using {journal_size:.1f} GB. "
                    f"Run: sudo journalctl --vacuum-size=500M"
                )
        elif pct >= 75:
            alerts.append(
                f"ℹ  {part.mountpoint}: {pct:.0f}% used ({free_gb:.1f} GB free) — monitoring."
            )

    return alerts


def _get_journal_size_gb() -> Optional[float]:
    """Get total journal disk usage in GB."""
    out = _run(["journalctl", "--disk-usage"], timeout=5)
    if out:
        m = re.search(r"([\d.]+)\s*(G|M|K)", out)
        if m:
            val = float(m.group(1))
            unit = m.group(2)
            if unit == "G":
                return val
            if unit == "M":
                return val / 1024
    return None


def _journal_growth_analysis() -> List[str]:
    """Analyze journal growth rate."""
    alerts: List[str] = []
    size_gb = _get_journal_size_gb()
    if size_gb is None:
        return alerts

    if size_gb > 4.0:
        alerts.append(
            f"🟡 Journal size: {size_gb:.1f} GB — consider pruning. "
            f"Run: sudo journalctl --vacuum-size=1G"
        )
    elif size_gb > 2.0:
        alerts.append(
            f"ℹ  Journal size: {size_gb:.1f} GB. "
            f"Set persistent limit: sudo journalctl --vacuum-time=7d"
        )

    # Check for log-flooding services
    out = _run(
        ["journalctl", "--since", "1 hour ago", "--no-pager", "-q",
         "--output=cat", "-p", "warning"],
        timeout=10,
    )
    if out:
        lines = out.splitlines()
        if len(lines) > 200:
            alerts.append(
                f"🟡 High log volume: {len(lines)} warnings in the last hour. "
                f"A service may be flooding logs."
            )

    return alerts


def _memory_pressure_check() -> List[str]:
    """Check for memory pressure and swap usage."""
    alerts: List[str] = []
    if not HAS_PSUTIL:
        return alerts

    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()

    if vm.percent > 90:
        alerts.append(
            f"🔴 RAM critically high: {vm.percent:.0f}% used "
            f"({vm.available / (1024**3):.1f} GB available). "
            f"OOM killer may activate."
        )
    elif vm.percent > 80:
        alerts.append(
            f"🟡 RAM elevated: {vm.percent:.0f}% used. "
            f"Consider closing heavy applications."
        )

    if swap.total > 0 and swap.percent > 50:
        alerts.append(
            f"🟡 Swap usage: {swap.percent:.0f}% "
            f"({swap.used / (1024**3):.1f} / {swap.total / (1024**3):.1f} GB). "
            f"System may feel sluggish."
        )

    return alerts


def _failing_services_prediction() -> List[str]:
    """Detect services that keep restarting (crash-looping)."""
    alerts: List[str] = []
    out = _run(
        ["systemctl", "list-units", "--type=service", "--state=failed",
         "--no-pager", "--no-legend", "--plain"],
        timeout=10,
    )
    if not out:
        return alerts

    failed = [line.split()[0] for line in out.splitlines() if line.strip()]
    if failed:
        alerts.append(f"🔴 {len(failed)} failed service(s):")
        for svc in failed[:5]:
            alerts.append(f"   • {svc}")
        if len(failed) > 5:
            alerts.append(f"   ... and {len(failed) - 5} more")

    return alerts


def _update_staleness_check() -> List[str]:
    """Check when packages were last updated."""
    alerts: List[str] = []

    # DNF
    if shutil.which("dnf"):
        out = _run(["dnf", "history", "list", "--reverse"], timeout=10)
        if out:
            lines = out.splitlines()
            if len(lines) >= 2:
                last_line = lines[-1]
                m = re.search(r"(\d{4}-\d{2}-\d{2})", last_line)
                if m:
                    try:
                        last_date = datetime.strptime(m.group(1), "%Y-%m-%d")
                        days_ago = (datetime.now() - last_date).days
                        if days_ago > 30:
                            alerts.append(
                                f"🟡 Last package update was {days_ago} days ago. "
                                f"Run: sudo dnf upgrade"
                            )
                    except Exception:
                        pass

    # APT
    elif shutil.which("apt"):
        stamp = Path("/var/lib/apt/periodic/update-stamp")
        if stamp.exists():
            try:
                mtime = datetime.fromtimestamp(stamp.stat().st_mtime)
                days_ago = (datetime.now() - mtime).days
                if days_ago > 14:
                    alerts.append(
                        f"🟡 APT cache is {days_ago} days old. "
                        f"Run: sudo apt update && sudo apt upgrade"
                    )
            except Exception:
                pass

    return alerts


# ══════════════════════════════════════════════════════════════════════════
#  4.  Semantic Log Search  (Natural Language → journalctl)
# ══════════════════════════════════════════════════════════════════════════

def semantic_log_search(query: str, hours: int = 24) -> List[str]:
    """Search system logs using natural language query.

    Extracts keywords from the query, searches journalctl, and returns
    contextualised results. For deeper analysis, the GUI can feed the
    results to the AI model.
    """
    results: List[str] = []
    results.append(f"═══ LOG SEARCH: \"{query}\" ═══\n")
    results.append(f"Time window: last {hours} hours\n")

    # Build keyword list from natural language
    keywords = _extract_log_keywords(query)
    if not keywords:
        results.append("Could not extract search terms. Try more specific wording.")
        return results

    results.append(f"Search terms: {', '.join(keywords)}\n")

    # Search journalctl
    since = f"{hours} hours ago"
    all_matches: List[Tuple[str, str]] = []  # (keyword, line)

    for kw in keywords:
        out = _run(
            ["journalctl", "--since", since, "--no-pager", "-q",
             "--output=short-iso", "--grep", kw, "--case-sensitive=no"],
            timeout=15,
        )
        if out:
            lines = out.splitlines()
            for line in lines[:20]:
                all_matches.append((kw, line))

    # Also search dmesg
    dmesg_out = _run(["dmesg", "--time-format=iso", "--level=err,warn"], timeout=5)
    if dmesg_out:
        for kw in keywords:
            for line in dmesg_out.splitlines():
                if kw.lower() in line.lower():
                    all_matches.append((kw, f"[dmesg] {line}"))

    # Deduplicate and sort
    seen = set()
    unique: List[Tuple[str, str]] = []
    for kw, line in all_matches:
        key = line.strip()[:100]
        if key not in seen:
            seen.add(key)
            unique.append((kw, line))

    if not unique:
        results.append("No matching log entries found.")
        results.append("")
        results.append("Tips:")
        results.append("  • Try broader terms (e.g. 'network' instead of 'ethernet')")
        results.append("  • Increase the time window")
        results.append("  • Check if journald is configured to persist logs")
        return results

    results.append(f"Found {len(unique)} relevant entries:\n")
    for kw, line in unique[:30]:
        results.append(f"  [{kw}] {line[:120]}")

    if len(unique) > 30:
        results.append(f"\n  ... {len(unique) - 30} more entries (showing first 30)")

    return results


def _extract_log_keywords(query: str) -> List[str]:
    """Extract searchable keywords from a natural language log query."""
    q = query.lower()

    # Topic expansion map
    expansions = {
        "wifi": ["wlan", "iwlwifi", "NetworkManager", "wpa_supplicant", "wireless"],
        "wi-fi": ["wlan", "iwlwifi", "NetworkManager", "wpa_supplicant"],
        "bluetooth": ["bluetooth", "btusb", "bluez", "hci"],
        "usb": ["usb", "xhci", "ehci", "hub"],
        "disk": ["disk", "nvme", "sata", "ata", "I/O error", "ext4", "btrfs", "xfs"],
        "network": ["network", "eth", "enp", "NetworkManager", "dhcp", "dns"],
        "gpu": ["gpu", "nvidia", "amdgpu", "i915", "drm", "mesa"],
        "audio": ["audio", "pulseaudio", "pipewire", "alsa", "snd"],
        "boot": ["boot", "systemd", "initrd", "grub", "kernel"],
        "crash": ["segfault", "oops", "panic", "oom", "killed", "core dump"],
        "slow": ["throttl", "latency", "timeout", "hang", "stall"],
        "power": ["power", "acpi", "suspend", "hibernate", "battery", "charge"],
        "mouse": ["mouse", "hid", "input", "usb"],
        "keyboard": ["keyboard", "input", "hid", "xkb"],
        "screen": ["display", "monitor", "drm", "xrandr", "wayland", "screen"],
        "temperature": ["thermal", "throttl", "overheat", "temp", "fan"],
        "memory": ["memory", "oom", "swap", "mce", "ecc"],
        "firewall": ["firewall", "nftables", "iptables", "ufw", "firewalld"],
    }

    keywords = set()

    # Check for topic matches
    for topic, terms in expansions.items():
        if topic in q:
            keywords.update(terms)

    # Extract individual meaningful words  
    stop_words = {
        "the", "a", "an", "is", "was", "my", "why", "did", "does", "do",
        "what", "when", "how", "where", "which", "this", "that", "it",
        "and", "or", "but", "in", "on", "at", "to", "for", "of", "with",
        "not", "no", "from", "out", "up", "down", "so", "if", "about",
        "has", "have", "had", "been", "be", "are", "were", "will",
        "would", "could", "should", "can", "may", "might", "i", "me",
    }

    words = re.findall(r"\b[a-z0-9_.-]{3,}\b", q)
    for w in words:
        if w not in stop_words and w not in expansions:
            keywords.add(w)

    return list(keywords)[:8]  # limit to prevent slow searches


def semantic_log_search_ai(query: str, hours: int = 24) -> str:
    """Search logs and use AI to interpret the results."""
    log_results = semantic_log_search(query, hours)
    log_text = "\n".join(log_results)

    # Feed to AI for interpretation
    try:
        from sysfixai.ai import get_deep_dive
        ai_prompt = (
            f"The user asked about their system logs: \"{query}\"\n\n"
            f"Here are the relevant log entries I found:\n{log_text}\n\n"
            f"Analyze these log entries and explain what happened, "
            f"what caused it, and what the user should do about it. "
            f"Be specific and reference the actual log entries."
        )
        return get_deep_dive(ai_prompt, gui_mode=True)
    except Exception:
        return log_text


# ══════════════════════════════════════════════════════════════════════════
#  5.  Safety Pin Mode  (Confirm everything vs. Autonomous)
# ══════════════════════════════════════════════════════════════════════════

def get_safety_pin_status() -> Dict[str, Any]:
    """Return current Safety Pin status."""
    cfg = load_config()
    pinned = not cfg.get("agent_mode_enabled", False)
    dry_run = cfg.get("agent_mode_dry_run", True)

    return {
        "pinned": pinned,
        "mode": "safe" if pinned else "autonomous",
        "label": "🔒 Safe Mode" if pinned else "🔓 Autonomous Mode",
        "description": (
            "Every action requires confirmation before execution."
            if pinned else
            "Non-destructive optimizations run automatically. "
            "Destructive actions still require confirmation."
        ),
        "dry_run": dry_run,
    }


def toggle_safety_pin() -> Dict[str, Any]:
    """Toggle between Safe and Autonomous mode."""
    cfg = load_config()
    currently_pinned = not cfg.get("agent_mode_enabled", False)

    if currently_pinned:
        # Switch to autonomous
        cfg["agent_mode_enabled"] = True
        cfg["agent_mode_dry_run"] = False
    else:
        # Switch to safe
        cfg["agent_mode_enabled"] = False
        cfg["agent_mode_dry_run"] = True

    save_config(cfg)
    return get_safety_pin_status()


def is_action_safe(command: str) -> Dict[str, Any]:
    """Classify a command as safe/unsafe for autonomous mode.

    Returns:
        {"safe": bool, "risk": "low"|"medium"|"high", "reason": str}
    """
    cmd_lower = command.lower().strip()

    # Always dangerous — require confirmation
    dangerous = [
        r"\brm\s+-rf\b", r"\bdd\s+if=", r"\bmkfs\.", r"/dev/(sda|nvme|vd)",
        r"\bshutdown\b", r"\breboot\b", r"\bpoweroff\b", r"\bhalt\b",
        r"\bchmod\s+[0-7]{3,4}\s+/", r"\bchown\s+.*\s+/(etc|boot|usr)",
        r">\s*/etc/", r">\s*/boot/", r"\bcurl\s+.*\|\s*(ba)?sh\b",
        r"\bwget\s+.*\|\s*(ba)?sh\b", r"\bsystemctl\s+(disable|mask|stop)",
        r"\biptables\s+-F\b", r"\bnft\s+flush\b",
    ]
    for pat in dangerous:
        if re.search(pat, cmd_lower):
            return {"safe": False, "risk": "high", "reason": f"Matches dangerous pattern: {pat}"}

    # Medium risk
    medium = [
        r"\bsudo\b", r"\bsystemctl\s+restart\b", r"\bpip\s+install\b",
        r"\bdnf\s+install\b", r"\bapt\s+install\b", r"\bpacman\s+-S\b",
    ]
    for pat in medium:
        if re.search(pat, cmd_lower):
            return {"safe": False, "risk": "medium", "reason": "Requires elevated privileges or installs software"}

    # Safe (read-only)
    return {"safe": True, "risk": "low", "reason": "Read-only or non-destructive command"}


# ══════════════════════════════════════════════════════════════════════════
#  6.  Combined Report
# ══════════════════════════════════════════════════════════════════════════

def full_sandbox_report() -> List[str]:
    """Run prescriptive analysis + golden state check + safety status."""
    results: List[str] = []

    # Prescriptive
    results.extend(prescriptive_analysis())
    results.append("")

    # Golden State
    results.extend(golden_state_drift_check())
    results.append("")

    # Safety Pin
    status = get_safety_pin_status()
    results.append(f"Safety mode: {status['label']}")
    results.append(f"  {status['description']}")

    # Sandbox availability
    backends = detect_sandbox_backend()
    if backends:
        labels = [b["label"] for b in backends.values()]
        results.append(f"\nSandbox backends available: {', '.join(labels)}")
    else:
        results.append("\nNo sandbox backend installed. Recommended: sudo dnf install bubblewrap")

    return results
