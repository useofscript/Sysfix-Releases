"""
Safe command executor helpers.

Provides a minimal, auditable way to run shell commands produced by Fyxa.
Execution requires explicit confirmation when run interactively.

Functions:
- run_commands(commands, cwd=None, use_sudo=False, require_confirmation=True)

"""
from typing import List, Optional, Dict, Any
import shlex
import subprocess
import time


def _prompt_confirm(commands: List[str]) -> bool:
    print("The following commands will be executed:")
    for c in commands:
        print("  ", c)
    print()
    resp = input("Type 'yes' to proceed, anything else to abort: ").strip().lower()
    return resp == "yes"


def run_commands(
    commands: List[str],
    cwd: Optional[str] = None,
    use_sudo: bool = False,
    require_confirmation: bool = True,
    timeout: int = 600,
) -> List[Dict[str, Any]]:
    """Execute a list of shell commands sequentially.

    Returns a list of result dicts: {'cmd': str, 'returncode': int, 'stdout': str, 'stderr': str, 'duration': float}

    Warning: running arbitrary shell commands can be dangerous. This helper
    requires interactive confirmation by default.
    """
    if require_confirmation:
        ok = _prompt_confirm(commands)
        if not ok:
            raise RuntimeError("Execution aborted by user")

    results: List[Dict[str, Any]] = []
    for cmd in commands:
        final_cmd = cmd
        if use_sudo:
            final_cmd = f"sudo {cmd}"

        start = time.time()
        try:
            proc = subprocess.run(
                final_cmd,
                shell=True,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            duration = time.time() - start
            results.append({
                "cmd": final_cmd,
                "returncode": proc.returncode,
                "stdout": proc.stdout.strip(),
                "stderr": proc.stderr.strip(),
                "duration": duration,
            })
        except subprocess.TimeoutExpired as e:
            duration = time.time() - start
            results.append({
                "cmd": final_cmd,
                "returncode": -1,
                "stdout": "",
                "stderr": f"Timed out after {timeout}s",
                "duration": duration,
            })
        except Exception as e:
            duration = time.time() - start
            results.append({
                "cmd": final_cmd,
                "returncode": -1,
                "stdout": "",
                "stderr": str(e),
                "duration": duration,
            })

    return results
