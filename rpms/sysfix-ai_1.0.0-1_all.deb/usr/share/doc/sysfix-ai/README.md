# sysfix-ai

**Professional Linux system diagnostics, AI-powered repairs, security auditing, and more — powered by Fyxa AI.**

> Detect issues, chat with an AI engineer, scan for malware, audit your security, check your network — all from a sleek GUI or a full-featured terminal.

---

## What Is Sysfix?

Sysfix is an all-in-one Linux health tool.  It scans your system for problems — memory leaks, overheating, disk pressure, failed services — and uses a local AI (Fyxa) to understand what's wrong and help you fix it.

Fyxa remembers your hardware, your projects, and past solutions in a persistent local brain so she gets smarter over time.

**Two interfaces, one toolbox:**

| Mode | Launch | Best for |
|------|--------|----------|
| **GUI** (7-tab desktop app) | `sysfix` or `sysfix gui` | Daily monitoring, AI chat, point-and-click |
| **Terminal** (Rich CLI) | `sysfix terminal` or `sysfix check` | Scripting, SSH sessions, quick scans |

Both interfaces share the same diagnostic engine, AI brain, and configuration.

---

## Features at a Glance

### Diagnostics & Fixes
- Detects CPU, RAM, disk, temperature, audio, BIOS, and motherboard issues
- Categorises results: **Problems** (red) → **Warnings** (yellow) → **Info** (blue)
- **Fast Sweep** — one-click AI-powered auto-fix with confirmation
- **Deep Dive** — interactive AI troubleshooting session
- **Memory optimisation** — view top RAM consumers
- **Disk cleanup** — find large directories in your home folder

### Fyxa AI Chat
- Conversational AI assistant with full system context
- **Web search** — Fyxa can search the internet when she needs current info
- **Brain memory** — persistent knowledge about your hardware, projects, tools, preferences, and past fixes
- **Project management** — helps you run, build, test, and debug code projects
- **Accurate reasoning** — step-by-step logic; won't guess or hallucinate
- **Smart keyword detection** — automatically recognises 6 topic areas (Wi-Fi, network, security, performance, disk, GPU) and gathers live system context before replying
- Auto-detects the best local Ollama model (qwen3, llama3.1, codellama, etc.)

### Security Auditing
- Listening ports, firewall status, failed logins
- SUID binaries, world-writable directories
- SSH configuration review, suspicious processes
- Rootkit tool detection, user account audit

### Virus / Malware Scanning
- SHA-256 hash checks against **MalwareBazaar**
- Optional **VirusTotal** integration (free API key)
- Scan individual files, directories, or ~/Downloads
- **Real-time antivirus** — background thread monitors `~/Downloads` for new files and auto-scans them against malware hash databases

### Network Diagnostics
- Interface listing, DNS resolution, gateway latency
- Internet connectivity check
- **Wi-Fi optimisation** — auto-detect BSSID, signal strength, channel, frequency; auto-roam to stronger APs
- **Desktop notifications** on scan/diagnostics completion

### System Health
- Boot time, failed systemd services, journal errors
- USB device listing, SMART disk health

### Advanced Health & Predictive Maintenance
- **Hardware health score** — 0-100 composite score across thermal, memory, CPU, disk, battery, and fan sensors
- **Predictive disk analysis** — S.M.A.R.T. trend analysis for NVMe (lifespan, TBW, write-rate extrapolation) and SATA (reallocated sectors, pending sectors, wear leveling)
- **Zombie process hunter** — finds zombie (Z) and D-state processes, can send SIGCHLD to parent processes to reap them
- **Kernel parameter audit** — checks 13 sysctl params (swappiness, vfs_cache_pressure, tcp_fastopen, BBR, inotify watches, etc.) against recommended values
- **Network self-healing** — BBR congestion control, DNS privacy (DNS-over-TLS detection), ghost interface cleanup, MTU mismatch detection
- **Log pattern analysis** — scans journalctl for 12 pre-failure signatures (ECC errors, disk I/O, OOM, thermal throttling, GPU hangs, kernel panics, etc.)
- **Repo & dependency audit** — orphaned packages, duplicates, broken dependencies (dnf/apt/pacman)
- **Energy profiler** — battery status, CPU governor, top power consumers, TLP/power-profiles-daemon detection
- **Config versioning & rollback** — timestamped snapshots with SHA-256 checksums
- **PII scrubbing** — 11 regex patterns mask emails, IPs, MACs, home paths, passwords, SSH keys, and API tokens before sending context to AI
- **ELI5 mode** — toggle between plain-language and technical explanations in AI responses

### Sandbox & System Intelligence
- **Sandboxed dry-runs** — test any command in an isolated environment (auto-detects bubblewrap, podman, or distrobox) before applying to the live system
- **Golden State Engine** — declare a system baseline (running services, open ports, sysctl values, config file checksums), detect drift, and auto-reconcile back to the desired state
- **Prescriptive analysis** — proactive insights: disk-full projection, journal growth rate, memory pressure trends, failing services, and package update staleness
- **Semantic log search** — ask natural-language questions like "Why did Bluetooth drop?" and Sysfix expands the query into 18 topic keyword categories, searches journalctl + dmesg, and returns correlated results
- **Safety Pin toggle** — switch between **Safe Mode** (Fyxa explains every step and waits for confirmation) and **Autonomous Mode** (non-destructive optimisations run automatically)
- **Command Palette (Ctrl+K)** — fuzzy-searchable overlay with 22 actions: jump to any tab, run any diagnostic, or ask Fyxa a question directly

### eBPF Sentinel (Real-Time Security)
- **Zero-day process monitor** — uses the BPF Compiler Collection (bcc) to trace `execve()` and `tcp_v4_connect()` in real time
- Flags processes that touch sensitive files (`/etc/shadow`, `.ssh/`, `.gnupg/`), run from `/tmp` or `/dev/shm`, or connect to suspicious ports
- Filters out 50+ known-benign system processes to reduce noise
- Desktop notifications on high/critical alerts
- Requires root + `python3-bcc`; gracefully disables itself otherwise

### Micro-VM Sandbox (Firecracker)
- **Run risky commands in a Firecracker micro-VM** — boots in ~150ms, fully isolated from the host
- Auto-generates minimal BusyBox rootfs; copies host kernel
- Falls back to bubblewrap or podman if Firecracker/KVM is unavailable
- Requires `/dev/kvm` for full micro-VM mode

### Sentinel AV — Kernel-Level Antivirus Engine
- **Real-time eBPF behavioural antivirus** — hooks `execve`, `tcp_v4_connect`, and `openat` syscalls via the BPF Compiler Collection (bcc) with zero CPU lag
- **Behavioral pattern detection:**
  - `/boot` and kernel module tampering by non-system processes
  - Malicious IP connections (curated set + C2 port detection)
  - Apps that should never touch the network (calculator, image viewer, PDF reader) opening sockets
  - **Ransomware detection** — Shannon entropy analysis (>7.5 = encrypted), rapid write-rate tracking (>5 files/s across 3+ dirs), known ransomware extension matching (.encrypted, .locked, .crypto, etc.)
  - curl-pipe-shell execution, debug tool usage, sensitive key file access
- **cgroups v2 process freezing** — instantly freezes suspicious processes via the cgroups v2 freezer (`cgroup.freeze=1`); falls back to `SIGSTOP` if cgroups v2 is unavailable
- **Stasis Chamber** — moves suspicious binaries into a Firecracker micro-VM for isolated forensic analysis (file type, strings, ELF headers, dynamic libraries); falls back to bwrap/podman or local static analysis; archives binaries to `~/.config/sysfix/stasis/`
- **ClamAV integration** — cross-references detected processes against the ClamAV signature database via `clamdscan`/`clamscan`
- **AI threat reasoning** — Fyxa analyses threat context (syscalls, files, network, ClamAV result, Stasis Chamber findings) and renders a structured VERDICT with confidence score (0-100%)
- **ThreatMap** — per-threat visualisation showing process tree, file access categorised by risk (boot_critical/sensitive_keys/system_critical/normal), and network connections flagged as malicious or clean
- **Spring-physics threat popup** — 144Hz (7ms intervals) Hooke's law spring animation slides a neon-bordered threat notification into view with:
  - Real-time mini threat map (files touched + network connections)
  - One-click **DELETE VIRUS** (red) — permanently removes the binary
  - One-click **JAIL FOREVER** (purple) — keeps the process frozen in cgroups quarantine indefinitely
  - Dismiss / 30-second auto-dismiss
- **Requirements:** root + `python3-bcc` for eBPF probes; ClamAV for signature scanning; Firecracker for Stasis Chamber — all optional with graceful degradation

### Malware Verification Pipeline
- **Three-stage concurrent deep scan** — runs ClamAV, YARA, and VirusTotal in parallel background threads so the UI stays at 144Hz
- **Stage 1 — ClamAV Deep Scan:** uses `pyclamd` (libclamav Python binding) for direct daemon communication; falls back to `clamdscan`/`clamscan` subprocess if pyclamd is unavailable
- **Stage 2 — YARA Behavioural Pattern Matching:** loads community-sourced YARA rules from the [Yara-Rules](https://github.com/Yara-Rules/rules) repository (`~/.config/sysfix/yara-rules/`); compiles and caches rules; matches against malware families, packers, crypto miners, exploits, webshells, and CVE signatures
- **Stage 3 — VirusTotal Global Reputation:** uses the official `vt-py` async client; calculates SHA-256 hash and queries the VirusTotal API for detection ratio, engine hits, tags, and community reputation score
- **ThreatProfile JSON:** all three stages aggregate into a single `ThreatProfile` dataclass with per-stage results, an aggregated risk score (0-100), and risk factors — fully JSON-serialisable
- **Fyxa AI Interpretation:** Fyxa reads the ThreatProfile and produces a plain-English risk assessment with confidence score, telling the user whether the file is safe, suspicious, or dangerous and what to do
- **Integrated into Sentinel AV:** the pipeline runs automatically during `_deep_analyze()` for every eBPF-detected threat, replacing the old single-stage ClamAV path; legacy fallback is preserved if the pipeline module is absent
- **CLI:** `sysfix pipeline <file>` for manual deep scan, `sysfix pipeline --status` for capability report, `sysfix pipeline --update-yara` to pull latest community rules
- **GUI:** "Deep Scan" button in the Health tab Sentinel AV deck opens a file picker and displays a live-updating staged report; "Pipeline Status" shows capability availability
- **Dependencies (all optional):** `pyclamd`, `yara-python`, `vt-py` — each stage degrades gracefully when its dependency is missing

### Sentinel Bridge (AI Security Scanner)
- **Pure-Python eBPF-style security bridge** — makes the Sentinel available to the free AI (Qwen2.5-Coder via Ollama) without requiring root or `python3-bcc`
- **`read_only_ebpf_scan()`** — combines process anomaly detection, network threat analysis, and file integrity scanning into a single risk-scored report (free tier)
- **Process scanning** — reads `/proc/<pid>/{comm,cmdline,cwd,fd}` to detect crypto miners, reverse shells, privilege-escalation tools, deleted binaries running from `/tmp`, and high file-descriptor counts
- **Network scanning** — parses `/proc/net/tcp` and `/proc/net/tcp6`, decodes hex socket addresses, flags suspicious ports (4444, 5555, 6666, 31337…), unexpected LISTEN sockets, and connections to known-bad IP ranges
- **File integrity** — checks SUID/SGID bits, world-writable permissions, suspicious locations (`/tmp`, `/dev/shm`), and computes byte-entropy to detect packed/encrypted payloads
- **AI intent mapping** — maps natural-language intents (`"scan processes"`, `"check network"`, `"scan file"`, `"full scan"`) to bridge methods so the Qwen model can reason about security
- **4 AI-callable tools** registered in the tool-calling system: `sentinel_security_scan`, `sentinel_process_scan`, `sentinel_network_scan`, `sentinel_bridge_status`
- **Free / Premium split** — all read-only scanning is included in the free tier; `auto_kill_threat()` (SIGKILL) is locked behind a premium check
- **CLI:** `sysfix bridge` for a full scan, `sysfix bridge --status` for capability report
- **GUI:** "Bridge Scan" and "Bridge Status" buttons in the Health tab AV deck; 4 command-palette entries

### NPU Offloading
- **Detect and use Intel Core Ultra / AMD Ryzen AI NPUs** for AI inference
- Auto-detects NPU via sysfs (`/sys/class/accel/`) and lspci fallback
- Wraps `intel-npu-acceleration-library` for ONNX/OpenVINO model compilation
- Reports Ollama NPU support status and OpenVINO integration readiness

### Agentic Reasoning Engine (v1.1.0)
- **Think-Act-Observe cycle** — stateful agentic loop that transforms Fyxa from a passive chatbot into an environment-aware system architect
- Up to 8 iterations per query with automatic tool-calling and result observation
- **System Pulse** — continuous real-time telemetry daemon collecting 30+ metrics every 5 seconds (CPU thermals, RAM pressure, disk I/O, GPU utilisation, network, zombies, dmesg errors, active window)
- System Pulse data is injected into every AI prompt as a persistent "System Status" header — including trend arrows (↑→↓)
- **Proactive Alerts** — trend analysis detects CPU runaway, OOM risk, thermal throttling, disk-full trajectory, and zombie buildup before they become critical
- **Tool Calling** — 10 registered functions the AI can invoke autonomously:
  - `get_kernel_diagnostics()` — kernel version, top modules, sysctl values, dmesg tail
  - `monitor_process_tree()` — ps --forest with CPU/RAM consumers
  - `analyze_ebpf_events()` — eBPF sentinel status and recent alerts
  - `check_service_status()` — systemctl status or failed listing
  - `check_network_status()` — interfaces, DNS, gateway ping
  - `run_sandbox_test()` — test commands in sandboxed environment
  - `read_file()` — read-only file access with sensitive path blocking
  - `search_logs()` — journalctl search
  - `get_disk_health()` — lsblk + SMART status
  - `get_system_pulse()` — current telemetry snapshot
- **Dual tool-calling modes** — native Ollama `tools[]` protocol for qwen2.5/llama3.1/mistral, prompt-based fallback with `<tool_call>` XML extraction for other models
- **Safety Intercept** — global safety gate that classifies every AI-generated command as safe/needs_confirm/blocked:
  - 9 never-allow patterns (rm -rf /, dd zero to disk, fork bombs, etc.)
  - 40+ caution patterns (sudo, systemctl, package managers, /etc/, /boot/, firewall, modprobe, etc.)
  - Confidence scoring (0-100%) with risk level escalation
  - Audit log with 500-entry cap for forensic review
  - Commands classified as "blocked" are rejected instantly with a neon warning
  - Commands classified as "needs_confirm" show a safety-aware approval card with confidence score

### UI Enhancements
- **CustomTkinter compatibility** — auto-upgrades to modern rounded widgets when `customtkinter` is installed; falls back to standard tkinter
- **Spring physics animations** — Hooke's law simulation for smooth widget transitions (move, scale, fade, slide)
- Optional **pymunk** 2D physics engine integration for advanced spring dynamics

### Updates
- Check and apply **system package updates** (dnf / apt)
- Check and apply **sysfix-ai updates** from GitHub (git pull)

### Brain / Memory System
- Persistent local storage at `~/.config/sysfix/brain.json`
- Learns hardware, OS, DE, shell, package manager, dev tools
- Deep scan: dotfiles, aliases, git config, SSH hosts, projects (30+ types)
- Learns from conversations — extracts facts and preferences automatically
- Stores solutions that worked (and ones that didn't)
- **Brain export** — portable JSON with secrets scrubbed; migrate your brain to a new machine
- **Brain import** — merge or replace existing brain from an exported file
- **Hardware Profile Onboarding** — import your old brain to a new machine so Fyxa knows your preferences from day one

### Settings & Configuration
- 18 configurable options (AI, scanning, brain, autostart, etc.)
- Model selector — choose or auto-detect your Ollama model
- VirusTotal API key field
- Autostart on login (XDG desktop entry)
- All settings stored at `~/.config/sysfix/settings.json`
- GUI singleton guard — only one Sysfix GUI process can run at a time

### UI & Themes
- **5 themes** — Frutiger Aero (default), Light, Dark, Cyberpunk, Glass
- Semi-transparent, frosted-glass backgrounds with Pillow-generated textures
- Smooth momentum-based scrolling on all scrollable areas
- Progress bars on long-running security scans
- Desktop toast notifications via `notify-send` with status-bar fallback
- Clean, polished, futuristic aesthetic across all tabs

---

## Requirements

| Requirement | Details |
|-------------|---------|
| **OS** | Any modern Linux (Fedora, Ubuntu, Debian, Arch, etc.) |
| **Python** | 3.10 or newer |
| **Ollama** | Required for AI features — [ollama.com/download](https://ollama.com/download) |
| **Display server** | X11 or Wayland (for GUI mode; CLI works without) |

### Recommended AI model

```bash
ollama pull qwen3:8b        # Best balance of speed and quality
# or
ollama pull llama3.1:8b     # Good alternative
# or
ollama pull codellama        # Lighter option
```

Sysfix auto-detects whichever model you have installed.

---

## Installation

### Quick Install (recommended)

```bash
git clone https://github.com/useofscript/sysfix-ai.git
cd sysfix-ai
pip install -e .
```

### Run without installing

```bash
git clone https://github.com/useofscript/sysfix-ai.git
cd sysfix-ai
pip install psutil click rich ollama Pillow
python -m sysfixai.launcher
```

---

## Usage

### Launching

```bash
sysfix                  # GUI if display available, else CLI status
sysfix gui              # Force GUI launch
sysfix terminal         # Force terminal/CLI mode
```

### CLI Commands

| Command | Description |
|---------|-------------|
| `sysfix check` | Full diagnostics with optional AI fix |
| `sysfix run` | Quick scan → auto-offer AI fixes |
| `sysfix status` | One-line system health summary |
| `sysfix security` | Full security audit |
| `sysfix network` | Network diagnostics |
| `sysfix health` | System health (boot, systemd, SMART, USB) |
| `sysfix scan <path>` | Virus/malware hash scan on a file or directory |
| `sysfix scan --downloads` | Scan ~/Downloads for malware |
| `sysfix update` | Check & apply system + sysfix updates |
| `sysfix update --self` | Update sysfix-ai only |
| `sysfix update --system` | Update OS packages only |
| `sysfix update --check-only` | Check without installing |
| `sysfix chat` | Interactive Fyxa AI conversation |
| `sysfix brain stats` | Show brain statistics |
| `sysfix brain view` | Dump all brain contents |
| `sysfix brain learn` | Quick system learn |
| `sysfix brain learn --deep` | Deep learn (dotfiles, projects, tools) |
| `sysfix brain clear` | Erase all brain memory |
| `sysfix advanced` | Full advanced diagnostics report |
| `sysfix health-score` | Hardware health score (0-100) |
| `sysfix predict` | Predictive disk S.M.A.R.T. analysis |
| `sysfix zombies` | Find and kill zombie processes |
| `sysfix kernel-audit` | Audit sysctl kernel parameters |
| `sysfix energy` | Energy & battery profile |
| `sysfix logs` | Pre-failure log pattern analysis |
| `sysfix repos` | Repo & dependency audit |
| `sysfix export-brain <path>` | Export brain to portable JSON |
| `sysfix import-brain <path>` | Import brain from exported file |
| `sysfix prescriptive` | Prescriptive analysis (disk, journal, memory, services, updates) |
| `sysfix golden-state` | Golden State drift check (baseline comparison) |
| `sysfix golden-state --capture` | Capture current system as Golden State baseline |
| `sysfix golden-state --reconcile` | Restart stopped services to match Golden State |
| `sysfix log-search <query>` | Semantic natural-language log search |
| `sysfix sandbox <cmd> ...` | Test command(s) in sandboxed environment |
| `sysfix safety-pin` | Toggle Safety Pin mode (safe vs autonomous) |
| `sysfix sentinel` | eBPF Sentinel status (add `--start` / `--stop`) |
| `sysfix microvm <cmd>` | Run command in Firecracker micro-VM |
| `sysfix microvm --status` | Show micro-VM backend status |
| `sysfix microvm --setup` | Set up Firecracker VM environment |
| `sysfix npu` | NPU detection and offloading status |
| `sysfix pulse` | System Pulse telemetry status and report |
| `sysfix pulse --start` | Start the System Pulse daemon |
| `sysfix pulse --stop` | Stop the System Pulse daemon |
| `sysfix agent-status` | Agentic engine (1.1.0) capability report |
| `sysfix safety-log` | Safety Intercept audit log and pending approvals |
| `sysfix sentinel-av` | Sentinel AV status (add `--start` / `--stop`) |
| `sysfix av-threats` | List all threats detected by Sentinel AV |
| `sysfix av-threat-map` | Visual threat map from Sentinel AV |
| `sysfix pipeline <file>` | Multi-stage deep scan (ClamAV + YARA + VirusTotal + AI) |
| `sysfix pipeline --status` | Malware pipeline capability report |
| `sysfix pipeline --update-yara` | Update YARA community rules from GitHub |
| `sysfix bridge` | Sentinel Bridge full security scan (free tier) |
| `sysfix bridge --processes` | Scan processes for anomalies (miners, shells) |
| `sysfix bridge --network` | Scan network for C2/suspicious connections |
| `sysfix bridge --status` | Sentinel Bridge capability report |
| `sysfix interactive` | Full interactive menu (all features) |
| `sysfix fix N` | Fix issue #N with AI |
| `sysfix sudomode` | Hardware tuning (⚠️ DANGEROUS) |
| `sysfix version` | Version, model, and runtime info |

### Interactive Menu

`sysfix interactive` gives you a numbered menu with every feature:

```
 [1] Run Diagnostics
 [2] Fast Sweep AI Fix        (Ollama)
 [3] Deep Dive Troubleshooting (Ollama)
 [4] Security Audit
 [5] Network Diagnostics
 [6] System Health
 [7] Virus / Malware Scan
 [8] Check for Updates
 [9] Fyxa AI Chat              (Ollama)
 [a] Advanced Diagnostics
 [p] Prescriptive Analysis
 [g] Golden State (Drift Check)
 [l] Log Search
 [x] Sandbox Dry-Run
 [e] eBPF Sentinel
 [m] Micro-VM Sandbox
 [n] NPU Status
 [t] System Pulse (Telemetry)
 [z] Agentic Engine Status
 [y] Safety Intercept Log
 [v] Sentinel AV (Kernel Antivirus)
 [d] Deep Scan (Malware Pipeline)
 [j] Sentinel Bridge (AI Security Scanner)
 [b] Brain (Memory)
 [s] System Status
 [h] Hardware Tuning           (DANGEROUS)
 [q] Quit
```

### GUI Tabs

The desktop GUI has 8 tabs:

1. **Dashboard** — Live CPU/RAM/Disk/Temp/GPU gauges, diagnostic log
2. **Quick Fix** — Fast Sweep, Auto-Fix, Memory Optimisation, Disk Cleanup
3. **Security** — Full audit, virus scanning, real-time AV, system updates
4. **Network** — Interface, DNS, gateway, connectivity checks, Wi-Fi optimisation
5. **Health** — Predictive maintenance, health score, zombie hunter, kernel tuning, log analysis, repo audit, energy profiler, network self-healing, prescriptive analysis, golden state engine, sandbox dry-run, semantic log search, safety pin toggle, eBPF sentinel, micro-VM sandbox, NPU status, Sentinel AV (kernel antivirus), UI enhancements status
6. **AI Chat** — Conversational Fyxa with web search and code execution (PII-scrubbed context, ELI5 mode, Command Palette via Ctrl+K)
7. **Brain** — View, learn, deep-learn, clear brain memory, export/import
8. **Settings** — All 22 toggles, model selector, API keys, autostart, ELI5 mode, advanced diagnostics

### Sudo Mode (GUI)

- Use **Dashboard → Enable Sudo Mode** to relaunch the GUI with root privileges
- Sysfix performs an automatic handoff: after authentication, the elevated window replaces the non-sudo window
- GUI runs in **single-instance mode**: a second launch is blocked while one instance is already running

---

## Safety

- Every destructive action requires your explicit `y/n` confirmation
- AI recommendations are shown *before* execution — nothing runs automatically
- **Safety Pin mode** — when pinned (Safe Mode), Fyxa explains every step and waits for confirmation; when unpinned (Autonomous Mode), only non-destructive optimisations run automatically
- **Sandboxed dry-runs** — proposed fixes can be tested in an isolated container (bwrap/podman/distrobox) before touching the live system
- **Config snapshots** — automatic versioned backups before any config change, with one-click rollback
- **PII scrubbing** — 11 regex patterns mask personal data before it reaches the AI
- GUI sudo elevation is explicit and replaces the existing non-sudo window
- Only one Sysfix GUI instance is allowed at a time
- Brain data never leaves your machine — stored locally at `~/.config/sysfix/`
- Virus scanning uses hash lookups only — files are never uploaded
- **Air-gap ready** — runs entirely on local Ollama models; works without internet

---

## Configuration

All settings are stored at `~/.config/sysfix/settings.json` and can be changed
via the GUI Settings tab or by editing the file directly.

Key settings:

| Setting | Default | Description |
|---------|---------|-------------|
| `enable_ai_features` | `true` | Enable AI-powered analysis |
| `enable_web_search` | `true` | Allow Fyxa to search the web |
| `enable_brain` | `true` | Master toggle for brain/memory |
| `brain_learn_conversations` | `true` | Learn from AI chat exchanges |
| `brain_auto_observe_on_startup` | `true` | Scan system when GUI opens |
| `autostart_on_boot` | `false` | Auto-launch on login |
| `ai_model` | `""` (auto) | Override AI model selection |
| `virustotal_api_key` | `""` | VirusTotal API key for malware scanning |
| `eli5_mode` | `false` | Plain-language vs technical AI explanations |
| `enable_predictive_maintenance` | `true` | Enable S.M.A.R.T. predictive analysis |
| `enable_zombie_hunter` | `true` | Enable zombie process detection |
| `auto_snapshot_before_fix` | `true` | Snapshot config before AI-applied fixes |
| `agent_mode_enabled` | `false` | Safety Pin: autonomous mode for non-destructive actions |
| `agent_mode_dry_run` | `true` | Agent mode dry-run (simulate before applying) |

---

## Troubleshooting

**"Ollama connection failed"**
→ Start Ollama: `ollama serve`

**AI is slow or unresponsive**
→ Try a lighter model: `ollama pull codellama`

**"Permission denied"**
→ Some checks need elevated privileges: `sudo sysfix check`

**Enable Sudo Mode says Sysfix is already running**
→ Close the existing Sysfix GUI window first, then relaunch.

**GUI won't launch**
→ Make sure you have a display server (X11/Wayland) and Tk: `sudo dnf install python3-tkinter`

**"No issues found"**
→ Your system is healthy! 🎉

---

## Project Structure

```
sysfixai/
├── __init__.py        # Package init, version
├── launcher.py        # Smart routing → GUI or CLI
├── gui.py             # 8-tab Tkinter desktop application
├── cli.py             # Full-featured Rich terminal interface
├── ai.py              # Fyxa AI — Ollama Chat API, web search, brain integration
├── core.py            # Diagnostic engine, issue tracking, AI fix orchestration
├── diagnostics.py     # Security, network, health, virus, updates
├── advanced_diagnostics.py  # Health score, predictive maintenance, zombie hunter, kernel tuning, log analysis, repo audit, energy, network heal, PII scrubbing, config versioning, brain export/import
├── sandbox.py         # Sandboxed dry-runs, Golden State engine, prescriptive analysis, semantic log search, safety pin
├── ebpf_sentinel.py   # eBPF real-time process & network monitoring (bcc)
├── sentinel_av.py     # Sentinel AV — kernel-level eBPF antivirus engine (cgroups freezing, Stasis Chamber, ClamAV, AI reasoning)
├── malware_pipeline.py # Multi-stage malware verification (ClamAV + YARA + VirusTotal + AI interpretation)
├── sentinel_bridge.py  # SentinelBridge — pure-Python eBPF security bridge for AI tool-calling (ebpfcat + /proc fallback)
├── microvm.py         # Firecracker micro-VM sandbox (fallback: bwrap/podman)
├── npu.py             # NPU detection & inference offloading (Intel/AMD)
├── ui_enhancements.py # CustomTkinter compat layer, spring physics animations
├── memory.py          # Brain/memory system (persistent JSON)
├── config.py          # Settings management (~/.config/sysfix/)
└── fixes.py           # Fix templates (extensible)
```

---

## Contributing

Found a bug?  Have a feature idea?

Open an issue or pull request:
[github.com/useofscript/sysfix-ai](https://github.com/useofscript/sysfix-ai)

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

**Made for Linux users who want full control over their system.** ✨
