"""
sysfixai — Professional Linux diagnostics with AI-powered fixes.

Powered by Fyxa AI.  Includes a 7-tab GUI, full-featured CLI,
security auditing, network diagnostics, virus scanning, and a
persistent brain/memory system.
"""

__version__ = "1.1.0"

__all__ = [
    "ai",
    "brain",
    "cli",
    "config",
    "core",
    "diagnostics",
    "hardware_governor",
    "license_guard",
    "memory",
    "ram_turbo",
    "sysfix_brain",
]
