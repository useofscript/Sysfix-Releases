"""
Pillar 3 — RAM-Turbo: Flexible Memory Compression & Optimization.

Provides:
  - ZramDetector    — detect zram-generator / zram-tools / zswap
  - ZramOptimizer   — configure zRAM with zstd + 1:1 ratio
  - KernelTuner     — vm.swappiness, vfs_cache_pressure, dirty_ratio
  - GlobalFlush     — emergency memory purge (sync + drop_caches)
  - RamTurbo        — unified façade

All writes go through pkexec — never runs as root directly.
"""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("sysfix.ram_turbo")


# ───────────────────────────────────────────────────────────────────────────
# Helpers
# ───────────────────────────────────────────────────────────────────────────

def _run(cmd: List[str], *, timeout: int = 5) -> str:
    if not shutil.which(cmd[0]):
        return ""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def _run_privileged(cmd: List[str], *, timeout: int = 10) -> Tuple[bool, str]:
    pkexec = shutil.which("pkexec")
    if not pkexec:
        return False, "pkexec not available"
    try:
        r = subprocess.run([pkexec] + cmd, capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        if r.returncode == 0:
            return True, r.stdout.strip()
        return False, r.stderr.strip() or f"exit code {r.returncode}"
    except subprocess.TimeoutExpired:
        return False, "command timed out"
    except Exception as exc:
        return False, str(exc)


def _read_sysfs(path: str) -> str:
    try:
        return Path(path).read_text().strip()
    except OSError:
        return ""


def _read_meminfo() -> Dict[str, int]:
    """Parse /proc/meminfo into a dict of kB values."""
    mem: Dict[str, int] = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val_parts = parts[1].strip().split()
                    if val_parts and val_parts[0].isdigit():
                        mem[key] = int(val_parts[0])
    except OSError:
        pass
    return mem


# ───────────────────────────────────────────────────────────────────────────
# Compression Detection
# ───────────────────────────────────────────────────────────────────────────

@dataclass
class MemoryCompressionState:
    """Detected memory compression backend."""
    method: str = "none"               # zram | zswap | none
    backend: str = "none"              # zram-generator | zram-tools | kernel
    zram_devices: List[str] = field(default_factory=list)
    zram_algorithm: str = ""           # lzo | lzo-rle | zstd | lz4
    zram_size_bytes: int = 0
    zram_compressed_bytes: int = 0
    zram_original_bytes: int = 0
    zswap_enabled: bool = False
    zswap_compressor: str = ""
    zswap_pool: str = ""
    physical_ram_kb: int = 0
    swap_total_kb: int = 0
    swap_free_kb: int = 0


class ZramDetector:
    """Detect zRAM / zswap configuration across distributions."""

    @classmethod
    def detect(cls) -> MemoryCompressionState:
        mem = _read_meminfo()
        state = MemoryCompressionState(
            physical_ram_kb=mem.get("MemTotal", 0),
            swap_total_kb=mem.get("SwapTotal", 0),
            swap_free_kb=mem.get("SwapFree", 0),
        )

        # Check zRAM
        cls._detect_zram(state)

        # Check zswap
        cls._detect_zswap(state)

        return state

    @classmethod
    def _detect_zram(cls, state: MemoryCompressionState) -> None:
        """Check for zRAM block devices."""
        zram_base = Path("/sys/block")
        if not zram_base.is_dir():
            return

        for entry in sorted(zram_base.iterdir()):
            if not entry.name.startswith("zram"):
                continue
            state.zram_devices.append(entry.name)

            # Read algorithm
            algo = _read_sysfs(str(entry / "comp_algorithm"))
            if algo:
                # Current algo is in brackets: lzo [lzo-rle] lz4 zstd
                m = re.search(r"\[(\w[\w-]*)\]", algo)
                state.zram_algorithm = m.group(1) if m else algo.split()[0]

            # Read stats
            disksize = _read_sysfs(str(entry / "disksize"))
            if disksize.isdigit():
                state.zram_size_bytes = int(disksize)

            # mm_stat: orig_data_size compr_data_size mem_used_total ...
            mm_stat = _read_sysfs(str(entry / "mm_stat"))
            if mm_stat:
                parts = mm_stat.split()
                if len(parts) >= 2:
                    if parts[0].isdigit():
                        state.zram_original_bytes = int(parts[0])
                    if parts[1].isdigit():
                        state.zram_compressed_bytes = int(parts[1])

        if state.zram_devices:
            state.method = "zram"
            # Detect the backend
            if shutil.which("zram-generator"):
                state.backend = "zram-generator"
            elif Path("/etc/systemd/zram-generator.conf").exists():
                state.backend = "zram-generator"
            elif shutil.which("zramctl"):
                state.backend = "zram-tools"
            elif Path("/etc/default/zramswap").exists():
                state.backend = "zram-tools"
            else:
                state.backend = "kernel"

    @classmethod
    def _detect_zswap(cls, state: MemoryCompressionState) -> None:
        """Check kernel zswap."""
        enabled = _read_sysfs("/sys/module/zswap/parameters/enabled")
        if enabled in ("Y", "1"):
            state.zswap_enabled = True
            state.zswap_compressor = _read_sysfs(
                "/sys/module/zswap/parameters/compressor"
            ) or "lzo"
            state.zswap_pool = _read_sysfs(
                "/sys/module/zswap/parameters/zpool"
            ) or "zbud"
            if state.method == "none":
                state.method = "zswap"
                state.backend = "kernel"


# ───────────────────────────────────────────────────────────────────────────
# zRAM Optimizer
# ───────────────────────────────────────────────────────────────────────────

class ZramOptimizer:
    """Configure zRAM for optimal compression."""

    @classmethod
    def optimize(cls, *, algorithm: str = "zstd",
                 ratio: float = 1.0) -> Tuple[bool, str]:
        """Configure zRAM with the desired algorithm and size ratio.

        Args:
            algorithm: Compression algorithm (zstd recommended for best ratio).
            ratio: Size relative to physical RAM (1.0 = same as RAM).

        Returns:
            (success, message) tuple.
        """
        state = ZramDetector.detect()
        results: List[str] = []

        if not state.zram_devices:
            # No zRAM devices — try to create one
            ok, msg = cls._create_zram(state.physical_ram_kb, algorithm, ratio)
            return ok, msg

        # Configure existing zRAM devices
        for dev in state.zram_devices:
            dev_path = f"/sys/block/{dev}"

            # Must reset before reconfiguring
            # First deactivate swap on this device
            _run_privileged(["swapoff", f"/dev/{dev}"])

            # Reset the device
            ok, _ = _run_privileged(
                ["sh", "-c", f"echo 1 > {dev_path}/reset"]
            )

            # Set algorithm
            ok, msg = _run_privileged(
                ["sh", "-c", f"echo {algorithm} > {dev_path}/comp_algorithm"]
            )
            if ok:
                results.append(f"✓ {dev}: algorithm → {algorithm}")
            else:
                results.append(f"✗ {dev}: failed to set {algorithm} ({msg})")

            # Set disk size (ratio × physical RAM)
            size_bytes = int(state.physical_ram_kb * 1024 * ratio)
            ok, msg = _run_privileged(
                ["sh", "-c", f"echo {size_bytes} > {dev_path}/disksize"]
            )
            if ok:
                size_gb = size_bytes / (1024 ** 3)
                results.append(f"✓ {dev}: size → {size_gb:.1f} GB ({ratio}:1 ratio)")
            else:
                results.append(f"✗ {dev}: failed to set size ({msg})")

            # Make and activate swap
            ok, _ = _run_privileged(["mkswap", f"/dev/{dev}"])
            ok, _ = _run_privileged(["swapon", "-p", "100", f"/dev/{dev}"])
            if ok:
                results.append(f"✓ {dev}: swap activated (priority 100)")

        return bool(results), "\n".join(results) if results else "✗ No changes made"

    @classmethod
    def _create_zram(cls, ram_kb: int, algorithm: str,
                     ratio: float) -> Tuple[bool, str]:
        """Create a new zRAM device from scratch."""
        # Load module
        _run_privileged(["modprobe", "zram"])

        # Check if device appeared
        if not Path("/sys/block/zram0").exists():
            return False, "✗ Could not create zRAM device (modprobe zram failed)"

        dev_path = "/sys/block/zram0"
        size_bytes = int(ram_kb * 1024 * ratio)

        results: List[str] = []

        ok, _ = _run_privileged(
            ["sh", "-c", f"echo {algorithm} > {dev_path}/comp_algorithm"]
        )
        if ok:
            results.append(f"✓ zram0: algorithm → {algorithm}")

        ok, _ = _run_privileged(
            ["sh", "-c", f"echo {size_bytes} > {dev_path}/disksize"]
        )
        if ok:
            results.append(f"✓ zram0: size → {size_bytes // (1024**3):.1f} GB")

        _run_privileged(["mkswap", "/dev/zram0"])
        ok, _ = _run_privileged(["swapon", "-p", "100", "/dev/zram0"])
        if ok:
            results.append("✓ zram0: activated as high-priority swap")

        return bool(results), "\n".join(results) if results else "✗ zRAM creation failed"

    @classmethod
    def status(cls) -> Dict[str, Any]:
        """Get a summary of zRAM status."""
        state = ZramDetector.detect()
        result: Dict[str, Any] = {
            "method": state.method,
            "backend": state.backend,
            "devices": state.zram_devices,
            "algorithm": state.zram_algorithm,
            "physical_ram_mb": state.physical_ram_kb // 1024,
        }
        if state.zram_size_bytes:
            result["zram_size_mb"] = state.zram_size_bytes // (1024 * 1024)
            result["zram_original_mb"] = state.zram_original_bytes // (1024 * 1024)
            result["zram_compressed_mb"] = state.zram_compressed_bytes // (1024 * 1024)
            if state.zram_compressed_bytes > 0:
                result["compression_ratio"] = round(
                    state.zram_original_bytes / state.zram_compressed_bytes, 2
                )
        if state.zswap_enabled:
            result["zswap"] = {
                "enabled": True,
                "compressor": state.zswap_compressor,
                "pool": state.zswap_pool,
            }
        return result


# ───────────────────────────────────────────────────────────────────────────
# Kernel Tuner — sysctl optimizations
# ───────────────────────────────────────────────────────────────────────────

@dataclass
class KernelTuneProfile:
    """A set of sysctl parameters to apply."""
    name: str
    params: Dict[str, str]
    description: str = ""


# Pre-defined tune profiles
TUNE_ZRAM = KernelTuneProfile(
    name="zram-optimized",
    description="Optimized for zRAM-backed systems",
    params={
        "vm.swappiness": "150",
        "vm.vfs_cache_pressure": "50",
        "vm.dirty_ratio": "10",
        "vm.dirty_background_ratio": "5",
        "vm.dirty_writeback_centisecs": "1500",
    },
)

TUNE_SSD = KernelTuneProfile(
    name="ssd-optimized",
    description="Optimized for SSD-backed systems",
    params={
        "vm.swappiness": "10",
        "vm.vfs_cache_pressure": "50",
        "vm.dirty_ratio": "15",
        "vm.dirty_background_ratio": "5",
    },
)

TUNE_DESKTOP = KernelTuneProfile(
    name="desktop-responsive",
    description="Low-latency desktop responsiveness",
    params={
        "vm.swappiness": "60",
        "vm.vfs_cache_pressure": "100",
        "vm.dirty_ratio": "20",
        "vm.dirty_background_ratio": "10",
        "kernel.sched_autogroup_enabled": "1",
    },
)


class KernelTuner:
    """Read and apply sysctl parameters."""

    @classmethod
    def read_param(cls, param: str) -> str:
        """Read a sysctl parameter's current value."""
        out = _run(["sysctl", "-n", param])
        return out

    @classmethod
    def read_all(cls, params: List[str]) -> Dict[str, str]:
        """Read multiple sysctl parameters."""
        return {p: cls.read_param(p) for p in params}

    @classmethod
    def apply_profile(cls, profile: KernelTuneProfile) -> Tuple[bool, str]:
        """Apply a predefined sysctl profile."""
        results: List[str] = []
        all_ok = True

        for param, value in profile.params.items():
            old_value = cls.read_param(param)
            if old_value == value:
                results.append(f"• {param} = {value} (already set)")
                continue

            ok, msg = _run_privileged(["sysctl", "-w", f"{param}={value}"])
            if ok:
                results.append(f"✓ {param}: {old_value} → {value}")
            else:
                results.append(f"✗ {param}: failed ({msg})")
                all_ok = False

        header = f"**{profile.name}** — {profile.description}"
        return all_ok, f"{header}\n\n" + "\n".join(results)

    @classmethod
    def auto_tune(cls) -> Tuple[bool, str]:
        """Automatically select and apply the best profile.

        Uses zRAM profile if zRAM is active, otherwise SSD or desktop.
        """
        state = ZramDetector.detect()

        if state.method == "zram":
            return cls.apply_profile(TUNE_ZRAM)

        # Check for SSD
        for dev in Path("/sys/block").iterdir():
            rotational = _read_sysfs(str(dev / "queue" / "rotational"))
            if rotational == "0" and not dev.name.startswith("zram"):
                return cls.apply_profile(TUNE_SSD)

        return cls.apply_profile(TUNE_DESKTOP)

    @classmethod
    def current_state(cls) -> Dict[str, str]:
        """Read all tunable parameters."""
        params = [
            "vm.swappiness",
            "vm.vfs_cache_pressure",
            "vm.dirty_ratio",
            "vm.dirty_background_ratio",
            "vm.dirty_writeback_centisecs",
            "kernel.sched_autogroup_enabled",
        ]
        return cls.read_all(params)


# ───────────────────────────────────────────────────────────────────────────
# Emergency Flush
# ───────────────────────────────────────────────────────────────────────────

class GlobalFlush:
    """Emergency memory purge — sync and drop caches.

    Respects different kernel versions and memory management quirks.
    """

    @classmethod
    def flush(cls, *, drop_level: int = 3) -> Tuple[bool, str]:
        """Perform a global memory flush.

        Args:
            drop_level: 1=pagecache, 2=dentries+inodes, 3=all (default).

        Returns:
            (success, detailed_report).
        """
        if drop_level not in (1, 2, 3):
            return False, "✗ drop_level must be 1, 2, or 3"

        mem_before = _read_meminfo()
        results: List[str] = []

        # Step 1: sync all filesystems
        ok, msg = _run_privileged(["sync"])
        if ok:
            results.append("✓ Filesystem sync complete")
        else:
            results.append(f"⚠ Sync returned: {msg}")

        # Step 2: drop caches
        ok, msg = _run_privileged(
            ["sh", "-c", f"echo {drop_level} > /proc/sys/vm/drop_caches"]
        )
        if ok:
            labels = {1: "page cache", 2: "dentries+inodes", 3: "all caches"}
            results.append(f"✓ Dropped {labels.get(drop_level, 'caches')}")
        else:
            results.append(f"✗ Cache drop failed: {msg}")

        # Step 3: compact memory (if available, kernel 5.1+)
        compact_path = "/proc/sys/vm/compact_memory"
        if Path(compact_path).exists():
            ok, _ = _run_privileged(
                ["sh", "-c", f"echo 1 > {compact_path}"]
            )
            if ok:
                results.append("✓ Memory compaction triggered")

        # Report freed memory
        mem_after = _read_meminfo()
        avail_before = mem_before.get("MemAvailable", 0)
        avail_after = mem_after.get("MemAvailable", 0)
        freed_kb = avail_after - avail_before
        if freed_kb > 0:
            freed_mb = freed_kb / 1024
            results.append(f"\n**Freed:** {freed_mb:.0f} MB")
        else:
            results.append("\nℹ No significant memory freed (caches were clean)")

        return ok, "\n".join(results)

    @classmethod
    def flush_swap(cls) -> Tuple[bool, str]:
        """Flush swap back to RAM (swapoff + swapon cycle).

        Only safe if there's enough free RAM to hold all swap data.
        """
        mem = _read_meminfo()
        avail_kb = mem.get("MemAvailable", 0)
        swap_used_kb = mem.get("SwapTotal", 0) - mem.get("SwapFree", 0)

        if swap_used_kb <= 0:
            return True, "ℹ No swap in use — nothing to flush"

        if avail_kb < swap_used_kb * 1.2:
            return False, (
                f"✗ Not enough free RAM ({avail_kb // 1024} MB available) "
                f"to flush swap ({swap_used_kb // 1024} MB in use). "
                f"Need at least {int(swap_used_kb * 1.2) // 1024} MB free."
            )

        # Get swap entries
        swaps_raw = _run(["swapon", "--show=NAME", "--noheadings"])
        if not swaps_raw:
            return False, "✗ Could not list swap devices"

        swap_devs = swaps_raw.strip().splitlines()
        results: List[str] = []

        for dev in swap_devs:
            dev = dev.strip()
            if not dev:
                continue
            # Deactivate
            ok, _ = _run_privileged(["swapoff", dev])
            if ok:
                results.append(f"✓ Deactivated: {dev}")
                # Reactivate
                ok, _ = _run_privileged(["swapon", dev])
                if ok:
                    results.append(f"✓ Reactivated: {dev}")
                else:
                    results.append(f"⚠ Re-activation failed: {dev}")
            else:
                results.append(f"✗ Could not deactivate: {dev}")

        return bool(results), "\n".join(results) if results else "✗ No swap devices processed"


# ───────────────────────────────────────────────────────────────────────────
# RamTurbo — unified façade
# ───────────────────────────────────────────────────────────────────────────

class RamTurbo:
    """Unified memory optimization interface."""

    @classmethod
    def status(cls) -> Dict[str, Any]:
        """Full memory subsystem status."""
        mem = _read_meminfo()
        zram_status = ZramOptimizer.status()
        kernel_state = KernelTuner.current_state()

        return {
            "physical_ram_mb": mem.get("MemTotal", 0) // 1024,
            "available_mb": mem.get("MemAvailable", 0) // 1024,
            "swap_total_mb": mem.get("SwapTotal", 0) // 1024,
            "swap_used_mb": (mem.get("SwapTotal", 0) - mem.get("SwapFree", 0)) // 1024,
            "cached_mb": mem.get("Cached", 0) // 1024,
            "buffers_mb": mem.get("Buffers", 0) // 1024,
            "zram": zram_status,
            "sysctl": kernel_state,
        }

    @classmethod
    def optimize(cls) -> Tuple[bool, str]:
        """Run the full memory optimization pipeline.

        1. Configure zRAM with zstd (1:1 ratio)
        2. Apply kernel sysctl tuning
        """
        results: List[str] = ["## RAM-Turbo Optimization\n"]
        all_ok = True

        # Step 1: zRAM
        state = ZramDetector.detect()
        if state.method == "zram" or state.zram_devices:
            ok, msg = ZramOptimizer.optimize(algorithm="zstd", ratio=1.0)
            results.append(f"### zRAM Configuration\n{msg}\n")
            all_ok = all_ok and ok
        else:
            results.append("### zRAM\nℹ No zRAM devices detected — creating one\n")
            ok, msg = ZramOptimizer.optimize(algorithm="zstd", ratio=1.0)
            results.append(f"{msg}\n")
            all_ok = all_ok and ok

        # Step 2: Kernel tuning
        ok, msg = KernelTuner.auto_tune()
        results.append(f"### Kernel Tuning\n{msg}\n")

        return all_ok, "\n".join(results)

    @classmethod
    def emergency_flush(cls) -> Tuple[bool, str]:
        """Emergency memory purge."""
        results: List[str] = ["## Emergency Memory Flush\n"]

        ok, msg = GlobalFlush.flush(drop_level=3)
        results.append(msg)

        return ok, "\n".join(results)
