"""
Sysfix Brain — Complete Local-First AI Engine.

A single-file, distro-agnostic AI agent that:
  • Connects to a locally running Ollama instance (with llama-cpp-python
    GGUF fallback for fully offline operation).
  • Gathers real-time system telemetry via psutil — no /proc/ parsing,
    works on every Linux distro (and macOS/Windows in a pinch).
  • Uses shutil.which() to discover available CLI tools instead of
    hard-coding distro-specific paths.
  • Searches the web via duckduckgo_search when the system context
    indicates an error or the model needs extra knowledge.
  • Chains telemetry → error detection → web research → LLM inference
    in a single think() call.

Zero-Cloud by default: all inference runs on-device through Ollama or
a local GGUF model.  Web search is the *only* network call and is
triggered only when needed.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import re
import shutil
import socket
import subprocess
import textwrap
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import psutil

log = logging.getLogger("sysfix.brain")

# ── Optional imports — graceful degradation ──────────────────────────────

_HAS_DDGS: bool = False
try:
    from duckduckgo_search import DDGS  # type: ignore[import-untyped]
    _HAS_DDGS = True
except ImportError:
    pass

_HAS_LLAMA_CPP: bool = False
try:
    from llama_cpp import Llama  # type: ignore[import-untyped]
    _HAS_LLAMA_CPP = True
except ImportError:
    pass


# ── Ollama configuration ────────────────────────────────────────────────

def _ollama_base() -> str:
    """Return the Ollama API base URL from config or environment."""
    base = os.environ.get("OLLAMA_HOST", "").strip()
    if base:
        return base.rstrip("/")
    try:
        from sysfixai.config import load_config  # type: ignore[import-untyped]
        cfg: Dict[str, Any] = load_config()
        return str(cfg.get("ollama_endpoint", "http://localhost:11434")).rstrip("/")
    except Exception:
        return "http://localhost:11434"


# Model preference — local first, only well-known open models
_MODEL_PREFERENCE = [
    "qwen3:8b",
    "llama3.1:8b",
    "mistral:7b",
    "gemma2:9b",
    "phi3:mini",
    "codellama:latest",
]


# ── GGUF discovery (for llama-cpp-python offline fallback) ───────────────

_GGUF_DIRS = [
    Path.home() / ".local" / "share" / "sysfix" / "models",
    Path.home() / ".cache" / "sysfix" / "models",
    Path("/usr/share/sysfix/models"),
    Path("/opt/sysfix/models"),
]


def _find_gguf(hint: str = "") -> Optional[Path]:
    """Locate a .gguf model file on disk."""
    if hint and os.path.isfile(hint):
        return Path(hint)
    hint_lower = hint.lower() if hint else ""
    candidates: list[Path] = []
    for d in _GGUF_DIRS:
        if not d.is_dir():
            continue
        for f in d.glob("*.gguf"):
            if hint_lower and hint_lower in f.name.lower():
                return f
            candidates.append(f)
    return sorted(candidates)[0] if candidates else None


# ═════════════════════════════════════════════════════════════════════════
#  Distro Detection — universal, no hard-coded paths
# ═════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class DistroSnapshot:
    """Immutable snapshot of the Linux environment."""
    name: str = "Unknown"
    pretty_name: str = "Unknown Linux"
    distro_id: str = "unknown"
    id_like: str = ""
    version: str = ""
    kernel: str = ""
    init_system: str = "unknown"
    pkg_manager: str = "unknown"
    desktop: str = "unknown"
    shell: str = "bash"
    hostname: str = ""


_distro_cache: Optional[DistroSnapshot] = None


def detect_distro(*, force: bool = False) -> DistroSnapshot:
    """Detect the Linux environment — cached singleton."""
    global _distro_cache
    if _distro_cache is not None and not force:
        return _distro_cache

    os_rel = _read_os_release()

    _distro_cache = DistroSnapshot(
        name=os_rel.get("NAME", "Unknown"),
        pretty_name=os_rel.get("PRETTY_NAME", "Unknown Linux"),
        distro_id=os_rel.get("ID", "unknown"),
        id_like=os_rel.get("ID_LIKE", ""),
        version=os_rel.get("VERSION_ID", ""),
        kernel=platform.release(),
        init_system=_detect_init(),
        pkg_manager=_detect_pkg_manager(os_rel.get("ID", ""),
                                         os_rel.get("ID_LIKE", "")),
        desktop=_detect_desktop(),
        shell=os.path.basename(os.environ.get("SHELL", "/bin/bash")),
        hostname=socket.gethostname(),
    )
    return _distro_cache


def _read_os_release() -> Dict[str, str]:
    for path in ("/etc/os-release", "/usr/lib/os-release"):
        try:
            data: Dict[str, str] = {}
            with open(path) as fh:
                for line in fh:
                    line = line.strip()
                    if "=" in line:
                        k, v = line.split("=", 1)
                        data[k] = v.strip('"')
            return data
        except FileNotFoundError:
            continue
    return {}


def _detect_init() -> str:
    try:
        comm = Path("/proc/1/comm").read_text().strip()
        if comm == "systemd":
            return "systemd"
    except OSError:
        pass
    for binary, name in [("systemctl", "systemd"), ("rc-service", "openrc"),
                         ("runit", "runit")]:
        if shutil.which(binary):
            return name
    return "sysvinit" if Path("/etc/init.d").is_dir() else "unknown"


def _detect_pkg_manager(distro_id: str, id_like: str) -> str:
    family = f"{distro_id} {id_like}".lower()
    mapping: list[tuple[list[str], str, str]] = [
        (["arch", "manjaro", "endeavouros", "garuda", "cachyos"], "pacman", "pacman"),
        (["debian", "ubuntu", "mint", "pop", "elementary", "zorin"], "apt", "apt"),
        (["fedora", "rhel", "centos", "rocky", "alma", "nobara"], "dnf", "dnf"),
        (["opensuse", "suse"], "zypper", "zypper"),
        (["void"], "xbps-install", "xbps"),
        (["alpine"], "apk", "apk"),
        (["gentoo", "funtoo"], "emerge", "portage"),
        (["nixos", "nix"], "nix-env", "nix"),
    ]
    for keywords, binary, label in mapping:
        if any(kw in family for kw in keywords) and shutil.which(binary):
            return label
    # Fallback — just check what's installed
    for binary, label in [("pacman", "pacman"), ("apt", "apt"), ("dnf", "dnf"),
                          ("zypper", "zypper"), ("xbps-install", "xbps"),
                          ("apk", "apk"), ("emerge", "portage")]:
        if shutil.which(binary):
            return label
    return "unknown"


def _detect_desktop() -> str:
    for var in ("XDG_CURRENT_DESKTOP", "XDG_SESSION_DESKTOP", "DESKTOP_SESSION"):
        val = os.environ.get(var, "").lower()
        if not val:
            continue
        for tag in ("kde", "plasma", "gnome", "xfce", "sway", "hyprland",
                    "i3", "cinnamon", "mate", "lxqt", "budgie", "cosmic"):
            if tag in val:
                return "kde" if tag == "plasma" else tag
        return val
    return "unknown"


# ═════════════════════════════════════════════════════════════════════════
#  System Telemetry — 100% psutil + shutil.which, zero /proc/ parsing
# ═════════════════════════════════════════════════════════════════════════

def _run_tool(args: list[str], timeout: int = 5) -> str:
    """Run a CLI tool only if it exists (via shutil.which)."""
    if not shutil.which(args[0]):
        return ""
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


class SystemTelemetry:
    """Cross-platform system telemetry via psutil.

    Every method uses the psutil API so this module works unchanged on
    Fedora, Ubuntu, Arch, Void, Alpine, NixOS — any distro.
    """

    @staticmethod
    def cpu() -> Dict[str, Any]:
        freq = psutil.cpu_freq()
        return {
            "usage_percent": psutil.cpu_percent(interval=0.3),
            "cores_logical": psutil.cpu_count(logical=True),
            "cores_physical": psutil.cpu_count(logical=False),
            "frequency_mhz": round(freq.current, 1) if freq else 0,
            "freq_max_mhz": round(freq.max, 1) if freq and freq.max else 0,
            "load_avg_1m": round(psutil.getloadavg()[0], 2),
            "load_avg_5m": round(psutil.getloadavg()[1], 2),
            "load_avg_15m": round(psutil.getloadavg()[2], 2),
        }

    @staticmethod
    def memory() -> Dict[str, Any]:
        vm = psutil.virtual_memory()
        sw = psutil.swap_memory()
        return {
            "total_mb": round(vm.total / 1048576),
            "available_mb": round(vm.available / 1048576),
            "used_mb": round(vm.used / 1048576),
            "usage_percent": vm.percent,
            "swap_total_mb": round(sw.total / 1048576),
            "swap_used_mb": round(sw.used / 1048576),
            "swap_percent": sw.percent,
        }

    @staticmethod
    def disk() -> Dict[str, Any]:
        root = psutil.disk_usage("/")
        io = psutil.disk_io_counters()
        return {
            "root_total_gb": round(root.total / 1073741824, 1),
            "root_used_gb": round(root.used / 1073741824, 1),
            "root_free_gb": round(root.free / 1073741824, 1),
            "root_percent": root.percent,
            "read_mb": round(io.read_bytes / 1048576) if io else 0,
            "write_mb": round(io.write_bytes / 1048576) if io else 0,
        }

    @staticmethod
    def network() -> Dict[str, Any]:
        net = psutil.net_io_counters()
        addrs = psutil.net_if_addrs()
        active_ifaces = [
            name for name, snics in addrs.items()
            if name != "lo" and any(s.address for s in snics)
        ]
        return {
            "bytes_sent_mb": round(net.bytes_sent / 1048576) if net else 0,
            "bytes_recv_mb": round(net.bytes_recv / 1048576) if net else 0,
            "active_interfaces": active_ifaces[:5],
        }

    @staticmethod
    def temperatures() -> Dict[str, float]:
        """CPU/GPU temperatures via psutil (uses lm-sensors on Linux)."""
        temps: Dict[str, float] = {}
        try:
            for label, entries in psutil.sensors_temperatures().items():
                for entry in entries:
                    tag = entry.label or label
                    temps[tag] = entry.current
        except (AttributeError, RuntimeError):
            pass
        return temps

    @staticmethod
    def battery() -> Optional[Dict[str, Any]]:
        bat = psutil.sensors_battery()
        if bat is None:
            return None
        return {
            "percent": bat.percent,
            "plugged_in": bat.power_plugged,
            "secs_left": bat.secsleft if bat.secsleft != psutil.POWER_TIME_UNLIMITED else -1,
        }

    @staticmethod
    def top_processes(n: int = 10) -> list[Dict[str, Any]]:
        """Top N processes by CPU usage."""
        procs: list[Dict[str, Any]] = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                info = p.info  # type: ignore[attr-defined]
                procs.append({
                    "pid": info["pid"],
                    "name": info["name"],
                    "cpu": info.get("cpu_percent", 0.0) or 0.0,
                    "mem": round(info.get("memory_percent", 0.0) or 0.0, 1),
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        procs.sort(key=lambda p: p["cpu"], reverse=True)
        return procs[:n]

    @staticmethod
    def uptime() -> str:
        boot = psutil.boot_time()
        delta = int(time.time() - boot)
        h, rem = divmod(delta, 3600)
        m, s = divmod(rem, 60)
        return f"{h}h {m}m {s}s"

    @staticmethod
    def gpu() -> list[Dict[str, str]]:
        """Detect GPUs via lspci or nvidia-smi (shutil.which guarded)."""
        gpus: list[Dict[str, str]] = []

        # NVIDIA — nvidia-smi
        nv = _run_tool([
            "nvidia-smi",
            "--query-gpu=name,driver_version,temperature.gpu,"
            "utilization.gpu,memory.used,memory.total",
            "--format=csv,noheader,nounits",
        ])
        if nv:
            for line in nv.splitlines():
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 6:
                    gpus.append({
                        "vendor": "NVIDIA",
                        "model": parts[0],
                        "driver": parts[1],
                        "temp_c": parts[2],
                        "util_pct": parts[3],
                        "vram_used_mb": parts[4],
                        "vram_total_mb": parts[5],
                    })

        # AMD / Intel — lspci
        lspci = _run_tool(["lspci"])
        if lspci:
            for line in lspci.splitlines():
                lower = line.lower()
                if any(k in lower for k in ("vga", "3d controller", "display")):
                    model = line.split(": ", 1)[1].strip() if ": " in line else line
                    # Skip if we already have it from nvidia-smi
                    if any(g["model"] in model for g in gpus):
                        continue
                    vendor = "AMD" if "amd" in lower or "radeon" in lower else \
                             "Intel" if "intel" in lower else "Unknown"
                    gpus.append({"vendor": vendor, "model": model})

        return gpus

    @classmethod
    def snapshot(cls) -> Dict[str, Any]:
        """Complete system snapshot — single call for everything."""
        snap: Dict[str, Any] = {
            "cpu": cls.cpu(),
            "memory": cls.memory(),
            "disk": cls.disk(),
            "network": cls.network(),
            "temperatures": cls.temperatures(),
            "gpu": cls.gpu(),
            "uptime": cls.uptime(),
            "kernel": platform.release(),
            "python": platform.python_version(),
        }
        bat = cls.battery()
        if bat is not None:
            snap["battery"] = bat
        return snap

    @classmethod
    def format_report(cls, snap: Optional[Dict[str, Any]] = None) -> str:
        """Human-readable telemetry string for LLM injection."""
        if snap is None:
            snap = cls.snapshot()

        lines: list[str] = ["## System Telemetry"]

        # CPU
        cpu = snap.get("cpu", {})
        lines.append(
            f"CPU: {cpu.get('usage_percent', '?')}% usage | "
            f"{cpu.get('cores_physical', '?')}C/{cpu.get('cores_logical', '?')}T | "
            f"{cpu.get('frequency_mhz', '?')} MHz | "
            f"Load: {cpu.get('load_avg_1m', '?')} / {cpu.get('load_avg_5m', '?')} / "
            f"{cpu.get('load_avg_15m', '?')}"
        )

        # Memory
        mem = snap.get("memory", {})
        lines.append(
            f"RAM: {mem.get('used_mb', '?')} / {mem.get('total_mb', '?')} MB "
            f"({mem.get('usage_percent', '?')}%) | "
            f"Available: {mem.get('available_mb', '?')} MB | "
            f"Swap: {mem.get('swap_used_mb', '?')} / {mem.get('swap_total_mb', '?')} MB"
        )

        # Disk
        disk = snap.get("disk", {})
        lines.append(
            f"Disk (/): {disk.get('root_used_gb', '?')} / "
            f"{disk.get('root_total_gb', '?')} GB ({disk.get('root_percent', '?')}%)"
        )

        # GPU
        for g in snap.get("gpu", []):
            gpu_line = f"GPU: {g.get('vendor', '')} {g.get('model', 'unknown')}"
            if g.get("temp_c"):
                gpu_line += f" | {g['temp_c']}°C"
            if g.get("util_pct"):
                gpu_line += f" | {g['util_pct']}% util"
            if g.get("vram_used_mb"):
                gpu_line += f" | VRAM: {g['vram_used_mb']}/{g.get('vram_total_mb', '?')} MB"
            lines.append(gpu_line)

        # Temps
        temps = snap.get("temperatures", {})
        if temps:
            temp_parts = [f"{k}: {v}°C" for k, v in list(temps.items())[:5]]
            lines.append(f"Temps: {' | '.join(temp_parts)}")

        # Battery
        bat = snap.get("battery")
        if bat:
            plug = "charging" if bat.get("plugged_in") else "discharging"
            lines.append(f"Battery: {bat.get('percent', '?')}% ({plug})")

        # Network
        net = snap.get("network", {})
        lines.append(
            f"Net: ↑ {net.get('bytes_sent_mb', 0)} MB / ↓ {net.get('bytes_recv_mb', 0)} MB | "
            f"Interfaces: {', '.join(net.get('active_interfaces', []))}"
        )

        lines.append(f"Uptime: {snap.get('uptime', '?')}")
        lines.append(f"Kernel: {snap.get('kernel', '?')}")

        # Top processes
        procs = cls.top_processes(5)
        if procs:
            lines.append("\n### Top Processes (by CPU)")
            for p in procs:
                lines.append(
                    f"  {p['pid']:>6}  {p['name']:<25}  CPU: {p['cpu']:>5.1f}%  "
                    f"MEM: {p['mem']:>5.1f}%"
                )

        return "\n".join(lines)


# ═════════════════════════════════════════════════════════════════════════
#  Web Search — DuckDuckGo with community source ranking
# ═════════════════════════════════════════════════════════════════════════

_TRUSTED_SOURCES = [
    "wiki.archlinux.org",
    "askubuntu.com",
    "discussion.fedoraproject.org",
    "unix.stackexchange.com",
    "superuser.com",
    "wiki.gentoo.org",
    "wiki.debian.org",
    "bbs.archlinux.org",
    "forums.opensuse.org",
    "man7.org",
]


def _search_web(query: str, max_results: int = 6) -> list[Dict[str, str]]:
    """Search DuckDuckGo for community fixes. Returns list of dicts."""
    if not _HAS_DDGS:
        return []
    try:
        results: list[Dict[str, str]] = []
        with DDGS() as ddgs:  # type: ignore[possibly-unbound]
            for r in ddgs.text(query, max_results=max_results):
                results.append({
                    "title": r.get("title", ""),
                    "body": r.get("body", ""),
                    "href": r.get("href", ""),
                })
        # Rank trusted sources higher
        def _score(r: Dict[str, str]) -> int:
            href = r.get("href", "").lower()
            for i, src in enumerate(_TRUSTED_SOURCES):
                if src in href:
                    return -100 + i
            return 0
        results.sort(key=_score)
        return results
    except Exception as exc:
        log.debug("Web search failed: %s", exc)
        return []


def _format_search_results(results: list[Dict[str, str]],
                           max_chars: int = 3000) -> str:
    """Format search results into context for the LLM."""
    lines: list[str] = []
    chars = 0
    for r in results:
        entry = f"[{r.get('title', 'Result')}]: {r.get('body', '')}"
        if r.get("href"):
            entry += f" (source: {r['href']})"
        if chars + len(entry) > max_chars:
            break
        lines.append(entry)
        chars += len(entry)
    return "\n".join(lines)


# ═════════════════════════════════════════════════════════════════════════
#  Error / Anomaly Detection
# ═════════════════════════════════════════════════════════════════════════

@dataclass
class SystemAnomaly:
    """A detected system anomaly with severity and description."""
    category: str          # cpu, memory, disk, temperature, process
    severity: str          # info, warning, critical
    description: str
    search_hint: str = ""  # Suggested web search query


def detect_anomalies(snap: Optional[Dict[str, Any]] = None) -> list[SystemAnomaly]:
    """Analyze a telemetry snapshot for anomalies worth researching."""
    if snap is None:
        snap = SystemTelemetry.snapshot()

    anomalies: list[SystemAnomaly] = []
    distro = detect_distro()

    # CPU overload
    cpu_pct = snap.get("cpu", {}).get("usage_percent", 0)
    load_1m = snap.get("cpu", {}).get("load_avg_1m", 0)
    cores = snap.get("cpu", {}).get("cores_logical", 1)
    if cpu_pct > 90:
        anomalies.append(SystemAnomaly(
            "cpu", "critical",
            f"CPU usage at {cpu_pct}%",
            f"{distro.pretty_name} high CPU usage troubleshooting",
        ))
    elif load_1m > cores * 1.5:
        anomalies.append(SystemAnomaly(
            "cpu", "warning",
            f"Load average ({load_1m}) exceeds core count ({cores}) by >50%",
            f"Linux high load average {distro.distro_id}",
        ))

    # Memory pressure
    mem = snap.get("memory", {})
    mem_pct = mem.get("usage_percent", 0)
    avail = mem.get("available_mb", 9999)
    if mem_pct > 90:
        anomalies.append(SystemAnomaly(
            "memory", "critical",
            f"RAM usage at {mem_pct}% — only {avail} MB available",
            f"{distro.pretty_name} high memory usage out of memory",
        ))
    elif mem_pct > 75:
        anomalies.append(SystemAnomaly(
            "memory", "warning",
            f"RAM usage at {mem_pct}%",
            f"Linux reduce memory usage {distro.pkg_manager}",
        ))

    # Swap thrashing
    swap_pct = mem.get("swap_percent", 0)
    if swap_pct > 60:
        anomalies.append(SystemAnomaly(
            "memory", "warning",
            f"Swap usage at {swap_pct}% — possible thrashing",
            f"Linux swap thrashing fix {distro.distro_id} zram",
        ))

    # Disk near full
    disk_pct = snap.get("disk", {}).get("root_percent", 0)
    if disk_pct > 95:
        anomalies.append(SystemAnomaly(
            "disk", "critical",
            f"Root filesystem at {disk_pct}% capacity",
            f"{distro.pretty_name} disk full clean space {distro.pkg_manager}",
        ))
    elif disk_pct > 85:
        anomalies.append(SystemAnomaly(
            "disk", "warning",
            f"Root filesystem at {disk_pct}%",
            f"Linux free disk space {distro.pkg_manager}",
        ))

    # Temperature
    for label, temp in snap.get("temperatures", {}).items():
        if temp > 90:
            anomalies.append(SystemAnomaly(
                "temperature", "critical",
                f"{label} temperature at {temp}°C",
                f"Linux {label} overheating {distro.distro_id}",
            ))
        elif temp > 75:
            anomalies.append(SystemAnomaly(
                "temperature", "warning",
                f"{label} temperature at {temp}°C",
                f"Linux CPU temperature high fix",
            ))

    # Runaway process
    procs = SystemTelemetry.top_processes(3)
    for p in procs:
        if p["cpu"] > 80:
            anomalies.append(SystemAnomaly(
                "process", "warning",
                f"Process '{p['name']}' (PID {p['pid']}) using {p['cpu']:.0f}% CPU",
                f"Linux {p['name']} high CPU usage fix",
            ))

    return anomalies


# ═════════════════════════════════════════════════════════════════════════
#  System Log Tail — journalctl / syslog / dmesg
# ═════════════════════════════════════════════════════════════════════════

def _recent_errors(n: int = 8) -> str:
    """Grab the last N error-level log entries."""
    out = _run_tool(["journalctl", "-n", str(n), "--no-pager", "-q",
                     "-p", "err..emerg", "--output=short-monotonic"])
    if out:
        return out

    # Syslog fallback
    try:
        lines = Path("/var/log/syslog").read_text().strip().splitlines()
        return "\n".join(lines[-n:])
    except OSError:
        pass

    # dmesg
    dm = _run_tool(["dmesg", "--level=err,warn", "-T"])
    if dm:
        return "\n".join(dm.strip().splitlines()[-n:])

    return "(no log entries available)"


# ═════════════════════════════════════════════════════════════════════════
#  Ollama Client — HTTP API + CLI fallback
# ═════════════════════════════════════════════════════════════════════════

def _ollama_list_models() -> list[str]:
    """Query Ollama /api/tags for installed models."""
    try:
        req = urllib.request.Request(f"{_ollama_base()}/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []


def _ollama_pick_model(preferred: str = "") -> str:
    """Pick the best available Ollama model."""
    installed = _ollama_list_models()
    if not installed:
        return preferred or _MODEL_PREFERENCE[0]

    # Exact match
    if preferred and preferred in installed:
        return preferred

    # Walk the preference list
    for pref in _MODEL_PREFERENCE:
        if pref in installed:
            return pref
        # Partial match (e.g. "llama3.1" matches "llama3.1:8b")
        base = pref.split(":")[0]
        for inst in installed:
            if inst.startswith(base):
                return inst

    return installed[0]


def _ollama_chat(messages: list[Dict[str, str]], model: str = "",
                 timeout: int = 120) -> str:
    """Send messages to Ollama /api/chat. Falls back to CLI."""
    model = model or _ollama_pick_model()

    # HTTP API
    try:
        payload = json.dumps({
            "model": model,
            "messages": messages,
            "stream": False,
        }).encode()
        req = urllib.request.Request(
            f"{_ollama_base()}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
        content = (data.get("message") or {}).get("content", "").strip()
        if content:
            return content
    except Exception as exc:
        log.debug("Ollama API failed: %s", exc)

    # CLI fallback — only if `ollama` binary exists
    if shutil.which("ollama"):
        flat_prompt = "\n".join(m.get("content", "") for m in messages)
        try:
            result = subprocess.run(
                ["ollama", "run", model, flat_prompt],
                capture_output=True, text=True, timeout=timeout,
                stdin=subprocess.DEVNULL,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except Exception:
            pass

    return ""


def _ollama_available() -> bool:
    """Quick probe: is Ollama responding?"""
    try:
        req = urllib.request.Request(f"{_ollama_base()}/api/tags")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False


# ═════════════════════════════════════════════════════════════════════════
#  llama-cpp-python Fallback — fully offline GGUF inference
# ═════════════════════════════════════════════════════════════════════════

_llama_instance: Optional[Any] = None


def _gguf_chat(messages: list[Dict[str, str]], model_path: str = "",
               max_tokens: int = 1024, temperature: float = 0.3) -> str:
    """Run inference via llama-cpp-python on a local GGUF file."""
    global _llama_instance
    if not _HAS_LLAMA_CPP:
        return ""

    if _llama_instance is None:
        gguf = _find_gguf(model_path)
        if gguf is None:
            return ""
        try:
            _llama_instance = Llama(  # type: ignore[possibly-unbound]
                model_path=str(gguf),
                n_ctx=4096,
                n_gpu_layers=-1,
                n_threads=os.cpu_count() or 4,
                verbose=False,
            )
        except Exception as exc:
            log.error("Failed to load GGUF: %s", exc)
            return ""

    try:
        result = _llama_instance.create_chat_completion(  # type: ignore[union-attr]
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            stop=["<|end|>", "<|eot_id|>", "</s>"],
        )
        choices = result.get("choices", [])  # type: ignore[union-attr]
        if choices:
            return choices[0].get("message", {}).get("content", "").strip()
    except Exception as exc:
        log.error("GGUF inference error: %s", exc)

    return ""


# ═════════════════════════════════════════════════════════════════════════
#  Response Cleaning
# ═════════════════════════════════════════════════════════════════════════

def _clean_response(text: str) -> str:
    """Strip thinking blocks and meta-reasoning from LLM output."""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<thinking>.*?</thinking>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<reasoning>.*?</reasoning>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(
        r"Thinking\.\.\..*?\.\.\.done thinking\.?", "", text,
        flags=re.DOTALL | re.IGNORECASE,
    )

    skip = {"let me think", "okay, let", "the instructions say",
            "the user wants", "let me analyze", "let me consider",
            "i need to", "let me figure", "since the user"}
    lines = []
    in_block = False
    for line in text.split("\n"):
        lower = line.strip().lower()
        if "<think" in lower or "<reasoning" in lower:
            in_block = True
            continue
        if "</think" in lower or "</reasoning" in lower:
            in_block = False
            continue
        if in_block:
            continue
        if any(lower.startswith(s) for s in skip):
            continue
        if line.strip():
            lines.append(line)

    result = "\n".join(lines).strip()
    return re.sub(r"\n{3,}", "\n\n", result)


# ═════════════════════════════════════════════════════════════════════════
#  SysfixAgent — the unified AI engine
# ═════════════════════════════════════════════════════════════════════════

class SysfixAgent:
    """Complete local-first AI agent for Linux system diagnostics.

    The agent chains together:
      1. Real-time system telemetry (via psutil)
      2. Anomaly detection and error log analysis
      3. Web research (DuckDuckGo) when the context indicates problems
      4. Local LLM inference (Ollama → llama-cpp-python GGUF → research-only)

    Usage::

        agent = SysfixAgent()
        print(agent.think("Why is my system slow?"))
    """

    def __init__(
        self,
        model: str = "",
        *,
        gguf_path: str = "",
        temperature: float = 0.3,
        max_tokens: int = 1536,
        auto_research: bool = True,
    ) -> None:
        self._preferred_model = model
        self._gguf_path = gguf_path
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._auto_research = auto_research
        self._distro = detect_distro()
        self._history: list[Dict[str, str]] = []
        self._last_snap: Optional[Dict[str, Any]] = None

    # ── Public API ────────────────────────────────────────────────────

    def get_system_telemetry(self) -> str:
        """Return a formatted string of current system state.

        Uses psutil exclusively — works on every Linux distro without
        relying on /proc/ parsing or distro-specific tools.
        """
        self._last_snap = SystemTelemetry.snapshot()
        return SystemTelemetry.format_report(self._last_snap)

    def search_web(self, query: str) -> str:
        """Search DuckDuckGo for community fixes and documentation.

        Enriches the query with distro context for more relevant results.
        """
        enriched = f"{self._distro.pretty_name} {query}"
        results = _search_web(enriched)
        if not results:
            return ""
        return _format_search_results(results)

    def think(self, user_prompt: str) -> str:
        """The core reasoning loop.

        1. Gathers live system telemetry via psutil.
        2. Detects anomalies (high CPU, low RAM, disk full, etc.).
        3. If anomalies are found, searches the web for fixes.
        4. Builds a rich system prompt with telemetry + errors + research.
        5. Sends everything to the local LLM (Ollama → GGUF fallback).
        6. If the model expresses uncertainty, does a follow-up search
           and retries with enriched context.

        Returns the AI's response as a string.
        """
        # Step 1: Gather telemetry
        telemetry = self.get_system_telemetry()

        # Step 2: Detect anomalies
        anomalies = detect_anomalies(self._last_snap)
        errors = _recent_errors()

        # Step 3: Web research if anomalies suggest problems
        research_context = ""
        if self._auto_research and anomalies:
            # Search for the most severe anomaly + user's question
            search_queries = set()
            for a in anomalies:
                if a.severity in ("critical", "warning") and a.search_hint:
                    search_queries.add(a.search_hint)
            # Also search the user's actual question
            search_queries.add(f"{self._distro.pretty_name} {user_prompt}")

            all_results: list[Dict[str, str]] = []
            for q in list(search_queries)[:3]:  # Cap at 3 searches
                all_results.extend(_search_web(q, max_results=4))
            if all_results:
                research_context = _format_search_results(all_results)

        # Step 4: Build system prompt
        system_prompt = self._build_system_prompt(
            telemetry=telemetry,
            anomalies=anomalies,
            errors=errors,
            research=research_context,
        )

        # Step 5: Send to LLM
        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(self._history[-10:])  # Keep last 10 turns
        messages.append({"role": "user", "content": user_prompt})

        response = self._infer(messages)

        # Step 6: Research fallback if uncertain
        if response and self._auto_research and self._seems_uncertain(response):
            extra = self.search_web(user_prompt)
            if extra:
                enriched_prompt = (
                    f"{user_prompt}\n\n"
                    f"[Additional research results:]\n{extra}"
                )
                messages[-1] = {"role": "user", "content": enriched_prompt}
                retry = self._infer(messages)
                if retry:
                    response = retry

        # No model available — assemble answer from research + anomalies
        if not response:
            response = self._research_only_answer(
                user_prompt, anomalies, research_context, telemetry
            )

        # Clean and store
        response = _clean_response(response)
        self._history.append({"role": "user", "content": user_prompt})
        self._history.append({"role": "assistant", "content": response})

        return response

    def reset_history(self) -> None:
        """Clear conversation history."""
        self._history.clear()

    @property
    def distro(self) -> DistroSnapshot:
        return self._distro

    @property
    def backend(self) -> str:
        """Which inference backend is active."""
        if _ollama_available():
            return f"ollama ({_ollama_pick_model(self._preferred_model)})"
        if _HAS_LLAMA_CPP and _find_gguf(self._gguf_path):
            return f"llama-cpp ({_find_gguf(self._gguf_path).name})"  # type: ignore[union-attr]
        return "research-only"

    # ── Distro-aware command helpers ──────────────────────────────────

    def install_cmd(self, package: str) -> str:
        """Return the install command for the detected distro."""
        cmds = {
            "apt": f"sudo apt install -y {package}",
            "dnf": f"sudo dnf install -y {package}",
            "pacman": f"sudo pacman -S --noconfirm {package}",
            "zypper": f"sudo zypper install -y {package}",
            "xbps": f"sudo xbps-install -y {package}",
            "apk": f"sudo apk add {package}",
            "portage": f"sudo emerge {package}",
            "nix": f"nix-env -iA nixpkgs.{package}",
        }
        return cmds.get(self._distro.pkg_manager,
                        f"# Install '{package}' with your package manager")

    def update_cmd(self) -> str:
        """Return the full system update command."""
        cmds = {
            "apt": "sudo apt update && sudo apt full-upgrade -y",
            "dnf": "sudo dnf upgrade --refresh -y",
            "pacman": "sudo pacman -Syu --noconfirm",
            "zypper": "sudo zypper ref && sudo zypper dup -y",
            "xbps": "sudo xbps-install -Su",
            "apk": "sudo apk update && sudo apk upgrade",
            "portage": "sudo emerge --sync && sudo emerge -uDN @world",
            "nix": "sudo nixos-rebuild switch --upgrade",
        }
        return cmds.get(self._distro.pkg_manager, "# Update with your package manager")

    def service_cmd(self, action: str, service: str) -> str:
        """Return a service management command for the detected init system."""
        init = self._distro.init_system
        if init == "systemd":
            return f"sudo systemctl {action} {service}"
        if init == "openrc":
            return f"sudo rc-service {service} {action}"
        if init == "runit":
            sv_map = {"start": "up", "stop": "down", "restart": "restart",
                      "status": "status"}
            return f"sudo sv {sv_map.get(action, action)} {service}"
        return f"sudo service {service} {action}"

    # ── Internal ──────────────────────────────────────────────────────

    def _build_system_prompt(
        self,
        telemetry: str,
        anomalies: list[SystemAnomaly],
        errors: str,
        research: str,
    ) -> str:
        d = self._distro
        parts: list[str] = [
            "You are **Fyxa**, the Sysfix AI — a Legendary Linux Systems "
            "Engineer with encyclopedic knowledge of every Linux distribution. "
            f"You provide precise, actionable terminal commands for the user's "
            f"**{d.shell}** shell.\n",

            "## Detected Environment",
            f"- OS: {d.pretty_name} ({d.distro_id})",
            f"- Kernel: {d.kernel}",
            f"- Init: {d.init_system}",
            f"- Package Manager: {d.pkg_manager}",
            f"- Desktop: {d.desktop}",
            f"- Shell: {d.shell}",
            f"- Host: {d.hostname}\n",

            telemetry,
        ]

        if anomalies:
            parts.append("\n## Detected Anomalies")
            for a in anomalies:
                icon = "🔴" if a.severity == "critical" else "🟡"
                parts.append(f"  {icon} [{a.category}] {a.description}")

        if errors and errors != "(no log entries available)":
            parts.append(f"\n## Recent System Errors\n```\n{errors}\n```")

        if research:
            parts.append(f"\n## Community Research\n{research}")

        parts.append(textwrap.dedent("""\

            ## Rules
            1. Tailor every command to the detected distro and package manager.
            2. Use the exact package manager shown above for installs/updates.
            3. Use the detected init system for service management.
            4. Give exact, copy-pasteable commands — no vague placeholders.
            5. If unsure, say so honestly and suggest verification steps.
            6. For destructive operations, always warn and suggest backups.
            7. Ground your answers in the telemetry and anomalies shown above.
            8. Be concise but thorough. Prioritize fixes for critical anomalies.
        """))

        return "\n".join(parts)

    def _infer(self, messages: list[Dict[str, str]]) -> str:
        """Try Ollama first, then GGUF, return empty if neither works."""
        # Ollama
        response = _ollama_chat(
            messages,
            model=self._preferred_model,
            timeout=120,
        )
        if response:
            return response

        # llama-cpp-python GGUF fallback
        response = _gguf_chat(
            messages,
            model_path=self._gguf_path,
            max_tokens=self._max_tokens,
            temperature=self._temperature,
        )
        if response:
            return response

        return ""

    @staticmethod
    def _seems_uncertain(text: str) -> bool:
        indicators = [
            "i'm not sure", "i don't know", "i cannot determine",
            "not certain", "please verify", "beyond my knowledge",
            "unable to determine", "i'd recommend checking",
            "i don't have enough information",
        ]
        lower = text.lower()
        return any(ind in lower for ind in indicators)

    def _research_only_answer(
        self,
        query: str,
        anomalies: list[SystemAnomaly],
        research: str,
        telemetry: str,
    ) -> str:
        """Build an answer when no LLM is available — pure research + telemetry."""
        lines: list[str] = []

        if anomalies:
            lines.append("## System Issues Detected\n")
            for a in anomalies:
                icon = "🔴" if a.severity == "critical" else "🟡"
                lines.append(f"{icon} **{a.category.upper()}**: {a.description}")
            lines.append("")

        if research:
            lines.append("## Community Resources\n")
            lines.append(research)
            lines.append("")

        if not anomalies and not research:
            # Nothing found — give a direct summary
            lines.append(
                "No specific issues detected and web research returned no results.\n\n"
                "**Current system health looks normal.**\n"
            )
            lines.append(f"### System Summary\n{telemetry}")

        lines.append(
            "\n---\n"
            "_Sysfix is running in research-only mode. For full AI reasoning, "
            "install Ollama (`curl -fsSL https://ollama.com/install.sh | sh`) "
            "and pull a model (`ollama pull qwen3:8b`)._"
        )
        return "\n".join(lines)


# ═════════════════════════════════════════════════════════════════════════
#  Module-level convenience
# ═════════════════════════════════════════════════════════════════════════

_agent_instance: Optional[SysfixAgent] = None


def get_agent() -> SysfixAgent:
    """Get or create the global SysfixAgent singleton."""
    global _agent_instance
    if _agent_instance is None:
        _agent_instance = SysfixAgent()
    return _agent_instance


# ═════════════════════════════════════════════════════════════════════════
#  Main — test the full pipeline
# ═════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.DEBUG if "--debug" in sys.argv else logging.WARNING,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    try:
        from rich.console import Console
        from rich.markdown import Markdown
        from rich.panel import Panel
        _console: Optional[Any] = Console()
        _rich = True
    except ImportError:
        _console = None
        Markdown = None  # type: ignore[assignment,misc]
        Panel = None  # type: ignore[assignment,misc]
        _rich = False

    agent = SysfixAgent()

    # Print backend info
    distro = agent.distro
    header = (
        f"Sysfix Brain v2 — {distro.pretty_name}\n"
        f"Backend: {agent.backend}\n"
        f"Kernel: {distro.kernel} | Init: {distro.init_system} | "
        f"Pkg: {distro.pkg_manager} | Desktop: {distro.desktop}"
    )
    if _rich and _console:
        _console.print(Panel(header, title="[bold cyan]Sysfix Brain[/]",
                             border_style="cyan"))
    else:
        print(f"\n{'=' * 60}")
        print(header)
        print(f"{'=' * 60}\n")

    # Show live telemetry
    telemetry = agent.get_system_telemetry()
    if _rich and _console:
        _console.print(Panel(telemetry, title="[bold green]Live Telemetry[/]",
                             border_style="green"))
    else:
        print(telemetry)
        print()

    # Show detected anomalies
    anomalies = detect_anomalies()
    if anomalies:
        if _rich and _console:
            anom_text = "\n".join(
                f"{'🔴' if a.severity == 'critical' else '🟡'} "
                f"[{a.category}] {a.description}"
                for a in anomalies
            )
            _console.print(Panel(anom_text, title="[bold yellow]Anomalies[/]",
                                 border_style="yellow"))
        else:
            print("--- Anomalies ---")
            for a in anomalies:
                print(f"  [{a.severity}] {a.category}: {a.description}")
            print()

    # Test the think() pipeline
    test_query = "Why is my system slow?"
    if _rich and _console:
        _console.print(f"\n[bold]Query:[/] {test_query}\n")
        _console.print("[dim]Thinking...[/]")
    else:
        print(f"Query: {test_query}")
        print("Thinking...")

    t0 = time.time()
    answer = agent.think(test_query)
    elapsed = time.time() - t0

    if _rich and _console:
        _console.print(Panel(Markdown(answer),
                             title="[bold blue]Fyxa Response[/]",
                             border_style="blue"))
        _console.print(f"[dim]Response time: {elapsed:.1f}s[/]\n")
    else:
        print(f"\n--- Response ({elapsed:.1f}s) ---")
        print(answer)
        print()
