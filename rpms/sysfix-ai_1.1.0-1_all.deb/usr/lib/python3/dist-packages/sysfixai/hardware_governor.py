"""
Pillar 2 — Omni-Turbo: Cross-Desktop Hardware Overdrive.

HardwareGovernor suite that detects and overrides performance constraints
across desktop environments (KDE, GNOME, XFCE, Sway, Hyprland, i3, etc.).

Sub-modules:
  - CPUGovernor       — power-profiles / tlp / sysfs governor control
  - GPUGovernor       — NVIDIA, AMD, Intel GPU performance tuning
  - CompositorTuner   — DE-specific animation / compositor toggles
  - HardwareGovernor  — unified façade

All privileged writes go through pkexec to avoid running as root.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("sysfix.hardware_governor")


# ───────────────────────────────────────────────────────────────────────────
# Helpers
# ───────────────────────────────────────────────────────────────────────────

def _run(cmd: List[str], *, timeout: int = 5, check: bool = False) -> str:
    """Run a command and return stdout.  Returns '' on failure."""
    if not shutil.which(cmd[0]):
        return ""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        if check and r.returncode != 0:
            return ""
        return r.stdout.strip()
    except Exception:
        return ""


def _run_privileged(cmd: List[str], *, timeout: int = 10) -> Tuple[bool, str]:
    """Run a command with pkexec privilege escalation.

    Returns (success, output_or_error).
    """
    pkexec = shutil.which("pkexec")
    if not pkexec:
        return False, "pkexec not available"
    try:
        r = subprocess.run([pkexec] + cmd, capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        if r.returncode == 0:
            return True, r.stdout.strip()
        return False, r.stderr.strip() or f"exit code {r.returncode}"
    except subprocess.TimeoutExpired:
        return False, "command timed out"
    except Exception as exc:
        return False, str(exc)


def _read_sysfs(path: str) -> str:
    """Read a sysfs node (no root needed for most)."""
    try:
        return Path(path).read_text().strip()
    except OSError:
        return ""


# ───────────────────────────────────────────────────────────────────────────
# CPU Governor
# ───────────────────────────────────────────────────────────────────────────

@dataclass
class CPUState:
    """Snapshot of current CPU performance state."""
    governor: str = "unknown"
    driver: str = "unknown"
    min_freq_khz: int = 0
    max_freq_khz: int = 0
    cur_freq_khz: int = 0
    available_governors: List[str] = field(default_factory=list)
    energy_profile: str = ""        # from power-profiles-daemon
    tlp_mode: str = ""              # from TLP
    turbo_enabled: bool = True
    cpu_count: int = 0


class CPUGovernor:
    """Detect and control CPU frequency scaling."""

    @classmethod
    def detect(cls) -> CPUState:
        state = CPUState(cpu_count=os.cpu_count() or 0)
        cpu0 = "/sys/devices/system/cpu/cpu0/cpufreq"

        state.governor = _read_sysfs(f"{cpu0}/scaling_governor")
        state.driver = _read_sysfs(f"{cpu0}/scaling_driver")
        state.available_governors = _read_sysfs(
            f"{cpu0}/scaling_available_governors"
        ).split()

        for attr, field_name in [
            ("scaling_min_freq", "min_freq_khz"),
            ("scaling_max_freq", "max_freq_khz"),
            ("scaling_cur_freq", "cur_freq_khz"),
        ]:
            raw = _read_sysfs(f"{cpu0}/{attr}")
            if raw.isdigit():
                setattr(state, field_name, int(raw))

        # Turbo / boost
        no_turbo = _read_sysfs("/sys/devices/system/cpu/intel_pstate/no_turbo")
        if no_turbo:
            state.turbo_enabled = no_turbo == "0"
        else:
            boost = _read_sysfs("/sys/devices/system/cpu/cpufreq/boost")
            if boost:
                state.turbo_enabled = boost == "1"

        # power-profiles-daemon
        ppd = _run(["powerprofilesctl", "get"], check=True)
        if ppd:
            state.energy_profile = ppd

        # TLP
        if shutil.which("tlp"):
            tlp_stat = _run(["tlp-stat", "-s"], check=True)
            if "Mode" in tlp_stat:
                for line in tlp_stat.splitlines():
                    if "Mode" in line:
                        state.tlp_mode = line.split("=")[-1].strip()
                        break

        return state

    @classmethod
    def set_performance(cls) -> Tuple[bool, str]:
        """Force 'performance' mode through whichever mechanism is available."""
        results: List[str] = []

        # Try power-profiles-daemon first
        if shutil.which("powerprofilesctl"):
            ok, msg = _run_privileged(["powerprofilesctl", "set", "performance"])
            if ok:
                results.append("✓ power-profiles-daemon → performance")
                return True, "\n".join(results)
            results.append(f"✗ power-profiles-daemon failed: {msg}")

        # Try TLP
        if shutil.which("tlp"):
            ok, msg = _run_privileged(["tlp", "ac"])
            if ok:
                results.append("✓ TLP → AC (performance) mode")
                return True, "\n".join(results)
            results.append(f"✗ TLP failed: {msg}")

        # Direct sysfs write as last resort
        cpu_count = os.cpu_count() or 1
        success_count = 0
        for i in range(cpu_count):
            gov_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor"
            if Path(gov_path).exists():
                ok, _ = _run_privileged(
                    ["sh", "-c", f"echo performance > {gov_path}"]
                )
                if ok:
                    success_count += 1

        if success_count > 0:
            results.append(
                f"✓ Set 'performance' governor on {success_count}/{cpu_count} CPUs"
            )
            return True, "\n".join(results)

        results.append("✗ Could not set performance mode via any method")
        return False, "\n".join(results)

    @classmethod
    def set_powersave(cls) -> Tuple[bool, str]:
        """Revert to power-saving mode."""
        if shutil.which("powerprofilesctl"):
            ok, _msg = _run_privileged(
                ["powerprofilesctl", "set", "balanced"]
            )
            if ok:
                return True, "✓ Reverted to 'balanced' profile"

        cpu_count = os.cpu_count() or 1
        count = 0
        for i in range(cpu_count):
            gov_path = f"/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_governor"
            if Path(gov_path).exists():
                ok, _ = _run_privileged(
                    ["sh", "-c", f"echo powersave > {gov_path}"]
                )
                if ok:
                    count += 1
        if count:
            return True, f"✓ Set 'powersave' on {count}/{cpu_count} CPUs"
        return False, "✗ Could not set powersave mode"

    @classmethod
    def enable_turbo(cls) -> Tuple[bool, str]:
        """Enable CPU turbo/boost."""
        intel = "/sys/devices/system/cpu/intel_pstate/no_turbo"
        amd = "/sys/devices/system/cpu/cpufreq/boost"
        if Path(intel).exists():
            ok, msg = _run_privileged(["sh", "-c", f"echo 0 > {intel}"])
            return ok, "✓ Intel turbo enabled" if ok else f"✗ {msg}"
        if Path(amd).exists():
            ok, msg = _run_privileged(["sh", "-c", f"echo 1 > {amd}"])
            return ok, "✓ AMD boost enabled" if ok else f"✗ {msg}"
        return False, "✗ No turbo/boost sysfs interface found"


# ───────────────────────────────────────────────────────────────────────────
# GPU Governor
# ───────────────────────────────────────────────────────────────────────────

@dataclass
class GPUState:
    """Snapshot of GPU hardware."""
    vendor: str = "unknown"     # nvidia | amd | intel
    model: str = ""
    driver: str = ""
    temperature: int = 0
    utilization: int = 0
    vram_total_mb: int = 0
    vram_used_mb: int = 0
    power_draw_w: float = 0.0
    current_clocks_mhz: int = 0
    max_clocks_mhz: int = 0


class GPUGovernor:
    """Detect and tune GPU performance across NVIDIA, AMD, and Intel."""

    @classmethod
    def detect(cls) -> GPUState:
        """Detect GPU vendor and current state."""
        # Try NVIDIA first
        nv = cls._detect_nvidia()
        if nv:
            return nv

        # Try AMD
        amd = cls._detect_amd()
        if amd:
            return amd

        # Try Intel
        intel = cls._detect_intel()
        if intel:
            return intel

        # lspci fallback
        lspci = _run(["lspci"])
        if lspci:
            for line in lspci.splitlines():
                ll = line.lower()
                if "vga" in ll or "3d controller" in ll:
                    model = line.split(": ", 1)[1] if ": " in line else line
                    if "nvidia" in ll:
                        return GPUState(vendor="nvidia", model=model)
                    if "amd" in ll or "radeon" in ll:
                        return GPUState(vendor="amd", model=model)
                    if "intel" in ll:
                        return GPUState(vendor="intel", model=model)

        return GPUState()

    # ── NVIDIA ────────────────────────────────────────────────────────

    @classmethod
    def _detect_nvidia(cls) -> Optional[GPUState]:
        if not shutil.which("nvidia-smi"):
            return None
        raw = _run([
            "nvidia-smi",
            "--query-gpu=name,driver_version,temperature.gpu,"
            "utilization.gpu,memory.total,memory.used,"
            "power.draw,clocks.gr,clocks.max.gr",
            "--format=csv,noheader,nounits",
        ])
        if not raw:
            return None
        parts = [p.strip() for p in raw.split(",")]
        if len(parts) < 9:
            return GPUState(vendor="nvidia", model=parts[0] if parts else "")
        try:
            return GPUState(
                vendor="nvidia",
                model=parts[0],
                driver=parts[1],
                temperature=int(parts[2]) if parts[2].isdigit() else 0,
                utilization=int(parts[3]) if parts[3].isdigit() else 0,
                vram_total_mb=int(parts[4]) if parts[4].isdigit() else 0,
                vram_used_mb=int(parts[5]) if parts[5].isdigit() else 0,
                power_draw_w=float(parts[6]) if parts[6].replace(".", "").isdigit() else 0,
                current_clocks_mhz=int(parts[7]) if parts[7].isdigit() else 0,
                max_clocks_mhz=int(parts[8]) if parts[8].isdigit() else 0,
            )
        except (ValueError, IndexError):
            return GPUState(vendor="nvidia", model=parts[0])

    @classmethod
    def _detect_amd(cls) -> Optional[GPUState]:
        """Detect AMD GPU via sysfs or rocm-smi."""
        # Check sysfs for amdgpu driver
        drm = Path("/sys/class/drm")
        if not drm.is_dir():
            return None

        for card in sorted(drm.iterdir()):
            device_dir = card / "device"
            driver_link = device_dir / "driver"
            if not driver_link.is_symlink():
                continue
            driver_name = os.path.basename(os.readlink(str(driver_link)))
            if driver_name != "amdgpu":
                continue

            state = GPUState(vendor="amd", driver="amdgpu")

            # Model from marketing name or device id
            name_path = device_dir / "product_name"
            if name_path.exists():
                state.model = _read_sysfs(str(name_path))

            # Temperature
            temp_files = list(device_dir.glob("hwmon/hwmon*/temp1_input"))
            if temp_files:
                raw = _read_sysfs(str(temp_files[0]))
                if raw.isdigit():
                    state.temperature = int(raw) // 1000

            # VRAM
            vram_total = _read_sysfs(str(device_dir / "mem_info_vram_total"))
            vram_used = _read_sysfs(str(device_dir / "mem_info_vram_used"))
            if vram_total.isdigit():
                state.vram_total_mb = int(vram_total) // (1024 * 1024)
            if vram_used.isdigit():
                state.vram_used_mb = int(vram_used) // (1024 * 1024)

            # Power usage
            power_files = list(device_dir.glob("hwmon/hwmon*/power1_average"))
            if power_files:
                raw = _read_sysfs(str(power_files[0]))
                if raw.isdigit():
                    state.power_draw_w = int(raw) / 1_000_000

            # GPU clock  
            sclk = _read_sysfs(str(device_dir / "pp_dpm_sclk"))
            if sclk:
                for line in sclk.splitlines():
                    if "*" in line:
                        m = re.search(r"(\d+)Mhz", line)
                        if m:
                            state.current_clocks_mhz = int(m.group(1))
                # Max is the last line
                all_clocks = re.findall(r"(\d+)Mhz", sclk)
                if all_clocks:
                    state.max_clocks_mhz = int(all_clocks[-1])

            return state

        # Try rocm-smi
        if shutil.which("rocm-smi"):
            raw = _run(["rocm-smi", "--showtemp", "--showuse", "--showmeminfo", "vram"])
            if raw:
                state = GPUState(vendor="amd", driver="rocm")
                # Parse basic info from rocm-smi output
                temp_match = re.search(r"Temperature.*?:\s*(\d+)", raw)
                if temp_match:
                    state.temperature = int(temp_match.group(1))
                return state

        return None

    @classmethod
    def _detect_intel(cls) -> Optional[GPUState]:
        """Detect Intel integrated/discrete GPU."""
        drm = Path("/sys/class/drm")
        if not drm.is_dir():
            return None

        for card in sorted(drm.iterdir()):
            device_dir = card / "device"
            driver_link = device_dir / "driver"
            if not driver_link.is_symlink():
                continue
            driver_name = os.path.basename(os.readlink(str(driver_link)))
            if driver_name not in ("i915", "xe"):
                continue

            state = GPUState(vendor="intel", driver=driver_name)

            # Frequency
            _gt_min = _read_sysfs(str(card / "gt_min_freq_mhz"))
            gt_max = _read_sysfs(str(card / "gt_max_freq_mhz"))
            gt_cur = _read_sysfs(str(card / "gt_cur_freq_mhz"))
            if gt_cur.isdigit():
                state.current_clocks_mhz = int(gt_cur)
            if gt_max.isdigit():
                state.max_clocks_mhz = int(gt_max)

            return state

        return None

    # ── Performance overrides ─────────────────────────────────────────

    @classmethod
    def set_nvidia_performance(cls) -> Tuple[bool, str]:
        """Lock NVIDIA GPU to max clocks."""
        if not shutil.which("nvidia-smi"):
            return False, "nvidia-smi not found"

        results: List[str] = []

        # Enable persistence mode
        ok, _msg = _run_privileged(["nvidia-smi", "-pm", "1"])
        if ok:
            results.append("✓ Persistence mode enabled")

        # Get max clocks
        raw = _run([
            "nvidia-smi",
            "--query-gpu=clocks.max.gr,clocks.max.mem",
            "--format=csv,noheader,nounits",
        ])
        if raw:
            parts = [p.strip() for p in raw.split(",")]
            if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
                ok, _msg = _run_privileged([
                    "nvidia-smi",
                    "-lgc", f"{parts[0]},{parts[0]}",
                ])
                if ok:
                    results.append(f"✓ GPU clocks locked at {parts[0]} MHz")
                ok, _msg = _run_privileged([
                    "nvidia-smi",
                    "-lmc", f"{parts[1]},{parts[1]}",
                ])
                if ok:
                    results.append(f"✓ Memory clocks locked at {parts[1]} MHz")

        # Set power limit to max
        power_raw = _run([
            "nvidia-smi",
            "--query-gpu=power.max_limit",
            "--format=csv,noheader,nounits",
        ])
        if power_raw:
            try:
                max_power = float(power_raw)
                ok, _ = _run_privileged([
                    "nvidia-smi", "-pl", str(int(max_power)),
                ])
                if ok:
                    results.append(f"✓ Power limit set to {int(max_power)}W")
            except ValueError:
                pass

        if results:
            return True, "\n".join(results)
        return False, "✗ Could not apply NVIDIA performance overrides"

    @classmethod
    def set_amd_performance(cls) -> Tuple[bool, str]:
        """Set AMD GPU to highest performance power level via sysfs."""
        drm = Path("/sys/class/drm")
        if not drm.is_dir():
            return False, "No DRM devices found"

        results: List[str] = []
        for card in sorted(drm.iterdir()):
            device_dir = card / "device"
            perf_path = device_dir / "power_dpm_force_performance_level"
            if not perf_path.exists():
                continue

            ok, _ = _run_privileged(
                ["sh", "-c", f"echo high > {perf_path}"]
            )
            if ok:
                results.append(f"✓ {card.name}: forced 'high' performance level")

            # Set highest sclk level
            sclk_path = device_dir / "pp_dpm_sclk"
            if sclk_path.exists():
                sclk = _read_sysfs(str(sclk_path))
                levels = re.findall(r"^(\d+):", sclk, re.MULTILINE)
                if levels:
                    highest = levels[-1]
                    ok, _ = _run_privileged(
                        ["sh", "-c", f"echo {highest} > {sclk_path}"]
                    )
                    if ok:
                        results.append(f"✓ {card.name}: GPU clock forced to level {highest}")

        if results:
            return True, "\n".join(results)
        return False, "✗ No AMD GPU sysfs controls found"

    @classmethod
    def set_intel_max_freq(cls) -> Tuple[bool, str]:
        """Set Intel GPU to maximum frequency."""
        drm = Path("/sys/class/drm")
        if not drm.is_dir():
            return False, "No DRM devices found"

        results: List[str] = []
        for card in sorted(drm.iterdir()):
            gt_max_path = card / "gt_max_freq_mhz"
            gt_min_path = card / "gt_min_freq_mhz"
            gt_boost = card / "gt_boost_freq_mhz"

            if not gt_max_path.exists():
                continue

            max_freq = _read_sysfs(str(gt_max_path))
            boost_freq = _read_sysfs(str(gt_boost))
            target = boost_freq or max_freq

            if target and gt_min_path.exists():
                ok, _ = _run_privileged(
                    ["sh", "-c", f"echo {target} > {gt_min_path}"]
                )
                if ok:
                    results.append(f"✓ {card.name}: min frequency raised to {target} MHz")

        if results:
            return True, "\n".join(results)
        return False, "✗ No Intel GPU frequency controls found"

    @classmethod
    def set_performance(cls) -> Tuple[bool, str]:
        """Auto-detect GPU vendor and apply max performance."""
        state = cls.detect()
        if state.vendor == "nvidia":
            return cls.set_nvidia_performance()
        if state.vendor == "amd":
            return cls.set_amd_performance()
        if state.vendor == "intel":
            return cls.set_intel_max_freq()
        return False, "✗ No supported GPU detected"


# ───────────────────────────────────────────────────────────────────────────
# Compositor Tuner — DE-specific animation/overhead control
# ───────────────────────────────────────────────────────────────────────────

@dataclass
class CompositorState:
    """Detected compositor / DE state."""
    desktop: str = "unknown"
    compositor: str = "unknown"
    animations_enabled: bool = True
    compositing_enabled: bool = True


class CompositorTuner:
    """Detect and control compositor overhead across desktop environments."""

    @classmethod
    def detect(cls) -> CompositorState:
        desktop = cls._detect_desktop()
        state = CompositorState(desktop=desktop)

        if desktop == "kde":
            state = cls._detect_kde(state)
        elif desktop == "gnome":
            state = cls._detect_gnome(state)
        elif desktop == "xfce":
            state = cls._detect_xfce(state)

        return state

    @staticmethod
    def _detect_desktop() -> str:
        de = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
        session = os.environ.get("XDG_SESSION_DESKTOP", "").lower()
        for hint in (de, session):
            if "kde" in hint or "plasma" in hint:
                return "kde"
            if "gnome" in hint:
                return "gnome"
            if "xfce" in hint:
                return "xfce"
            if "sway" in hint:
                return "sway"
            if "hyprland" in hint:
                return "hyprland"
            if "i3" in hint:
                return "i3"
        return de or session or "unknown"

    @classmethod
    def _detect_kde(cls, state: CompositorState) -> CompositorState:
        state.compositor = "kwin"
        # Check compositing
        comp = _run(["qdbus", "org.kde.KWin", "/Compositor",
                     "org.kde.kwin.Compositing.active"])
        if comp:
            state.compositing_enabled = comp.lower() == "true"
        # Check animations
        anim = _run(["kreadconfig5", "--file", "kdeglobals",
                     "--group", "KDE", "--key", "AnimationDurationFactor"])
        if anim:
            try:
                state.animations_enabled = float(anim) > 0
            except ValueError:
                pass
        return state

    @classmethod
    def _detect_gnome(cls, state: CompositorState) -> CompositorState:
        state.compositor = "mutter"
        anim = _run(["gsettings", "get", "org.gnome.desktop.interface",
                     "enable-animations"])
        if anim:
            state.animations_enabled = anim.strip().lower() == "true"
        return state

    @classmethod
    def _detect_xfce(cls, state: CompositorState) -> CompositorState:
        state.compositor = "xfwm4"
        comp = _run(["xfconf-query", "-c", "xfwm4", "-p",
                     "/general/use_compositing"])
        if comp:
            state.compositing_enabled = comp.lower() == "true"
        return state

    # ── Performance toggles ───────────────────────────────────────────

    @classmethod
    def disable_animations(cls) -> Tuple[bool, str]:
        """Disable animations on the detected DE for maximum performance."""
        desktop = cls._detect_desktop()
        results: List[str] = []

        if desktop == "kde":
            # Set animation factor to 0
            _r = _run(["kwriteconfig5", "--file", "kdeglobals",
                       "--group", "KDE", "--key", "AnimationDurationFactor",
                       "0"])
            # Notify KWin to reload
            _run(["qdbus", "org.kde.KWin", "/KWin", "reconfigure"])
            results.append("✓ KDE: animations disabled (factor=0)")

        elif desktop == "gnome":
            _run(["gsettings", "set", "org.gnome.desktop.interface",
                  "enable-animations", "false"])
            results.append("✓ GNOME: animations disabled")

        elif desktop == "xfce":
            _run(["xfconf-query", "-c", "xfwm4", "-p",
                  "/general/use_compositing", "-s", "false"])
            results.append("✓ XFCE: compositing disabled")

        elif desktop == "sway":
            # Sway: no built-in animations, but can set max_render_time
            results.append("ℹ Sway: no compositor animations to disable")

        elif desktop == "hyprland":
            # Hyprland: animations can be disabled via hyprctl
            _run(["hyprctl", "keyword", "animations:enabled", "false"])
            results.append("✓ Hyprland: animations disabled")

        elif desktop == "i3":
            results.append("ℹ i3: no compositor animations (tiling WM)")

        else:
            return False, f"✗ Unsupported desktop: {desktop}"

        return bool(results), "\n".join(results) if results else "✗ No changes made"

    @classmethod
    def enable_animations(cls) -> Tuple[bool, str]:
        """Re-enable animations."""
        desktop = cls._detect_desktop()

        if desktop == "kde":
            _run(["kwriteconfig5", "--file", "kdeglobals",
                  "--group", "KDE", "--key", "AnimationDurationFactor",
                  "1"])
            _run(["qdbus", "org.kde.KWin", "/KWin", "reconfigure"])
            return True, "✓ KDE: animations re-enabled"

        if desktop == "gnome":
            _run(["gsettings", "set", "org.gnome.desktop.interface",
                  "enable-animations", "true"])
            return True, "✓ GNOME: animations re-enabled"

        if desktop == "xfce":
            _run(["xfconf-query", "-c", "xfwm4", "-p",
                  "/general/use_compositing", "-s", "true"])
            return True, "✓ XFCE: compositing re-enabled"

        if desktop == "hyprland":
            _run(["hyprctl", "keyword", "animations:enabled", "true"])
            return True, "✓ Hyprland: animations re-enabled"

        return False, f"✗ Unsupported desktop: {desktop}"


# ───────────────────────────────────────────────────────────────────────────
# Polkit Policy — universal passwordless policy for hardware governors
# ───────────────────────────────────────────────────────────────────────────

_POLKIT_POLICY_XML = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE policyconfig PUBLIC
 "-//freedesktop//DTD PolicyKit Policy Configuration 1.0//EN"
 "http://www.freedesktop.org/standards/PolicyKit/1.0/policyconfig.dtd">
<policyconfig>
  <vendor>Sysfix Pro</vendor>
  <vendor_url>https://sysfix.app</vendor_url>
  <icon_name>sysfix</icon_name>

  <action id="app.sysfix.hardware-governor">
    <description>Sysfix Pro — Hardware Performance Override</description>
    <message>Sysfix needs privileges to tune CPU/GPU performance settings.</message>
    <defaults>
      <allow_any>auth_admin_keep</allow_any>
      <allow_inactive>auth_admin_keep</allow_inactive>
      <allow_active>yes</allow_active>
    </defaults>
  </action>
</policyconfig>
"""

_POLKIT_POLICY_PATH = "/usr/share/polkit-1/actions/app.sysfix.hardware-governor.policy"


def install_polkit_policy() -> Tuple[bool, str]:
    """Install the Sysfix Polkit policy for passwordless hardware writes."""
    if Path(_POLKIT_POLICY_PATH).exists():
        return True, "Policy already installed"

    # Write via pkexec tee
    try:
        r = subprocess.run(
            ["pkexec", "tee", _POLKIT_POLICY_PATH],
            input=_POLKIT_POLICY_XML,
            capture_output=True, text=True, timeout=15,
            stdin=subprocess.PIPE,
        )
        if r.returncode == 0:
            return True, "✓ Polkit policy installed"
        return False, f"✗ Policy install failed: {r.stderr.strip()}"
    except Exception as exc:
        return False, f"✗ Policy install error: {exc}"


# ───────────────────────────────────────────────────────────────────────────
# HardwareGovernor — unified façade
# ───────────────────────────────────────────────────────────────────────────

class HardwareGovernor:
    """Unified interface for all hardware performance overrides."""

    @classmethod
    def status(cls) -> Dict[str, Any]:
        """Get a full snapshot of hardware performance state."""
        return {
            "cpu": {
                "governor": (s := CPUGovernor.detect()).governor,
                "driver": s.driver,
                "turbo": s.turbo_enabled,
                "freq_mhz": s.cur_freq_khz // 1000 if s.cur_freq_khz else 0,
                "max_freq_mhz": s.max_freq_khz // 1000 if s.max_freq_khz else 0,
                "available_governors": s.available_governors,
                "energy_profile": s.energy_profile,
                "tlp_mode": s.tlp_mode,
                "cores": s.cpu_count,
            },
            "gpu": {
                "vendor": (g := GPUGovernor.detect()).vendor,
                "model": g.model,
                "driver": g.driver,
                "temperature": g.temperature,
                "utilization": g.utilization,
                "vram_total_mb": g.vram_total_mb,
                "vram_used_mb": g.vram_used_mb,
                "power_w": g.power_draw_w,
                "clock_mhz": g.current_clocks_mhz,
                "max_clock_mhz": g.max_clocks_mhz,
            },
            "compositor": {
                "desktop": (c := CompositorTuner.detect()).desktop,
                "compositor": c.compositor,
                "animations": c.animations_enabled,
                "compositing": c.compositing_enabled,
            },
        }

    @classmethod
    def overdrive(cls) -> Tuple[bool, str]:
        """Engage all performance overrides simultaneously.

        Sets CPU to performance, GPU to max clocks, disables
        compositor animations, and enables turbo boost.
        """
        all_results: List[str] = []
        all_ok = True

        # CPU
        ok, msg = CPUGovernor.set_performance()
        all_results.append(f"**CPU:** {msg}")
        all_ok = all_ok and ok

        # Turbo
        ok, msg = CPUGovernor.enable_turbo()
        all_results.append(f"**Turbo:** {msg}")

        # GPU
        ok, msg = GPUGovernor.set_performance()
        all_results.append(f"**GPU:** {msg}")
        all_ok = all_ok and ok

        # Compositor
        ok, msg = CompositorTuner.disable_animations()
        all_results.append(f"**Compositor:** {msg}")

        return all_ok, "\n".join(all_results)

    @classmethod
    def revert(cls) -> Tuple[bool, str]:
        """Revert all overrides to defaults."""
        results: List[str] = []

        _ok, msg = CPUGovernor.set_powersave()
        results.append(f"**CPU:** {msg}")

        _ok, msg = CompositorTuner.enable_animations()
        results.append(f"**Compositor:** {msg}")

        results.append("**GPU:** Reboot to fully reset GPU clocks")

        return True, "\n".join(results)
