"""
Pillar 1 — Universal-Brain: Distro-Agnostic Intelligence Engine.

Provides:
  - DistroDetector     — OS / init system / package manager detection
  - ResearchAgent      — DuckDuckGo fallback for community fixes
  - SysfixBrain        — Local GGUF LLM via llama-cpp-python with
                          system-aware prompting and research loop

Zero-Cloud: all inference runs locally.  No data leaves the machine.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("sysfix.brain")

# Optional heavy imports ─ graceful degradation
HAS_LLAMA_CPP: bool = False
try:
    from llama_cpp import Llama          # type: ignore[import-untyped]
    HAS_LLAMA_CPP = True
except ImportError:
    pass

HAS_DDGS: bool = False
try:
    from duckduckgo_search import DDGS   # type: ignore[import-untyped]
    HAS_DDGS = True
except ImportError:
    pass


# ───────────────────────────────────────────────────────────────────────────
# DistroDetector — identify OS, init system, package manager, shell
# ───────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class DistroInfo:
    """Immutable snapshot of the detected Linux environment."""
    name: str = "Unknown"
    pretty_name: str = "Unknown Linux"
    distro_id: str = "unknown"
    id_like: str = ""
    version_id: str = ""
    version_codename: str = ""
    init_system: str = "unknown"        # systemd | openrc | runit | sysvinit
    package_manager: str = "unknown"    # apt | dnf | pacman | zypper | xbps | apk
    shell: str = "bash"                 # bash | zsh | fish
    desktop: str = "unknown"            # kde | gnome | xfce | sway | hyprland | i3 | ...
    kernel: str = ""


class DistroDetector:
    """One-shot Linux environment fingerprint."""

    _cache: Optional[DistroInfo] = None

    @classmethod
    def detect(cls, *, force: bool = False) -> DistroInfo:
        if cls._cache is not None and not force:
            return cls._cache

        os_data = cls._read_os_release()
        cls._cache = DistroInfo(
            name=os_data.get("NAME", "Unknown"),
            pretty_name=os_data.get("PRETTY_NAME", "Unknown Linux"),
            distro_id=os_data.get("ID", "unknown"),
            id_like=os_data.get("ID_LIKE", ""),
            version_id=os_data.get("VERSION_ID", ""),
            version_codename=os_data.get("VERSION_CODENAME", ""),
            init_system=cls._detect_init(),
            package_manager=cls._detect_pkg_mgr(os_data.get("ID", ""),
                                                os_data.get("ID_LIKE", "")),
            shell=cls._detect_shell(),
            desktop=cls._detect_desktop(),
            kernel=platform.release(),
        )
        return cls._cache

    # ── internal helpers ──────────────────────────────────────────────

    @staticmethod
    def _read_os_release() -> Dict[str, str]:
        for path in ("/etc/os-release", "/usr/lib/os-release"):
            try:
                data: Dict[str, str] = {}
                with open(path) as fh:
                    for line in fh:
                        line = line.strip()
                        if "=" in line:
                            k, v = line.split("=", 1)
                            data[k] = v.strip('"')
                return data
            except FileNotFoundError:
                continue
        return {}

    @staticmethod
    def _detect_init() -> str:
        """Detect the init system."""
        # systemd: PID 1 is /usr/lib/systemd/systemd (or /sbin/init → systemd)
        try:
            p1 = Path("/proc/1/comm").read_text().strip()
            if p1 == "systemd":
                return "systemd"
        except OSError:
            pass
        if shutil.which("systemctl"):
            return "systemd"
        if shutil.which("rc-service") or shutil.which("openrc"):
            return "openrc"
        if shutil.which("runit") or Path("/run/runit").exists():
            return "runit"
        if Path("/etc/init.d").is_dir() and not shutil.which("systemctl"):
            return "sysvinit"
        return "unknown"

    @staticmethod
    def _detect_pkg_mgr(distro_id: str, id_like: str) -> str:
        """Detect the primary package manager."""
        family = f"{distro_id} {id_like}".lower()

        # Map distro families to package managers
        _MAP: List[Tuple[List[str], str, str]] = [
            # (family keywords, binary, label)
            (["arch", "manjaro", "endeavouros", "garuda", "cachyos"], "pacman", "pacman"),
            (["debian", "ubuntu", "mint", "pop", "elementary", "zorin", "kali"], "apt", "apt"),
            (["fedora", "rhel", "centos", "rocky", "alma", "nobara"], "dnf", "dnf"),
            (["opensuse", "suse", "sles"], "zypper", "zypper"),
            (["void"], "xbps-install", "xbps"),
            (["alpine"], "apk", "apk"),
            (["gentoo", "funtoo"], "emerge", "portage"),
            (["nixos", "nix"], "nix-env", "nix"),
        ]
        for keywords, binary, label in _MAP:
            if any(kw in family for kw in keywords):
                if shutil.which(binary):
                    return label

        # Fallback: just check which binaries exist
        for binary, label in [("pacman", "pacman"), ("apt", "apt"),
                              ("dnf", "dnf"), ("zypper", "zypper"),
                              ("xbps-install", "xbps"), ("apk", "apk"),
                              ("emerge", "portage"), ("nix-env", "nix")]:
            if shutil.which(binary):
                return label
        return "unknown"

    @staticmethod
    def _detect_shell() -> str:
        """Detect the user's login shell."""
        shell = os.environ.get("SHELL", "/bin/bash")
        base = os.path.basename(shell)
        if base in ("bash", "zsh", "fish"):
            return base
        return "bash"

    @staticmethod
    def _detect_desktop() -> str:
        """Detect the desktop environment / window manager."""
        de = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
        session = os.environ.get("XDG_SESSION_DESKTOP", "").lower()
        wm = os.environ.get("DESKTOP_SESSION", "").lower()

        for hint in (de, session, wm):
            if not hint:
                continue
            if "kde" in hint or "plasma" in hint:
                return "kde"
            if "gnome" in hint:
                return "gnome"
            if "xfce" in hint:
                return "xfce"
            if "sway" in hint:
                return "sway"
            if "hyprland" in hint:
                return "hyprland"
            if "i3" in hint:
                return "i3"
            if "cinnamon" in hint:
                return "cinnamon"
            if "mate" in hint:
                return "mate"
            if "lxqt" in hint:
                return "lxqt"
            if "lxde" in hint:
                return "lxde"
            if "budgie" in hint:
                return "budgie"
            if "cosmic" in hint:
                return "cosmic"

        return de or session or wm or "unknown"


# ───────────────────────────────────────────────────────────────────────────
# Hardware Telemetry Snapshot — reads /proc/ and /sys/ directly
# ───────────────────────────────────────────────────────────────────────────

def _read_file_safe(path: str, default: str = "") -> str:
    try:
        return Path(path).read_text().strip()
    except OSError:
        return default


def _run_cmd(cmd: List[str], timeout: int = 5) -> str:
    if not shutil.which(cmd[0]):
        return ""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def hardware_telemetry() -> Dict[str, Any]:
    """Gather real-time hardware telemetry from /proc/ and /sys/."""
    t: Dict[str, Any] = {}

    # CPU
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    t["cpu_model"] = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    t["cpu_cores"] = os.cpu_count() or 0

    # Load average
    t["load_avg"] = _read_file_safe("/proc/loadavg")

    # Memory
    try:
        with open("/proc/meminfo") as f:
            mem = {}
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip().split()[0]
                    mem[key] = int(val)
            t["mem_total_kb"] = mem.get("MemTotal", 0)
            t["mem_available_kb"] = mem.get("MemAvailable", 0)
            t["swap_total_kb"] = mem.get("SwapTotal", 0)
            t["swap_free_kb"] = mem.get("SwapFree", 0)
            t["zram_total_kb"] = mem.get("Zram", 0) if "Zram" in mem else 0
    except OSError:
        pass

    # Uptime
    raw_uptime = _read_file_safe("/proc/uptime")
    if raw_uptime:
        secs = float(raw_uptime.split()[0])
        h, rem = divmod(int(secs), 3600)
        m, s = divmod(rem, 60)
        t["uptime"] = f"{h}h {m}m {s}s"

    # Temperatures — /sys/class/thermal
    temps: Dict[str, str] = {}
    thermal_base = Path("/sys/class/thermal")
    if thermal_base.is_dir():
        for tz in sorted(thermal_base.iterdir()):
            temp_file = tz / "temp"
            type_file = tz / "type"
            if temp_file.exists():
                raw = _read_file_safe(str(temp_file))
                label = _read_file_safe(str(type_file), tz.name)
                if raw:
                    try:
                        temps[label] = f"{int(raw) / 1000:.1f}°C"
                    except ValueError:
                        pass
    if temps:
        t["temperatures"] = temps

    # GPU — quick detection
    lspci = _run_cmd(["lspci"])
    if lspci:
        gpu_lines = [l for l in lspci.splitlines()
                     if any(k in l.lower() for k in ("vga", "3d controller", "display"))]
        if gpu_lines:
            t["gpus"] = [l.split(": ", 1)[1].strip() if ": " in l else l
                         for l in gpu_lines]

    # Battery
    bat_path = Path("/sys/class/power_supply/BAT0/capacity")
    if bat_path.exists():
        t["battery_pct"] = _read_file_safe(str(bat_path))
        t["battery_status"] = _read_file_safe("/sys/class/power_supply/BAT0/status")

    # Kernel
    t["kernel"] = platform.release()

    return t


def system_log_tail(n: int = 5) -> str:
    """Grab the last *n* entries from the system log.

    Tries journalctl first (systemd), then /var/log/syslog, then dmesg.
    """
    # journalctl (most distros)
    out = _run_cmd(["journalctl", "-n", str(n), "--no-pager", "-q",
                    "-p", "err..emerg", "--output=short-monotonic"])
    if out:
        return out

    # Syslog (Debian without persistent journal)
    try:
        lines = Path("/var/log/syslog").read_text().strip().splitlines()
        return "\n".join(lines[-n:])
    except OSError:
        pass

    # dmesg fallback
    dm = _run_cmd(["dmesg", "--level=err,warn", "-T"])
    if dm:
        return "\n".join(dm.strip().splitlines()[-n:])

    return "(no log entries available)"


# ───────────────────────────────────────────────────────────────────────────
# ResearchAgent — DuckDuckGo search for community fixes
# ───────────────────────────────────────────────────────────────────────────

class ResearchAgent:
    """Search Linux community forums for distro-specific fixes.

    Uses duckduckgo_search when available, falls back to the existing
    web_search() in sysfixai.ai.
    """

    # Trusted community sources to prefer
    _TRUSTED_SOURCES = [
        "wiki.archlinux.org",
        "askubuntu.com",
        "discussion.fedoraproject.org",
        "forums.opensuse.org",
        "wiki.gentoo.org",
        "bbs.archlinux.org",
        "unix.stackexchange.com",
        "superuser.com",
        "wiki.debian.org",
    ]

    @classmethod
    def search(cls, query: str, distro: Optional[DistroInfo] = None,
               max_results: int = 6) -> List[Dict[str, str]]:
        """Return a list of {title, body, href} dicts."""
        # Enhance query with distro context
        if distro and distro.distro_id != "unknown":
            query = f"{distro.pretty_name} {query}"

        results: List[Dict[str, str]] = []

        # Try duckduckgo_search library first
        if HAS_DDGS:
            try:
                with DDGS() as ddgs:  # type: ignore[possibly-unbound]
                    for r in ddgs.text(query, max_results=max_results):
                        results.append({
                            "title": r.get("title", ""),
                            "body": r.get("body", ""),
                            "href": r.get("href", ""),
                        })
                if results:
                    return cls._rank(results)
            except Exception as exc:
                log.debug("DDGS search failed: %s", exc)

        # Fallback to existing web_search
        try:
            from sysfixai.ai import web_search
            raw = web_search(query, max_results=max_results)
            if raw:
                for block in raw.split("---"):
                    block = block.strip()
                    if not block:
                        continue
                    lines = block.splitlines()
                    title = ""
                    body = ""
                    href = ""
                    for line in lines:
                        line = line.strip()
                        if line.startswith("**") and line.endswith("**"):
                            title = line.strip("* ")
                        elif line.startswith("_Source:"):
                            href = line.replace("_Source:", "").strip().rstrip("_")
                        elif line:
                            body = line
                    if body:
                        results.append({"title": title, "body": body, "href": href})
        except Exception as exc:
            log.debug("Fallback web_search failed: %s", exc)

        return cls._rank(results)

    @classmethod
    def _rank(cls, results: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Reorder so trusted community sources come first."""
        def score(r: Dict[str, str]) -> int:
            href = r.get("href", "").lower()
            for i, src in enumerate(cls._TRUSTED_SOURCES):
                if src in href:
                    return -100 + i  # Trusted sources first
            return 0
        return sorted(results, key=score)

    @classmethod
    def format_context(cls, results: List[Dict[str, str]],
                       max_chars: int = 3000) -> str:
        """Format search results into a compact context block for the LLM."""
        lines: List[str] = []
        chars = 0
        for r in results:
            entry = f"[{r.get('title', 'Result')}]: {r.get('body', '')}"
            if r.get("href"):
                entry += f" (source: {r['href']})"
            if chars + len(entry) > max_chars:
                break
            lines.append(entry)
            chars += len(entry)
        return "\n".join(lines)


# ───────────────────────────────────────────────────────────────────────────
# SysfixBrain — Local GGUF LLM via llama-cpp-python
# ───────────────────────────────────────────────────────────────────────────

# Default GGUF discovery paths (user / system)
_GGUF_SEARCH_DIRS = [
    Path.home() / ".local" / "share" / "sysfix" / "models",
    Path.home() / ".cache" / "sysfix" / "models",
    Path("/usr/share/sysfix/models"),
    Path("/opt/sysfix/models"),
]


def _find_gguf(model_hint: str = "") -> Optional[Path]:
    """Locate a .gguf model file on disk.

    If *model_hint* is an absolute path, use it directly.
    Otherwise search the standard directories for any .gguf file,
    preferring files whose name contains *model_hint*.
    """
    if model_hint and os.path.isfile(model_hint):
        return Path(model_hint)

    hint_lower = model_hint.lower() if model_hint else ""
    candidates: List[Path] = []

    for d in _GGUF_SEARCH_DIRS:
        if not d.is_dir():
            continue
        for f in d.glob("*.gguf"):
            if hint_lower and hint_lower in f.name.lower():
                return f  # exact hint match — use immediately
            candidates.append(f)

    # Return the first candidate (alphabetical)
    return sorted(candidates)[0] if candidates else None


class SysfixBrain:
    """Local-first LLM engine running a GGUF model via llama-cpp-python.

    The brain maintains distro-awareness, hardware context, and a
    research fallback loop.  All inference is on-device.

    Usage::

        brain = SysfixBrain()          # auto-detects model
        brain = SysfixBrain("/path/to/model.gguf")
        answer = brain.ask("Why is my system using 100% CPU?")
    """

    def __init__(
        self,
        model_path: str = "",
        *,
        n_ctx: int = 4096,
        n_gpu_layers: int = -1,     # offload everything if GPU available
        n_threads: int = 0,         # 0 = auto
        verbose: bool = False,
    ) -> None:
        self._distro = DistroDetector.detect()
        self._model: Optional[Any] = None  # Llama instance
        self._model_path: Optional[Path] = None

        if not HAS_LLAMA_CPP:
            log.warning("llama-cpp-python not installed — SysfixBrain will "
                        "use research-only mode.")
            return

        gguf = _find_gguf(model_path)
        if gguf is None:
            log.warning("No GGUF model found — SysfixBrain will use "
                        "research-only mode.  Place a .gguf file in "
                        "~/.local/share/sysfix/models/")
            return

        self._model_path = gguf
        try:
            self._model = Llama(  # type: ignore[possibly-unbound]
                model_path=str(gguf),
                n_ctx=n_ctx,
                n_gpu_layers=n_gpu_layers,
                n_threads=n_threads or (os.cpu_count() or 4),
                verbose=verbose,
            )
            log.info("SysfixBrain loaded model: %s", gguf.name)
        except Exception as exc:
            log.error("Failed to load GGUF model %s: %s", gguf, exc)
            self._model = None

    # ── properties ────────────────────────────────────────────────────

    @property
    def ready(self) -> bool:
        return self._model is not None

    @property
    def distro(self) -> DistroInfo:
        return self._distro

    @property
    def model_name(self) -> str:
        return self._model_path.name if self._model_path else "(none)"

    # ── system prompt ─────────────────────────────────────────────────

    def _build_system_prompt(self) -> str:
        d = self._distro
        telem = hardware_telemetry()
        logs = system_log_tail(5)

        prompt = (
            "You are **Fyxa**, a Legendary Multi-Distro Architect — a Master "
            "Systems Engineer with encyclopedic knowledge of every Linux "
            "distribution.  You provide precise, copy-pasteable terminal "
            f"commands tailored to the user's **{d.shell}** shell.\n\n"
            "## Detected Environment\n"
            f"- **OS:** {d.pretty_name} ({d.distro_id})\n"
            f"- **Kernel:** {d.kernel}\n"
            f"- **Init System:** {d.init_system}\n"
            f"- **Package Manager:** {d.package_manager}\n"
            f"- **Desktop:** {d.desktop}\n"
            f"- **Shell:** {d.shell}\n\n"
            "## Live Hardware Telemetry\n"
        )

        for key, val in telem.items():
            if isinstance(val, dict):
                prompt += f"- **{key}:** {json.dumps(val)}\n"
            elif isinstance(val, list):
                prompt += f"- **{key}:** {', '.join(str(v) for v in val)}\n"
            else:
                prompt += f"- **{key}:** {val}\n"

        prompt += (
            "\n## Recent System Errors\n"
            f"```\n{logs}\n```\n\n"
            "## Rules\n"
            "1. Always tailor commands to the detected distro and package manager.\n"
            f"2. Use `{d.package_manager}` for package operations.\n"
            f"3. For service management, use `{'systemctl' if d.init_system == 'systemd' else 'rc-service' if d.init_system == 'openrc' else 'sv' if d.init_system == 'runit' else 'service'}`.\n"
            "4. Provide exact commands — no placeholders unless variable.\n"
            "5. If uncertain, say so and suggest the user verify.\n"
            "6. For destructive operations, always warn and suggest a backup.\n"
            "7. Never suggest commands that require cloud or external AI services.\n"
        )

        return prompt

    # ── inference ─────────────────────────────────────────────────────

    def ask(
        self,
        query: str,
        *,
        history: Optional[List[Dict[str, str]]] = None,
        max_tokens: int = 1024,
        temperature: float = 0.3,
        research_fallback: bool = True,
    ) -> str:
        """Send a query to the local LLM.

        If the model is not loaded, falls back to research-only mode.
        If the model's answer indicates uncertainty, triggers a
        ResearchAgent lookup and retries with enriched context.
        """
        messages: List[Dict[str, str]] = [
            {"role": "system", "content": self._build_system_prompt()},
        ]
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": query})

        # No model — research-only mode
        if not self._model:
            return self._research_only(query)

        response = self._infer(messages, max_tokens=max_tokens,
                               temperature=temperature)

        # Check if the model expressed uncertainty
        if research_fallback and self._needs_research(response):
            research_ctx = self._do_research(query)
            if research_ctx:
                enriched_query = (
                    f"{query}\n\n"
                    f"[Community research results for reference:]\n{research_ctx}"
                )
                messages[-1] = {"role": "user", "content": enriched_query}
                response = self._infer(messages, max_tokens=max_tokens,
                                       temperature=temperature)

        return response

    def _infer(self, messages: List[Dict[str, str]], *,
               max_tokens: int = 1024, temperature: float = 0.3) -> str:
        """Run a chat completion on the local model."""
        try:
            result = self._model.create_chat_completion(  # type: ignore[union-attr]
                messages=messages,
                max_tokens=max_tokens,
                temperature=temperature,
                stop=["<|end|>", "<|eot_id|>", "</s>"],
            )
            choices = result.get("choices", [])
            if choices:
                return choices[0].get("message", {}).get("content", "").strip()
            return "(no response from model)"
        except Exception as exc:
            log.error("Inference error: %s", exc)
            return f"(inference error: {exc})"

    @staticmethod
    def _needs_research(response: str) -> bool:
        """Heuristic: does the model's response indicate uncertainty?"""
        indicators = [
            "i'm not sure",
            "i don't know",
            "i cannot determine",
            "not certain",
            "i'd recommend checking",
            "please verify",
            "i don't have enough information",
            "beyond my knowledge",
            "unable to determine",
        ]
        rl = response.lower()
        return any(ind in rl for ind in indicators)

    def _do_research(self, query: str) -> str:
        """Run a ResearchAgent search and return formatted context."""
        results = ResearchAgent.search(query, distro=self._distro)
        if not results:
            return ""
        return ResearchAgent.format_context(results)

    def _research_only(self, query: str) -> str:
        """No local model — provide answer from web research alone."""
        results = ResearchAgent.search(query, distro=self._distro)
        if not results:
            return (
                "No local LLM is available and web research returned no results.\n\n"
                "**To enable the full AI engine:**\n"
                "1. Download a GGUF model (e.g. Qwen2.5-7B-Instruct)\n"
                "2. Place it in `~/.local/share/sysfix/models/`\n"
                "3. Restart Sysfix"
            )

        lines = [f"### Research Results for: {query}\n"]
        for r in results[:6]:
            title = r.get("title", "Result")
            body = r.get("body", "")
            href = r.get("href", "")
            lines.append(f"**{title}**")
            if body:
                lines.append(f"  {body}")
            if href:
                lines.append(f"  _Source: {href}_")
            lines.append("")
        lines.append("_Note: Install a local GGUF model for full AI reasoning._")
        return "\n".join(lines)

    # ── distro-aware command helpers ──────────────────────────────────

    def install_command(self, package: str) -> str:
        """Return the install command for the detected package manager."""
        pm = self._distro.package_manager
        _INSTALL_CMDS = {
            "apt": f"sudo apt install -y {package}",
            "dnf": f"sudo dnf install -y {package}",
            "pacman": f"sudo pacman -S --noconfirm {package}",
            "zypper": f"sudo zypper install -y {package}",
            "xbps": f"sudo xbps-install -y {package}",
            "apk": f"sudo apk add {package}",
            "portage": f"sudo emerge {package}",
            "nix": f"nix-env -iA nixpkgs.{package}",
        }
        return _INSTALL_CMDS.get(pm, f"# Install {package} using your package manager")

    def update_command(self) -> str:
        """Return the full system update command."""
        pm = self._distro.package_manager
        _UPDATE_CMDS = {
            "apt": "sudo apt update && sudo apt full-upgrade -y",
            "dnf": "sudo dnf upgrade --refresh -y",
            "pacman": "sudo pacman -Syu --noconfirm",
            "zypper": "sudo zypper ref && sudo zypper dup -y",
            "xbps": "sudo xbps-install -Su",
            "apk": "sudo apk update && sudo apk upgrade",
            "portage": "sudo emerge --sync && sudo emerge -uDN @world",
            "nix": "sudo nixos-rebuild switch --upgrade",
        }
        return _UPDATE_CMDS.get(pm, "# Update your system using your package manager")

    def service_command(self, action: str, service: str) -> str:
        """Return a service management command (start/stop/restart/status)."""
        init = self._distro.init_system
        if init == "systemd":
            return f"sudo systemctl {action} {service}"
        if init == "openrc":
            return f"sudo rc-service {service} {action}"
        if init == "runit":
            act_map = {"start": "up", "stop": "down", "restart": "restart",
                       "status": "status"}
            return f"sudo sv {act_map.get(action, action)} {service}"
        return f"sudo service {service} {action}"


# ───────────────────────────────────────────────────────────────────────────
# Module-level convenience
# ───────────────────────────────────────────────────────────────────────────

_brain_instance: Optional[SysfixBrain] = None


def get_brain() -> SysfixBrain:
    """Get or create the global SysfixBrain singleton."""
    global _brain_instance
    if _brain_instance is None:
        _brain_instance = SysfixBrain()
    return _brain_instance


def get_distro() -> DistroInfo:
    """Convenience: detect distro without initializing the full brain."""
    return DistroDetector.detect()
