


"""
Pillar 4 — Production & Licensing Backend: Hardware-Locked License Guard.

Provides:
  - HardwareID          — machine fingerprint from /etc/machine-id + CPU serial
  - LicenseGuard        — validates hardware-locked keys, gates Pro features
  - PolarWebhookHandler — HTTP handler for order.paid webhook events

Integrates with the existing polar.py for checkout/activation.
The UI theme adaptation uses the system's GTK/Qt theme detection.
"""

from __future__ import annotations

import hashlib
import json
import hmac
import logging
import os
import platform
import secrets
import subprocess
import shutil
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from threading import Thread
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("sysfix.license_guard")


# ───────────────────────────────────────────────────────────────────────────
# Config paths (mirrors polar.py, avoids circular imports)
# ───────────────────────────────────────────────────────────────────────────

_CONFIG_DIR = Path.home() / ".config" / "sysfix"
_LICENCE_FILE = _CONFIG_DIR / "licence.json"
_AUDIT_LOG = _CONFIG_DIR / "license_audit.log"


def _audit(action: str, **fields: Any) -> None:
    try:
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        entry = {"ts": ts, "action": action, **fields}
        with open(_AUDIT_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


# ───────────────────────────────────────────────────────────────────────────
# Hardware ID — enhanced fingerprint with CPU serial
# ───────────────────────────────────────────────────────────────────────────

class HardwareID:
    """Generate a hardware-locked machine fingerprint.

    Combines /etc/machine-id (or fallback DMI UUID) with the CPU serial
    number to produce a deterministic, privacy-respecting SHA-256 digest.
    """

    _cache: Optional[str] = None

    @classmethod
    def fingerprint(cls, *, force: bool = False) -> str:
        """Return the cached hardware fingerprint (compute once)."""
        if cls._cache is not None and not force:
            return cls._cache
        cls._cache = cls._compute()
        return cls._cache

    @classmethod
    def _compute(cls) -> str:
        parts: List[str] = []

        # Machine ID (systemd — present on Fedora, Ubuntu, Arch, etc.)
        machine_id = Path("/etc/machine-id")
        if machine_id.exists():
            try:
                parts.append(machine_id.read_text().strip())
            except OSError:
                pass

        # Fallback: DMI product UUID
        if not parts:
            try:
                dmi = Path("/sys/class/dmi/id/product_uuid")
                if dmi.exists():
                    parts.append(dmi.read_text().strip())
            except OSError:
                pass

        # CPU serial / model (unique per chip family)
        cpu_serial = cls._get_cpu_serial()
        if cpu_serial:
            parts.append(cpu_serial)

        # Board serial as additional entropy
        board_serial = cls._read_safe("/sys/class/dmi/id/board_serial")
        if board_serial and board_serial != "Default string":
            parts.append(board_serial)

        # Architecture + OS (prevents cross-platform key reuse)
        parts.append(platform.machine())
        parts.append(platform.system())

        if not parts:
            # Last resort — hostname (least stable)
            parts.append(platform.node())

        raw = "|".join(parts)
        return hashlib.sha256(raw.encode()).hexdigest()

    @classmethod
    def _get_cpu_serial(cls) -> str:
        """Extract CPU serial or model identifier from /proc/cpuinfo."""
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    # ARM/embedded: "Serial : ..."
                    if line.startswith("Serial"):
                        return line.split(":", 1)[1].strip()
                    # x86: use model name as a component (not unique per chip,
                    # but combined with machine-id is sufficient)
                    if line.startswith("model name"):
                        return line.split(":", 1)[1].strip()
        except OSError:
            pass
        return ""

    @staticmethod
    def _read_safe(path: str) -> str:
        try:
            return Path(path).read_text().strip()
        except OSError:
            return ""

    @classmethod
    def summary(cls) -> Dict[str, str]:
        """Return a human-readable summary of the hardware binding."""
        return {
            "fingerprint": cls.fingerprint()[:16] + "...",
            "machine": platform.node(),
            "arch": platform.machine(),
            "kernel": platform.release(),
        }


# ───────────────────────────────────────────────────────────────────────────
# License Key Generation & Validation
# ───────────────────────────────────────────────────────────────────────────

def _generate_key() -> str:
    """Generate a SYSFIX-XXXXX-XXXXX-XXXXX-XXXXX format license key."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    groups = ["SYSFIX"]
    for _ in range(4):
        groups.append("".join(secrets.choice(alphabet) for _ in range(5)))
    return "-".join(groups)


def _sign_key(key: str, hw_fingerprint: str) -> str:
    """Create an HMAC-SHA256 signature binding a key to hardware."""
    msg = f"{key}:{hw_fingerprint}".encode()
    # Use a fixed application secret (not user-facing)
    app_secret = b"sysfix-pro-hw-lock-v1"
    return hmac.new(app_secret, msg, hashlib.sha256).hexdigest()[:32]


def _verify_key_signature(key: str, hw_fingerprint: str, signature: str) -> bool:
    """Verify that a key's HMAC signature matches the current hardware."""
    expected = _sign_key(key, hw_fingerprint)
    return hmac.compare_digest(expected, signature)


# ───────────────────────────────────────────────────────────────────────────
# LicenseGuard — feature gating for Pro tier
# ───────────────────────────────────────────────────────────────────────────

class LicenseGuard:
    """Validates hardware-locked license keys and gates Pro features.

    Usage::

        guard = LicenseGuard()
        if guard.is_pro:
            enable_performance_overdrive()
        else:
            show_upgrade_prompt()
    """

    _instance: Optional["LicenseGuard"] = None

    def __init__(self) -> None:
        self._valid: Optional[bool] = None
        self._licence: Optional[Dict[str, Any]] = None

    @classmethod
    def get(cls) -> "LicenseGuard":
        """Get or create the singleton LicenseGuard."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @property
    def is_pro(self) -> bool:
        """Check if the current machine has a valid Pro license."""
        if self._valid is None:
            self._valid = self._validate()
        return self._valid

    @property
    def licence_info(self) -> Optional[Dict[str, Any]]:
        """Return the license record or None."""
        if self._licence is None:
            self._load()
        return self._licence

    def invalidate_cache(self) -> None:
        """Force re-validation on next check."""
        self._valid = None
        self._licence = None

    def _load(self) -> None:
        if not _LICENCE_FILE.exists():
            self._licence = None
            return
        try:
            self._licence = json.loads(_LICENCE_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            self._licence = None

    def _validate(self) -> bool:
        """Validate the license against current hardware."""
        self._load()
        if self._licence is None:
            return False

        stored_fp = self._licence.get("hw_fingerprint", "")
        current_fp = HardwareID.fingerprint()

        if not stored_fp or stored_fp != current_fp:
            log.warning("License hardware mismatch: stored=%s... current=%s...",
                        stored_fp[:12], current_fp[:12])
            _audit("VALIDATION_FAILED", reason="hw_mismatch",
                   stored=stored_fp[:12], current=current_fp[:12])
            return False

        # Optional: verify HMAC signature if present
        sig = self._licence.get("hw_signature")
        key = self._licence.get("licence_key", "")
        if sig and key:
            if not _verify_key_signature(key, current_fp, sig):
                log.warning("License signature mismatch")
                _audit("VALIDATION_FAILED", reason="sig_mismatch")
                return False

        _audit("VALIDATION_OK", key=key[:10] + "..." if key else "")
        return True

    # ── Activation ────────────────────────────────────────────────────

    @classmethod
    def activate(cls, order_id: str, customer_email: str = "") -> Dict[str, Any]:
        """Activate a Pro license for this machine.

        Called after a successful Polar webhook or manual activation.
        Generates a hardware-locked key and persists it.
        """
        hw_fp = HardwareID.fingerprint()
        key = _generate_key()
        sig = _sign_key(key, hw_fp)

        record: Dict[str, Any] = {
            "licence_key": key,
            "hw_signature": sig,
            "order_id": order_id,
            "customer_email": customer_email,
            "hw_fingerprint": hw_fp,
            "activated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "machine_node": platform.node(),
            "tier": "pro",
        }

        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        _LICENCE_FILE.write_text(json.dumps(record, indent=2))

        _audit("ACTIVATED", order_id=order_id, key=key, email=customer_email)
        log.info("Pro license activated: %s", key)

        # Invalidate cached state
        guard = cls.get()
        guard.invalidate_cache()

        return record

    @classmethod
    def deactivate(cls) -> bool:
        """Revoke the local license (e.g. for machine transfer)."""
        try:
            if _LICENCE_FILE.exists():
                try:
                    rec = json.loads(_LICENCE_FILE.read_text())
                    _audit("DEACTIVATED", order_id=rec.get("order_id", ""),
                           key=rec.get("licence_key", ""))
                except Exception:
                    pass
                _LICENCE_FILE.unlink()

            guard = cls.get()
            guard.invalidate_cache()
            log.info("Pro license deactivated")
            return True
        except Exception as exc:
            log.error("Deactivation failed: %s", exc)
            return False

    # ── Feature gates ─────────────────────────────────────────────────

    def require_pro(self, feature: str = "") -> None:
        """Raise RuntimeError if not Pro. Use as a gate."""
        if not self.is_pro:
            msg = f"Sysfix Pro required"
            if feature:
                msg += f" for '{feature}'"
            msg += ". Upgrade at https://sysfix.app"
            raise RuntimeError(msg)


# ───────────────────────────────────────────────────────────────────────────
# Polar Webhook Handler — order.paid events
# ───────────────────────────────────────────────────────────────────────────

class PolarWebhookHandler(BaseHTTPRequestHandler):
    """HTTP handler for Polar order.paid webhook events.

    Verifies the Standard Webhooks HMAC-SHA256 signature, extracts
    the order details, and activates the Pro license.

    Attributes set on the server:
        server.webhook_secret: str — the Polar webhook signing secret
        server.on_activated: Optional[Callable] — callback after activation
    """

    def do_POST(self) -> None:
        if self.path != "/api/webhook/polar":
            self.send_response(404)
            self.end_headers()
            return

        content_length = int(self.headers.get("Content-Length", 0))
        if content_length > 65536:
            self.send_response(413)
            self.end_headers()
            return

        body = self.rfile.read(content_length)

        # Verify signature (Standard Webhooks / svix format)
        webhook_secret = getattr(self.server, "webhook_secret", "")
        if webhook_secret:
            sig_header = self.headers.get("webhook-signature", "")
            msg_id = self.headers.get("webhook-id", "")
            timestamp = self.headers.get("webhook-timestamp", "")

            if not self._verify_signature(body, sig_header, msg_id,
                                          timestamp, webhook_secret):
                _audit("WEBHOOK_REJECTED", reason="signature_invalid")
                self.send_response(401)
                self.end_headers()
                return

        # Parse payload
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            self.send_response(400)
            self.end_headers()
            return

        event_type = payload.get("type", "")
        if event_type != "order.paid":
            # Acknowledge but ignore non-order events
            _audit("WEBHOOK_IGNORED", event_type=event_type)
            self.send_response(200)
            self.end_headers()
            return

        # Extract order details
        data = payload.get("data", {})
        order_id = data.get("id", "")
        customer = data.get("customer", {})
        email = customer.get("email", "")

        if not order_id:
            self.send_response(400)
            self.end_headers()
            return

        # Activate
        record = LicenseGuard.activate(order_id, email)
        _audit("WEBHOOK_ACTIVATED", order_id=order_id, email=email)

        # Notify callback if set
        callback = getattr(self.server, "on_activated", None)
        if callback:
            try:
                callback(record)
            except Exception as exc:
                log.error("Activation callback error: %s", exc)

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"status": "activated"}).encode())

    @staticmethod
    def _verify_signature(body: bytes, sig_header: str, msg_id: str,
                          timestamp: str, secret: str) -> bool:
        """Verify Standard Webhooks HMAC-SHA256 signature."""
        if not sig_header or not msg_id or not timestamp:
            return False

        # Replay protection: reject timestamps older than 5 minutes
        try:
            ts = int(timestamp)
            if abs(time.time() - ts) > 300:
                return False
        except ValueError:
            return False

        # Decode the secret (base64 with "whsec_" prefix)
        import base64
        raw_secret = secret
        if raw_secret.startswith("whsec_"):
            raw_secret = raw_secret[6:]
        try:
            secret_bytes = base64.b64decode(raw_secret)
        except Exception:
            secret_bytes = raw_secret.encode()

        # Compute expected signature
        to_sign = f"{msg_id}.{timestamp}.".encode() + body
        expected = hmac.new(secret_bytes, to_sign, hashlib.sha256).digest()
        expected_b64 = "v1," + base64.b64encode(expected).decode()

        # The header may contain multiple signatures separated by space
        for sig in sig_header.split():
            if hmac.compare_digest(sig.strip(), expected_b64):
                return True
        return False

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default stderr logging."""
        log.debug(format, *args)


def start_webhook_server(
    *,
    port: int = 9452,
    webhook_secret: str = "",
    on_activated: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> HTTPServer:
    """Start the Polar webhook listener in a background thread.

    Returns the HTTPServer instance (call .shutdown() to stop).
    """
    server = HTTPServer(("127.0.0.1", port), PolarWebhookHandler)
    server.webhook_secret = webhook_secret  # type: ignore[attr-defined]
    server.on_activated = on_activated       # type: ignore[attr-defined]

    thread = Thread(target=server.serve_forever, daemon=True,
                    name="sysfix-polar-webhook")
    thread.start()
    log.info("Polar webhook listener started on port %d", port)
    return server


# ───────────────────────────────────────────────────────────────────────────
# UI Theme Detection — adapt to system aesthetics
# ───────────────────────────────────────────────────────────────────────────

@dataclass
class SystemTheme:
    """Detected system theme information."""
    desktop: str = "unknown"
    dark_mode: bool = False
    accent_color: str = ""
    gtk_theme: str = ""
    icon_theme: str = ""
    font_name: str = ""
    font_size: int = 10


def _run_cmd(cmd: List[str]) -> str:
    if not shutil.which(cmd[0]):
        return ""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=5, stdin=subprocess.DEVNULL)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def detect_system_theme() -> SystemTheme:
    """Detect the current system theme for UI adaptation."""
    theme = SystemTheme()
    de = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()

    if "kde" in de or "plasma" in de:
        theme.desktop = "kde"
        # Read from kdeglobals
        raw = _run_cmd(["kreadconfig5", "--file", "kdeglobals",
                        "--group", "General", "--key", "ColorScheme"])
        if raw:
            theme.dark_mode = any(k in raw.lower() for k in ("dark", "breeze-dark"))

    elif "gnome" in de:
        theme.desktop = "gnome"
        color_scheme = _run_cmd([
            "gsettings", "get", "org.gnome.desktop.interface", "color-scheme"
        ])
        theme.dark_mode = "dark" in color_scheme.lower() if color_scheme else False

        gtk = _run_cmd([
            "gsettings", "get", "org.gnome.desktop.interface", "gtk-theme"
        ])
        if gtk:
            theme.gtk_theme = gtk.strip("'\" ")
            if "dark" in theme.gtk_theme.lower():
                theme.dark_mode = True

    elif "xfce" in de:
        theme.desktop = "xfce"
        gtk = _run_cmd([
            "xfconf-query", "-c", "xsettings", "-p", "/Net/ThemeName"
        ])
        if gtk:
            theme.gtk_theme = gtk
            theme.dark_mode = "dark" in gtk.lower()

    else:
        theme.desktop = de or "unknown"

    # GTK theme fallback (works across most DEs)
    if not theme.gtk_theme:
        gtk3_settings = Path.home() / ".config" / "gtk-3.0" / "settings.ini"
        if gtk3_settings.exists():
            try:
                for line in gtk3_settings.read_text().splitlines():
                    if line.startswith("gtk-theme-name"):
                        theme.gtk_theme = line.split("=", 1)[1].strip()
                        if "dark" in theme.gtk_theme.lower():
                            theme.dark_mode = True
                    if line.startswith("gtk-icon-theme-name"):
                        theme.icon_theme = line.split("=", 1)[1].strip()
                    if line.startswith("gtk-font-name"):
                        font = line.split("=", 1)[1].strip()
                        theme.font_name = font
                        # Extract size
                        parts = font.rsplit(" ", 1)
                        if len(parts) == 2 and parts[1].isdigit():
                            theme.font_size = int(parts[1])
            except OSError:
                pass

    return theme
